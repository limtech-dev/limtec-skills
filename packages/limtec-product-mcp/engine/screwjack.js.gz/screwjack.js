/*

*/
(function (g) {
  'use strict';
  var C = g.SJCore;
  var fN = C.fN, iN = C.iN, r = C.pyRound, gv = C.gv, isTodo = C.isTodo, Missing = C.Missing;
  /*
*/
  var fKw = function (x) {
    var v0 = Number(x) || 0;
    return (v0 !== 0 && Math.abs(v0) < 0.01) ? fN(v0, 4) : fN(v0, 2);
  };

  /*




*/
  function comboCoefOf(units) {
    var n = Number(units) || 1;
    if (n <= 1) return 1;
    if (n === 2) return 0.95;
    if (n === 3) return 0.9;
    if (n <= 5) return 0.85;
    if (n <= 8) return 0.8;
    return 0.75;
  }
  function ampCoefOf(units) {
    var n = Number(units) || 1;
    if (n === 2) return 1.2;
    if (n === 3) return 1.3;
    if (n === 4) return 1.5;
    if (n === 5) return 1.5;
    return 1.6;
  }
  /*

*/
  function floorCoefOf(model) {
    return /^(SJB|SCB|EHB)/.test(String(model || '')) ? 0.15 : 0.2;
  }
  /*

*/
  function ampCoefOfEx(units, model, loadRate, temp) {
    var n = Number(units) || 1;
    /*


*/
    var a;
    if (Number(temp) >= 80) {
      a = (n <= 2) ? 1 : (n === 3) ? 1.25 : (n <= 7) ? 1.5 : 2;
    } else {
      a = ampCoefOf(units);
    }
    var lr = (loadRate === null || loadRate === undefined || !isFinite(Number(loadRate))) ? null : Number(loadRate);
    /**/
    if (Number(temp) < 80 && (Number(units) === 4) && lr !== null && lr < 0.10 + 1e-9) {
      if (/^(SJB|SCB|EHB)/.test(String(model || ''))) return 1.1;
      if (/^(SJA|SCA|KV)/.test(String(model || ''))) return 1;
    }
    return a;
  }

  /*




*/
  function envCoefOf(temp) {
    if (temp === null || temp === undefined || temp === '') return 1;
    var t = Number(temp);
    if (!isFinite(t)) return 1;
    if (t <= -40) return 2;
    if (t <= -30) return 1.5;
    if (t >= 80) return 2;
    return 1;
  }
  function envNoteOf(temp) {
    var t = Number(temp);
    if (!isFinite(t)) return '';
    if (t <= -40) return '低温 -40℃：丝杠与蜗轮副润滑脂凝固，传动效率约降低 50%';
    if (t <= -30) return '低温 -30℃：丝杠与蜗轮副润滑脂黏度上升，传动效率约降低 30%';
    if (t >= 80) return '高温 +80℃：高温润滑脂特别黏稠，传动阻力明显上升';
    return '';
  }
  function hasVacuumGrease(special) {
    return (Array.isArray(special) ? special : []).indexOf('vacuum_grease') >= 0;
  }
  /*





*/
  /*

*/
  /*


*/
  var GB_STD = [3, 4, 5, 7, 10, 12, 15, 16, 20, 25, 28, 30, 40, 50, 60, 64, 70, 75, 80, 100, 125, 140, 160, 175];
  function gbEffOf(i) { return i >= 12 ? 0.80 : 0.90; }
  /**/
  /*

*/
  /*




*/
  var GB_L2_SET = { 12: 1, 15: 1, 16: 1, 20: 1, 25: 1, 28: 1, 30: 1, 40: 1, 50: 1, 70: 1 };
  function gbStageOf(i) {
    if (i <= 10) return 'L1';
    return GB_L2_SET[i] ? 'L2' : 'L3';
  }
  /*



*/
  /*

*/
  var STD_FLANGE = [40, 60, 80, 100, 130, 150, 180, 200, 220, 240, 260, 280];
  function nearestFlange(x) {
    var best = STD_FLANGE[0], d = 1e9;
    STD_FLANGE.forEach(function (f) { if (Math.abs(f - x) < d) { d = Math.abs(f - x); best = f; } });
    return best;
  }
  function shaftOfFlange(flange, kw) {
    if (flange <= 40) return 8;
    if (flange <= 60) return kw <= 0.4 ? 11 : 14;
    if (flange <= 80) return kw <= 1.5 ? 19 : 22;
    if (flange <= 100) return 24;
    if (flange <= 130) return kw < 2 ? 24 : 28;
    if (flange <= 150) return 30;
    if (flange <= 180) return kw <= 5.5 ? 35 : 42;
    if (flange <= 200) return 42;
    if (flange <= 220) return 48;
    if (flange <= 240) return 55;
    if (flange <= 260) return 60;
    return 65;
  }
  function motorMountOf(m) {
    if (!m) return null;
    var fr = String(m.frame || '');
    var kw = Number(m.power_kW) || 0;
    /*

*/
    var nums = [];
    fr.replace(/\d+(\.\d+)?/g, function (sTxt) { nums.push(Number(sTxt)); return sTxt; });
    var isCenterH = /轴高/.test(fr);
    var isFlange = /法兰/.test(fr);
    var flanges = [];
    nums.forEach(function (v) {
      var f = 0;
      if (isCenterH) f = nearestFlange(v * 2);
      else if (isFlange) f = nearestFlange(v);
      else if (v >= 40) f = nearestFlange(v);
      else if (v > 0) f = nearestFlange(v * 2);
      if (f && flanges.indexOf(f) < 0) flanges.push(f);
    });
    flanges.sort(function (a, b) { return a - b; });
    var flange = flanges.length ? flanges[0] : 0;
    return { power: kw, flange: flange, flanges: flanges, multi: flanges.length > 1,
      shaft: flange ? shaftOfFlange(flange, kw) : 0, frame: fr };
  }
  /**/
  function motorShaftOf(m) {
    var mo = motorMountOf(m);
    return mo ? mo.shaft : 0;
  }
  function planetPickOf(data, ratio, motorTorque, motorRpm, motorShaft) {
    /**/
    var lib = (data && data.planetary_hv)
      || (typeof SJ_DATA !== 'undefined' && SJ_DATA && SJ_DATA.planetary_hv) || null;
    if (!lib || !ratio || ratio <= 1) return null;
    var stage = gbStageOf(ratio);
    var outT = (Number(motorTorque) || 0) * ratio;
    var inRpm = Number(motorRpm) || 0;
    var mShaft = Number(motorShaft) || 0;   /**/
    var fs = ['42', '60', '90', '120', '142', '180'];
    /**/
    var topOf = function (seg) {
      var lastK = null;
      for (var kk in seg) {
        if (!lastK || Number(kk) > Number(lastK)) lastK = kk;
      }
      return lastK ? { k: lastK, rec: seg[lastK] } : null;
    };
    var infos = [];   /**/
    for (var fi = 0; fi < fs.length; fi++) {
      var f = fs[fi], fr = lib.frames[f];
      if (!fr) continue;
      var stUse = stage;
      var rec = fr[stUse] ? fr[stUse][ratio] : null;
      var recAssumed = false, topK = null;
      if (!rec && stage === 'L2' && fr.L2) {
        /*


*/
        var tp = topOf(fr.L2);
        if (tp) { rec = tp.rec; topK = tp.k; recAssumed = true; }
      } else if (!rec && stage === 'L3' && ratio === 100 && fr.L2) {
        /*
*/
        var tp2 = topOf(fr.L2);
        if (tp2) { stUse = 'L2'; rec = tp2.rec; topK = tp2.k; recAssumed = true; }
      }
      if (!rec) continue;
      var p = fr.price && fr.price.direct ? fr.price.direct[stUse] : null;
      var info = { frame: f, stage: stUse, ratio: ratio, C: rec.C, D: rec.D, outT: outT,
        inRpm: inRpm, inOk: !inRpm || inRpm <= 3000 + 1e-9,
        shafts: lib.shafts[f] || [],
        price: (p === null || p === undefined) ? null : p,
        priceNote: (p === null || p === undefined) ? '待询价（机座 ' + f + ' 报价单空白）' : '报价单直连型 ' + stUse + ' 牌价',
        recAssumed: recAssumed,
        torqueNote: recAssumed ? ('扭矩按同机座 ' + stUse + ' 最高档 ' + topK + ':1 真源行保守校核') : '',
        model: 'HVB' + f + '-' + stUse + '-i' + ratio };
      if (ratio === 100) {
        info.torqueNote = (stUse === 'L3')
          ? '速比 100 厂家建议用三级，此处按三级真源扭矩/牌价'
          : '速比 100 厂家建议用三级；本机座三级无图纸行，扭矩按双级 ' + topK + ':1 真源行保守校核，下单前与厂家确认';
      }
      infos.push(info);
    }
    if (!infos.length) return null;
    /*



*/
    var pick = null, peak = null;
    /*
*/
    for (var ti = 0; ti < infos.length; ti++) {
      var base = infos[ti];
      if (!pick && outT <= base.C + 1e-9) pick = base;
      if (!peak && outT > base.C + 1e-9 && outT <= base.D + 1e-9) peak = base;
    }
    var baseline = pick || peak;
    var pool = infos;
    if (mShaft) {
      pool = infos.filter(function (x) { return x.shafts.indexOf(mShaft) >= 0; });
      pick = null; peak = null;
    }
    if (!pool.length && mShaft) {
      /**/
      var lastInfo = infos[infos.length - 1];
      lastInfo.shaftNote = '电机轴径 ' + mShaft + 'mm 超出全部机座适配表（最大 ' +
        Math.max.apply(null, lastInfo.shafts.concat([0])) + 'mm），须与厂家确认';
      peak = lastInfo;
    } else if (mShaft) {
      for (var pi = 0; pi < pool.length; pi++) {
        var it = pool[pi];
        if (!pick && outT <= it.C + 1e-9) pick = it;
        if (!peak && outT > it.C + 1e-9 && outT <= it.D + 1e-9) peak = it;
      }
      /**/
      var finalPick = pick || peak;
      if (baseline && finalPick && Number(finalPick.frame) > Number(baseline.frame)
        && baseline.shafts.indexOf(mShaft) < 0) {
        finalPick.shaftNote = '已按电机轴径 ' + mShaft + 'mm 升档：HV' + baseline.frame + '→HV' + finalPick.frame;
      }
    }
    var r = pick || peak;
    if (r) r.level = (pick ? '额定内' : '峰值（≤最大输出扭矩，寿命影响与厂家确认）');
    return r;
  }
  /*


*/
  var JACK_IN_MAX = 1500;
  /*




*/
  var SERVO_MIN_RPM = 30;
  /*



*/
  function speedAllowPctOf(inp, isServo) {
    if (!isServo) return 20;
    var a = Number(inp && inp.speed_allow_pct);
    if (!(a > 0)) return 25;
    return Math.min(50, Math.max(20, a));
  }
  var SMALL_PWR_ORDER = [0.2, 0.4, 0.1, 0.05, 0.75];
  function smallPwrRank(p) {
    var v = Number(p) || 0;
    for (var i = 0; i < SMALL_PWR_ORDER.length; i++) {
      if (Math.abs(v - SMALL_PWR_ORDER[i]) <= 1e-6) return i;
    }
    return SMALL_PWR_ORDER.length;
  }
  function v220Rank(m) {
    var s = String((m && m.voltage) || '');
    return /220/.test(s) ? 0 : (/380/.test(s) ? 1 : 2);
  }
  /*

*/
  /*



*/
  function pickGbRatioEx(vDirect, vNeed, servoPos) {
    var rLo = vDirect / (vNeed * 1.2), rHi = vDirect / (vNeed * 0.8);
    function inWin(r) {
      if (r < rLo - 1e-9 || r > rHi + 1e-9) return false;
      /**/
      return !(vDirect / r > JACK_IN_MAX + 1e-9);
    }
    if (servoPos) {
      var pBest = null, pDev = Infinity;
      for (var p = 0; p < GB_STD.length; p++) {
        var rp = GB_STD[p];
        if (vDirect / rp < vNeed - 1e-9) continue;          /**/
        if (!inWin(rp)) continue;
        var dP = vDirect / rp / vNeed - 1;                  /**/
        if (dP < pDev - 1e-12) { pDev = dP; pBest = rp; }
      }
      if (pBest !== null) return { i: pBest, neg: false };
      var nBest = null, nDev = Infinity;
      for (var q = 0; q < GB_STD.length; q++) {
        var rn = GB_STD[q];
        if (vDirect / rn >= vNeed - 1e-9) continue;         /**/
        if (!inWin(rn)) continue;
        var dN = Math.abs(vDirect / rn / vNeed - 1);
        if (dN < nDev - 1e-12) { nDev = dN; nBest = rn; }
      }
      return (nBest !== null) ? { i: nBest, neg: true } : { i: null, neg: false };
    }
    var gb = null, gbScore = Infinity;
    for (var si = 0; si < GB_STD.length; si++) {
      var r = GB_STD[si];
      if (!inWin(r)) continue;
      var dev = Math.abs(vDirect / r / vNeed - 1);
      var score = dev * 2 + (vDirect / r >= vNeed - 1e-9 ? 0 : 0.001);   /**/
      if (score < gbScore - 1e-12) { gbScore = score; gb = r; }
    }
    return { i: gb, neg: false };
  }
  function pickGbRatio(vDirect, vNeed) { return pickGbRatioEx(vDirect, vNeed, false).i; }
  /*

*/
  function pullDominantOf(inp) {
    var pullT = Number(inp && inp.load_pull_t) || 0;
    var pushKN = Number(inp && inp.load_push_kN) || 0;
    return pullT > 0 && pullT * 9.81 > pushKN;
  }
  function motorOverloadCoefOf(drive) {
    var d = String(drive || '');
    if (d === 'stepper') return 2;
    if (d === 'ac1') return 1.5;
    return 1;
  }

  /*



*/
  function screwDiaOf(def, modelName) {
    var cands = [gv(def, 'screw', ''), gv(def, 'screw_code', ''),
      gv(def, 'model_code', ''), String(modelName || '')];
    for (var i = 0; i < cands.length; i++) {
      var mm = String(cands[i]).match(/(\d{2,3})\s*[xX×*]/);
      if (mm) { var d = Number(mm[1]); if (d >= 8 && d <= 200) return d; }
    }
    return 0;
  }
  function eulerAllowedLen(screwDia, loadKN) {
    if (!screwDia || !(loadKN > 0)) return 0;
    var dRoot = 0.85 * screwDia;                       /**/
    var I = Math.PI * Math.pow(dRoot, 4) / 64;         /* mm^4 */
    var P = loadKN * 1000;                             /* N */
    return Math.sqrt(Math.PI * Math.PI * 206000 * I / (P * 4));   /**/
  }
  function stabilityCheck(modelDef, fEff, stroke, motion, mounting, modelName, data, screwDia) {
    motion = motion || 'S';
    mounting = mounting || '地脚安装';
    var fk = C.resolveFk(data || {}, modelName || '', mounting, motion);
    if (fk === null || fk === undefined) fk = 1.0;
    function eulerVerdict(tag) {
      if (!screwDia) return null;
      var lkE = eulerAllowedLen(screwDia, fEff);
      if (!(lkE > 0)) return null;
      var lkShow = Math.round(lkE);
      var allowedE = Math.round(lkE * fk);
      var ok = stroke <= allowedE;
      /**/
      return [ok, tag + '：载荷 ' + fN(fEff, 1) + 'kN 超出样本数据范围，按欧拉压杆公式估算（安全系数 4）'
        + ' Lk≈' + iN(lkShow) + 'mm，' + mounting + ' fk=' + fN(fk, 1)
        + '，最大稳定行程 L≈' + iN(allowedE) + 'mm ' + (ok ? '≥' : '<') + ' 要求 ' + iN(stroke) + 'mm'
        + (ok ? '，稳定性满足（估算值，建议与厂家样本曲线复核）' : '，稳定性不足（估算值，需与厂家确认）'), 'est'];
    }
    var curve = modelDef.stability_curve || {};
    /*
*/
    var borrowed = !!curve.borrowed_from;
    var cpts = (curve && typeof curve === 'object' && !Array.isArray(curve)) ? curve.points : curve;
    if (cpts && cpts.length) {
      if (modelName && (modelName.slice(0, 3) === 'SJA' || modelName.slice(0, 3) === 'SJB') && stroke <= 300) {
        return [true, '行程 ' + iN(stroke) + 'mm ≤ 300mm，按样本规则无需稳定性校核'];
      }
      /*
*/
      if (modelName && (modelName.slice(0, 3) === 'SCA' || modelName.slice(0, 3) === 'SCB') && stroke <= 500) {
        return [true, '行程 ' + iN(stroke) + 'mm ≤ 500mm，按样本规则（p121）无需稳定性校核'];
      }
      /*
*/
      var capNote = '';
      if (cpts.length) {
        var cptsAsc = cpts.slice().sort(function (a, b) { return a[0] - b[0]; });
        var p0L = cptsAsc[0][0], k0L = cptsAsc[0][1];
        var maxLenL = Math.max.apply(null, cpts.map(function (p) { return p[1]; }));
        if (fEff < p0L && p0L > 0 && fEff > 0 && k0L * Math.sqrt(p0L / fEff) > maxLenL) {
          capNote = '（低载外延按样本曲线最大长度 ' + iN(maxLenL) + 'mm 封顶）';
        }
      }
      var lk = C.curveLookup(cpts, fEff);
      if (lk === null) {
        var ev = eulerVerdict('按欧拉公式外推');
        if (ev) return ev;
        return [false, '载荷 ' + fN(fEff, 1) + 'kN 超出稳定性曲线范围（曲线最大 '
          + fN(Math.max.apply(null, cpts.map(function (p) { return p[0]; })), 0) + 'kN），需人工向厂家确认'];
      }
      var allowed = Math.round(lk * fk);
      if (stroke <= allowed) {
        return [true, '按2026样本稳定性曲线' + (borrowed ? '（' + String(modelName || '') + '借用 ' + curve.borrowed_from + ' 曲线，过渡口径）' : '')
          + '，载荷 ' + fN(fEff, 1) + 'kN 下允许稳定长度 Lk≈' + iN(lk)
          + 'mm，' + mounting + ' fk=' + fN(fk, 1) + '，最大稳定行程 L≈' + iN(allowed)
          + 'mm ≥ 要求 ' + iN(stroke) + 'mm（安全系数4）' + capNote, borrowed ? 'est' : undefined];
      }
      return [false, '稳定性不足：载荷 ' + fN(fEff, 1) + 'kN 下 Lk≈' + iN(lk) + 'mm，' + mounting
        + ' fk=' + fN(fk, 1) + '，最大稳定行程 L≈' + iN(allowed) + 'mm < 要求 ' + iN(stroke) + 'mm'
        + capNote
        + (borrowed ? '（借用 ' + curve.borrowed_from + ' 曲线，过渡口径）' : ''), borrowed ? 'est' : undefined];
    }
    var pts = modelDef.stability_points || [];
    var usable = pts.filter(function (p) { return p.load_kN >= fEff; });
    if (usable.length) {
      var best = Math.max.apply(null, usable.map(function (p) { return p.stroke_mm; }));
      if (stroke <= best) {
        var nearest = usable.reduce(function (a, b) { return b.stroke_mm < a.stroke_mm ? b : a; });
        return [true, '载荷 ' + fN(fEff, 1) + 'kN 下许用行程 ' + iN(nearest.stroke_mm) + 'mm ≥ 要求 '
          + iN(stroke) + 'mm（依据：' + gv(nearest, 'note', '稳定性表格') + '）'];
      }
      return [false, '稳定性不足：载荷 ' + fN(fEff, 1) + 'kN 下许用行程 ' + iN(best) + 'mm < 要求 ' + iN(stroke) + 'mm'];
    }
    if (pts.length) {
      var ev2 = eulerVerdict('按欧拉公式外推');
      if (ev2) return ev2;
      return [false, '载荷 ' + fN(fEff, 1) + 'kN 超出稳定性表数据范围（最大数据点 '
        + iN(Math.max.apply(null, pts.map(function (p) { return p.load_kN; }))) + 'kN），需查稳定性曲线人工确认'];
    }
    var ev3 = eulerVerdict('按欧拉公式估算');
    if (ev3) return ev3;
    /*
*/
    if (modelName && (modelName.slice(0, 3) === 'SJA' || modelName.slice(0, 3) === 'SJB') && stroke <= 300) {
      return [true, '行程 ' + iN(stroke) + 'mm ≤ 300mm，按样本规则（p63）无需稳定性校核'];
    }
    /**/
    if (modelName && (modelName.slice(0, 3) === 'SCA' || modelName.slice(0, 3) === 'SCB') && stroke <= 500) {
      return [true, '行程 ' + iN(stroke) + 'mm ≤ 500mm，按样本规则（p121）无需稳定性校核'];
    }
    /*
*/
    return [null, '该型号稳定性数据待补全：按样本 p64 稳定性曲线校核（丝杠运动：地脚安装 fk=1、'
      + '耳轴 fk=2、导向杆 fk=2.5；螺母运动（KV/SJA/SJB）不分安装 fk=2.5，安全系数 4；'
      + '拉力工况免校核），需人工查稳定性表格确认'];
  }

  /*




*/
  function scStabOf(inp, model, def, data) {
    var se = String((inp && inp.series) || '').toUpperCase();
    var mt = (inp && inp.mounting) || '地脚安装';
    if (se !== 'SCA' && se !== 'SCB') return { def: def, model: model, mounting: mt };
    var disp = String(model).replace(/^SJA/, 'SCA').replace(/^SJB/, 'SCB');
    var cu = ((((data || {}).catalog_rules_2026) || {}).stability_curves_p121) || {};
    var pts = cu[disp] && cu[disp].points;
    /*
*/
    if (!pts || !pts.length) return { def: def, model: model, mounting: mt };
    var d2 = {}, k;
    for (k in def) { if (Object.prototype.hasOwnProperty.call(def, k)) d2[k] = def[k]; }
    d2.stability_curve = { points: pts, source: cu.source || '样本 p121 推杆款稳定性曲线' };
    return {
      def: d2,
      model: disp,                                   /**/
      mounting: (mt === '耳轴安装') ? '尾部铰接安装' : mt
    };
  }

  /*


*/
  function staticCheckStep(m, rated, inp, fEff, units) {
    var ratedStatic = (typeof m.rated_static_kN === 'number' && !isTodo(m.rated_static_kN))
      ? m.rated_static_kN
      : ((typeof rated === 'number') ? rated * 1.5 : null);
    var staticT = Number(inp.static_load_t) || 0;
    var need = staticT > 0 ? staticT * 9.81 / units : fEff;
    var src = staticT > 0
      ? '静载 ' + staticT + ' t（单台 ' + fN(need, 1) + 'kN）'
      : '未单独提供静载，按动载需求 ' + fN(fEff, 1) + 'kN 计';
    if (ratedStatic == null) return [null, src + '：产品静载数据待补全，需与厂家确认'];
    var ok = need <= ratedStatic * 1.001;
    return [ok, src + ' ≤ 额定静载 ' + fN(ratedStatic, 1) + 'kN'
      + ((typeof m.rated_static_kN === 'number' && !isTodo(m.rated_static_kN)) ? '（样本值）' : '（按额定动载 ×1.5 口径）')
      + '，' + (ok ? '静载校核通过' : '静载超限，需放大型号')];
  }

  /**/
  var HAND_MAX_TQ_FACTOR = 2;

  /*


*/
  function handForcePlan(handTorque) {
    if (handTorque == null) return null;
    var f200 = handTorque / 0.2 / 9.81;
    var f400 = handTorque / 0.4 / 9.81;
    var overPct = Math.round((f400 / 10 - 1) * 1000) / 10;   /**/
    var p = { f200: r(f200, 1), f400: r(f400, 1), over_pct_400: overPct, radius: 200, force: r(f200, 1), ok: true };
    if (f200 <= 10) {
      p.txt = '手摇力 = ' + fN(f200, 1) + 'kg ≤ 10kg，半径 200mm 即可';
    } else if (f400 <= 10) {
      p.radius = 400; p.force = r(f400, 1);
      p.txt = '手摇力 = ' + fN(f200, 1) + 'kg > 10kg，需要 400mm 手摇半径，此时手摇力 '
        + fN(f400, 1) + 'kg ≤ 10kg';
    } else if (f400 <= 10 * 1.05) {
      p.radius = 400; p.force = r(f400, 1); p.tolerance = true;
      p.txt = '手摇力 = ' + fN(f200, 1) + 'kg > 10kg，需要 400mm 手摇半径，此时手摇力 '
        + fN(f400, 1) + 'kg，超出 10kg 限额 ' + fN(overPct, 1) + '%，差额 ≤5%，可设定合格';
    } else {
      p.radius = 400; p.force = r(f400, 1); p.ok = false;
      p.txt = '手摇力 = ' + fN(f200, 1) + 'kg > 10kg，加大手摇半径至最大 400mm 仍为 '
        + fN(f400, 1) + 'kg > 10kg（超出限额 ' + fN(overPct, 1) + '% > 5%），需增加减速机 5:1 或 10:1';
    }
    return p;
  }

  /*


*/
  function brakeAdvice(model, ratioKey, m) {
    var src = String(model || '').toUpperCase();
    var num = parseInt(String(src).replace(/^[A-Z]+/, ''), 10) || 0;
    var fam;
    if (src.indexOf('SJA') === 0) fam = 'SJA';
    else if (src.indexOf('SJB') === 0 || src.indexOf('SCB') === 0) fam = 'SJB';
    else return '';                                        //
    var rk = String(ratioKey || (m && m.ratio) || '').toUpperCase();
    if (fam === 'SJA') {
      if (num >= 100) return 'SJA100-1000 标准梯形丝杠自锁，V1/L1 综合均自锁，电机可不加制动器（如客户要求双保险可选配）';
      if (rk.indexOf('L1') === 0) return 'L1 蜗轮蜗杆自锁，电机可不加制动器（如客户要求双保险可选配）';
      /**/
      return 'V1 蜗轮蜗杆不自锁、标准梯形丝杠不自锁，建议电机增加制动器；'
        + '标准梯形丝杠可非标减少丝杠导程实现自锁（非标导程需与力姆泰克工程师沟通确认）';
    }
    if (rk.indexOf('L1') === 0) return 'L1 蜗轮蜗杆自锁，电机可不加制动器（如客户要求双保险可选配）';
    return '该速比下蜗轮蜗杆不自锁，建议电机增加制动器';
  }

  /*




*/
  function needBrakeOfAdv(adv) {
    var s = String(adv || '');
    return s.indexOf('增加制动器') >= 0 && s.indexOf('可不加') < 0;
  }
  function isISMG2Row(r) { return String((r && r.code) || '').indexOf('ISMG2') === 0; }
  function applyBrakePolicy(rows, needBrake) {
    if (!needBrake || !Array.isArray(rows) || !rows.length) return rows;
    var hasISMG1 = rows.some(function (x) {
      return String((x && x.code) || '').indexOf('ISMG1') === 0 && x.fit !== 'over';
    });
    var out = [];
    rows.forEach(function (r) {
      if (isISMG2Row(r)) {
        if (hasISMG1) return;   /**/
        r.brake = '不带制动（该系列无抱闸选配）；制动须与汇川确认或另行解决';
        r.brake_warn = true;
      }
      out.push(r);
    });
    return out;
  }

  /*


*/
  var SJ_TQ_UNDER = 0.02;
  function tqTolOf(rated, req) {
    if (req == null || rated == null || !isFinite(req) || !isFinite(rated)) return 0;
    if (rated >= req - 1e-9) return 0;
    if (req > 0 && rated >= req * (1 - SJ_TQ_UNDER) - 1e-9) return (req - rated) / req;
    return -1;
  }
  /**/
  function sinkTqTol(rows) {
    if (!Array.isArray(rows)) return rows;
    var ok = [], tol = [];
    rows.forEach(function (r) { ((r && r.tq_under != null) ? tol : ok).push(r); });
    return ok.concat(tol);
  }

  /**/
  /*


*/
  var EHA_DUTY_SPEED_MAX = 100;
  function dutyCheck(model, series, cycles, speed, loadRate) {
    var src = String(series || model || '').toUpperCase();
    var fam, isEhaDuty = false;
    if (['SJA', 'SCA', 'KV'].some(function (p) { return src.indexOf(p) === 0; })) fam = '梯形丝杠';
    else if (['SJB', 'SCB'].some(function (p) { return src.indexOf(p) === 0; })) fam = '滚珠丝杠';
    else if (['EHB', 'DHB'].some(function (p) { return src.indexOf(p) === 0; })) fam = '伞齿轮';
    else if (src.indexOf('EHA') === 0) { fam = '梯形丝杠'; isEhaDuty = true; }
    else return [null, '系列未识别（' + (series || model || '?') + '），工作制按厂家样本确认'];

    var probs = [], dutyExt = '';
    if (fam === '梯形丝杠') {
      var vCapDuty = isEhaDuty ? EHA_DUTY_SPEED_MAX : 30;
      if (speed !== null && speed !== undefined && speed >= vCapDuty) probs.push('速度 ' + fN(speed, 1) + 'mm/s ≥ ' + iN(vCapDuty) + 'mm/s 上限');
      /*

*/
      if (cycles !== null && cycles !== undefined && cycles > 50) {
        var lrN = (loadRate !== null && loadRate !== undefined) ? Math.min(0.5, Math.max(0.2, loadRate)) : null;
        var maxCyc = (lrN !== null) ? 50 + (0.5 - lrN) / 0.3 * 50 : 50;
        if (cycles <= maxCyc + 1e-9) {
          dutyExt = '每日 ' + iN(cycles) + ' 次（负载率 ' + fN(loadRate * 100, 0) + '%，按负载率插值可用至 '
            + fN(maxCyc, 0) + ' 次/日：负载率 50%→50 次、20%→100 次）';
        } else {
          var lrTxt = (loadRate !== null && loadRate !== undefined) ? (fN(loadRate * 100, 0) + '%') : '未知';
          probs.push('每日 ' + iN(cycles) + ' 次超过当前负载率（' + lrTxt + '）允许上限 ' + fN(maxCyc, 0)
            + ' 次/日（负载率 50%→50 次/日、20%→100 次/日 线性插值）；梯形丝杠每日次数超限，优先改选滚珠丝杠系列（SJB/SCB）');
        }
      }
    } else if (fam === '滚珠丝杠') {
      if (cycles !== null && cycles !== undefined && cycles > 200) probs.push('每日 ' + iN(cycles) + ' 次超过滚珠丝杠上限 200 次/日');
      if (speed !== null && speed !== undefined && speed >= 100) probs.push('速度 ' + fN(speed, 1) + 'mm/s ≥ 100mm/s 上限');
    } else {
      if (cycles !== null && cycles !== undefined && cycles > 1000) probs.push('每日 ' + iN(cycles) + ' 次超过伞齿轮上限 1000 次/日');
      if (speed !== null && speed !== undefined && speed >= 300) probs.push('速度 ' + fN(speed, 1) + 'mm/s ≥ 300mm/s 上限');
    }

    var tag = (isEhaDuty ? '梯形丝杠（EHA 伞齿轮型）' : fam) + '系列（' + (series || model) + '）';
    if (probs.length) return [false, tag + ' 超出选择原则：' + probs.join('；') + '；建议改选系列或与厂家技术确认'];
    if (dutyExt) return [true, tag + '：' + dutyExt + '、速度 ' + fN(speed || 0, 1) + 'mm/s，符合选择原则'];
    var cycTxt = (cycles !== null && cycles !== undefined) ? ('每日 ' + iN(cycles) + ' 次') : '次数未填';
    var spdTxt = (speed !== null && speed !== undefined) ? ('速度 ' + fN(speed, 1) + 'mm/s') : '速度未填';
    return [true, tag + '：' + cycTxt + '、' + spdTxt + '，符合选择原则'];
  }

  /*




*/
  function motorKind(m) {
    return m.kind || (String(m.brand || '').indexOf('交流') === 0 ? 'ac' : 'servo');
  }
  /*


*/
  function driveKindOf(inp) {
    var d = String((inp && inp.drive) || '');
    if (d === 'ac3' || d === 'ac1') return 'ac';
    if (d === 'servo220' || d === 'servo380') return 'servo';
    if (d === 'dc24') return 'dc';
    return '';
  }
  /*




*/
  /*




*/
  var SMALL_PWR_MAX = 0.75;   /**/
  var SERVO_RPM_SET = [1500, 2000, 2500, 3000];
  function servoRpmAllowed(powerKw, rpm, brand) {
    var r = Number(rpm) || 0;
    if (r > 3000 + 1e-9) return false;
    /*
*/
    if (powerKw !== null && powerKw !== undefined && Number(powerKw) <= 0.75 + 1e-9) {
      return Math.abs(r - 3000) < 1e-6;
    }
    for (var i = 0; i < SERVO_RPM_SET.length; i++) {
      if (Math.abs(r - SERVO_RPM_SET[i]) < 1e-6) return true;
    }
    return false;
  }
  /*



*/
  var REV158 = [1, 2, 3, 5, 6, 8, 10, 15, 20, 25, 30, 40, 50];
  function recommendMotor(data, powerKw, torque, rpm, wantKind, servoRpm, gbInfo, svLock, multi, pMotorEnd, huLayout, needBrake, acCapKw, svDirect154) {
    /*



*/
    var kwMarginGb = pMotorEnd ? 1.1 : (multi ? 1.0 : 1.1);
    var sRpm = (servoRpm === null || servoRpm === undefined) ? rpm : servoRpm;
    /**/
    var smallMode = (powerKw !== null && powerKw !== undefined && Number(powerKw) <= 0.75 + 1e-9);
    /*



*/
    if (wantKind === 'dc') {
      var pDc233 = (powerKw !== null && powerKw !== undefined && isFinite(Number(powerKw))) ? Number(powerKw) : 0;
      var pMain233 = Math.max(0.1, Math.ceil(pDc233 * 10 - 1e-9) / 10);
      var pAlt233 = Math.round((pMain233 + 0.1) * 10) / 10;
      var rpmMain233 = (Number(rpm) === 3000) ? 3000 : 1500;
      var rpmAlt233 = (rpmMain233 === 1500) ? 3000 : 1500;
      var dcMain233 = {
        brand: '直流电机', code: '24VDC', kind: 'dc', voltage: '24VDC',
        power_kW: pMain233, rpm: rpmMain233,
        torque_Nm: Math.ceil(9550 * pMain233 / rpmMain233 * 10) / 10,
        fit: 'direct', dc_main: true
      };
      var dcAlt233 = {
        brand: '直流电机', code: '24VDC', kind: 'dc', voltage: '24VDC',
        power_kW: pAlt233, rpm: rpmAlt233,
        torque_Nm: Math.ceil(9550 * pAlt233 / rpmAlt233 * 10) / 10,
        fit: 'direct'
      };
      /**/
      if (needBrake) {
        dcMain233.brake = '须选带制动器版本（24VDC）';
        dcAlt233.brake = dcMain233.brake;
      }
      return applyBrakePolicy([dcMain233, dcAlt233], needBrake);
    }
    /*


*/
    var huTier = !!huLayout && !(svLock && (svLock.ratio || svLock.huRev));
    var HU_TIER_REV = [1, 2, 3, 4, 5, 6, 8, 10];
    function huTierRatio(ratedRpm) {
      if (!(sRpm > 0) || !(ratedRpm > 0)) return null;
      /*
*/
      var best = null, outB = 0, neg = false;
      function scan(posOnly) {
        var b = null, oB = 0;
        HU_TIER_REV.forEach(function (rvH) {
          var oH = ratedRpm / rvH;
          if (posOnly && oH < sRpm - 1e-9) return;
          if (oH >= sRpm / 1.2 - 1e-9 && oH <= sRpm * 1.2 + 1e-9 && oH <= JACK_IN_MAX + 1e-9) {
            var dv = Math.abs(oH - sRpm);
            if (b === null || dv < oB - 1e-9 || (Math.abs(dv - oB) <= 1e-9 && rvH > b)) { b = rvH; oB = dv; }
          }
        });
        return { b: b, dv: oB };
      }
      var pos = scan(true);
      if (pos.b !== null) { best = pos.b; outB = ratedRpm / best; }
      else {
        var nres = scan(false);
        if (nres.b !== null) { best = nres.b; outB = ratedRpm / best; neg = true; }
      }
      return (best === null) ? null : { rv: best, out: outB, neg: neg };
    }
    var lib = data.motor_library || [];
    var ac = [], servo = [], servoGb = [], servoOver = [];
    lib.forEach(function (m) {
      var kind = motorKind(m);
      var brakeRaw = gv(m, 'brake', '');
      var base = {
        brand: m.brand, code: m.code, kind: kind, poles: gv(m, 'poles', null),
        power_kW: m.power_kW, rpm: m.rpm, torque_Nm: m.torque_Nm,
        current_A: gv(m, 'current_A', null), frame: gv(m, 'frame', ''),
        flange: gv(m, 'flange', ''), voltage: gv(m, 'voltage', ''),
        ip: gv(m, 'ip', ''), insulation: gv(m, 'insulation', ''),
        brake: (typeof brakeRaw === 'string') ? brakeRaw : (brakeRaw ? '内置抱闸可选配' : ''),
        note: gv(m, 'note', '')
      };
      if (kind === 'ac') {
        /*


*/
        if (Number(gv(m, 'poles', 0)) === 2) return;
        /*
*/
        if (!gbInfo && m.rpm > JACK_IN_MAX + 1e-9) return;
        if (gbInfo && Number(gbInfo.out_rpm) > JACK_IN_MAX + 1e-9) return;
        /*

*/
        /*



*/
        var _overList = (acCapKw != null && m.power_kW > acCapKw + 1e-9) ? acCapKw : null;
        if (!multi && _overList != null) base.ac_over_cap = acCapKw;
        base._overList = _overList;
        /*






*/
        var kwAcMargin = (multi === false) ? 1.1 : 1.0;
        var pReqAc = (powerKw === null || powerKw === undefined) ? null : powerKw * kwAcMargin;
        var okP = (pReqAc === null || m.power_kW >= pReqAc - 1e-9);
        var tReq = (pReqAc !== null) ? (9550 * pReqAc / m.rpm) : torque;
        var tTolAC = tqTolOf(m.torque_Nm, tReq);
        var okT = tTolAC >= 0;
        if (okP && okT) {
          if (tTolAC > 0) base.tq_under = tTolAC;   /**/
          base.fit = ((powerKw !== null && powerKw !== undefined && m.power_kW >= powerKw * 1.2 - 1e-9)
            || (powerKw === null || powerKw === undefined) && tReq && m.torque_Nm >= tReq * 1.2 - 1e-9)
            ? '1.2'
            : ((powerKw !== null && powerKw !== undefined && m.power_kW >= powerKw * 1.1 - 1e-9)
              || (powerKw === null || powerKw === undefined) && tReq && m.torque_Nm >= tReq * 1.1 - 1e-9)
              ? '1.1' : 'direct';
          base.within_10pct = base.fit === '1.1';
          /*

*/
          if (svLock && svLock.ratio) {
            /*
*/
            if (sRpm > 0) {
              var outAC = m.rpm / svLock.ratio;
              if (outAC < sRpm * 0.8 - 1e-9 || outAC > sRpm * 1.2 + 1e-9) return;
            }
            var gbAC = JSON.parse(JSON.stringify(base));
            gbAC.gearbox = { ratio: svLock.ratio + ':1', type: svLock.type || '行星减速机',
              out_rpm: Math.round(m.rpm / svLock.ratio * 10) / 10, eff: svLock.eff || 0.9 };
            ac.push(gbAC);
            return;
          }
          /**/
          if (gbInfo) {
            /*


*/
            var rvG = Number(String(gbInfo.ratio || '').split(':')[0]) || 1;
            var outG = m.rpm / rvG;
            if (sRpm > 0 && (outG < sRpm * 0.8 - 1e-9 || outG > sRpm * 1.2 + 1e-9
              || outG > JACK_IN_MAX + 1e-9)) return;
            base.gearbox = gbInfo;
          }
          ac.push(base);
        }
      } else {
        /**/
        if (!servoRpmAllowed(m.power_kW, m.rpm, m.brand)) return;
        /*

*/
        if (huTier) {
          var huR = huTierRatio(Number(m.rpm) || 0);
          if (huR) {
            var okKwHT = (powerKw === null || powerKw === undefined || m.power_kW >= powerKw - 1e-9);
            var tTolHT = tqTolOf(m.torque_Nm, torque);
            var okTqHT = tTolHT >= 0;
            if (okKwHT && okTqHT) {
              var gbHT = JSON.parse(JSON.stringify(base));
              if (tTolHT > 0) gbHT.tq_under = tTolHT;   /**/
              gbHT.gearbox = { ratio: huR.rv + ':1', type: '伞齿轮换向器', out_rpm: Math.round(huR.out), eff: 1 };
              gbHT.pEnd = true;
              /*
*/
              if (huR.neg) {
                gbHT.overspeed = true;
                gbHT.note = (gbHT.note ? gbHT.note + '；' : '')
                  + '本档窗口内无「额定转速下速度≥要求」的速比，需超额定转速弱磁运行达速（扭矩降额），须与厂家确认';
              }
              gbHT.fit = (powerKw !== null && powerKw !== undefined && m.power_kW >= powerKw * 1.2 - 1e-9) ? '1.2' : '1.1';
              gbHT.within_10pct = gbHT.fit === '1.1';
              servoGb.push(gbHT);
            }
          }
          return;   /**/
        }
        /*


*/
        /**/
        /**/
        /*
*/
        if ((!svLock || (!svLock.ratio && !svLock.huRev))
          && !(sRpm !== null && sRpm !== undefined && sRpm > JACK_IN_MAX + 1e-9)
          && !(sRpm !== null && sRpm !== undefined && sRpm < SERVO_MIN_RPM - 1e-9)) {
        var tAvail = m.torque_Nm, overSpd = false;
        if (sRpm !== null && sRpm !== undefined && m.rpm < sRpm - 1e-9) {
          if (sRpm > 3000 + 1e-9) return;
          /*
*/
          if (sRpm > (Number(m.nmax_rpm) || 3000) + 1e-9) return;
          tAvail = m.torque_Nm * m.rpm / sRpm;
          overSpd = true;
        }
        var okRpm = (sRpm === null || sRpm === undefined) || overSpd || (m.rpm >= sRpm - 1e-9);
        /*
*/
        var okT2 = torque ? (tAvail >= torque - 1e-9)
          : (powerKw === null || powerKw === undefined || m.power_kW >= powerKw - 1e-9);
        if (okRpm && okT2) {
          base.fit = (torque ? (tAvail >= torque * 1.2 - 1e-9)
            : (powerKw != null && m.power_kW >= powerKw * 1.2 - 1e-9)) ? '1.2' : '1.1';
          base.within_10pct = base.fit === '1.1';
          if (overSpd) { base.overspeed = true; base.torque_at_speed = Math.round(tAvail * 100) / 100; }
          (overSpd ? servoOver : servo).push(base);
        }
        }   /**/
        /*



*/
        if (sRpm > 0) {
          /*

*/
            if (svLock && svLock.huRev) {
              /*


*/
              if (svLock.fixed) {
                /*
*/
                var rvF = 0;
                for (var iv158m = 0; iv158m < REV158.length; iv158m++) {
                  if (sRpm * REV158[iv158m] <= Number(m.rpm) * 1.002 + 1e-6) rvF = REV158[iv158m];
                }
                var runF = rvF ? sRpm * rvF : 0;
                /*

*/
                if (rvF && runF >= SERVO_MIN_RPM - 1e-9) {
                  var tReqF = (powerKw !== null && powerKw !== undefined) ? (9550 * powerKw / runF) : 0;
                  var okKwF = (powerKw === null || powerKw === undefined || m.power_kW >= powerKw - 1e-9);
                  var tTolF = tqTolOf(m.torque_Nm, tReqF);
                  var okTqF = tTolF >= 0;
                  if (okKwF && okTqF) {
                    var gbF = JSON.parse(JSON.stringify(base));
                    gbF.gearbox = { ratio: rvF + ':1', type: '伞齿轮换向器', out_rpm: Math.round(sRpm), eff: 1 };
                    gbF.pEnd = true;
                    if (tTolF > 0) gbF.tq_under = tTolF;   /**/
                    /**/
                    gbF.motor_run_rpm = Math.round(runF * 10) / 10;
                    gbF.hu_fixed = true;
                    gbF.hu_over20 = runF < Number(m.rpm) * 0.8 - 1e-6;   /**/
                    gbF.fit = (powerKw !== null && powerKw !== undefined && m.power_kW >= powerKw * 1.2 - 1e-9) ? '1.2' : '1.1';
                    gbF.within_10pct = gbF.fit === '1.1';
                    servoGb.push(gbF);
                  }
                }
              }
              if (!svLock.fixed) {
              /*





*/
              var giH = null, outH = 0;
            /*





*/
            var winU86 = (svLock && svLock.winU > 0) ? svLock.winU : 1.2;
            var sRow86 = (svLock && svLock.outNeed > 0) ? svLock.outNeed : sRpm;
            (svLock.revList || [1, 2, 3, 4, 5, 6, 8, 10]).forEach(function (rvH) {
              var oH = m.rpm / rvH;
              if (oH >= sRow86 - 1e-9 && oH <= sRow86 * winU86 + 1e-9 && oH <= JACK_IN_MAX + 1e-9) {
                if (giH === null || rvH > giH) { giH = rvH; outH = oH; }
              }
            });
            if (giH === null) {
              /**/
              (svLock.revList || [1, 2, 3, 4, 5, 6, 8, 10]).forEach(function (rvH2) {
                var oH2 = m.rpm / rvH2;
                if (oH2 >= sRow86 * 0.8 - 1e-9 && oH2 < sRow86 - 1e-9 && oH2 <= JACK_IN_MAX + 1e-9) {
                  if (giH === null || oH2 > outH) { giH = rvH2; outH = oH2; }
                }
              });
            }
            if (giH !== null) {
              var hNeg = outH < sRpm - 1e-9;
              var okKwH = (powerKw === null || powerKw === undefined
                || m.power_kW >= powerKw - 1e-9);
              var tTolH = tqTolOf(m.torque_Nm, torque);
              var okTqH = tTolH >= 0;
              if (okKwH && okTqH) {
                var gbH = JSON.parse(JSON.stringify(base));
                gbH.gearbox = { ratio: giH + ':1', type: '伞齿轮换向器', out_rpm: Math.round(outH), eff: 1 };
                if (tTolH > 0) gbH.tq_under = tTolH;
                if (hNeg) {
                  gbH.overspeed = true;
                  gbH.note = (gbH.note ? gbH.note + '；' : '')
                    + '本档窗口内最大速比对应输出 ' + Math.round(outH) + 'rpm（较所需 ' + Math.round(sRow86)
                    + 'rpm 低 ' + Math.round((1 - outH / sRpm) * 1000) / 10 + '%，在 ±20% 接受窗口内）'
                    + '，如需精确达速须与厂家确认调档';
                }
                gbH.fit = (powerKw !== null && powerKw !== undefined && m.power_kW >= powerKw * 1.2 - 1e-9) ? '1.2' : '1.1';
                gbH.within_10pct = gbH.fit === '1.1';
                servoGb.push(gbH);
              }
              /*



*/
              var giU = null, outU = 0;
              (svLock.revList || [1, 2, 3, 4, 5, 6, 8, 10]).forEach(function (rvU) {
                if (rvU <= giH) return;
                var oU = m.rpm / rvU;
                /**/
                if (oU >= sRow86 * 0.8 - 1e-9 && oU < sRow86 - 1e-9 && oU <= JACK_IN_MAX + 1e-9) {
                  if (giU === null || rvU > giU) { giU = rvU; outU = oU; }
                }
              });
              if (giU !== null) {
                var fU = giH / giU;
                var needKwU = (powerKw === null || powerKw === undefined) ? null : powerKw * fU;
                var needTqU = torque ? torque * fU : null;
                var okKwU = (needKwU === null || m.power_kW >= needKwU - 1e-9);
                var tTolU = tqTolOf(m.torque_Nm, needTqU);
                var okTqU = tTolU >= 0;
                if (okKwU && okTqU) {
                  var gbU = JSON.parse(JSON.stringify(base));
                  gbU.gearbox = { ratio: giU + ':1', type: '伞齿轮换向器', out_rpm: Math.round(outU), eff: 1 };
                  if (tTolU > 0) gbU.tq_under = tTolU;   /**/
                  gbU.overspeed = true;
                  gbU.alt_underspeed = true;
                  gbU.note = '欠速备选（同档更大速比 ' + giU + ':1）：电机端需求 '
                    + (needKwU === null ? '—' : (Math.round(needKwU * 100) / 100 + 'kW')) + ' / '
                    + (needTqU === null ? '—' : (Math.round(needTqU * 100) / 100 + 'Nm'))
                    + '，输出 ' + Math.round(outU) + 'rpm 较所需 ' + Math.round(sRow86) + 'rpm 低 '
                    + Math.round((1 - outU / sRpm) * 1000) / 10 + '%（±20% 窗口内），如需精确达速请与厂家确认调档';
                  gbU.fit = (needKwU !== null && m.power_kW >= needKwU * 1.2 - 1e-9) ? '1.2' : '1.1';
                  gbU.within_10pct = gbU.fit === '1.1';
                  servoGb.push(gbU);
                }
              }
            }
            }   /**/
            return;
          }
          /*


*/
      /*


*/
      if (svLock && svLock.changer && sRpm > 0) {
        var REV_M = [1, 2, 3, 4, 5, 6, 8, 10];
        for (var riM = 0; riM < REV_M.length; riM++) {
          var rvM = REV_M[riM];
          var runM = sRpm * rvM;
          if (runM < SERVO_MIN_RPM - 1e-9) continue;
          if (runM > 3000 / rvM + 1e-9) continue;
          var needTqM = torque ? torque / (rvM * 0.9) : null;
          var needKwM = (powerKw !== null && powerKw !== undefined) ? powerKw / 0.9 : null;
          var tTolM = tqTolOf(m.torque_Nm, needTqM);
          var okTqM = tTolM >= 0;
          var okKwM = (needKwM === null) || (m.power_kW >= needKwM - 1e-9);
          if (!(okTqM && okKwM)) continue;
          var gbM = JSON.parse(JSON.stringify(base));
          gbM.gearbox = { ratio: rvM + ':1', type: '换向器',
            out_rpm: Math.round(sRpm * 10) / 10, eff: 0.9 };
          if (tTolM > 0) gbM.tq_under = tTolM;   /**/
          gbM.lowspeed_gearbox = true;
          gbM.motor_run_rpm = Math.round(runM * 10) / 10;
          gbM.fit = (needKwM !== null && m.power_kW >= needKwM * 1.2 - 1e-9) ? '1.2' : '1.1';
          gbM.within_10pct = gbM.fit === '1.1';
          gbM.note = (gbM.note ? gbM.note + '；' : '')
            + '低速换向器直配：所需输入 ' + (Math.round(sRpm * 10) / 10) + 'rpm，电机端换向器速比 1:'
            + rvM + '（额定输入 ' + iN(3000 / rvM) + 'rpm、允许 ' + fN(30 / rvM, 0) + '~'
            + iN(3000 / rvM) + 'rpm），电机调速到 ' + gbM.motor_run_rpm + 'rpm 运行；扭矩校核 电机'
            + fN(m.torque_Nm, 2) + 'Nm × ' + rvM + ' ÷ 0.9 = ' + fN(m.torque_Nm * rvM / 0.9, 2)
            + 'Nm ≥ 需求 ' + fN(torque, 2) + 'Nm';
          servoGb.push(gbM);
          break;
        }
        return;
      }
          if (!(svLock && svLock.ratio) && sRpm > 0 && sRpm < SERVO_MIN_RPM - 1e-9) {
            /*

*/
            var giFirstLS = null;
            for (var siLS = 0; siLS < GB_STD.length; siLS++) {
              if (sRpm * GB_STD[siLS] >= SERVO_MIN_RPM - 1e-9) { giFirstLS = GB_STD[siLS]; break; }
            }
            if (giFirstLS !== null) {
              for (var ixLS = GB_STD.indexOf(giFirstLS); ixLS < GB_STD.length; ixLS++) {
                var giLS = GB_STD[ixLS];
                var effLS = gbEffOf(giLS);
                var needKwLS = (powerKw !== null && powerKw !== undefined) ? powerKw / effLS : null;
                var needTqLS = torque ? torque / giLS / effLS : null;
                var okKwLS = (needKwLS === null) || (m.power_kW >= needKwLS - 1e-9);
                var tTolLS = tqTolOf(m.torque_Nm, needTqLS);
                var okTqLS = tTolLS >= 0;
                if (!(okKwLS && okTqLS)) continue;
                var gbLS = JSON.parse(JSON.stringify(base));
                gbLS.gearbox = { ratio: giLS + ':1', type: '行星减速机',
                  out_rpm: Math.round(sRpm * 10) / 10, eff: effLS };
                if (tTolLS > 0) gbLS.tq_under = tTolLS;   /**/
                gbLS.lowspeed_gearbox = true;
                gbLS.motor_run_rpm = Math.round(sRpm * giLS * 10) / 10;
                gbLS.fit = (needKwLS !== null && m.power_kW >= needKwLS * 1.2 - 1e-9) ? '1.2' : '1.1';
                gbLS.within_10pct = gbLS.fit === '1.1';
                gbLS.note = (gbLS.note ? gbLS.note + '；' : '')
                  + '极低速工况：所需输入 ' + (Math.round(sRpm * 10) / 10) + 'rpm 低于伺服稳定调速下限 '
                  + SERVO_MIN_RPM + 'rpm，按本档电机扭矩独立配比取最小可行比 ' + giLS + ':1，电机调速到 '
                  + gbLS.motor_run_rpm + 'rpm 运行（30~3000rpm 稳定区内），输出即所需转速';
                servoGb.push(gbLS);
                break;
              }
            }
            return;
          }
          /*
*/
          /**/
            var giX = (svLock && svLock.ratio) ? null : pickGbRatioEx(m.rpm, sRpm, true);
            var gi = (svLock && svLock.ratio) ? ((m.rpm === svLock.rated) ? svLock.ratio : null) : giX.i;
            var outRpmG = (gi !== null) ? m.rpm / gi : 0;
            /*
*/
            /*


*/
            if (gi !== null && (outRpmG >= sRpm / 1.2 - 1e-9 || (svLock && svLock.forced))
              && outRpmG <= JACK_IN_MAX + 1e-9) {
            /*
*/
            var effG = (svLock && svLock.pEnd && typeof svLock.eff === 'number') ? svLock.eff : gbEffOf(gi);
            var needKwG = (powerKw !== null && powerKw !== undefined)
              ? ((pMotorEnd || (svLock && svLock.pEnd)) ? powerKw : powerKw / effG) : null;
            var needTqG = (pMotorEnd || (svLock && svLock.pEnd)) ? torque
              : (torque ? torque / gi / effG : null);
            /*



*/
            var okKwG = (needKwG === null) || (m.power_kW >= needKwG - 1e-9);
            var tTolG = tqTolOf(m.torque_Nm, needTqG);
            var okTqG = tTolG >= 0;
            if (okKwG && okTqG) {
              var gbM = JSON.parse(JSON.stringify(base));
              var isLowSv = !!(svLock && svLock.lowSpeed);
              gbM.gearbox = {
                ratio: gi + ':1', type: (svLock && svLock.type) || '行星减速机',
                out_rpm: isLowSv ? (Math.round(sRpm * 10) / 10) : Math.round(outRpmG), eff: effG
              };
              if (tTolG > 0) gbM.tq_under = tTolG;   /**/
              if (isLowSv) {
                gbM.lowspeed_gearbox = true;
                gbM.motor_run_rpm = Math.round(sRpm * gi * 10) / 10;
                gbM.note = (gbM.note ? gbM.note + '；' : '')
                  + '极低速工况：所需输入 ' + (Math.round(sRpm * 10) / 10) + 'rpm 低于伺服稳定调速下限 '
                  + SERVO_MIN_RPM + 'rpm，配 ' + gi + ':1 行星减速机，电机调速到 '
                  + gbM.motor_run_rpm + 'rpm 运行（30~3000rpm 稳定区内），输出即所需转速';
              }
              /**/
              if (giX && giX.neg) {
                gbM.overspeed = true;
                gbM.note = (gbM.note ? gbM.note + '；' : '')
                  + '本档窗口内无「额定转速下速度≥要求」的速比，需超额定转速弱磁运行达速（扭矩降额），须与厂家确认';
              }
              gbM.fit = (needKwG !== null && m.power_kW >= needKwG * 1.2 - 1e-9) ? '1.2' : '1.1';
              gbM.within_10pct = gbM.fit === '1.1';
              servoGb.push(gbM);
            }
          } else if (sRpm > JACK_IN_MAX + 1e-9 && !(svLock && svLock.ratio)) {
            /*

*/
            var giF = null;
            for (var siF = 0; siF < GB_STD.length; siF++) {
              if (m.rpm / GB_STD[siF] <= JACK_IN_MAX + 1e-9) { giF = GB_STD[siF]; break; }
            }
            if (giF !== null) {
              var outF = m.rpm / giF, effF = gbEffOf(giF);
              var needKwF = (powerKw !== null && powerKw !== undefined) ? (pMotorEnd ? powerKw : powerKw / effF) : null;
              var needTqF = pMotorEnd ? torque : (torque ? torque / giF / effF : null);
              var okKwF = (needKwF === null) || (m.power_kW >= needKwF * kwMarginGb - 1e-9);
              var okTqF = !needTqF || (m.torque_Nm >= needTqF - 1e-9);
              if (okKwF && okTqF) {
                var gbF = JSON.parse(JSON.stringify(base));
                gbF.gearbox = { ratio: giF + ':1', type: '行星减速机', out_rpm: Math.round(outF), eff: effF };
                gbF.fit = (needKwF !== null && m.power_kW >= needKwF * 1.2 - 1e-9) ? '1.2' : '1.1';
                gbF.within_10pct = gbF.fit === '1.1';
                gbF.input_capped = true;
                gbF.note = '（升降机输入转速限 1500rpm：所需 ' + iN(Math.round(sRpm)) + 'rpm 超限，'
                  + '配减速机后输出速度低于要求，工况需加大导程/复核）' + (gbF.note || ' ');
                servoGb.push(gbF);
              }
            }
          }
        }
      }
    });
    /*



*/
    function acTierSync(r0T) {
      r0T = Number(r0T) || 0;
      return r0T >= 1200 ? 1500 : (r0T >= 850 ? 1000 : 750);
    }
    ac.sort(function (a, b) {
      var oc = (a.ac_over_cap != null ? 1 : 0) - (b.ac_over_cap != null ? 1 : 0);
      if (oc !== 0) return oc;
      /*
*/
      if (svLock && svLock.ratio) {
        return powerKw ? (a.power_kW - b.power_kW) : (a.torque_Nm - b.torque_Nm);
      }
      if (rpm) {
        var d = Math.abs(acTierSync(a.rpm) - rpm) - Math.abs(acTierSync(b.rpm) - rpm);
        if (d !== 0) return d;
      }
      return powerKw ? (a.power_kW - b.power_kW) : (a.torque_Nm - b.torque_Nm);
    });
    /*



*/
    function svIsSiemens(brand) { return /西门子|V90|S200|S120/i.test(String(brand || '')); }
    function svPrefList(brand) {
      var small = (powerKw !== null && powerKw !== undefined) ? (powerKw < SMALL_PWR_MAX + 1e-9) : false;
      var sie = svIsSiemens(brand);
      /*


*/
      if (small) return svDirect154 ? [1500, 3000] : [3000];
      return sie ? [2000, 3000] : [1500, 2000, 2500, 3000];
    }
    function svClassRank(rpm, brand) {
      var r = Number(rpm) || 0;
      var pref = svPrefList(brand);
      for (var i = 0; i < pref.length; i++) {
        if (Math.abs(r - pref[i]) < 1e-6) return i;
      }
      return 9;
    }
    function byKey(a, b) {
      var d = svClassRank(a.rpm, a.brand) - svClassRank(b.rpm, b.brand);
      if (d !== 0) return d;
      return powerKw ? (a.power_kW - b.power_kW) : (a.torque_Nm - b.torque_Nm);
    }
    servo.sort(byKey);
    /**/
    servoGb.sort(byKey);
    /*



*/
    if (sRpm > 0 && sRpm < SERVO_MIN_RPM - 1e-9 && !(svLock && svLock.ratio)) {
      var gAltLS = null, devAltLS = Infinity;
      GB_STD.forEach(function (gLS0) {
        var oLS0 = 300 / gLS0;
        if (oLS0 < sRpm / 1.2 - 1e-9 || oLS0 > sRpm * 1.2 + 1e-9) return;
        var dLS0 = Math.abs(oLS0 - sRpm);
        if (dLS0 < devAltLS - 1e-9) { devAltLS = dLS0; gAltLS = gLS0; }
      });
      if (gAltLS !== null) {
        var runAltLS = 300, outAltLS = runAltLS / gAltLS;
        var lsPool = servoGb.filter(function (r) { return r.lowspeed_gearbox && !r.lowspeed_alt; });
        if (lsPool.length) {
          var lsTop = lsPool.slice().sort(function (a, b) {
            if (smallMode) {
              var dA0 = smallPwrRank(a.power_kW) - smallPwrRank(b.power_kW);
              if (dA0 !== 0) return dA0;
              var dA1 = v220Rank(a) - v220Rank(b);
              if (dA1 !== 0) return dA1;
            }
            return (a.power_kW - b.power_kW) || (a.torque_Nm - b.torque_Nm);
          })[0];
          if (parseInt(String(lsTop.gearbox && lsTop.gearbox.ratio), 10) !== gAltLS) {
            var effAltLS = gbEffOf(gAltLS);
            var gbAltLS = JSON.parse(JSON.stringify(lsTop));
            gbAltLS.gearbox = { ratio: gAltLS + ':1', type: '行星减速机',
              out_rpm: Math.round(outAltLS * 10) / 10, eff: effAltLS };
            gbAltLS.lowspeed_gearbox = true;
            gbAltLS.lowspeed_alt = true;
            gbAltLS.alt_underspeed = true;
            gbAltLS.motor_run_rpm = runAltLS;
            gbAltLS.fit = '1.2';
            gbAltLS.within_10pct = false;
            gbAltLS.note = (gbAltLS.note ? gbAltLS.note + '；' : '')
              + '降速运行备选：配 ' + gAltLS + ':1 标准比，电机由驱动器调速到 ' + runAltLS
              + 'rpm 运行（降速比 10:1 口径），输出 ' + (Math.round(outAltLS * 10) / 10) + 'rpm（偏差 '
              + (outAltLS >= sRpm ? '+' : '') + (Math.round((outAltLS / sRpm - 1) * 1000) / 10) + '%，1.0~1.2 倍窗口内）'
              + (torque ? '，电机端需求扭矩 ' + fN(torque / (gAltLS * effAltLS), 2)
                + 'Nm，扭矩富余最大，降速运行利于电机寿命与噪音' : '');
            servoGb.push(gbAltLS);
          }
        }
      }
    }
    function famOf(b) { return servoFamOf(b.brand); }
    var directTop = [], seenD = {};
    servo.forEach(function (s) {
      var f = famOf(s);
      if (!seenD[f]) { seenD[f] = 1; directTop.push(s); }
    });
    var gbTop = [], seenG = {};
    servoGb.forEach(function (s) {
      var f = famOf(s);
      if (!seenG[f]) { seenG[f] = 1; gbTop.push(s); }
    });
    /*




*/
    var famOfRow = famOf;
    /**/
    var _pool = sinkTqTol(servo.concat(servoGb));
    /*

*/
    var _tierList = [];
    _pool.forEach(function (s) {
      var r0 = Number(s.rpm) || 0;
      if (r0 && _tierList.indexOf(r0) < 0) _tierList.push(r0);
    });
    _tierList.sort(function (a, b) { return a - b; });
    var _famSeq = [];
    _pool.forEach(function (s) { var f0 = famOfRow(s); if (_famSeq.indexOf(f0) < 0) _famSeq.push(f0); });
    var servoTop = [];
    _famSeq.forEach(function (f) {
      var rowsF = [];
      _tierList.forEach(function (T) {
        var cand = _pool.filter(function (s) { return famOfRow(s) === f && Number(s.rpm) === T; });
        if (!cand.length) return;
        cand.sort(function (a, b) {
          /*

*/
          if (smallMode && !svDirect154) {
            var dS0 = smallPwrRank(a.power_kW) - smallPwrRank(b.power_kW);
            if (dS0 !== 0) return dS0;
            var dS1 = v220Rank(a) - v220Rank(b);
            if (dS1 !== 0) return dS1;
          }
          /**/
          return (a.power_kW - b.power_kW)
            || ((a.alt_underspeed ? 1 : 0) - (b.alt_underspeed ? 1 : 0))
            || (a.torque_Nm - b.torque_Nm);
        });
        /*



*/
        if (!smallMode && powerKw !== null && powerKw !== undefined && cand[0].power_kW > powerKw * 2 - 1e-9) return;
        /*
*/
        if (smallMode) {
          var seenV = {};
          cand.forEach(function (sv) {
            if (sv.alt_underspeed) return;   /**/
            var k = String(sv.power_kW) + '|' + v220Rank(sv);
            sv._dup = !!seenV[k];
            seenV[k] = 1;
            sv._vAlt = false;
          });
        }
        /*



*/
        var pwSeen = [], pwCount = 0;
        cand.forEach(function (sv) {
          if (smallMode && sv._dup && !sv.alt_underspeed) return;
          var pwKey = String(sv.power_kW);
          var known = pwSeen.indexOf(pwKey) >= 0;
          if (!known) {
            if (pwCount >= 2) return;
            pwSeen.push(pwKey);
            pwCount++;
          } else if (!sv.alt_underspeed && !sv._vAlt) {
            return;   /**/
          }
          rowsF.push(sv);
        });
      });
      /*

*/
      rowsF.sort(function (a, b) {
        if (smallMode && !svDirect154) {
          var dS0 = smallPwrRank(a.power_kW) - smallPwrRank(b.power_kW);
          if (dS0 !== 0) return dS0;
          var dS1 = v220Rank(a) - v220Rank(b);
          if (dS1 !== 0) return dS1;
        }
        /**/
        if (svDirect154) {
          var dD0 = svClassRank(a.rpm, a.brand) - svClassRank(b.rpm, b.brand);
          if (dD0 !== 0) return dD0;
        }
        return (a.power_kW - b.power_kW)
          || (svClassRank(a.rpm, a.brand) - svClassRank(b.rpm, b.brand))
          || (Number(a.rpm) - Number(b.rpm));
      });
      rowsF.forEach(function (r) { servoTop.push(r); });
    });
    /*

*/
    if (smallMode) {
      var _keep15 = svDirect154 ? servoTop.filter(function (s) { return Number(s.rpm) === 1500; }) : [];
      var _only3k = servoTop.filter(function (s) { return Number(s.rpm) === 3000; });
      if (_only3k.length || _keep15.length) servoTop = _keep15.concat(_only3k);
    }
    /*
*/
    servoOver.sort(byKey);
    var seenO = {};
    servoTop.forEach(function (s) { seenO[famOf(s)] = 1; });
    servoOver.forEach(function (s) {
      var f = famOf(s);
      if (!seenO[f]) { seenO[f] = 1; servoTop.push(s); }
    });
    /*

*/
    if (data.servo_narrow !== false) {
      servoTop = servoTop.filter(function (s) {
        var f = famOf(s);
        return f === 'V90' || f === 'S200';
      });
    }
    /*



*/
    if (svLock && svLock.huRev) {
      var _pinRatio = svLock.huRev + ':1';
      var _byFam = {}, _famKeys = [], _outT = [];
      servoTop.forEach(function (s) {
        var f = famOf(s);
        if (!_byFam[f]) { _byFam[f] = []; _famKeys.push(f); }
        _byFam[f].push(s);
      });
      _famKeys.forEach(function (f) {
        var rows = _byFam[f];
        var main = rows.filter(function (s) {
          return !s.alt_underspeed && s.gearbox && s.gearbox.ratio === _pinRatio;
        });
        if (main.length) {
          _outT = _outT.concat(main, rows.filter(function (s) { return main.indexOf(s) < 0; }));
        } else {
          _outT = _outT.concat(rows);
        }
      });
      servoTop = _outT;
    }
    /*



*/
    var acTop = [];
    if (ac.length) {
      var _tierAc = acTierSync(ac[0].rpm);
      var _pw2Ac = (powerKw !== null && powerKw !== undefined) ? (powerKw * 2 + 1e-9) : null;
      for (var _iAc = 0; _iAc < ac.length && acTop.length < 3; _iAc++) {
        var _mAc = ac[_iAc];
        if (acTierSync(_mAc.rpm) !== _tierAc) continue;
        /*
*/
        if (_mAc._overList == null && _pw2Ac !== null && _mAc.power_kW > _pw2Ac) continue;
        acTop.push(_mAc);
      }
    }
    /*


*/
    if (!acTop.length && ac.length) {
      var _tierAcFb = acTierSync(ac[0].rpm);
      for (var _iAcF = 0; _iAcF < ac.length && acTop.length < 3; _iAcF++) {
        if (acTierSync(ac[_iAcF].rpm) !== _tierAcFb) continue;
        acTop.push(ac[_iAcF]);
      }
    }
    /*
*/
    if (wantKind === 'servo' && !servoTop.length) {
      var overRefs = [];
      var narrowO = (data.servo_narrow !== false);   /**/
      [2000, 3000].forEach(function (rv) {
        var pool = [];
        lib.forEach(function (mm) {
          if (motorKind(mm) !== 'servo' || Number(mm.rpm) !== rv) return;
          if (narrowO) {
            var fO = servoFamOf(mm.brand);
            if (fO !== 'V90' && fO !== 'S200') return;
          }
          if (!servoRpmAllowed(mm.power_kW, mm.rpm, mm.brand)) return;
          pool.push(mm);
        });
        if (!pool.length) return;
        /*

*/
        pool.sort(function (a2, b2) {
          return Math.abs(a2.power_kW - powerKw) - Math.abs(b2.power_kW - powerKw);
        });
        var t2 = pool[0];
        /*

*/
        var brakeRaw2 = gv(t2, 'brake', '');
        overRefs.push({
          brand: t2.brand, code: t2.code, kind: 'servo', poles: gv(t2, 'poles', null),
          power_kW: t2.power_kW, rpm: t2.rpm, torque_Nm: t2.torque_Nm,
          current_A: gv(t2, 'current_A', null), frame: gv(t2, 'frame', ''),
          flange: gv(t2, 'flange', ''), voltage: gv(t2, 'voltage', ''),
          ip: gv(t2, 'ip', ''), insulation: gv(t2, 'insulation', ''),
          brake: (typeof brakeRaw2 === 'string') ? brakeRaw2 : (brakeRaw2 ? '内置抱闸可选配' : ''),
          fit: 'over', within_10pct: false,
          /*
*/
          gearbox: (function () {
            /*


*/
            if (svLock && svLock.huRev) {
              var giH2 = null;
              (svLock.revList || [1, 2, 3, 5, 6, 8, 10]).forEach(function (rvH2) {
                var oH2 = rv / rvH2;
                if (oH2 >= sRpm - 1e-9 && oH2 <= sRpm * 1.2 + 1e-9 && oH2 <= JACK_IN_MAX + 1e-9) {
                  if (giH2 === null || rvH2 > giH2) giH2 = rvH2;
                }
              });
              if (giH2 === null) {
                (svLock.revList || [1, 2, 3, 5, 6, 8, 10]).forEach(function (rvH3) {
                  var oH3 = rv / rvH3;
                  if (oH3 >= sRpm * 0.8 - 1e-9 && oH3 < sRpm - 1e-9 && oH3 <= JACK_IN_MAX + 1e-9) {
                    if (giH2 === null || oH3 > (rv / giH2)) giH2 = rvH3;
                  }
                });
              }
              return (giH2 !== null)
                ? { ratio: giH2 + ':1', type: '伞齿轮换向器', out_rpm: Math.round(rv / giH2), eff: 1 }
                : null;
            }
            /*
*/
            var giO = pickGbRatioEx(rv, sRpm, true).i;
            return (giO !== null && rv / giO >= sRpm / 1.2 - 1e-9)
              ? { ratio: giO + ':1', type: '行星减速机', out_rpm: Math.round(rv / giO), eff: gbEffOf(giO) }
              : null;
          })(),
          /*
*/
          note: (t2.power_kW < powerKw - 1e-9
            ? '库内 ' + iN(rv) + 'rpm 无完全适用真机型，此为最后参考档：额定 ' + t2.power_kW + 'kW 较需求 ' + (Math.round(powerKw * 100) / 100) + 'kW 差 ' + Math.round((1 - t2.power_kW / powerKw) * 1000) / 10 + '%，需与厂家确认更大机座号或调整方案'
            : '所需功率/扭矩超出库内 ' + iN(rv) + 'rpm 伺服最大档（' + t2.power_kW + 'kW），此为最接近参考档，需与厂家确认更大机座号或调整方案'),
        });
      });
      return applyBrakePolicy(overRefs, needBrake);
    }
    /*




*/
    /*
*/
    var _rowsDec = (wantKind === 'servo') ? servoTop : acTop.concat(servoTop);
    _rowsDec.forEach(function (rr) {
      ['gearbox', 'lowspeed_gearbox', 'lowspeed_alt'].forEach(function (k) {
        var gb = rr[k];
        if (gb && !gb.planet && /行星减速机/.test(String(gb.type || ''))) {
          var rNum = parseFloat(String(gb.ratio));
          /**/
        gb.planet = planetPickOf(data, rNum, rr.torque_Nm, rr.rpm, motorShaftOf(rr));
        }
      });
    });
    /**/
    return applyBrakePolicy(sinkTqTol((wantKind === 'servo') ? servoTop : acTop.concat(servoTop)), needBrake);
  }

  /*


*/
  function servoBrandLockOf(inp) {
    if (String((inp && inp.drive) || '').indexOf('servo') !== 0) return null;
    /**/
    if (servoBrandPickOf(inp).indexOf('S120') >= 0) return 'S120';
    var sp = (inp && inp.special) || [];
    var hasBrandReq = false;
    for (var i = 0; i < sp.length; i++) {
      if (String(sp[i]).indexOf('brand_servo') === 0) { hasBrandReq = true; break; }
    }
    if (!hasBrandReq) return null;
    var txt = '';
    try { txt = String(((inp && inp.special_texts) || {}).brand_servo || ''); } catch (e) {}
    if (/S120/i.test(txt)) return 'S120';
    return null;
  }
  /*


*/
  var SERVO_BRAND_KEYS = ['汇川', 'V90', 'S200', 'S120', '台达', '雷赛', '惠斯通'];
  function servoBrandPickOf(inp) {
    if (String((inp && inp.drive) || '').indexOf('servo') !== 0) return [];
    var arr = (inp && inp.servo_brand) || [];
    if (!Array.isArray(arr)) return [];
    var out = [];
    arr.forEach(function (v) {
      var k = String(v || '').trim();
      var std = null;
      SERVO_BRAND_KEYS.forEach(function (x) { if (!std && x.toLowerCase() === k.toLowerCase()) std = x; });
      if (std && out.indexOf(std) < 0) out.push(std);
    });
    return out;
  }
  /**/
  function servoFamOf(brand) {
    var br = String(brand || '');
    if (br.indexOf('V90') >= 0) return 'V90';
    if (br.indexOf('S200') >= 0) return 'S200';
    if (br.indexOf('S120') >= 0) return 'S120';
    return br.split(/[\s（(]/)[0] || br;
  }
  /*





*/
  function motorLibData(inp, data) {
    var lock = servoBrandLockOf(inp);
    var pick = servoBrandPickOf(inp);
    var spArr = (inp && Array.isArray(inp.special)) ? inp.special : [];
    /*





*/
    /*

*/
    var seUp201 = String(inp && inp.series || '').toUpperCase();
    var ehaTrap201 = (seUp201 === 'EHB' && Number(inp && inp.precision_mm) === 0.1);
    var isBevelCase = /^(EHB|DHB)/i.test(String(inp && inp.model || ''))
      || (/^(EHB|DHB)$/.test(seUp201) && !ehaTrap201);
    var wantBrake = isBevelCase || !!(inp && (inp.wantBrake || inp.acBrake || inp.ac_brake))
      || spArr.indexOf('ac_brake') >= 0;
    var lib = (data && data.motor_library) || [];
    var filtered = lib.filter(function (m) {
      /*
*/
      var kind = m.kind || (String(m.brand || '').indexOf('交流') === 0 ? 'ac' : 'servo');
      if (kind === 'ac') {
        if (pick.length) return false;
        var isEJ = /YE3EJ|电磁制动/.test(String(m.brand || ''));
        return wantBrake ? isEJ : !isEJ;
      }
      /**/
      if (isBevelCase && /不带制动|无抱闸|不带抱闸|详见样本/.test(String(gv(m, 'brake', '') || ''))) return false;
      var fam = servoFamOf(m.brand);
      var isS120 = fam === 'S120';
      var isHST = fam === '惠斯通';
      if (lock === 'S120') return isS120;
      if (isS120) return false;
      if (pick.length) return pick.indexOf(fam) >= 0;
      if (isHST) return false;   /**/
      return true;
    });
    /*
*/
    return { motor_library: filtered, servo_narrow: !(lock === 'S120' || pick.length) };
  }
  function applyServoBrandLock(motors, inp, pw, tq, rpm) {
    if (servoBrandLockOf(inp) !== 'S120') return motors;
    if (motors && motors.length) return motors;   /**/
    return [{
      brand: '西门子 S120', code: 'S120 配套伺服电机（1FK7 / 1FT6 等）', kind: 'servo',
      power_kW: pw != null ? r(pw, 2) : null, rpm: rpm || null,
      torque_Nm: tq != null ? r(tq, 1) : null,
      current_A: null, frame: '按 S120 电机接口', flange: '按 S120 电机接口',
      voltage: 'SINAMICS S120 驱动系统', ip: '—', insulation: '—',
      brake: '抱闸可选配', fit: 'over', within_10pct: false, gearbox: null,
      note: '特殊要求指定西门子 S120：伺服电机只能匹配 S120，V90（1FL6）/ S200（1FL2）均不适用；'
        + '本行功率/扭矩/转速为需求值，具体型号按 S120 支持的电机系列（1FK7 / 1FT6 等）用西门子 S120 选型工具细化'
    }];
  }

  /**/
  function calcRouteA(inp, data, warnings) {
    var models = data.models, model = inp.model;
    if (!Object.prototype.hasOwnProperty.call(models, model)) throw Missing('参数库无型号 ' + model);
    var m = models[model];
    var ratioKeys = Object.keys(m.ratio_options || {});
    var ratioKey = inp.ratio_key || (ratioKeys.length ? ratioKeys[0] : null);
    if (!ratioKey) throw Missing('型号 ' + model + ' 无速比档数据');
    var opt = m.ratio_options[ratioKey];
    if (isTodo(opt.max_input_power_kW)) warnings.push('型号 ' + model + ' ' + ratioKey + ' 档最大输入功率待补全');
    var isHand = inp.drive === 'hand';   /**/
    var ov = inp.overrides || {};
    var steps = [];

    var units = inp.units;
    var totalKn = inp.total_load_kN;
    /*
*/
    var pullT = Number(inp.load_pull_t) || 0;
    var pushKn = (inp.load_push_kN != null) ? Number(inp.load_push_kN) : null;
    var f1 = totalKn / units;
    steps.push(['单台负载', (pullT > 0 && pushKn != null
      ? '推力 ' + fN(pushKn, 1) + 'kN / 拉力 ' + fN(pullT * 9.81, 1) + 'kN，按大者（'
        + (pullT * 9.81 > pushKn ? '拉力' : '推力') + '）' + fN(totalKn, 1) + 'kN'
      : '总负载 ' + fN(totalKn, 1) + 'kN')
      + ' ÷ ' + iN(units) + ' 台 = ' + fN(f1, 2) + 'kN']);

    var rated = m.rated_load_kN;
    if (isTodo(rated)) throw Missing('型号 ' + model + ' 额定载荷待补全');
    /**/
    var fCoef = floorCoefOf(model);
    var floor = (typeof rated === 'number') ? fCoef * rated : null;
    var floorPct = iN(Math.round(fCoef * 100)) + '%';
    var fEff;
    if (floor && f1 < floor && !ov.skip_floor) {
      fEff = floor;
      steps.push([floorPct + '动载率下限', '载荷 ' + fN(f1, 2) + 'kN 小于额定载荷 ' + fN(rated, 0) + 'kN 的 ' + floorPct + '（'
        + fN(floor, 1) + 'kN），故推力按 ' + fN(fEff, 1) + 'kN 计算'
        + (fCoef === 0.15 ? '（滚珠丝杠下限 15%）' : '')]);
    } else {
      fEff = f1;
      steps.push([floorPct + '动载率下限', '载荷 ' + fN(f1, 2) + 'kN ≥ 额定载荷 ' + fN(rated, 0) + 'kN 的 ' + floorPct + '，按实际载荷计算']);
    }

    var v = inp.speed_mm_s;
    /*

*/
    var rpmSync = (inp.motor_rpm !== null && inp.motor_rpm !== undefined) ? Number(inp.motor_rpm) : 1500;
    var SYNC2ACT = { 3000: 2800, 1500: 1400, 1000: 900, 750: 700 };
    /*
*/
    var rpm = (inp.drive === 'dc24') ? rpmSync : (SYNC2ACT[rpmSync] || rpmSync);
    var mmPerRev = opt.mm_per_rev;
    var vActual = rpm / 60 * mmPerRev;
    /*







*/
    var vDirect = vActual, planet = 1, planetEff = 1, planetTxt = '', poleTxt = '';
    var acFixed = (inp.drive === 'ac3' || inp.drive === 'ac1' || inp.drive === 'none');
    /*


*/
    var isServo = (inp.drive === 'servo220' || inp.drive === 'servo380');
    var rpmPostPlanet = false, svAltPlans = [], svForcedLeg = false, svLowSpeed = false, svChanger = false, svDirect154 = false;   /**/
    /*





*/
    var REV83 = [1, 2, 3, 4, 5, 6, 8, 10];
    /**/
    var huFixed149 = false, huFbk149 = false;
    /*
*/
    var svAdj230 = false, svKwRated230 = null;
    var huRevSv = 1;
    if (!isHand && isServo && v > 0) {
      var rpmNeedSv = Math.round(v * 60 / mmPerRev);
      /*

*/
      function tqSvOf(rpmRun) {
        var vAE = rpmRun / 60 * mmPerRev;
        var pOutE = fEff * vAE;                        /**/
        var etaE = ov.efficiency;
        if ((etaE === null || etaE === undefined) && typeof opt.eff_running_1500rpm === 'number') etaE = opt.eff_running_1500rpm;
        if (etaE === null || etaE === undefined) etaE = C.pickEfficiency(m, fEff);
        if ((ov.efficiency === null || ov.efficiency === undefined) && rpmRun) {
          var fRpmE = C.speedEffFactor(data, model, m, rpmRun);
          if (fRpmE !== null && fRpmE !== undefined && Math.abs(fRpmE - 1) > 1e-9) etaE = etaE * fRpmE;
        }
        var pInCalcE = pOutE / etaE * envCoefOf(inp.ambient_temp) * (hasVacuumGrease(inp.special) ? 2 : 1);
        var layoutE = (inp && inp.layout !== null && inp.layout !== undefined) ? inp.layout : null;
        var isCLayE = String(layoutE) === '直线布置' && [4, 6, 8].indexOf(units) >= 0;
        var stagesE = (ov.stages !== null && ov.stages !== undefined) ? ov.stages
          : ((layoutE === null) ? 3
            : (/^(H型|U2型|U型)/.test(String(layoutE)) ? Math.max(1, (dualShaftA ? Math.min(2, units - 1) : (units >= 4 ? 3 : units - 1)))
              : (isInlineLayout(String(layoutE)) ? (isMidMotorLayout(String(layoutE)) ? 1 : (isCLayE ? (dualShaftA ? 0 : 1) : 0)) : 2)));
        if (units > 1) {
          /**/
          if (inp.sync === '电气') return 9550 * (pInCalcE / 1000) * 1.5 / rpmRun;
          var comboE = gv(ov, 'combo_coef', comboCoefOf(units));
          var revE = gv(ov, 'reverse_eff', 0.9);
          var divE = C.evalDivisor(ov.custom_divisor, comboE * Math.pow(revE, stagesE));
          var ampE = gv(ov, 'amp_coef', ampCoefOfEx(units, model, (rated > 0) ? f1 / rated : null, inp.ambient_temp));
          return 9550 * (pInCalcE / 1000 * units / divE) * ampE / rpmRun;
        }
        return 9550 * (pInCalcE / 1000) / rpmRun;
      }
      /*

*/
      function ratedKw230(screwRpmRated) {
        if (!screwRpmRated || screwRpmRated <= 0) return null;
        var vRE = screwRpmRated / 60 * mmPerRev;
        var pOutE = fEff * vRE;
        var etaE = ov.efficiency;
        if ((etaE === null || etaE === undefined) && typeof opt.eff_running_1500rpm === 'number') etaE = opt.eff_running_1500rpm;
        if (etaE === null || etaE === undefined) etaE = C.pickEfficiency(m, fEff);
        if ((ov.efficiency === null || ov.efficiency === undefined) && screwRpmRated) {
          var fRE = C.speedEffFactor(data, model, m, screwRpmRated);
          if (fRE !== null && fRE !== undefined && Math.abs(fRE - 1) > 1e-9) etaE = etaE * fRE;
        }
        var pInE = pOutE / etaE * envCoefOf(inp.ambient_temp) * (hasVacuumGrease(inp.special) ? 2 : 1);
        if (units > 1 && inp.sync === '电气') return pInE / 1000 * 1.5;
        if (units > 1) {
          var layoutE2 = (inp && inp.layout !== null && inp.layout !== undefined) ? inp.layout : null;
          var isCLayE2 = String(layoutE2) === '直线布置' && [4, 6, 8].indexOf(units) >= 0;
          var stagesE2 = (ov.stages !== null && ov.stages !== undefined) ? ov.stages
            : ((layoutE2 === null) ? 3
              : (/^(H型|U2型|U型)/.test(String(layoutE2)) ? Math.max(1, (dualShaftA ? Math.min(2, units - 1) : (units >= 4 ? 3 : units - 1)))
                : (isInlineLayout(String(layoutE2)) ? (isMidMotorLayout(String(layoutE2)) ? 1 : (isCLayE2 ? (dualShaftA ? 0 : 1) : 0)) : 2)));
          var comboE2 = gv(ov, 'combo_coef', comboCoefOf(units));
          var revE2 = gv(ov, 'reverse_eff', 0.9);
          var divE2 = C.evalDivisor(ov.custom_divisor, comboE2 * Math.pow(revE2, stagesE2));
          var ampE2 = gv(ov, 'amp_coef', ampCoefOfEx(units, model, (rated > 0) ? f1 / rated : null, inp.ambient_temp));
          return pInE / 1000 * units / divE2 * ampE2;
        }
        return pInE / 1000;
      }
      var svCand = [];
      /*
*/
      var svForced = Number(inp.servo_rated) || 0;
      /*


*/
      var svMd = motorLibData(inp, data);
      var svLib = svMd.motor_library || [];
      var svNarrow = svMd.servo_narrow !== false;   /**/
      /**/
      var svRpms = [1500, 2000, 2500, 3000].filter(function (rv) {
            return svLib.some(function (mm) {
              if (motorKind(mm) !== 'servo' || Number(mm.rpm) !== rv) return false;
              if (svNarrow) { var fSv = servoFamOf(mm.brand); return fSv === 'V90' || fSv === 'S200'; }
              return true;
            });
          });
      if (svForced > 0 && svRpms.indexOf(svForced) < 0) svRpms.push(svForced);
      /**/
      var svLockTiers = svForced > 0 ? [svForced] : svRpms;
      svRpms.forEach(function (rv) {
        /**/
        var giX = pickGbRatioEx(rv, rpmNeedSv, true);
        if (giX.i !== null && rv / giX.i >= rpmNeedSv / 1.2 - 1e-9)
          svCand.push({ r: rv, i: giX.i, out: rv / giX.i, neg: giX.neg });
      });
      /*








*/
      [1500, 2000, 3000].forEach(function (rDc) {
        if (svRpms.indexOf(rDc) < 0) return;
        if (!(rpmNeedSv >= 0.8 * rDc - 1e-9 && rpmNeedSv <= Math.min(rDc, JACK_IN_MAX) + 1e-9)) return;
        var tqDc = tqSvOf(rpmNeedSv);
        var pDc = tqDc * rpmNeedSv / 9550;   /**/
        var hasDc = svLib.some(function (mm) {
          if (motorKind(mm) !== 'servo' || Number(mm.rpm) !== rDc) return false;
          if (svNarrow) { var fDc = servoFamOf(mm.brand); if (fDc !== 'V90' && fDc !== 'S200') return false; }
          return (Number(mm.torque_Nm) || 0) >= tqDc - 1e-9
            && (Number(mm.power_kW) || 0) <= pDc * 2 + 1e-9;
        });
        if (hasDc) svCand.push({ r: rDc, i: 1, out: rpmNeedSv, neg: false, direct: true, tq: tqDc });
      });
      rpmSync = null;
      var svRatedUsed = null;
      /*

*/
      var huServoRev = null;
      /*


*/
      var isBevelFam = /^(EHB|EHA|DHB)/i.test(String(model || ''));
      var huLayoutNow = (Number(units) || 1) >= 2
        && /电机中间|导向柱一体化|H型|U2型|U型/.test(String(inp.layout || ''));
      if (!isBevelFam && huLayoutNow) {
        /*




*/
        svLockTiers.forEach(function (rr) {
          REV83.forEach(function (rv) {
            if (rv === 1 && rr > JACK_IN_MAX + 1e-9) return;
            var o = (rr / rv / rpmNeedSv - 1) * 100;
            if (o <= 20 + 1e-9 && o >= -20 - 1e-9) {
              var grp = (o >= -1e-9) ? 0 : 1;
              var ao = Math.abs(o);
              if (!huServoRev || grp < huServoRev.grp
                || (grp === huServoRev.grp
                  && (ao < Math.abs(huServoRev.o) - 1e-9
                    || (Math.abs(ao - Math.abs(huServoRev.o)) <= 1e-9
                      && (rr < huServoRev.r || (rr === huServoRev.r && rv > huServoRev.rv))))))
                huServoRev = { rv: rv, r: rr, o: o, grp: grp };
            }
          });
        });
      }
      /*









*/
      var lsChanger = null;
      if (!isHand && isServo && !huLayoutNow && mmPerRev > 0 && rpmNeedSv > 0
        && rpmNeedSv <= 3000 / 10 + 1e-9) {
        var tqLS = (function () {
          var vAE = rpmNeedSv / 60 * mmPerRev;
          var pOutE = fEff * vAE;
          var etaE = ov.efficiency;
          if ((etaE === null || etaE === undefined) && typeof opt.eff_running_1500rpm === 'number') etaE = opt.eff_running_1500rpm;
          if (etaE === null || etaE === undefined) etaE = C.pickEfficiency(m, fEff);
          if ((ov.efficiency === null || ov.efficiency === undefined) && rpmNeedSv) {
            var fRpmE = C.speedEffFactor(data, model, m, rpmNeedSv);
            if (fRpmE !== null && fRpmE !== undefined && Math.abs(fRpmE - 1) > 1e-9) etaE = etaE * fRpmE;
          }
          var pInCalcE = pOutE / etaE * envCoefOf(inp.ambient_temp) * (hasVacuumGrease(inp.special) ? 2 : 1);
          var layoutE = (inp && inp.layout !== null && inp.layout !== undefined) ? inp.layout : null;
          var isCLayE = String(layoutE) === '直线布置' && [4, 6, 8].indexOf(units) >= 0;
          var stagesE = (ov.stages !== null && ov.stages !== undefined) ? ov.stages
            : ((layoutE === null) ? 3
              : (/^(H型|U2型|U型)/.test(String(layoutE)) ? Math.max(1, (dualShaftA ? Math.min(2, units - 1) : (units >= 4 ? 3 : units - 1)))
                : (isInlineLayout(String(layoutE)) ? (isMidMotorLayout(String(layoutE)) ? 1 : (isCLayE ? (dualShaftA ? 0 : 1) : 0)) : 2)));
          if (units > 1) {
            var comboE = gv(ov, 'combo_coef', comboCoefOf(units));
            var revE = gv(ov, 'reverse_eff', 0.9);
            var divE = C.evalDivisor(ov.custom_divisor, comboE * Math.pow(revE, stagesE));
            var ampE = gv(ov, 'amp_coef', ampCoefOfEx(units, model, (rated > 0) ? f1 / rated : null, inp.ambient_temp));
            return 9550 * (pInCalcE / 1000 * units / divE) * ampE / rpmNeedSv;
          }
          return 9550 * (pInCalcE / 1000) / rpmNeedSv;
        })();
        var REV_LS = [1, 2, 3, 4, 5, 6, 8, 10];
        var _mdLS = motorLibData(inp, data) || {};
        var _libLS = _mdLS.motor_library || [];
        var _narrowLS = (_mdLS.servo_narrow !== false);
        for (var piLS = 0; piLS < SMALL_PWR_ORDER.length && lsChanger === null; piLS++) {
          var pLS = SMALL_PWR_ORDER[piLS], tMinLS = null;
          _libLS.forEach(function (mmLS) {
            if (motorKind(mmLS) !== 'servo' || Math.abs(mmLS.power_kW - pLS) > 1e-6) return;
            if (!servoRpmAllowed(mmLS.power_kW, mmLS.rpm, mmLS.brand)) return;
            if (_narrowLS) { var fLS = servoFamOf(mmLS.brand); if (fLS !== 'V90' && fLS !== 'S200') return; }
            if (tMinLS === null || mmLS.torque_Nm < tMinLS) tMinLS = mmLS.torque_Nm;
          });
          if (tMinLS === null) continue;
          for (var riLS = 0; riLS < REV_LS.length; riLS++) {
            var rvLS = REV_LS[riLS];
            var runLS = rpmNeedSv * rvLS;
            if (runLS < SERVO_MIN_RPM - 1e-9) continue;          /**/
            if (runLS > 3000 / rvLS + 1e-9) continue;            /**/
            if (tqLS / (rvLS * 0.9) <= tMinLS + 1e-9) { lsChanger = { rv: rvLS, p: pLS }; break; }
          }
        }
      }
      /*









*/
      if (!isHand && isServo && v > 0 && huLayoutNow && !isBevelFam) {
        var tqHU = (function () {
          var vAE = rpmNeedSv / 60 * mmPerRev;
          var pOutE = fEff * vAE;
          var etaE = ov.efficiency;
          if ((etaE === null || etaE === undefined) && typeof opt.eff_running_1500rpm === 'number') etaE = opt.eff_running_1500rpm;
          if (etaE === null || etaE === undefined) etaE = C.pickEfficiency(m, fEff);
          if ((ov.efficiency === null || ov.efficiency === undefined) && rpmNeedSv) {
            var fRpmE = C.speedEffFactor(data, model, m, rpmNeedSv);
            if (fRpmE !== null && fRpmE !== undefined && Math.abs(fRpmE - 1) > 1e-9) etaE = etaE * fRpmE;
          }
          var pInCalcE = pOutE / etaE * envCoefOf(inp.ambient_temp) * (hasVacuumGrease(inp.special) ? 2 : 1);
          var layoutE = (inp && inp.layout !== null && inp.layout !== undefined) ? inp.layout : null;
          var isCLayE = String(layoutE) === '直线布置' && [4, 6, 8].indexOf(units) >= 0;
          var stagesE = (ov.stages !== null && ov.stages !== undefined) ? ov.stages
            : ((layoutE === null) ? 3
              : (/^(H型|U2型|U型)/.test(String(layoutE)) ? Math.max(1, (dualShaftA ? Math.min(2, units - 1) : (units >= 4 ? 3 : units - 1)))
                : (isInlineLayout(String(layoutE)) ? (isMidMotorLayout(String(layoutE)) ? 1 : (isCLayE ? (dualShaftA ? 0 : 1) : 0)) : 2)));
          if (units > 1) {
            var comboE = gv(ov, 'combo_coef', comboCoefOf(units));
            var revE = gv(ov, 'reverse_eff', 0.9);
            var divE = C.evalDivisor(ov.custom_divisor, comboE * Math.pow(revE, stagesE));
            var ampE = gv(ov, 'amp_coef', ampCoefOfEx(units, model, (rated > 0) ? f1 / rated : null, inp.ambient_temp));
            return pInCalcE / 1000 * units / divE * ampE;
          }
          return pInCalcE / 1000;
        })();
        /*
*/
        var libHU = svLib.filter(function (mm) {
          if (motorKind(mm) !== 'servo') return false;
          if (svNarrow) { var fSv = servoFamOf(mm.brand); return fSv === 'V90' || fSv === 'S200'; }
          return true;
        });
        /*



*/
        var tiers158 = (svForced > 0 || tqHU > SMALL_PWR_MAX + 1e-9) ? svLockTiers : [3000];
        var best158 = null, fbk158 = null;
        for (var iT158 = 0; iT158 < tiers158.length; iT158++) {
          var rrF = tiers158[iT158];
          for (var iv158 = 0; iv158 < REV158.length; iv158++) {
            var rvF = REV158[iv158];
            var runF = rpmNeedSv * rvF;
            if (runF > rrF * 1.002 + 1e-6 || runF < SERVO_MIN_RPM - 1e-9) continue;   /**/
            var tReqF = 9550 * tqHU / runF;
            var hasMF = libHU.some(function (mm) {
              if (Number(mm.rpm) !== rrF) return false;
              var p0 = Number(mm.power_kW) || 0;
              /*


*/
              if (!servoRpmAllowed(p0, rrF, mm.brand)) return false;
              return p0 >= tqHU - 1e-9 && p0 <= tqHU * 2 + 1e-9 && (Number(mm.torque_Nm) || 0) >= tReqF - 1e-9;
            });
            if (!hasMF) continue;
            var devF = 1 - runF / rrF;   /**/
            var cd158 = { rv: rvF, r: rrF, o: 0, grp: 0, fixed: true, run: runF, dev: devF };
            if (devF <= 0.2 + 1e-9) {
              if (!best158 || devF < best158.dev - 1e-9
                || (Math.abs(devF - best158.dev) <= 1e-9 && rrF < best158.r)) best158 = cd158;
            } else if (!fbk158 || devF < fbk158.dev - 1e-9
              || (Math.abs(devF - fbk158.dev) <= 1e-9 && rrF < fbk158.r)) fbk158 = cd158;
          }
        }
        if (best158 || fbk158) {
          huServoRev = best158 || fbk158;   /**/
          huFixed149 = true;
          huFbk149 = !best158;
        } else if (huServoRev) {
          huServoRev.fbk = true;   /**/
          huFbk149 = true;
        }
      }
      if (huServoRev) {
        huRevSv = huServoRev.rv;
        /*
*/
        /*
*/
        svKwRated230 = huServoRev.fixed ? ratedKw230(huServoRev.r / huRevSv) : null;
        svAdj230 = !!(huServoRev.fixed && !huFbk149 && svKwRated230 !== null && svKwRated230 > 0.4 + 1e-9);
        rpm = (huServoRev.fixed && svAdj230) ? huServoRev.r
          : (huServoRev.fixed ? huServoRev.run : huServoRev.r);
        vActual = rpm / huRevSv / 60 * mmPerRev;
        svRatedUsed = huServoRev.r;
        rpmPostPlanet = true;
        svAltPlans = [];
      } else if (lsChanger) {
        /**/
        planet = lsChanger.rv;
        planetEff = 0.9;                          /**/
        svChanger = true;
        svLowSpeed = true;                        /**/
        rpmPostPlanet = true;
        svAltPlans = [];
        rpm = rpmNeedSv;
        vActual = rpm / 60 * mmPerRev;
        planetTxt = '伺服低速工况：所需输入转速 ' + iN(rpmNeedSv) + 'rpm，伺服电机 30~3000rpm 任意调速'
          + ' —— 电机端配换向器减速比 1:' + planet + '（效率 ' + fN(planetEff, 2)
          + '，该速比额定输入转速 ' + iN(3000 / planet) + 'rpm、允许 ' + fN(30 / planet, 0) + '~'
          + iN(3000 / planet) + 'rpm），电机由驱动器调速到 ' + iN(rpmNeedSv * planet)
          + 'rpm 运行（落在允许域内），输出速度 ' + fN(vActual, 2) + 'mm/s 即为要求值；电机端扭矩 '
          + fN(tqLS / (planet * 0.9), 2) + 'Nm ≤ 电机额定扭矩，扭矩合格'
          + (lsChanger.p !== null && lsChanger.p !== undefined
            ? '（按性价比序 ' + iN(lsChanger.p * 1000) + 'W 档独立配比取最小可行比）' : '');
      } else if (isServo && !huLayoutNow && mmPerRev
        && rpmNeedSv > 0 && rpmNeedSv < SERVO_MIN_RPM - 1e-9) {
        /*


*/
        /*


*/
        var tqJackLS = tqSvOf(rpmNeedSv);
        var _mdLS = motorLibData(inp, data) || {};
        var _libLS = _mdLS.motor_library || [];
        var _narrowLS = (_mdLS.servo_narrow !== false);   /**/
        var giLSv = null, pPickLS = null;
        for (var piLS = 0; piLS < SMALL_PWR_ORDER.length && giLSv === null; piLS++) {
          var pLS = SMALL_PWR_ORDER[piLS], tMinLS = null;
          _libLS.forEach(function (mmLS) {
            if (motorKind(mmLS) !== 'servo' || Math.abs(mmLS.power_kW - pLS) > 1e-6) return;
            if (!servoRpmAllowed(mmLS.power_kW, mmLS.rpm, mmLS.brand)) return;
            if (_narrowLS) { var fLS = servoFamOf(mmLS.brand); if (fLS !== 'V90' && fLS !== 'S200') return; }
            if (tMinLS === null || mmLS.torque_Nm < tMinLS) tMinLS = mmLS.torque_Nm;
          });
          if (tMinLS === null) continue;
          for (var siLSv = 0; siLSv < GB_STD.length; siLSv++) {
            var gLSv = GB_STD[siLSv];
            if (rpmNeedSv * gLSv < SERVO_MIN_RPM - 1e-9) continue;
            var eLSv = gbEffOf(gLSv);
            if (tqJackLS / (gLSv * eLSv) <= tMinLS + 1e-9) { giLSv = gLSv; pPickLS = pLS; break; }
          }
        }
        if (giLSv === null) {
          /**/
          for (var siLSf = 0; siLSf < GB_STD.length; siLSf++) {
            if (rpmNeedSv * GB_STD[siLSf] >= SERVO_MIN_RPM - 1e-9) { giLSv = GB_STD[siLSf]; break; }
          }
        }
        if (giLSv !== null) {
          planet = giLSv;
          planetEff = gbEffOf(planet);
          /*
*/
          rpmPostPlanet = true;
          svLowSpeed = true;
          svAltPlans = [];
          rpm = rpmNeedSv;
          vActual = rpm / 60 * mmPerRev;
          planetTxt = '伺服极低速工况：所需输入转速 ' + iN(rpmNeedSv) + 'rpm 低于伺服稳定调速下限 '
            + SERVO_MIN_RPM + 'rpm，直连不可用 —— 配行星减速机 i=' + planet + ':1（效率 '
            + fN(planetEff, 2) + '），电机由驱动器调速到 '
            + iN(rpmNeedSv * planet) + 'rpm 运行（30~3000rpm 稳定区内），输出速度 '
            + fN(vActual, 2) + 'mm/s 即为要求值'
            + (pPickLS !== null ? '（按性价比序 ' + iN(pPickLS * 1000) + 'W 档独立配比取最小可行比）' : '');
        }
      } else if (svCand.length) {
        /*
*/
        svCand.sort(function (a, b) {
          if (svForced > 0) {
            var fa = (a.r === svForced) ? 0 : 1, fb = (b.r === svForced) ? 0 : 1;
            if (fa !== fb) return fa - fb;
          }
          /**/
          if ((a.neg ? 1 : 0) !== (b.neg ? 1 : 0)) return (a.neg ? 1 : 0) - (b.neg ? 1 : 0);
          if (a.r !== b.r) return a.r - b.r;
          return Math.abs(a.out - rpmNeedSv) - Math.abs(b.out - rpmNeedSv);
        });
        planet = svCand[0].i;
        if (svCand[0].direct) {
          /**/
          svRatedUsed = svCand[0].r;
          svDirect154 = true;
          /*
*/
          svKwRated230 = ratedKw230(svCand[0].r);
          svAdj230 = !!(svKwRated230 !== null && svKwRated230 > 0.4 + 1e-9);
          rpm = svAdj230 ? svCand[0].r : rpmNeedSv;
          vActual = svAdj230 ? (svCand[0].r / 60 * mmPerRev) : v;
          svAltPlans = svCand.slice(1).filter(function (x) { return !x.direct; });   /**/
          planetTxt = svAdj230
            ? '伺服直连：额定口径需求功率 ' + fN(svKwRated230, 2) + 'kW > 400W，功率/速度按额定转速 '
            + iN(svCand[0].r) + 'rpm 满速口径计算（直连需求 ' + fN(svCand[0].tq, 2) + 'Nm），输出速度 '
            + fN(vActual, 2) + 'mm/s ≥ 要求 ' + fN(v, 2) + 'mm/s；实际运行由驱动器调速至 ' + iN(rpmNeedSv)
            + 'rpm 实现要求速度 —— 免配行星减速机、节约费用'
            : '伺服直连调速（第一选择）：库内 ' + iN(svCand[0].r) + 'rpm 档存在扭矩可行机型'
            + '（直连需求 ' + fN(svCand[0].tq, 2) + 'Nm），电机由驱动器调速到 ' + iN(rpmNeedSv) + 'rpm 直连运行（'
            + SERVO_MIN_RPM + '~' + iN(svCand[0].r) + 'rpm 恒扭矩区内），输出速度 ' + fN(v, 2)
            + 'mm/s 精确达速 —— 免配行星减速机、节约费用（直连调速为第一选择，配减速机为第二选择）';
        } else {
          planetEff = gbEffOf(planet);
          svRatedUsed = svCand[0].r;
          rpmPostPlanet = true;
          svAltPlans = svCand.slice(1);   /**/
          rpm = Math.round(svCand[0].r / planet);
          vActual = rpm / 60 * mmPerRev;
          planetTxt = '伺服电机额定 ' + iN(svCand[0].r) + 'rpm，按「额定转速 ÷ 所需输入转速 ' + iN(rpmNeedSv)
            + 'rpm」匹配行星减速机 i=' + planet + ':1（效率 ' + fN(planetEff, 2) + '）：升降机输入转速 '
            + iN(svCand[0].r) + '÷' + planet + ' = ' + iN(rpm) + 'rpm，输出速度 ' + fN(vActual, 2)
            + 'mm/s' + (svCand[0].neg
              ? '（要求 ' + fN(v, 2) + 'mm/s；本档正偏差域无解，需超额定转速弱磁运行达速、扭矩降额，须与厂家确认）'
              : '（要求 ' + fN(v, 2) + 'mm/s 的 1.0~1.2 倍口径内，电机恒扭矩区运行）');
        }
      } else if (rpmNeedSv > JACK_IN_MAX + 1e-9) {
        /*

*/
        var bestF = null;
        svLockTiers.forEach(function (rv) {
          var giF = null;
          for (var si = 0; si < GB_STD.length; si++) {
            if (rv / GB_STD[si] <= JACK_IN_MAX + 1e-9) { giF = GB_STD[si]; break; }
          }
          if (giF === null) return;
          var outF = rv / giF;
          if (!bestF || outF > bestF.out + 1e-9) bestF = { r: rv, i: giF, out: outF };
        });
        if (bestF) {
          planet = bestF.i;
          planetEff = gbEffOf(planet);
          svRatedUsed = bestF.r;
          rpmPostPlanet = true;
          svForcedLeg = true;
          svAltPlans = [];
          rpm = Math.round(bestF.r / planet);
          vActual = rpm / 60 * mmPerRev;
          planetTxt = '所需输入转速 ' + iN(rpmNeedSv) + 'rpm 超出升降机最大输入转速 1500rpm（2026-10-25 定稿），'
            + '直连禁用、匹配行星减速机 i=' + planet + ':1（效率 ' + fN(planetEff, 2) + '）：升降机输入转速 '
            + iN(bestF.r) + '÷' + planet + ' = ' + iN(rpm) + 'rpm，输出速度 ' + fN(vActual, 2)
            + 'mm/s 低于要求 ' + fN(v, 2) + 'mm/s（速度校核如实判定，工况需加大导程/调整）';
        } else {
          rpm = rpmNeedSv;
          vActual = v;
        }
      } else {
        rpm = rpmNeedSv;
        vActual = v;
      }
    }
    /*


*/
    var huPlan = null, huRev = 1, huNote = '';
    if (huRevSv > 1) huRev = huRevSv;   /**/
    /*

*/
    if (!isHand && isServo && huFixed149 && !huFbk149) {
      huNote = svAdj230
        ? '伺服换向器方案（功率按额定满速）：额定转速 ÷ 速比 = 升降机输入转速——本方案取 '
          + iN(svRatedUsed) + 'rpm 档 + 伞齿轮换向器速比 1:' + iN(huRevSv) + '，功率/速度按电机额定 '
          + iN(rpm) + 'rpm 计算（额定口径需求功率 ' + fN(svKwRated230, 2) + 'kW > 400W，不按调速），'
          + '升降机输入转速 ' + iN(rpm / huRevSv) + 'rpm，输出速度 ' + fN(vActual, 2) + 'mm/s ≥ 要求 '
          + fN(v, 2) + 'mm/s；实际运行由驱动器调速至 ' + iN(rpmNeedSv * huRevSv) + 'rpm 实现要求速度（恒扭矩区，调速下限 30rpm）'
        : '伺服换向器方案（20% 调速窗口配比）：速比跟速度走——额定转速（允许向下调速 0~20%）'
        + '÷ 速比 = 客户要求转速。本方案取 ' + iN(svRatedUsed) + 'rpm 档 + 伞齿轮换向器速比 1:' + iN(huRevSv)
        + '，电机由驱动器调速到 ' + iN(rpm) + 'rpm 运行（额定 ' + iN(svRatedUsed) + 'rpm，向下调速 '
        + iN(Math.round((1 - rpm / svRatedUsed) * 1000) / 10) + '%，落 0~20% 窗口内、恒扭矩区，调速下限 30rpm），'
        + '升降机输入转速 = 所需 ' + iN(rpm / huRevSv) + 'rpm，输出速度 ' + fN(vActual, 2) + 'mm/s 精确达速';
    } else if (!isHand && isServo && huFbk149) {
      huNote = huFixed149
        ? '伺服换向器兜底方案：所有档位×标准速比在勾选品牌电机库内均无法落进「向下调速 0~20%」窗口 → '
          + '取调速幅度最小的 ' + iN(svRatedUsed) + 'rpm 档 + 换向器速比 1:' + iN(huRevSv)
          + '（电机调速运行 ' + iN(rpm) + 'rpm，超出 20% 窗口），输出速度 ' + fN(vActual, 2)
          + 'mm/s；超出窗口须与厂家确认后选用'
        : '伺服换向器兜底方案：各档位×标准速比在勾选品牌电机库内均无「功率不超过所需 ×2、且运行点扭矩满足」'
          + '的机型 → 按窗口配速兜底取 ' + iN(svRatedUsed) + 'rpm 档 + 换向器速比 1:' + iN(huRevSv)
          + '（大速比减扭），供与厂家确认后选用';
    }
    var HU_POLE = { 1500: 4, 1000: 6, 750: 8 };
    var isHuMultiAc = (!isHand && v > 0 && (inp.drive === 'ac3' || inp.drive === 'ac1')
      && units > 1 && /^(H型|U2型|U型)/.test(String(inp.layout || '')));
    if (isHuMultiAc && mmPerRev > 0) {
      var needRpmHu = v * 60 / mmPerRev;
      var huBest1 = null, huBest2 = null;
      /*




*/
      var bevelNoDual = /^(EHB|EHA|DHB)$/.test(String(inp.series || '')) && gv(inp, 'ehb_dual', true) === false;
      [[1500, 1400], [1000, 900], [750, 700]].forEach(function (ps) {
        var iT = ps[1] / needRpmHu;
        /*



*/
        [1, 2].forEach(function (rv) {
          {
            var o = (iT / rv - 1) * 100;
            /*
*/
            if (o <= 20 + 1e-9 && o >= -20 - 1e-9) {
              var better = !huBest1 || rv > huBest1.rev
                || (rv === huBest1.rev
                  && (((o >= 0) !== (huBest1.over >= 0)) ? o >= 0 : ps[1] < huBest1.sp));
              if (better) huBest1 = { over: o, rev: rv, sp: ps[1], sync: ps[0] };
            }
          }
        });
        /*


*/
        var r2 = null, o2 = 0, s2 = 0;
        if (bevelNoDual) {
          /**/
          var best2d = null;
          [2, 3, 4, 5, 8, 10].forEach(function (rv) {
            var o2v = (iT / rv - 1) * 100;
            var inWin2 = (o2v <= 20 + 1e-9 && o2v >= -20 - 1e-9);
            var sc2 = inWin2 ? Math.abs(o2v) : 1000 + Math.abs(o2v);
            var bet2 = !best2d || sc2 < best2d.score - 1e-9
              || (Math.abs(sc2 - best2d.score) < 1e-9
                && ((o2v >= 0) !== (best2d.over >= 0) ? o2v >= 0 : rv < best2d.rev));
            if (bet2) best2d = { score: sc2, over: o2v, rev: rv };
          });
          r2 = best2d ? best2d.rev : 1;
          o2 = best2d ? best2d.over : 0;
          s2 = best2d ? best2d.score : 0;
        } else {
          /**/
          [2, 3, 4, 5, 8, 10].forEach(function (rv) { if (rv <= iT + 1e-9) r2 = rv; });
          if (r2 === null) r2 = 1;
          o2 = (iT / r2 - 1) * 100;
          s2 = (o2 <= 20 + 1e-9 && o2 >= -20 - 1e-9) ? Math.abs(o2) : 1000 + Math.abs(o2);
        }
        var b2 = !huBest2 || s2 < huBest2.score - 1e-9
          || (Math.abs(s2 - huBest2.score) < 1e-9
            && ((o2 >= 0) !== (huBest2.over >= 0) ? o2 >= 0 : ps[1] < huBest2.sp));
        if (b2) huBest2 = { score: s2, over: o2, rev: r2, sync: ps[0], sp: ps[1] };
      });
      /*
*/
      if (String(inp.hu_plan || '') === 'int' || bevelNoDual) huBest1 = null;
      if (huBest1) {
        huPlan = 'dual'; huRev = huBest1.rev; rpmSync = huBest1.sync;
        rpm = SYNC2ACT[huBest1.sync] || huBest1.sync;
        /**/
        var huPre = /^(U2?型)/.test(String(inp.layout || '')) ? 'RSSXX' : 'RSDXX';   /**/
        huNote = '方案1 双出轴交流电机：' + HU_POLE[huBest1.sync] + ' 极（同步 ' + iN(huBest1.sync)
          + 'rpm，实际 ' + iN(SYNC2ACT[huBest1.sync])
          + 'rpm）直连（不配行星减速机），两台伞齿轮换向器 ' + (huRev > 1 ? '1:' + iN(huRev) + '（' + huPre + '/' + iN(huRev) + '）' : '1:1（' + huPre + '/1）')
          + '，升降机输入转速 ' + iN(rpm / huRev) + 'rpm';
      } else if (huBest2) {
        huPlan = 'int'; huRev = huBest2.rev; rpmSync = huBest2.sync;
        rpm = SYNC2ACT[huBest2.sync] || huBest2.sync;
        huNote = '方案2 电机与首台换向器一体化（非双出轴）：' + HU_POLE[huBest2.sync] + ' 极（同步 '
          + iN(huBest2.sync) + 'rpm，实际 ' + iN(SYNC2ACT[huBest2.sync]) + 'rpm）× 电机端换向器 1:' + iN(huRev)
          + '，其余换向器 1:1，升降机输入转速 ' + iN(rpm / huRev) + 'rpm——按定稿不选双出轴、不配行星减速机'
          + (huBest2.score > 20 + 1e-9 ? '（极数直连与 1:2 换向器均达不到速度要求，此为最接近组合，速度校核如实标注）' : '');
      }
      if (huPlan) {
        vActual = rpm / huRev / 60 * mmPerRev;
        vDirect = vActual;
      }
    }
    /*

*/
    if (!isHand && v > 0 && (acFixed || inp.drive === 'dc24') && !huPlan) {
      var devDirect = (vActual - v) / v * 100;
      if (acFixed) {
      /**/
      var R1400 = SYNC2ACT[1500];
      if (rpm !== R1400 && Math.abs(devDirect) > 20) {
        var v1400 = R1400 / 60 * mmPerRev;
        var dev1400 = (v1400 - v) / v * 100;
        if (Math.abs(dev1400) <= 20) {
          /**/
          rpm = R1400; rpmSync = 1500;
          vActual = v1400; vDirect = v1400; devDirect = dev1400;
          poleTxt = '原极数直连偏差超 ±20%，按定稿电机极数优先 4极：4极（实际 ' + iN(R1400)
            + 'rpm）直连速度 ' + fN(v1400, 2) + 'mm/s（偏差 ' + (dev1400 >= 0 ? '+' : '') + fN(dev1400, 1)
            + '%，±20% 内）→ 免减速机直连（方案1，省减速机省成本）';
        } else {
          var gb1400 = pickGbRatio(v1400, v);
          if (gb1400 !== null) {
            var vGb1400 = v1400 / gb1400, devGb1400 = (vGb1400 - v) / v * 100;
            if (devGb1400 >= -20 + 1e-9 && Math.abs(devGb1400) <= Math.abs(devDirect) + 1e-9) {
              rpm = R1400; rpmSync = 1500; devDirect = dev1400;
              vActual = vGb1400; vDirect = v1400; planet = gb1400; planetEff = gbEffOf(planet);
              planetTxt = '4极（实际 ' + iN(R1400) + 'rpm）直连速度 ' + fN(v1400, 2) + 'mm/s（偏差 '
                + (dev1400 >= 0 ? '+' : '') + fN(dev1400, 0) + '%，超 ±20%）→ 电机极数优先 4极，配行星减速机 i='
                + planet + ':1（效率 ' + fN(planetEff, 2) + '）：升降机输入转速 ' + iN(R1400) + '÷' + planet
                + ' = ' + iN(R1400 / planet) + 'rpm，输出速度 ' + fN(vActual, 2) + 'mm/s';
            }
          }
        }
      }
      }
      if (planet === 1 && !poleTxt && Math.abs(devDirect) > 20) {
        var gb = pickGbRatio(vDirect, v);
        if (gb !== null) {
          var vGb = vDirect / gb;
          var devGb = (vGb - v) / v * 100;
          /**/
          if (Math.abs(devGb) <= Math.abs(devDirect) + 1e-9) {
            planet = gb;
            planetEff = gbEffOf(gb);
            vActual = vGb;
            planetTxt = '直连速度 ' + fN(vDirect, 2) + 'mm/s（偏差 ' + (devDirect >= 0 ? '+' : '') + fN(devDirect, 0)
              + '%，超 ±20%）→ 配行星减速机 i=' + planet + ':1（效率 ' + fN(planetEff, 2) + '）：'
              + '升降机输入转速 ' + iN(rpm) + '÷' + planet + ' = ' + iN(rpm / planet) + 'rpm，'
              + '输出速度 ' + fN(vActual, 2) + 'mm/s（要求 ' + fN(v, 2) + 'mm/s 的 1.0~1.2 倍范围内，校核通过）';
          }
        }
      }
    }
    var pOut = fEff * 1000 * vActual / 1000;
    /*





*/
    /*
*/
    var svRegKw228 = (isServo && svDirect154 && svCand.length && svCand[0].direct && rpmNeedSv)
      ? svCand[0].tq * rpmNeedSv / 9550 : null;
    var svReg400_228 = (isServo && svDirect154 && svCand.length && svCand[0].direct)
      ? !svAdj230 : false;
    if (!isHand) steps.push(['输出功率', 'P出 = ' + fN(fEff, 1) + 'kN × ' + fN(vActual, 2) + 'mm/s ÷ 1000 = ' + fN(pOut, 1)
      + 'W（速度 = ' + (huFixed149
        ? (svAdj230
          ? '电机额定 ' + iN(svRatedUsed) + 'rpm（功率按额定满速口径）÷ 换向器速比 1:' + iN(huRevSv)
            + ' = ' + iN(rpm / huRevSv) + 'rpm，实际运行调速至 ' + iN(rpmNeedSv * huRevSv) + 'rpm'
          : '电机调速运行 ' + iN(rpm) + 'rpm（额定 ' + iN(svRatedUsed) + 'rpm）÷ 换向器速比 1:' + iN(huRevSv)
            + ' = ' + iN(rpm / huRevSv) + 'rpm')
        : huRev > 1
        ? '电机额定 ' + iN(rpm) + 'rpm ÷ 换向器速比 1:' + iN(huRev) + ' = ' + iN(rpm / huRev) + 'rpm'
        : (rpmPostPlanet
        ? (svLowSpeed ? '电机调速 ' + iN(rpmNeedSv * planet) + 'rpm' : '电机额定 ' + iN(svRatedUsed) + 'rpm')
          + ' ÷ 减速比 ' + planet + ' = ' + iN(rpm) + 'rpm'
        : (isServo && svDirect154
        ? (svAdj230
          ? '电机额定转速 ' + iN(rpm) + 'rpm 满速 ' + fN(vActual, 2) + 'mm/s（功率/速度按额定满速口径），实际运行调速至 '
            + iN(rpmNeedSv) + 'rpm = 要求速度 ' + fN(v, 2) + 'mm/s'
          : '电机调速运行 ' + iN(rpm) + 'rpm = 要求速度 ' + fN(vActual, 2) + 'mm/s（电机功率 ≤400W，按调速计算口径）')
        : '电机实际转速 ' + iN(rpm) + 'rpm' + (planet > 1 ? ' ÷ 减速比 ' + planet : '')))) + ' 口径）']);
    if (poleTxt) steps.push(['极数匹配', poleTxt]);
    if (planetTxt) steps.push([svChanger ? '换向器减速比' : '行星减速机', planetTxt]);
    if (huNote) steps.push(['换向器方案', huNote]);

    //
    var eta = ov.efficiency, etaSrc = '用户指定';
    if ((eta === null || eta === undefined) && typeof opt.eff_running_1500rpm === 'number') {
      eta = opt.eff_running_1500rpm;
      etaSrc = ratioKey + ' 档运转效率（2026样本 1400rpm 口径）';
    }
    if (eta === null || eta === undefined) {
      eta = C.pickEfficiency(m, fEff);
      etaSrc = '效率参考值（就近负载点）';
    }

    /*
*/
    var rpmInput = mmPerRev ? ((planet > 1 && !rpmPostPlanet) ? rpm / planet
      : (huRev > 1 ? rpm / huRev : rpm)) : null;   /**/
    /*
*/
    var inputRpmOk = isHand ? true
      : (rpmInput === null || rpmInput === undefined) ? true
      : rpmInput <= JACK_IN_MAX + 0.5;
    if (!inputRpmOk) {
      steps.push(['输入转速校核', '升降机输入转速 ' + iN(Math.round(rpmInput)) + 'rpm 超出最大输入转速 1500rpm'
        + '（SJA/SJB/KV/SCA/SCB/EHB 限值），该配置不可用']);
    }
    if (!isHand && eta !== null && eta !== undefined && (ov.efficiency === null || ov.efficiency === undefined) && rpmInput) {
      var fRpm = C.speedEffFactor(data, model, m, rpmInput);
      if (fRpm !== null && fRpm !== undefined && Math.abs(fRpm - 1) > 1e-9) {
        var etaAdj = eta * fRpm;
        steps.push(['转速效率修正', '升降机输入转速 ' + fN(rpmInput, 0) + 'rpm'
          + (planet > 1
            ? (rpmPostPlanet
              ? '（' + (svLowSpeed ? '电机调速 ' + iN(rpmNeedSv * planet) + 'rpm' : '电机额定 ' + iN(svRatedUsed) + 'rpm')
                + ' ÷ ' + (svChanger ? '换向器速比 1:' + planet : '减速比 ' + planet) + '）'
              : '（电机实际转速 ' + iN(rpm) + 'rpm ÷ 减速比 ' + planet + '）')
            : (huFixed149
              ? (svAdj230
                ? '（电机额定 ' + iN(rpm) + 'rpm，功率按额定满速口径 ÷ 换向器速比 1:' + iN(huRevSv) + '）'
                : '（电机调速运行 ' + iN(rpm) + 'rpm ÷ 换向器速比 1:' + iN(huRevSv) + '）')
              : huRev > 1
              ? '（电机实际转速 ' + iN(rpm) + 'rpm ÷ 换向器速比 1:' + iN(huRev) + '）'
              : (svAdj230 ? '（电机额定转速，功率按额定满速口径）' : '（电机实际转速）')))
          + '，样本效率表按 1400rpm 转速口径，转速修正系数 ×' + fN(fRpm, 3)
          + '：η = ' + fN(eta, 3) + '×' + fN(fRpm, 3) + ' = ' + fN(etaAdj, 3)]);
        eta = etaAdj;
      }
    }

    var pIn = pOut / eta;
    /*


*/
    var pInCalc = pIn, envSeg = '';
    var kTemp = envCoefOf(inp.ambient_temp);
    if (kTemp !== 1) {
      pInCalc *= kTemp;
      envSeg += '；' + envNoteOf(inp.ambient_temp) + ' → × ' + fN(kTemp, 1) + ' = '
        + fKw(pInCalc / 1000) + 'kW';
    }
    if (hasVacuumGrease(inp.special)) {
      pInCalc *= 2;
      envSeg += '；真空润滑脂效率很低、价格单独计费 → × 2 = ' + fKw(pInCalc / 1000) + 'kW';
    }
    /*

*/
    if (!isHand) steps.push(['输入功率', 'P入 = ' + fN(pOut, 1) + 'W ÷ η(' + fN(eta, 3) + ') = ' + fN(pIn, 1)
      + 'W ≈ ' + fKw(pIn / 1000) + 'kW（η 取' + etaSrc + '）' + envSeg]);
    /*


*/
    if (planet > 1 && !isHand) {
      /*
*/
      steps.push(['减速机效率', (svChanger
        ? '电机端换向器速比 1:' + planet + '（减速比 ' + planet + ':1），效率 ' + fN(planetEff, 2)
        : '行星减速机 i=' + planet + ':1，效率 ' + fN(planetEff, 2))]);
    }

    var maxKw = opt.max_input_power_kW, powerOk = null;
    if (typeof maxKw === 'number' && !isHand) {
      var tc = C.tempCoef(inp.ambient_temp);
      var maxKwEff = maxKw * tc;
      if (tc !== 1.0) {
        steps.push(['温度降容', '环境温度 ' + inp.ambient_temp + '℃，温度系数 ' + fN(tc, 2)
          + '，许用最大输入功率 = ' + fN(maxKw, 1) + '×' + fN(tc, 2) + ' = ' + fN(maxKwEff, 2) + 'kW']);
      }
      var pInKw = pInCalc / 1000, relaxNote = '', marginal = false;
      /*


*/
      var basePass, verdict;
      if (units <= 1) {
        basePass = pInKw * 1.2 <= maxKwEff;
        powerOk = basePass;
        if (!powerOk && maxKwEff >= pInKw * 1.1) {
          powerOk = true; marginal = true;
          relaxNote = '（最大输入功率为计算功率的 ' + fN(maxKwEff / pInKw, 2) + ' 倍，介于 ×1.1~×1.2——勉强通过，裕量偏小，建议与厂家确认）';
          warnings.push('【勉强通过】' + model + ' ' + ratioKey + ' 最大输入功率仅为计算功率的 '
            + fN(maxKwEff / pInKw, 2) + ' 倍（×1.1~×1.2 区间），勉强可用、裕量偏小');
        }
        /*

*/
        if (!powerOk && typeof inp.cycles_per_day === 'number' && inp.cycles_per_day <= 20
          && pInKw <= maxKwEff * 1.5) {
          powerOk = true;
          relaxNote = '（每日工作次数不超过 20 次，最大输入功率允许放大 1.5 倍采用，功率裕量偏紧）';
          warnings.push('【审核通过】' + model + ' ' + ratioKey + ' 每日工作次数不超过 20 次，'
            + '最大输入功率允许放大 1.5 倍采用（功率裕量偏紧，建议与厂家确认）');
        }
        verdict = (basePass ? '校核通过（裕量足）' : (marginal ? '勉强通过' : (powerOk ? '审核通过' : '校核失败')));
         steps.push(['最大输入功率校核', 'P入(×1.2 放大) ' + fKw(pInKw * 1.2) + 'kW ' + (basePass ? '≤' : '>')
          + ' 最大输入功率 ' + fKw(maxKwEff) + 'kW' + (tc === 1.0 ? '' : '（温度降容后）') + '，'
          + verdict + relaxNote]);
      } else {
        basePass = pInKw <= maxKwEff;
        powerOk = basePass;
        /*
*/
        if (!powerOk && typeof inp.cycles_per_day === 'number' && inp.cycles_per_day <= 20
          && pInKw <= maxKwEff * 1.5) {
          powerOk = true;
          relaxNote = '（每日工作次数不超过 20 次，最大输入功率允许放大 1.5 倍采用，功率裕量偏紧）';
          warnings.push('【审核通过】' + model + ' ' + ratioKey + ' 每日工作次数不超过 20 次，'
            + '最大输入功率允许放大 1.5 倍采用（功率裕量偏紧，建议与厂家确认）');
        }
        /**/
        steps.push(['最大输入功率校核', 'P入 ' + fKw(pInKw) + 'kW ' + (basePass ? '≤' : '>')
          + ' 最大输入功率 ' + fKw(maxKwEff) + 'kW' + (tc === 1.0 ? '' : '（温度降容后）')
          + (basePass ? '，校核通过' : (powerOk ? '，审核通过' + relaxNote : '，校核失败'))]);
      }
    } else if (!isHand) {
      warnings.push('最大输入功率数据 TODO，跳过该项校核');
    }

    var sync = (inp.sync !== null && inp.sync !== undefined) ? inp.sync : (units > 1 ? '机械' : '单台');
    var layout = inp.layout;
    /*


*/
    function isInlineLayout(l) {
      return l === '电机单侧' || l === '电机中间' || l === '直线布置-电机单侧'
        || l === '垂直布置-电机中间' || l === '直线布置';
    }
    function isMidMotorLayout(l) {
      return l === '电机中间' || l === '垂直布置-电机中间';
    }
    /*




*/
    var dualShaftA = gv(inp, 'dual_shaft', false) === true;
    /*
*/
    if (huPlan === 'int') dualShaftA = false;
    var isCLayA = String(layout) === '直线布置' && [4, 6, 8].indexOf(units) >= 0;
    var stages = (ov.stages !== null && ov.stages !== undefined) ? ov.stages
      : ((layout === null || layout === undefined) ? 3
        : (/^(H型|U2型|U型)/.test(String(layout)) ? Math.max(1, dualShaftA ? Math.min(2, units - 1) : (units >= 4 ? 3 : units - 1))
          : (isInlineLayout(String(layout)) ? (isMidMotorLayout(String(layout)) ? 1 : (isCLayA ? (dualShaftA ? 0 : 1) : 0)) : 2)));
    var totalPower = pInCalc / 1000;
    if (units > 1) {
      if (sync === '电气') {
        /*

*/
        totalPower = pInCalc / 1000 * 1.5;
        if (!isHand) {
          steps.push(['电气同步 · 单台电机功率', '每台一台伺服电机（可加行星减速机）：单台输入功率 '
            + fKw(pInCalc / 1000) + 'kW（= 总负载 ÷ ' + iN(units) + ' 台口径）× 放大系数 1.5 = '
            + fKw(totalPower) + 'kW（唯一放大：无组合系数/换向器级损/台数放大；2026-11-03 批复）']);
        }
      } else {
      /*


*/
      var combo = gv(ov, 'combo_coef', comboCoefOf(units));
      var rev = gv(ov, 'reverse_eff', 0.9);
      var divisor = C.evalDivisor(ov.custom_divisor, combo * Math.pow(rev, stages));
      var plat = pInCalc / 1000 * units / divisor;
      /*

*/
      var hot = Number(inp.ambient_temp) >= 80;
      var lrA = (rated > 0) ? f1 / rated : null;
      var amp = gv(ov, 'amp_coef', ampCoefOfEx(units, model, lrA, inp.ambient_temp));
      var ampTxt = (Math.abs(amp * 10 - Math.round(amp * 10)) < 1e-9) ? fN(amp, 1) : fN(amp, 2);
      var ampOvr = (ov.amp_coef == null && !hot && amp !== ampCoefOf(units))
        ? '；四台同步且单台负载率 ' + fN(lrA * 100, 1) + '%<10%：放大系数由 ' + fN(ampCoefOf(units), 1)
          + ' 调整为 ' + fN(amp, 1) + '（' + (floorCoefOf(model) === 0.15 ? '滚珠丝杠' : '梯形丝杠') + '，2026-10-22 定稿）'
        : '';
      totalPower = plat * amp;
      var divTxt = ov.custom_divisor || ('组合系数' + fN(combo, 2) + '×' + fN(rev, 2) + '^' + iN(stages));
      var stageTxt = (stages > 0)
        ? '每级换向器/减速机 η=0.90 累计相乘，共 ' + iN(stages) + ' 级'
          + (dualShaftA ? '（双出轴：换向器共 2 台，省去电机端换向器，级损少一级）' : '')
          + (huPlan === 'int' ? '（方案2 电机端一体化换向器 1:' + iN(huRev) + '：不选双出轴、不配行星减速机）' : '')
        : '';   /**/
      var ampStepA = null;
      if (!isHand) {
        /*
*/
        steps.push(['平台总功率', 'P平 = ' + fKw(pInCalc / 1000) + 'kW × ' + iN(units) + ' ÷ (' + divTxt
          + ') = ' + fKw(plat) + 'kW' + (stageTxt ? '；' + stageTxt : '')]);
        ampStepA = ['放大系数', '总功率 = ' + fKw(plat) + 'kW × ' + ampTxt + ' = ' + fKw(totalPower)
          + 'kW'
          + (hot ? '；高温 +80℃ 按台数取 单台2/两台2/三台2.5/四台3/八台4（含高温环境系数 ×2，此处台数放大 ' + ampTxt + '）' : '')
          + ampOvr];
        steps.push(ampStepA);
      }
      if (sync === '电气' && !isHand) {
        var ec = gv(ov, 'elec_coef', 1.5);
        totalPower *= ec;
        steps.push(['电气同步', '总功率 × ' + fN(ec, 1) + ' = ' + fKw(totalPower) + 'kW']);
      }
      }
    }

    /**/
    var kMotor = motorOverloadCoefOf(inp.drive);
    if (kMotor !== 1) {
      var baseKw = totalPower;
      totalPower *= kMotor;
      steps.push(['电机不过载裕量', (inp.drive === 'stepper'
        ? '步进电机额定 300rpm、最大 1000rpm，不能过载' : '单相交流电机不能过载')
        + '，功率与扭矩按 × ' + fN(kMotor, 1) + ' 放大选型：总功率 = ' + fN(baseKw, 2) + 'kW × '
        + fN(kMotor, 1) + ' = ' + fN(totalPower, 2) + 'kW']);
    }

    var rpmNeed = v * 60 / mmPerRev;
    /*

*/
    var speedOk = true, res_speed_warn = '';
    var devPct = v ? (vActual - v) / v * 100 : 0;
    var AC_DEV_LIMIT = 20;
    var devTail = (planet > 1) ? '，配行星减速机 i=' + planet + ':1 后满足使用要求'
      : (huRev > 1 ? '，配换向器速比 1:' + iN(huRev) + ' 后满足使用要求' : '，按最接近速度档使用，满足使用要求');
    var speedWarn = '';
    /*
*/
    if (v && Math.abs(devPct) > AC_DEV_LIMIT && !(isServo && svAdj230)) {
      /*
*/
      var iNeed = vActual / v;
      var STD_GB = [3, 4, 5, 6, 8, 10];
      var gb = null;
      for (var gi = STD_GB.length - 1; gi >= 0; gi--) { if (STD_GB[gi] <= iNeed) { gb = STD_GB[gi]; break; } }
      var sug = gb
        ? '建议配行星减速机（标准 ' + gb + ':1，减速后约 ' + fN(vActual / gb, 2) + 'mm/s）或改用伺服电机调速'
        : '建议改用伺服电机调速';
      /*

*/
      if (devPct < 0) {
        speedOk = false;
        devTail = (inp.drive === 'dc24')
          ? '，直流电机最慢档仍比要求慢 ' + fN(-devPct, 0) + '%，无法满足速度要求（需更大导程/更高转速档或伺服调速）'
          : '，交流电机最慢仍比要求慢 ' + fN(-devPct, 0) + '%，无法满足速度要求（需更大导程/更高转速或伺服调速）';
      } else {
        devTail = (inp.drive === 'dc24')
          ? '，直流电机无更慢档位，实际速度比要求快 ' + fN(devPct, 0) + '%——' + sug + '（需与厂家确认）'
          : '，交流电机无更慢档位，实际速度比要求快 ' + fN(devPct, 0) + '%——' + sug + '（需与厂家确认）';
        speedWarn = (inp.drive === 'dc24')
          ? '【速度校核】' + model + ' 直流电机最接近档实际 ' + fN(vActual, 2) + 'mm/s，'
            + '比要求 ' + fN(v, 2) + 'mm/s 快 ' + fN(devPct, 0) + '%：' + sug
            + '；本计算按实际档位速度取值，功率/电机偏保守'
          : '【速度校核】' + model + ' 交流电机最接近档实际 ' + fN(vActual, 2) + 'mm/s，'
            + '比要求 ' + fN(v, 2) + 'mm/s 快 ' + fN(devPct, 0) + '%：' + sug
            + '；本计算按实际档位速度取值，功率/电机偏保守';
      }
    }
    if (!isHand) steps.push(['速度校核', (isServo
      ? (huFixed149
        ? (svAdj230
          ? '伺服换向器类布置（功率按额定满速）：取 ' + iN(svRatedUsed) + 'rpm 档 + 伞齿轮换向器速比 1:'
            + iN(huRevSv) + '，功率/速度按电机额定 ' + iN(rpm) + 'rpm 计算：升降机输入转速 '
            + iN(rpm / huRevSv) + 'rpm：v = ' + iN(rpm) + '÷' + iN(huRevSv)
            + '÷60×' + fN(mmPerRev, 2) + 'mm = ' + fN(vActual, 2) + 'mm/s ≥ 要求 ' + fN(v, 2)
            + 'mm/s，满足使用要求（实际运行由驱动器调速至 ' + iN(rpmNeedSv * huRevSv) + 'rpm，v = '
            + fN(v, 2) + 'mm/s = 要求速度，恒扭矩区，调速下限 30rpm）'
            + (huFbk149 ? '；超出 20% 调速窗口，为最小调速兜底，须与厂家确认' : '')
          : '伺服换向器类布置（20% 调速窗口配比）：取 ' + iN(svRatedUsed) + 'rpm 档 + 伞齿轮换向器速比 1:'
          + iN(huRevSv) + '，电机由驱动器调速运行至 ' + iN(rpm) + 'rpm（额定 ' + iN(svRatedUsed)
          + 'rpm，向下调速 ' + iN(Math.round((1 - rpm / svRatedUsed) * 1000) / 10) + '%，恒扭矩区）：升降机输入转速 '
          + iN(rpm / huRevSv) + 'rpm：v = ' + iN(rpm) + '÷' + iN(huRevSv)
          + '÷60×' + fN(mmPerRev, 2) + 'mm = ' + fN(vActual, 2) + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 '
          + (devPct >= 0 ? '+' : '') + fN(devPct, 1) + '%，精确达速）'
          + (huFbk149 ? '；超出 20% 调速窗口，为最小调速兜底，须与厂家确认' : ''))
        : huRev > 1
        ? '伺服电机额定 ' + iN(rpm) + 'rpm 满速运行 + 伞齿轮换向器速比 1:' + iN(huRev)
          + '（窗口内正偏差优先、域内取最贴近所需的最大速比）：升降机输入转速 ' + iN(rpm / huRev)
          + 'rpm：v = ' + iN(rpm) + '÷' + iN(huRev) + '÷60×' + fN(mmPerRev, 2)
          + 'mm = ' + fN(vActual, 2) + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 ' + (devPct >= 0 ? '+' : '') + fN(devPct, 1) + '%'
          + (speedOk === false ? '，超出 0.8~1.2 倍允许窗口' : '，0.8~1.2 倍窗口内') + '）'
          + (devPct < 0 && mmPerRev > 0
            ? '；【】窗口内无「额定转速下速度≥要求」的正偏差速比，达速需电机超额定转速 ×'
              + fN((v * 60 / mmPerRev) * huRev / rpm, 2)
              + ' 弱磁运行（超出恒扭矩区、额定扭矩降额），须与厂家确认'
            : '')
        : (planet > 1
        ? (svLowSpeed
          ? (svChanger
            ? '伺服低速 + 电机端换向器：所需输入 ' + iN(rpmNeedSv) + 'rpm，伺服 30~3000rpm 任意调速，'
              + '电机端换向器速比 1:' + planet + '（效率 ' + fN(planetEff, 2) + '，该速比额定输入 '
              + iN(3000 / planet) + 'rpm、允许 ' + fN(30 / planet, 0) + '~' + iN(3000 / planet) + 'rpm）；'
              + '电机调速运行至 ' + iN(rpmNeedSv * planet) + 'rpm（允许域内），扭矩 ' + iN(rpmNeedSv) + 'rpm 需求 '
              + '÷' + planet + '÷' + fN(planetEff, 2) + ' 由电机承担；升降机输入转速 ' + iN(rpm) + 'rpm：v = '
            : '伺服极低速 + 行星减速机：所需输入 ' + iN(rpmNeedSv) + 'rpm 低于稳定调速下限 30rpm，'
            + '配 i=' + planet + ':1（效率 ' + fN(planetEff, 2) + '）；若按电机额定转速 3000rpm 满速运行，'
            + '升降机输入 ' + iN(3000 / planet) + 'rpm：v = ' + fN(3000 / planet / 60 * mmPerRev, 2)
            + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 +' + fN((3000 / planet / 60 * mmPerRev - v) / v * 100, 1)
            + '%，此为满速理论值）——实际电机调速运行至所需转速 ' + iN(rpmNeedSv * planet)
            + 'rpm（30~3000rpm 稳定区内）；升降机输入转速 ' + iN(rpm) + 'rpm：v = ')
          : '伺服电机调速 + 行星减速机：按电机额定转速匹配 i=' + planet + ':1（效率 ' + fN(planetEff, 2)
            + '），升降机输入转速 ' + iN(rpm) + 'rpm：v = ')
          + iN(rpm) + '÷60×' + fN(mmPerRev, 2)
          + 'mm = ' + fN(vActual, 2) + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 ' + (devPct >= 0 ? '+' : '') + fN(devPct, 1) + '%'
          + (speedOk === false ? '，超出 0.8~1.2 倍允许窗口' : '，1.0~1.2 倍内') + '）'
        : (svReg400_228
          ? '伺服电机调速运行：按所需输入转速 ' + iN(rpm) + 'rpm 直连（v = ' + iN(rpm) + '÷60×' + fN(mmPerRev, 2)
            + 'mm = ' + fN(vActual, 2) + 'mm/s = 要求速度，偏差 0%），伺服在额定转速内恒扭矩输出'
            + '（电机功率 ≤400W，按调速计算口径）'
          : (svRatedUsed > 0
            ? '伺服电机按额定转速 ' + iN(svRatedUsed) + 'rpm 计算功率与速度（不按调速）：v = ' + iN(svRatedUsed) + '÷60×'
              + fN(mmPerRev, 2) + 'mm = ' + fN(svRatedUsed / 60 * mmPerRev, 2) + 'mm/s ≥ 要求速度 ' + fN(v, 2)
              + 'mm/s，满足使用要求（实际运行由驱动器调速至 ' + iN(rpmNeedSv) + 'rpm，v = ' + fN(v, 2)
              + 'mm/s = 要求速度）；伺服在额定转速内恒扭矩输出'
            : '伺服电机调速运行：按所需输入转速 ' + iN(rpm) + 'rpm 直连（v = ' + iN(rpm) + '÷60×' + fN(mmPerRev, 2)
              + 'mm = ' + fN(vActual, 2) + 'mm/s = 要求速度，偏差 0%），伺服在额定转速内恒扭矩输出'))))
      : (inp.drive === 'dc24'
      ? '直流电机按额定转速档使用（24VDC，额定＝实际转速）：v = ' + iN(rpm) + '÷60'
        + (planet > 1 ? '÷' + planet + '（行星减速机）' : '')
        + (huRev > 1 ? '÷' + iN(huRev) + '（换向器速比 1:' + iN(huRev) + '）' : '')
        + '×' + fN(mmPerRev, 2) + 'mm = ' + fN(vActual, 2)
        + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 ' + (devPct >= 0 ? '+' : '') + fN(devPct, 1)
        + '%）' + devTail
      : '交流电机不可调速，按同步 ' + iN(rpmSync) + 'rpm 的实际转速 ' + iN(rpm)
        + 'rpm 计算：v = ' + iN(rpm) + '÷60' + (planet > 1 ? '÷' + planet + '（行星减速机）' : '')
        + (huRev > 1 ? '÷' + iN(huRev) + '（换向器速比 1:' + iN(huRev) + '）' : '') + '×' + fN(mmPerRev, 2) + 'mm = ' + fN(vActual, 2)
        + 'mm/s（要求 ' + fN(v, 2) + 'mm/s，偏差 ' + (devPct >= 0 ? '+' : '') + fN(devPct, 1)
        + '%）' + devTail))]);
    /**/
    res_speed_warn = speedWarn;

    /*
*/
    var handTorque = null, etaStartUsed = null, etaStartTxt = '', torqueOk = null, handForce = null, stPage = null;
    if (inp.drive === 'hand') {
      etaStartUsed = (opt.eff_startup != null && !isTodo(opt.eff_startup)) ? opt.eff_startup : null;
      var etaStartVal;
      if (etaStartUsed !== null) {
        etaStartVal = etaStartUsed;
        etaStartTxt = ratioKey + ' 档启动效率（样本满载口径）';
      } else {
        etaStartVal = eta ? eta * 0.75 : 0.2;   /**/
        etaStartTxt = '样本未单列启动效率，按运转效率 75% 估算，需与厂家确认';
      }
      /*
*/
      var handTorqueBase = fEff * 1000 * mmPerRev / (2 * Math.PI * etaStartVal) / 1000;   /* N·m */
      handTorque = handTorqueBase;
      var coefTxt = '';
      if (kTemp !== 1) {
        handTorque *= kTemp;
        coefTxt += '× ' + fN(kTemp, 1) + '（' + envNoteOf(inp.ambient_temp) + '，手摇扭矩放大 ' + fN(kTemp, 1) + ' 倍）';
      }
      if (hasVacuumGrease(inp.special)) {
        handTorque *= 2;
        coefTxt += (coefTxt ? ' ' : '') + '× 2（真空润滑脂：效率很低且须单独计费，手摇扭矩放大 2 倍）';
      }
      steps.push(['手摇扭矩', 'T手 = F×每转行程÷(2π×启动效率) = ' + fN(fEff * 1000, 0) + 'N×'
        + fN(mmPerRev, 2) + 'mm÷(2×3.14×' + fN(etaStartVal, 2) + ') = ' + fN(handTorqueBase, 1) + 'Nm'
        + (coefTxt ? ' ' + coefTxt + ' = ' + fN(handTorque, 1) + 'Nm' : '')
        + '（启动效率 ' + fN(etaStartVal, 2) + '：' + etaStartTxt
        + '；手摇驱动无电机功率/转速计算）']);
      /*
*/
      /*
*/
      var stPageM = /p(\d+)/.exec(String(opt.source || ''));
      var stPage = stPageM ? Number(stPageM[1]) : 63;
      var stTq = (typeof opt.startup_torque_Nm === 'number' && !isTodo(opt.startup_torque_Nm))
        ? opt.startup_torque_Nm
        : ((typeof m.startup_torque_Nm === 'number' && !isTodo(m.startup_torque_Nm))
          ? m.startup_torque_Nm : null);   /**/
      var maxTq = (stTq !== null) ? stTq * HAND_MAX_TQ_FACTOR
        : ((typeof opt.max_input_torque_Nm === 'number' && !isTodo(opt.max_input_torque_Nm))
          ? opt.max_input_torque_Nm : null);
      var maxTqTxt = (stTq !== null)
        ? '最大输入扭矩 = 满载启动扭矩 ' + fN(stTq, 1) + 'Nm × ' + HAND_MAX_TQ_FACTOR
          + ' = ' + fN(maxTq, 1) + 'Nm（样本 p' + stPage + '）'
        : '最大输入扭矩（= 满载启动扭矩 × ' + HAND_MAX_TQ_FACTOR + '，样本 p' + stPage
          + '）数据待补全，需与厂家确认';
      torqueOk = (maxTq !== null) ? (handTorque <= maxTq * 1.001) : null;
      /**/
      var fp = handForcePlan(handTorque);
      handForce = fp ? fp.f200 : null;
      var forceTxt = fp.txt;
      steps.push(['扭矩校核', (maxTq !== null
        ? '手摇扭矩 ' + fN(handTorque, 1) + 'Nm ' + (torqueOk ? '≤' : '>') + ' ' + maxTqTxt
          + '，' + (torqueOk ? '不超过最大输入扭矩，校核通过' : '超过最大输入扭矩，需增加减速机')
        : maxTqTxt)
        + '；按手摇把半径 200mm 计算，手摇力不能超过 10kg：' + forceTxt]);
      /**/
      if (/V/i.test(ratioKey)) {
        steps.push(['手摇安全', ratioKey + ' 蜗轮蜗杆不自锁，须加装制动器或其他安全措施防逆转，注意安全']);
        warnings.push('【手摇安全】' + model + ' ' + ratioKey + ' 蜗轮蜗杆不自锁，须加装制动器或其他安全措施，注意安全');
      }
      if (torqueOk === false) warnings.push('【扭矩校核】' + model + ' 手摇扭矩 ' + fN(handTorque, 1)
        + 'Nm 超过最大输入扭矩，需增加减速机 5:1 或 10:1');
    } else {
      /*

*/
      var tBase = 9550 * totalPower / rpm;
      /*
*/
      /*
*/
      var gbHu = (huRevSv > 1)
        ? { ratio: huRevSv + ':1', type: '伞齿轮换向器', out_rpm: Math.round(rpm / huRevSv), eff: 1 }
        : (huFixed149 ? { ratio: '1:1', type: '伞齿轮换向器', out_rpm: Math.round(rpm / huRevSv), eff: 1 } : null);
      var svLockHu = (isServo && (huRevSv > 1 || huFixed149))
        ? { huRev: huRevSv, revList: REV83, fixed: huFixed149 } : null;
      /*
*/
      var needBrakeA = (inp.drive === 'hand' || inp.drive === 'none')
        ? false : needBrakeOfAdv(brakeAdvice(model, ratioKey, m));
      /*
*/
      var acCapKw = (typeof opt.max_input_power_kW === 'number' && inp.drive !== 'hand' && inp.drive !== 'none')
        ? opt.max_input_power_kW * C.tempCoef(inp.ambient_temp) : null;
      var motorsPre = (inp.drive === 'hand' || inp.drive === 'none')
        ? [] : recommendMotor(motorLibData(inp, data), totalPower, tBase, rpm, driveKindOf(inp), rpmNeed,
            (planet > 1) ? { ratio: planet + ':1', type: svChanger ? '换向器' : '行星减速机',
              out_rpm: rpmPostPlanet ? Math.round(rpm) : Math.round(rpm / planet), eff: planetEff } : gbHu,
            (planet > 1 && (isServo || typeof svRatedUsed === 'number'))
              ? { rated: svRatedUsed, ratio: planet, forced: svForcedLeg, lowSpeed: svLowSpeed, changer: svChanger } : svLockHu,
            (Number(inp.units) || 1) >= 2, false, false, needBrakeA, acCapKw, svDirect154);
            /**/
      /*
*/
      if (units === 4 && ov.amp_coef == null && amp === 1.5 && !hot && motorsPre.length) {
        var pReq14 = r(plat * 1.4, 2);
        var tBase14 = 9550 * pReq14 / rpm;
        /*
*/
        var motors14 = recommendMotor(motorLibData(inp, data), pReq14, tBase14, rpm, driveKindOf(inp), rpmNeed,
            (planet > 1) ? { ratio: planet + ':1', type: svChanger ? '换向器' : '行星减速机',
              out_rpm: rpmPostPlanet ? Math.round(rpm) : Math.round(rpm / planet), eff: planetEff } : gbHu,
            (planet > 1 && (isServo || typeof svRatedUsed === 'number')) ? { rated: svRatedUsed, ratio: planet, lowSpeed: svLowSpeed, changer: svChanger } : svLockHu,
            (Number(inp.units) || 1) >= 2, false, false, needBrakeA, acCapKw, svDirect154);
        if (motors14.length && motors14[0].power_kW < motorsPre[0].power_kW - 1e-9) {
          amp = 1.4;
          totalPower = plat * 1.4;
          /**/
          ampStepA[1] = ampStepA[1].replace(/× [\d.]+ = [\d.]+kW/, '× 1.4 = ' + fKw(totalPower) + 'kW')
            + '；四台同步放大系数改取 1.4';
          motorsPre = motors14;
        }
      }
      /*



*/
      svAltPlans.forEach(function (ap) {
        if (!ap || ap.out < rpmNeed / 1.2 - 1e-9) return;
        var outAlt = Math.round(ap.r / ap.i);
        var tBaseAlt = 9550 * totalPower / outAlt;
        var motorsAlt = recommendMotor(motorLibData(inp, data), totalPower, tBaseAlt, outAlt,
          driveKindOf(inp), rpmNeed,
          { ratio: ap.i + ':1', type: '行星减速机', out_rpm: outAlt, eff: gbEffOf(ap.i) },
          { rated: ap.r, ratio: ap.i }, (Number(inp.units) || 1) >= 2, false, false, needBrakeA);
        motorsAlt.forEach(function (mm) {
          /*
*/
          if (mm.fit === 'over' && motorsPre.some(function (x) {
            return x.fit !== 'over' && Number(x.rpm) === Number(mm.rpm)
              && String(x.gearbox && x.gearbox.ratio) === String(mm.gearbox && mm.gearbox.ratio);
          })) return;
          /*

*/
          if (mm.fit === 'over' && mm.power_kW < totalPower * 0.98 - 1e-9
              && motorsPre.some(function (x) { return x.fit !== 'over'; })) return;
          var dup = motorsPre.some(function (x) {
            return x.code === mm.code && String(x.gearbox && x.gearbox.ratio) === String(mm.gearbox && mm.gearbox.ratio);
          });
          if (!dup) motorsPre.push(mm);
        });
      });
      var ampMotor = 1, ampMotorTxt = '（已含台数放大系数，不再二次放大）';
      /*
*/
      var pCalcR = r(totalPower, 2);
      if (units <= 1) {
        ampMotor = 1.2;
        ampMotorTxt = ' × 1.2 放大';
        if (motorsPre.length && motorsPre[0].power_kW < pCalcR * 1.2 - 1e-9) {
          ampMotor = 1.1;
          ampMotorTxt = ' × 1.1（小于 1.2，为凑标准电机功率档）';
        }
      }
      var pMotorReq = r(pCalcR * ampMotor, 2);
      /*

*/
      var pTqBase = (pMotorReq < 0.005 - 1e-12) ? (totalPower * ampMotor) : pMotorReq;
      var torque = 9550 * pTqBase / rpm;
      /*


*/
      var tqShowA = (isServo && svRatedUsed) ? 9550 * pTqBase / svRatedUsed : null;
      var tqShowRpmA = (isServo && svRatedUsed) ? svRatedUsed : rpm;
      /**/
      /**/
      /**/
      var fPw = function (x) {
        var v0 = Number(x) || 0;
        return (v0 !== 0 && Math.abs(v0) < 0.01) ? fN(v0, 4) : fN(v0, 2);
      };
      steps.push(['电机扭矩', 'T = 9550×' + fPw(pTqBase) + 'kW÷' + iN(tqShowRpmA) + 'rpm'
        + (isServo && svRatedUsed ? '（电机额定转速）' : '') + ' = ' + fN(tqShowA != null ? tqShowA : torque, 1)
        + 'Nm' + (tqShowA != null ? '（扭矩按电机额定转速计算）' : '')
        + '（所需功率 = 电机侧计算功率 ' + fPw(pCalcR !== 0 ? pCalcR : totalPower) + 'kW'
        + (planet > 1 ? '（= P入 ÷ 减速机效率）' : '') + ampMotorTxt + '）'
        + (isServo && planet > 1 ? '；电机端需求扭矩 = ' + fN(tqShowA != null ? tqShowA : torque, 1) + 'Nm'
          + '（额定口径电机端）；升降机输入端需求 = ' + fN(tqShowA != null ? tqShowA : torque, 1) + 'Nm × 减速比 ' + planet
          + ' × 效率 ' + fN(planetEff, 2) + ' = ' + fN((tqShowA != null ? tqShowA : torque) * planet * planetEff, 1) + 'Nm' : '')
        + (kMotor !== 1 ? '（含' + (inp.drive === 'stepper' ? '步进电机' : '单相交流电机')
          + '不过载 × ' + fN(kMotor, 1) + ' 裕量）' : '')]);
    }

    /*
*/
    if (svLowSpeed && planet > 1 && units >= 2 && !isHand && stages === 0
        && kTemp === 1 && !hasVacuumGrease(inp.special)) {
      var fDirectN = pOut * 1000 / v;                       /**/
      var tDirect = fDirectN * (mmPerRev / 1000) / (2 * Math.PI) / eta;   /**/
      var kElec = (typeof ec === 'number') ? ec : 1;
      /**/
      var tChain = (sync === '电气') ? (tDirect * 1.5) : (tDirect * units / combo * amp * kElec);
      var relDiff = torque > 0 ? Math.abs(tChain - torque) / torque : 0;
      steps.push(['扭矩直算核对', 'T单台 = 单台负载 ' + fN(fDirectN / 1000, 2) + 'kN × 导程 ' + fN(mmPerRev, 2)
        + 'mm ÷ (2π) ÷ η ' + fN(eta, 3) + ' = ' + fN(tDirect, 2) + 'Nm'
        + (sync === '电气'
          ? '；× 电气同步放大 1.5（一步到位）'
          : '；× ' + iN(units) + ' 台 ÷ 组合系数 ' + fN(combo, 2) + ' × 台数放大 ' + fN(amp, 1)
            + (kElec !== 1 ? ' × 电气同步 ' + fN(kElec, 1) : ''))
        + ' = ' + fN(tChain, 1) + 'Nm'
        + (relDiff < 0.001 ? '，与功率链一致（电缸同款一式到底口径）'
          : relDiff <= 0.05 ? '，与功率链一致（差 ' + fN(relDiff * 100, 1) + '%，功率链转速按显示整数舍入口径）'
          : '，与功率链折算 ' + fN(torque, 1) + 'Nm 有差异，须核实')]);
    }

    /*



*/
    var pullDomA = pullDominantOf(inp);
    /**/
    var scA225 = scStabOf(inp, model, m, data);
    var stab;
    if (pullDomA && pushKn > 0) {
      var fPush = pushKn / units;
      stab = stabilityCheck(scA225.def, fPush, inp.stroke_mm, inp.motion || 'S', scA225.mounting, scA225.model, data,
        screwDiaOf({ screw: gv(opt, 'screw', '') || gv(m, 'screw', '') }, model));
      stab = [stab[0], '拉力工况（总负载拉力大于推力），按推力 ' + fN(fPush, 1) + 'kN 校核稳定性；' + stab[1]];
    } else if (pullDomA) {
      stab = [true, '拉力工况且推力为 0，丝杠受拉无压弯风险，按选择规则不校核稳定性'];
    } else {
      stab = stabilityCheck(scA225.def, f1, inp.stroke_mm, inp.motion || 'S', scA225.mounting, scA225.model, data,
        screwDiaOf({ screw: gv(opt, 'screw', '') || gv(m, 'screw', '') }, model));
    }
    steps.push(['稳定性校核', stab[1] + (stab[0] === true ? '，校核通过' : (stab[0] === false ? '，校核失败' : ''))]);
    if (stab[0] === null) warnings.push('稳定性数据待补全（' + model + '）');

    /*
*/
    var staticChk = staticCheckStep(m, rated, inp, fEff, units);
    steps.push(['静载校核', staticChk[1]]);
    if (staticChk[0] === false) warnings.push('【静载校核】' + model + ' 静载需求超过额定静载，请放大型号或与厂家确认');

    /*
*/
    var ratedDyn = (typeof m.rated_load_kN === 'number' && !isTodo(m.rated_load_kN)) ? m.rated_load_kN : null;
    var thrustOk = (ratedDyn != null) ? (fEff <= ratedDyn * 1.001) : null;
    steps.push(['推拉力校核', '单台需求 ' + fN(fEff, 1) + 'kN '
      + (thrustOk === null ? '：产品推拉力数据待补全，需与厂家确认'
        : (thrustOk ? '≤' : '>') + ' 额定推拉力（提升力）' + fN(ratedDyn, 1) + 'kN，'
          + (thrustOk ? '校核通过' : '推拉力不足，需放大型号'))]);
    if (thrustOk === false) warnings.push('【推拉力校核】' + model + ' 单台需求 ' + fN(fEff, 1)
      + 'kN 超过额定推拉力 ' + fN(ratedDyn, 1) + 'kN，需放大型号');

    /*
*/
    var brakeAdv = brakeAdvice(model, ratioKey, m);
    /**/
    if (brakeAdv && inp.drive !== 'hand') warnings.push('【制动器建议】' + brakeAdv);

    var life = null;
    if (m.life_check === true && !isTodo(m.ball_C_kN)) {
      life = C.lifeCheck(m.ball_C_kN, m.lead_mm, fEff, inp.stroke_mm, inp.cycles_per_day,
        (inp.days_per_year !== null && inp.days_per_year !== undefined) ? inp.days_per_year : 300,
        gv(ov, 'round_trip', true), inp.life_years);
      if (life) {
        steps.push(['寿命校核', '理论公里数 = (' + m.ball_C_kN + '/' + fN(fEff, 1) + ')³×' + m.lead_mm
          + 'mm = ' + fN(life.life_km, 0) + 'km；年用 ' + fN(life.annual_km, 1) + 'km；' + life.note]);
      }
    } else if (m.life_check === true) {
      warnings.push('型号 ' + model + ' 滚珠动载数据 TODO，寿命校核跳过');
    }

    var dutyRated = m.rated_load_kN;
    var loadRate = (typeof dutyRated === 'number' && dutyRated) ? (fEff / dutyRated) : null;
    var duty = dutyCheck(model, inp.series, inp.cycles_per_day, v, loadRate);
    steps.push(['工作制校核', duty[1]]);
    if (duty[0] === false) warnings.push('【系列选择原则警告】' + duty[1]);

    /*
*/
    /**/
    var motors = applyServoBrandLock(motorsPre || [], inp,
      (typeof pMotorReq === 'number') ? pMotorReq : totalPower,
      (typeof torque === 'number') ? torque : null, rpm);

    /*
*/
    var svRealMissing = false, svRealNote = '';
    if (!isHand && String(inp.drive || '').indexOf('servo') === 0) {
      var realRows = (motors || []).filter(function (x) { return x.fit !== 'over'; });
      if (!realRows.length) {
        svRealMissing = true;
        var ovRow0 = (motors || []).filter(function (x) { return x.fit === 'over'; })[0];
        svRealNote = ovRow0 ? ('所选品牌库内无适用真机型（' + (ovRow0.note || '超出库内最大档') + '）；方案机械侧校核按需求值计算，需与厂家确认更大机座号或调整方案')
          : '所选品牌库内无适用真机型；方案机械侧校核按需求值计算，需与厂家确认更大机座号或调整方案';
        warnings.push('【电机真机型】' + svRealNote);
      }
    }

    var checks = { '最大输入功率': powerOk, '速度': speedOk, '输入转速': inputRpmOk, '稳定性': stab[0], '推拉力': thrustOk, '工作制': duty[0], '静载': staticChk[0] };
    if (isHand) { delete checks['最大输入功率']; delete checks['速度']; checks['扭矩'] = torqueOk; }
    if (svRealMissing) checks['电机真机型'] = false;
    var allPass = powerOk !== false && speedOk && inputRpmOk !== false && stab[0] !== false && thrustOk !== false && staticChk[0] !== false
      && (!isHand || torqueOk !== false);
    if (life) { checks['寿命'] = life.pass; allPass = allPass && life.pass; }
    /**/
    var estStab = stab[2] === 'est';
    return {
      route: 'A', model: model, ratio: opt.ratio, ratio_key: ratioKey, mm_per_rev: mmPerRev,
      steps: steps, checks: checks, all_pass: allPass, est_stab: estStab,
      motor_real_missing: svRealMissing, motor_real_note: svRealNote,
      power_relaxed: !!relaxNote, power_marginal: marginal,
      per_unit_load_kN: r(f1, 2), effective_load_kN: r(fEff, 2),
      p_out_W: r(pOut, 1), p_in_kW: r(pIn / 1000, 3),
      p_in_calc_kW: r(pInCalc / 1000, 3),
      env_coef: kTemp * (hasVacuumGrease(inp.special) ? 2 : 1), motor_overload_coef: kMotor,
      total_power_kW: r(totalPower, 2), motor_torque_Nm: r((tqShowA != null ? tqShowA : (torque != null ? torque : 0)), 1),
      /**/
      motor_torque_motor_Nm: (torque != null && isServo && planet > 1) ? r(torque / (planet * planetEff), 1) : null,
      /**/
      motor_demand_kW: (typeof pMotorReq === 'number') ? r(pMotorReq, 2) : null,
      motor_amp_coef: (typeof ampMotor === 'number') ? ampMotor : null,
      /*
*/
      dual_shaft: dualShaftA ? true : null,
      /**/
      rev_ratio: (huRevSv > 1) ? huRevSv : (huRev > 1 ? huRev : null),
      hand_torque_Nm: handTorque != null ? r(handTorque, 1) : null,
      hand_force_kg: handForce != null ? r(handForce, 1) : null,
      /**/
      hand_force_kg_400: fp ? fp.f400 : null,
      hand_radius_mm: fp ? fp.radius : null,
      hand_force_use_kg: fp ? fp.force : null,
      hand_force_tolerance: fp ? !!fp.tolerance : false,
      hand_force_ok: fp ? fp.ok : null,
      startup_torque_Nm: (typeof stTq === 'number') ? r(stTq, 1) : null,
      startup_torque_page: stPage,
      max_input_torque_Nm: (typeof maxTq === 'number') ? r(maxTq, 1) : null,
      eta_start: etaStartUsed,
      speed_mm_s: r(vActual, 2), rpm_needed: r(rpmNeed, 0),
      /**/
      planetary_ratio: planet > 1 ? planet : null,
      planetary_eff: planet > 1 ? planetEff : null,
      planetary_v_direct: planet > 1 ? r(vDirect, 2) : null,
      /**/
      planetary_out_torque_Nm: planet > 1 && torque != null ? r(torque, 1) : null,
      /**/
      sv_changer: (planet > 1 && svChanger) ? true : null,
      /*
*/
      sv_direct: svDirect154 ? true : null,
      /*

*/
      sv_rated_used: (!isHand && isServo && huFixed149 && svRatedUsed) ? svRatedUsed : null,
      hu_window: (!isHand && isServo && huFixed149) ? true : null,
      /*

*/
      sv_window_dev: (!isHand && isServo && huFixed149 && svRatedUsed && huServoRev)
        ? r((1 - (huServoRev.fixed ? huServoRev.run : huServoRev.r) / svRatedUsed) * 100, 1)
        : null,
      /*

*/
      sv_adj230: (!isHand && isServo && svAdj230) ? true : null,
      /**/
      motor_sync: (!isHand && acFixed) ? rpmSync
        : ((!isHand && isServo && huFixed149 && svRatedUsed) ? svRatedUsed : null),   /**/
      /**/
      speed_warn: res_speed_warn || '',
      motor_recommend: motors, life: life, warnings: warnings
    };
  }

  /**/
  function calcRouteC(inp, data, warnings) {
    var models = data.models, model = inp.model;
    if (!Object.prototype.hasOwnProperty.call(models, model)) throw Missing('参数库无型号 ' + model);
    var m = models[model];
    var ov = inp.overrides || {};
    var steps = [];

    var lead, ballC, rated, eff, stabDef, variant;
    if (Object.prototype.hasOwnProperty.call(m, 'variants')) {
      var varKey = inp.variant;
      if (!varKey) varKey = Object.keys(m.variants)[0];
      var vDef = m.variants[varKey];
      lead = vDef.lead_mm;
      ballC = gv(vDef, 'ball_C_kN', null);
      rated = gv(vDef, 'rated_thrust_kN', null);
      eff = C.pickEfficiency(vDef, gv(inp, 'load_kN', 0), ov.efficiency);
      stabDef = vDef;
      /*

*/
      if (m.stability_curve || m.stability_points) {
        var merged = {}, kk;
        for (kk in vDef) { if (Object.prototype.hasOwnProperty.call(vDef, kk)) merged[kk] = vDef[kk]; }
        if (m.stability_curve) merged.stability_curve = m.stability_curve;
        if (m.stability_points) merged.stability_points = m.stability_points;
        stabDef = merged;
      }
      variant = varKey;
    } else {
      lead = m.lead_mm;
      ballC = gv(m, 'ball_C_kN', null);
      rated = gv(m, 'rated_thrust_kN', null);
      if (isTodo(rated)) throw Missing('型号 ' + model + ' 额定推力待补全');
      eff = C.pickEfficiency(m, gv(inp, 'load_kN', 0), ov.efficiency);
      stabDef = m;
      variant = null;
    }
    /**/
    var scC225 = scStabOf(inp, model, stabDef, data);
    stabDef = scC225.def;

    var units = inp.units;
    var totalKn = gv(inp, 'total_load_kN', null);
    if (totalKn === null && inp.load_kN) totalKn = inp.load_kN * units;
    /**/
    var pullT = Number(inp.load_pull_t) || 0;
    var pushKnC = (inp.load_push_kN != null) ? Number(inp.load_push_kN) : null;
    var f1 = totalKn / units;
    steps.push(['单台负载', (pullT > 0 && pushKnC != null
      ? '推力 ' + fN(pushKnC, 1) + 'kN / 拉力 ' + fN(pullT * 9.81, 1) + 'kN，按大者（'
        + (pullT * 9.81 > pushKnC ? '拉力' : '推力') + '）' + fN(totalKn, 1) + 'kN'
      : '总负载 ' + fN(totalKn, 1) + 'kN')
      + ' ÷ ' + iN(units) + ' 台 = ' + fN(f1, 2) + 'kN']);

    /**/
    var fCoefC = floorCoefOf(model);
    var floorC = (typeof rated === 'number') ? fCoefC * rated : null;
    var floorPctC = iN(Math.round(fCoefC * 100)) + '%';
    var fEff;
    if (floorC && f1 < floorC && !ov.skip_floor) {
      fEff = floorC;
      steps.push([floorPctC + '动载率下限', '按最小负载率 ' + floorPctC + ' 计算，推力取 ' + fN(fEff, 1) + 'kN'
        + (fCoefC === 0.15 ? '（滚珠丝杠下限 15%）' : '')]);
    } else {
      fEff = f1;
      steps.push([floorPctC + '动载率下限', '按实际载荷 ' + fN(fEff, 2) + 'kN 计算']);
    }

    var gearRatio = gv(ov, 'gear_ratio', 2);
    var tScrew = fEff * 1000 * lead / (2 * Math.PI * 1000 * gearRatio * eff);

    /*
*/
    var kTemp = envCoefOf(inp.ambient_temp), envSeg = '';
    var tPure = tScrew;
    if (kTemp !== 1) {
      tScrew *= kTemp;
      envSeg += '；' + envNoteOf(inp.ambient_temp) + ' → × ' + fN(kTemp, 1) + ' = ' + fN(tScrew, 2) + 'Nm';
    }
    if (hasVacuumGrease(inp.special)) {
      tScrew *= 2;
      envSeg += '；真空润滑脂效率很低、价格单独计费 → × 2 = ' + fN(tScrew, 2) + 'Nm';
    }
    steps.push(['丝杠驱动扭矩', 'T = ' + fN(fEff * 1000, 1) + 'N×' + lead + 'mm ÷ (2×3.14×1000×'
      + gearRatio + '×' + fN(eff, 2) + ') = ' + fN(tPure, 2) + 'Nm' + envSeg]);

    /*
*/
    var isHandDrive = inp.drive === 'hand';
    var handTorque = null, etaStartC = null, torqueOkC = null, handForceC = null;
    if (isHandDrive) {
      etaStartC = eff * 0.85;
      handTorque = tScrew / 0.85;   /**/
      /**/
      var handCoefNote = '';
      if (kTemp !== 1) handCoefNote += '低温/高温放大系数 ×' + fN(kTemp, 1) + ' 已含在 T运行内';
      if (hasVacuumGrease(inp.special)) handCoefNote += (handCoefNote ? '；' : '') + '真空润滑脂放大 ×2 已含在 T运行内';
      steps.push(['手摇扭矩', 'T手 = T运行 ÷ (启动效率/运转效率) = ' + fN(tScrew, 2) + 'Nm ÷ 0.85 = '
        + fN(handTorque, 1) + 'Nm（启动效率 = 运转效率 ' + fN(eff, 2) + ' × 0.85 = ' + fN(etaStartC, 2)
        + '，样本未单列启动效率按此估算，需与厂家确认'
        + (handCoefNote ? '；' + handCoefNote : '') + '；手摇驱动无电机功率/转速计算）']);
      /*
*/
      var maxTqC = (typeof gv(stabDef, 'max_input_torque_Nm', null) === 'number'
        && !isTodo(gv(stabDef, 'max_input_torque_Nm', null))) ? gv(stabDef, 'max_input_torque_Nm', null) : null;
      torqueOkC = (maxTqC !== null) ? (handTorque <= maxTqC * 1.001) : null;
      /**/
      var fpC = handForcePlan(handTorque);
      handForceC = fpC ? fpC.f200 : null;
      var forceTxtC = fpC.txt;
      steps.push(['扭矩校核', (maxTqC !== null
        ? '手摇扭矩 ' + fN(handTorque, 1) + 'Nm ' + (torqueOkC ? '≤' : '>') + ' 最大输入扭矩 ' + fN(maxTqC, 1)
          + 'Nm，' + (torqueOkC ? '不超过最大输入扭矩，校核通过' : '超过最大输入扭矩，需增加减速机')
        : '产品最大输入扭矩数据待补全，需与厂家确认')
        + '；按手摇把半径 200mm 计算，手摇力不能超过 10kg：' + forceTxtC]);
      if (torqueOkC === false) warnings.push('【扭矩校核】' + model + ' 手摇扭矩 ' + fN(handTorque, 1)
        + 'Nm 超过最大输入扭矩，需增加减速机 5:1 或 10:1');
    }

    var sync = (inp.sync !== null && inp.sync !== undefined) ? inp.sync : (units > 1 ? '机械' : '单台');
    /*

*/
    var hotC = Number(inp.ambient_temp) >= 80;
    var lrC = (rated > 0) ? f1 / rated : null;
    var amp = gv(ov, 'amp_coef', ampCoefOfEx(units, model, lrC, inp.ambient_temp));
    var ampTxtC = (Math.abs(amp * 10 - Math.round(amp * 10)) < 1e-9) ? fN(amp, 1) : fN(amp, 2);
    var ampOvrC = (ov.amp_coef == null && !hotC && amp !== ampCoefOf(units))
      ? '；四台同步且单台负载率 ' + fN(lrC * 100, 1) + '%<10%：放大系数由 ' + fN(ampCoefOf(units), 1)
        + ' 调整为 ' + fN(amp, 1) + '（' + (floorCoefOf(model) === 0.15 ? '滚珠丝杠' : '梯形丝杠') + '，2026-10-22 定稿）'
      : '';
    var tTotal, tPlatform = null, stagesUsed = 0;
    var elecOneStepC = false;   /**/
    if (units > 1 && !isHandDrive) {
      if (sync === '电气') {
        /*

*/
        tTotal = tScrew * 1.5;
        elecOneStepC = true;
        steps.push(['电气同步 · 单台电机扭矩', '每台一台伺服电机（可加行星减速机）：单台丝杠驱动扭矩 '
          + fN(tScrew, 2) + 'Nm（= 总负载 ÷ ' + iN(units) + ' 台口径）× 放大系数 1.5 = '
          + fN(tTotal, 2) + 'Nm（唯一放大：无组合系数/换向器级损/台数放大；2026-11-03 批复）']);
      } else {
      var combo = gv(ov, 'combo_coef', comboCoefOf(units));
      var rev = gv(ov, 'reverse_eff', 0.9);
      /*





*/
      stagesUsed = gv(ov, 'stages', (function (layC221) {
        layC221 = String(layC221 || '');
        if (/^U2/.test(layC221)) return 3;
        if (layC221.indexOf('H型') === 0) return units >= 4 ? 3 : Math.max(1, units - 1);
        return 1;
      })(inp.layout));
      /*
*/
      var divisor = C.evalDivisor(ov.custom_divisor, combo * Math.pow(rev, stagesUsed));
      tPlatform = tScrew * units / divisor;
      tTotal = tPlatform * amp;
      /*


*/
      var lossName = (function (lay) {
        lay = String(lay || '');
        if (lay.indexOf('电机中间') >= 0 || lay.indexOf('垂直') >= 0 || lay === 'H型布置' || lay === 'U型布置' || lay === 'U2型布置' || lay === 'H型' || lay === 'U型' || lay === 'U2型') return '换向器';
        if (lay === '直线布置' && [4, 6, 8].indexOf(units) >= 0 && gv(inp, 'dual_shaft', false) !== true) return '换向器';
        return '传动级损';
      })(inp.layout);
      var divTxt = ov.custom_divisor || ('组合' + fN(combo, 2) + '×' + lossName + fN(rev, 2) + '^' + iN(stagesUsed));
      /*


*/
      var ampRuleC = (units === 4 && !ov.amp_coef && !hotC)
        ? '；4 台默认放大系数 1.5，若按 1.4 可靠到小一档标准电机功率则取 1.4（2026-10-22 定稿）'
        : '';
      steps.push(['平台扭矩', 'T平 = ' + fN(tScrew, 2) + 'Nm×' + iN(units) + ' ÷ (' + divTxt + ') = '
        + fN(tPlatform, 2) + 'Nm；× 放大系数 ' + ampTxtC + ' = ' + fN(tTotal, 2) + 'Nm'
        + '（多台同步只放大这一次；' + (hotC
          ? '高温 +80℃ 台数放大按 单台2/两台2/三台2.5/四台3/八台4（含高温环境系数 ×2），低温/高温环境系数已在丝杠驱动扭矩计入'
          : '低温/高温系数已在丝杠驱动扭矩计入')
        + ampRuleC + ampOvrC + '）']);
      /*
*/
      if (units === 4 && ov.amp_coef == null && amp === 1.5 && !hotC && !isHandDrive) {
        var revF = Number(gv(inp, 'rev_ratio', 1)) || 1;
        var rpmF = (inp.motor_rpm !== null && inp.motor_rpm !== undefined) ? inp.motor_rpm : 3000;
        var plF = gv(ov, 'planetary_ratio', null);
        var plEffF = gv(ov, 'planetary_eff', 0.95);
        var chain14 = function (t) {
          var x = t;
          if (revF > 1) x = x / revF / (stagesUsed > 0 ? 1 : 0.9);
          if (plF) x = x / plEffF / plF;
          return x;
        };
        var t15F = chain14(tPlatform * 1.5), t14F = chain14(tPlatform * 1.4);
        var m15F = recommendMotor(motorLibData(inp, data), t15F * rpmF / 9550, t15F, rpmF, driveKindOf(inp));
        var m14F = recommendMotor(motorLibData(inp, data), t14F * rpmF / 9550, t14F, rpmF, driveKindOf(inp));
        if (m15F.length && m14F.length && m14F[0].power_kW < m15F[0].power_kW - 1e-9) {
          amp = 1.4;
          tTotal = tPlatform * 1.4;
          steps[steps.length - 1][1] += '；四台同步放大系数改取 1.4';   /**/
        }
      }
      }
    } else {
      tTotal = tScrew;
    }

    /*

*/
    var revRatio = Number(gv(inp, 'rev_ratio', 1)) || 1;
    /*






*/
    var isServoC16 = String(inp.drive || '').indexOf('servo') === 0;
    var vReqC16 = Number(inp.speed_mm_s) || 0;
    var svForcedC16 = Number(inp.servo_rated) || 0;   /**/
    var svTierC16 = null, svWinC16 = null;
    var plRatioC16 = isHandDrive ? null : gv(ov, 'planetary_ratio', null);
    if (!isHandDrive && isServoC16 && !(svForcedC16 > 0) && units >= 2 && vReqC16 > 0 && !plRatioC16
      && /电机中间|导向柱一体化|H型|U2型|U型/.test(String(inp.layout || ''))) {
      var needInC16 = vReqC16 * 60 * gearRatio / lead;   /**/
      if (needInC16 > 0) {
        var mdC16 = motorLibData(inp, data) || {};
        var libC16 = (mdC16.motor_library || []).filter(function (mm) {
          if (motorKind(mm) !== 'servo') return false;
          if (mdC16.servo_narrow !== false) {
            var fC = servoFamOf(mm.brand); if (fC !== 'V90' && fC !== 'S200') return false;
          }
          return true;
        });
        /*





*/
        var pBaseC16 = tTotal * needInC16 / 9550 / (stagesUsed > 0 ? 1 : 0.9);
        var smallC16 = pBaseC16 <= SMALL_PWR_MAX + 1e-9;
        var tiersC16 = (smallC16 ? [3000] : [1500, 2000, 2500, 3000]).filter(function (t) {
          return libC16.some(function (mm) { return Number(mm.rpm) === t; });
        });
        var bestC16 = null, fbkC16 = null;
        var devMaxC16 = 1 - 1 / (1 + speedAllowPctOf(inp, true) / 100);   /* 25% → dev 20% */
        tiersC16.forEach(function (t) {
          REV158.forEach(function (rv) {
            if (rv === 1 && t > JACK_IN_MAX + 1e-9) return;    /**/
            var runF = needInC16 * rv;
            if (runF > t * 1.002 + 1e-6 || runF < SERVO_MIN_RPM - 1e-9) return;
            var tReqF = tTotal / rv / (stagesUsed > 0 ? 1 : 0.9);   /**/
            var pReqF = tReqF * runF / 9550;                        /**/
            var hasMF = libC16.some(function (mm) {
              if (Number(mm.rpm) !== t) return false;
              var p0 = Number(mm.power_kW) || 0;
              /*




*/
              if (!servoRpmAllowed(p0, t, mm.brand)) return false;
              return p0 >= pReqF - 1e-9 && p0 <= pReqF * 2 + 1e-9 && (Number(mm.torque_Nm) || 0) >= tReqF - 1e-9;
            });
            if (!hasMF) return;
            var devF = 1 - runF / t;
            var cd = { rv: rv, r: t, run: runF, dev: devF };
            if (devF <= devMaxC16 + 1e-9) {
              if (!bestC16 || devF < bestC16.dev - 1e-9
                || (Math.abs(devF - bestC16.dev) <= 1e-9 && t < bestC16.r)) bestC16 = cd;
            } else if (!fbkC16 || devF < fbkC16.dev - 1e-9
              || (Math.abs(devF - fbkC16.dev) <= 1e-9 && t < fbkC16.r)) fbkC16 = cd;
          });
        });
        var winC16 = bestC16 || fbkC16;
        if (winC16) {
          revRatio = winC16.rv;
          svTierC16 = winC16.r;
          svWinC16 = winC16;
          steps.push(['换向器速比配比', '按「调速窗口配比」（速比跟速度走）：所需输入 ' + iN(needInC16)
            + 'rpm，取 ' + iN(winC16.r) + 'rpm 档 + 换向器速比 1:' + iN(winC16.rv)
            + (winC16.rv === 1 ? '（直通）' : '') + '，运行转速 ' + iN(winC16.run) + 'rpm（向下调速 '
            + iN(Math.round(winC16.dev * 1000) / 10) + '%，'
            + (bestC16 ? '落 ' + fN(devMaxC16 * 100, 1) + '% 窗口内、同幅度取低额定档' : '超出窗口，为最小调速兜底，须与厂家确认')
            + '）；换向器输入端 ' + iN(winC16.run / winC16.rv) + 'rpm ≤ 1500rpm']);
        }
      }
    }
    var tMotor = tTotal;
    if (revRatio > 1) {
      var revEffN = stagesUsed > 0 ? 1 : 0.9;   /**/
      var tPre = tMotor;
      tMotor = tMotor / revRatio / revEffN;
      steps.push(['换向器减速折算', '伞齿轮换向器减速比 1:' + fN(revRatio, 1)
        + (revRatio === 1 || revRatio === 2 ? '（RS 系列标准）' : '（可选，非 1:1/1:2 优先档）')
        + '：T = ' + fN(tPre, 2) + 'Nm ÷ ' + fN(revRatio, 1) + (revEffN < 1 ? ' ÷ 0.9' : '')
        + ' = ' + fN(tMotor, 2) + 'Nm（电机端扭矩随减速比减小，电机选小、性价比高）']);
    }

    /**/
    var rpm = svTierC16
      || ((inp.motor_rpm !== null && inp.motor_rpm !== undefined) ? inp.motor_rpm : 3000);
    /*

*/
    var acSyncC = null;
    if ((inp.drive === 'ac3' || inp.drive === 'ac1') && !svTierC16) acSyncC = rpm;
    var plRatio = isHandDrive ? null : gv(ov, 'planetary_ratio', null);
    var tPlOut = null;   /**/
    var safetyCoefUsed = null;
    /*





*/
    var plEffAuto = null, plAutoApplied = false;
    var isServoC0 = String(inp.drive || '').indexOf('servo') === 0;
    /*
*/
    var isAcC0 = (inp.drive === 'ac3' || inp.drive === 'ac1' || inp.drive === 'dc24');
    var isDcC233 = (inp.drive === 'dc24');
    var vReqC0 = Number(inp.speed_mm_s) || 0;
    if (!isHandDrive && isAcC0 && !plRatio && revRatio <= 1 && vReqC0 > 0) {
      var rpmNeedC0 = vReqC0 * 60 * gearRatio * revRatio / lead;
      var vDirC0 = rpm / 60 / gearRatio / revRatio * lead;
      var devDirC0 = (vDirC0 / vReqC0 - 1) * 100;
      if (Math.abs(devDirC0) > 20 + 1e-9) {
        var marginC0 = (Number(inp.units) || 1) >= 2 ? 1.0 : 1.1;
        var scC0 = (units <= 1) ? gv(ov, 'safety_coef', 1.2) : 1;
        var kMotorC0 = motorOverloadCoefOf(inp.drive);
        if (isDcC233) {
          /*
*/
          var bestD233 = null, dvD233 = 0;
          GB_STD.forEach(function (iD) {
            var outD = rpm / iD;
            if (outD < rpmNeedC0 * 0.8 - 1e-9 || outD > rpmNeedC0 * 1.2 + 1e-9) return;
            var dvD = Math.abs(outD - rpmNeedC0);
            if (bestD233 === null || dvD < dvD233 - 1e-9 || (Math.abs(dvD - dvD233) <= 1e-9 && iD > bestD233)) {
              bestD233 = iD; dvD233 = dvD;
            }
          });
          if (bestD233 !== null) {
            plRatio = bestD233;
            plEffAuto = gbEffOf(plRatio);
            plAutoApplied = true;
            steps.push(['行星减速机匹配', '直流直连实际速度 ' + fN(vDirC0, 2) + 'mm/s 比要求 ' + fN(vReqC0, 2)
              + 'mm/s 偏差 ' + (devDirC0 >= 0 ? '+' : '') + fN(devDirC0, 0) + '%（超 ±20%，不满足速度匹配）'
              + '——按交流电机同一规则自动配行星减速机：直流电机（' + rpm + 'rpm）配 i=' + fN(plRatio, plRatio % 1 ? 1 : 0)
              + ':1（效率 ' + fN(plEffAuto, 2) + '），升降机输入 ' + fN(rpm / plRatio, 1)
              + 'rpm，输出速度 ' + fN(rpm / plRatio / 60 / gearRatio * lead, 2)
              + 'mm/s（要求 ' + fN(vReqC0, 2) + 'mm/s，偏差 '
              + ((rpm / plRatio / 60 / gearRatio * lead / vReqC0 - 1) * 100 >= 0 ? '+' : '')
              + fN((rpm / plRatio / 60 / gearRatio * lead / vReqC0 - 1) * 100, 1)
              + '%，0.8~1.2 倍窗口内最贴近）；电机表锁定该口径、不再出直连行']);
          }
        } else {
        var candsC0 = [];
        (motorLibData(inp, data).motor_library || []).forEach(function (mm0) {
          if (!mm0 || (mm0.kind && mm0.kind !== 'ac') || (!mm0.kind && String(mm0.brand || '').indexOf('交流') !== 0)) return;
          if ((Number(mm0.rpm) || 0) > JACK_IN_MAX + 1e-9) return;   /**/
          var bestI0 = null, bestDv0 = 0;
          GB_STD.forEach(function (i0) {
            var out0 = mm0.rpm / i0;
            if (out0 < rpmNeedC0 * 0.8 - 1e-9 || out0 > rpmNeedC0 * 1.2 + 1e-9) return;
            var dv0 = Math.abs(out0 - rpmNeedC0);
            if (bestI0 === null || dv0 < bestDv0 - 1e-9 || (Math.abs(dv0 - bestDv0) <= 1e-9 && i0 > bestI0)) {
              bestI0 = i0; bestDv0 = dv0;
            }
          });
          if (bestI0 === null) return;
          var tM0 = tMotor / (gbEffOf(bestI0) * bestI0) * scC0 * kMotorC0;
          var pM0 = tM0 * mm0.rpm / 9550;
          if (mm0.power_kW < pM0 * marginC0 - 1e-9) return;
          if (mm0.torque_Nm < tM0 * marginC0 - 1e-9) return;
          candsC0.push({ motor: mm0, i: bestI0, v: mm0.rpm / bestI0 / 60 / gearRatio * lead,
            dv: bestDv0, p: mm0.power_kW });
        });
        candsC0.sort(function (a0, b0) {
          return (a0.p - b0.p) || (a0.dv - b0.dv) || (b0.i - a0.i);
        });
        if (candsC0.length) {
          var w0 = candsC0[0];
          plRatio = w0.i;
          rpm = w0.motor.rpm;
          plEffAuto = gbEffOf(plRatio);
          plAutoApplied = true;
          steps.push(['行星减速机匹配', '交流直连实际速度 ' + fN(vDirC0, 2) + 'mm/s 比要求 ' + fN(vReqC0, 2)
            + 'mm/s 偏差 ' + (devDirC0 >= 0 ? '+' : '') + fN(devDirC0, 0) + '%（超 ±20%，不满足速度匹配）'
            + '——按 自动配行星减速机：' + w0.motor.code + '（' + fN(w0.motor.power_kW, 2)
            + 'kW，' + iN(w0.motor.rpm) + 'rpm）配 i=' + fN(plRatio, plRatio % 1 ? 1 : 0)
            + ':1（效率 ' + fN(plEffAuto, 2) + '），升降机输入 ' + fN(rpm / plRatio, 1)
            + 'rpm，输出速度 ' + fN(w0.v, 2) + 'mm/s（要求 ' + fN(vReqC0, 2) + 'mm/s，偏差 '
            + ((w0.v / vReqC0 - 1) * 100 >= 0 ? '+' : '') + fN((w0.v / vReqC0 - 1) * 100, 1)
            + '%，0.8~1.2 倍窗口内最贴近）；电机表锁定该口径、不再出直连行']);
        }
        }
      }
    }
    if (plRatio) {
      var plEff = plEffAuto || gv(ov, 'planetary_eff', 0.95);
      var tPrePl = tMotor;
      tMotor = tMotor / plEff / plRatio;
      tPlOut = tPrePl;
      /*
*/
      steps.push(['行星减速机', '减速比 ' + fN(plRatio, plRatio % 1 ? 1 : 0) + ':1：电机端需求 T = '
        + fN(tPrePl, 2) + 'Nm ÷ ' + fN(plEff, 2) + '（效率）÷ ' + fN(plRatio, 1) + ' = ' + fN(tMotor, 2)
        + 'Nm；输出端需求扭矩约 ' + fN(tPlOut, 1) + 'Nm（额定输出扭矩须大于电机扭矩×' + fN(plRatio, 0)
        + '），输入转速 ' + iN(rpm) + ' rpm（≤减速机额定输入转速）']);
    }
    if (units <= 1 && !isHandDrive) {
      /*

*/
      var sc = gv(ov, 'safety_coef', 1.2);
      tMotor *= sc;
      steps.push(['安全系数', '电机扭矩 × ' + fN(sc, 1) + ' = ' + fN(tMotor, 2) + 'Nm（单台安全裕量，唯一次放大；'
        + '安全系数一般取 1.2，为凑电机标准功率档可取 1.1，须在方案中注明）']);
      safetyCoefUsed = sc;
    }
    /**/
    var kMotor = motorOverloadCoefOf(inp.drive);
    if (kMotor !== 1) {
      var tBase = tMotor;
      tMotor *= kMotor;
      steps.push(['电机不过载裕量', (inp.drive === 'stepper'
        ? '步进电机额定 300rpm、最大 1000rpm，不能过载' : '单相交流电机不能过载')
        + '，功率与扭矩按 × ' + fN(kMotor, 1) + ' 放大选型：T = ' + fN(tBase, 2) + 'Nm × '
        + fN(kMotor, 1) + ' = ' + fN(tMotor, 2) + 'Nm']);
    }
    if (sync === '电气' && !elecOneStepC) {
      var ec = gv(ov, 'elec_coef', 1.5);
      tMotor *= ec;
      steps.push(['电气同步', '电机扭矩 × ' + fN(ec, 1) + ' = ' + fN(tMotor, 2) + 'Nm']);
    }

    var vActual, extra = '';
    if (plRatio) {
      vActual = rpm / 60 / gearRatio / revRatio / plRatio * lead;
      extra = '÷' + plRatio + '(减速机)';
    } else {
      vActual = rpm / 60 / gearRatio / revRatio * lead;
    }
    /*

*/
    var vReq = Number(inp.speed_mm_s) || 0;
    var speedOk = true, speedNote = '';
    var isServo = (String(inp.drive || '').indexOf('servo') === 0);
    if (isServo && vReq > 0) {
      var overPct = (vActual / vReq - 1) * 100;
      var allowPctC = speedAllowPctOf(inp, true);
      var revTag = '总减速比 = 伞齿轮 1:' + fN(gearRatio, 1)
        + (revRatio > 1 ? ' × 换向器 1:' + fN(revRatio, 1)
          + (revRatio === 1 || revRatio === 2 ? '（标准）' : '（可选，非 1:1/1:2 优先档）') : '')
        + (plRatio ? ' × 行星减速机 ' + fN(plRatio, plRatio % 1 ? 1 : 0) + ':1' : '');
      /*

*/
      if (vActual < vReq * 0.995 - 1e-9) {
        speedOk = false;
        speedNote = '；输出速度低于要求，需减小减速比或加大导程档';
      } else if (overPct > allowPctC + 1e-9) {
        speedOk = false;
        speedNote = '；高出要求 ' + fN(overPct, 1) + '%，超过 +' + fN(allowPctC, 0) + '% 允许范围，需调整减速比';
      } else {
        /**/
        speedNote = '；高出要求 ' + fN(overPct, 1) + '%，在 +' + fN(allowPctC, 0) + '% 允许范围内'
          + (overPct > 10 + 1e-9
            ? '（伺服向下调速 ' + fN(overPct / (100 + overPct) * 100, 1) + '% 即精确达速）' : '');
      }
      steps.push(['速度校核', '按电机额定转速 ' + iN(rpm) + 'rpm 计算（不按调速）：' + revTag
        + '，v = ' + iN(rpm) + '÷60÷' + fN(gearRatio * revRatio, 1) + extra + '×' + lead + 'mm = '
        + fN(vActual, 2) + 'mm/s（要求 ' + fN(vReq, 2) + 'mm/s）' + speedNote
        + (isServo
          ? '；计算基准转速按 2026-10-22 规则选取（需求功率 <0.75kW 按 3000rpm；'
            + '≥0.85kW 西门子按 2000rpm 优先、其次 3000rpm），电机表按同一基准推荐'
          : '')]);
    } else if (!isHandDrive) {
      /**/
      /*
*/
      var acTagC = acSyncC
        ? '，交流 ' + ({ 1500: 4, 1000: 6, 750: 8 }[acSyncC] || '?') + ' 极（同步 ' + iN(acSyncC) + 'rpm）'
        : '';
      /**/
      var drvTagC233 = isDcC233
        ? '（直流电机按额定转速档使用）'
        : '（交流电机按最接近转速档使用' + acTagC + '）';
      steps.push(['速度校核', 'v = ' + iN(rpm) + '÷60÷' + fN(gearRatio * revRatio, 1) + extra + '×' + lead + 'mm = '
        + fN(vActual, 2) + 'mm/s'
        + (plAutoApplied && vReq > 0
          ? '（要求 ' + fN(vReq, 2) + 'mm/s，偏差 ' + ((vActual / vReq - 1) * 100 >= 0 ? '+' : '')
            + fN((vActual / vReq - 1) * 100, 1) + '%，0.8~1.2 倍窗口内' + (isDcC233 ? '' : acTagC) + '）'
          : drvTagC233)]);
    }

    /*
*/
    var trapMaxC = (m && m.trap_speed_max_mm_s != null) ? Number(m.trap_speed_max_mm_s) : null;
    if (trapMaxC != null && !isHandDrive && vActual > trapMaxC + 1e-9) {
      speedOk = false;
      steps.push(['速度上限校核', '梯形丝杠自锁型（EHA）输出速度不能高于 ' + fN(trapMaxC, 0)
        + 'mm/s，当前按 ' + fN(vActual, 2) + 'mm/s 超限——需减小丝杠导程档或降低输入转速']);
    }
    if (trapMaxC != null && !isHandDrive) {
      steps.push(['梯形丝杠自锁说明', 'EHA（梯形丝杠）自锁，整体效率 ' + fN(eff * 100, 0)
        + '%，不做寿命校核；电机可不增加制动器（梯形丝杠自锁防逆转）']);
    }

    /*

*/
    var rpmInputC = rpm / ((plRatio || 1) * revRatio);
    var inputRpmOkC = isHandDrive ? true : (!vReq ? true : rpmInputC <= JACK_IN_MAX + 0.5);
    if (!inputRpmOkC) {
      steps.push(['输入转速校核', '升降机输入转速 ' + iN(Math.round(rpmInputC)) + 'rpm 超出最大输入转速 1500rpm'
        + '（SJA/SJB/KV/SCA/SCB/EHB 限值），该配置不可用']);
    }

    /*

*/
    var pullDomC = pullDominantOf(inp);
    var stab;
    if (pullDomC && pushKnC > 0) {
      var fPushC = pushKnC / units;
      stab = stabilityCheck(stabDef, fPushC, inp.stroke_mm, inp.motion || 'S', scC225.mounting, scC225.model, data,
        screwDiaOf({ screw: gv(stabDef, 'screw', '') || gv(m, 'screw', '') }, model));
      stab = [stab[0], '拉力工况（总负载拉力大于推力），按推力 ' + fN(fPushC, 1) + 'kN 校核稳定性；' + stab[1]];
    } else if (pullDomC) {
      stab = [true, '拉力工况且推力为 0，丝杠受拉无压弯风险，按选择规则不校核稳定性'];
    } else {
      stab = stabilityCheck(stabDef, f1, inp.stroke_mm, inp.motion || 'S', scC225.mounting, scC225.model, data,
        screwDiaOf({ screw: gv(stabDef, 'screw', '') || gv(m, 'screw', '') }, model));
    }
    steps.push(['稳定性校核', stab[1] + (stab[0] === true ? '，校核通过' : (stab[0] === false ? '，校核失败' : ''))]);
    if (stab[0] === null) warnings.push('稳定性数据待补全（' + model + '）');

    /**/
    var staticChk = staticCheckStep(m, rated, inp, fEff, units);
    steps.push(['静载校核', staticChk[1]]);
    if (staticChk[0] === false) warnings.push('【静载校核】' + model + ' 静载需求超过额定静载，请放大型号或与厂家确认');

    /*

*/
    var thrustOk = (typeof rated === 'number' && !isTodo(rated)) ? (fEff <= rated * 1.001) : null;
    steps.push(['推力校核', '单台需求 ' + fN(fEff, 1) + 'kN '
      + (thrustOk === null ? '：产品推力数据待补全，需与厂家确认'
        : (thrustOk ? '≤' : '>') + ' 最大提升力（=最大推拉力）' + fN(rated, 1) + 'kN，'
          + (thrustOk ? '校核通过' : '推力不足，需选更大型号'))]);
    if (thrustOk === false) warnings.push('【推力校核】' + model + ' 单台需求 ' + fN(fEff, 1)
      + 'kN 超过最大提升力 ' + fN(rated, 1) + 'kN，需选更大型号');

    var brakeAdv = brakeAdvice(model, null, m);
    /**/
    if (brakeAdv && inp.drive !== 'hand') warnings.push('【制动器建议】' + brakeAdv);

    var life = null;
    var doLife = m.life_check;
    if (doLife === true || isTodo(doLife)) {
      if (ballC && !isTodo(ballC)) {
        life = C.lifeCheck(ballC, lead, fEff, inp.stroke_mm, inp.cycles_per_day,
          (inp.days_per_year !== null && inp.days_per_year !== undefined) ? inp.days_per_year : 300,
          gv(ov, 'round_trip', true), inp.life_years);
        if (life) {
          steps.push(['寿命校核', '理论公里数 = (' + ballC + '/' + fN(fEff, 1) + ')³×' + lead
            + 'mm = ' + fN(life.life_km, 0) + 'km；年用 ' + fN(life.annual_km, 1) + 'km；' + life.note]);
        }
      } else {
        warnings.push('型号 ' + model + ' 丝杠类型/动载 TODO，寿命校核需人工确认');
      }
    }

    var loadRate = (typeof rated === 'number' && rated) ? (fEff / rated) : null;
    var duty = dutyCheck(model, inp.series, inp.cycles_per_day, inp.speed_mm_s || vActual, loadRate);
    steps.push(['工作制校核', duty[1]]);
    if (duty[0] === false) warnings.push('【系列选择原则警告】' + duty[1]);

    /*

*/
    var powerKw = isHandDrive ? null : (tMotor * rpm / 9550);
    if (powerKw) {
      steps.push(['电机功率', 'P = ' + fN(tMotor, 2) + 'Nm×' + iN(rpm) + 'rpm÷9550 = ' + fN(powerKw, 2) + 'kW'
        + (plRatio ? '（电机端，已经行星减速机折算）' : '')]);
    }
/*


*/
var svLockC = null;
if (!isHandDrive) {
  if (revRatio > 1) {
    /*



*/
    var bevelFamC = /^(EHB|EHA|DHB)/i.test(String(model || ''));
    /*





*/
    svLockC = { huRev: revRatio, rated: rpm,
      winU: (typeof devMaxC16 === 'number') ? (1 / (1 - devMaxC16)) : undefined,
      outNeed: (typeof devMaxC16 === 'number' && typeof needInC16 === 'number') ? needInC16 : undefined,
      revList: bevelFamC ? [1, 2, 3, 5, 6, 8, 10, 15, 20, 25, 30, 40, 50] : [1, 2, 3, 5, 6, 8, 10],
      pEnd: true, eff: revEffN };
  } else if (plRatio > 1) {
    /**/
    svLockC = { rated: rpm, ratio: plRatio, type: '行星减速机', pEnd: true, eff: plEffAuto || gv(ov, 'planetary_eff', 0.95) };
  }
}
var needBrakeC = (isHandDrive) ? false : needBrakeOfAdv(brakeAdvice(model, null, m));
/*



*/
var rpmForMotorC = ((driveKindOf(inp) === 'ac' || driveKindOf(inp) === 'dc') && svLockC && svLockC.huRev && !svLockC.ratio)
  ? rpm
  : (rpmInputC > 0 ? rpmInputC : rpm);
var motors = applyServoBrandLock((inp.drive === 'hand' || inp.drive === 'none')
  ? [] : recommendMotor(motorLibData(inp, data), powerKw, tMotor, rpmForMotorC,
    driveKindOf(inp),
    null, null, svLockC, (Number(inp.units) || 1) >= 2, true, false, needBrakeC),
  inp, powerKw, tMotor, rpm);

/*




*/
if (svLockC && svLockC.huRev && !isHandDrive && /servo/i.test(String(inp.drive || ''))) {
  var hRatedC = Number(svLockC.rated) || 0;
  var hRatioC = Number(svLockC.huRev) || 0;
  var hTagC = hRatioC + ':1';
  var hasMainC = (motors || []).some(function (x) {
    return !x.alt_underspeed && Number(x.rpm) === hRatedC
      && x.gearbox && String(x.gearbox.ratio) === hTagC;
  });
  if (hRatedC > 0 && hRatioC > 0 && !hasMainC) {
    /*
*/
    var srcC = (motors || []).filter(function (x) { return Number(x.rpm) === hRatedC; })[0] || null;
    if (!srcC) {
      var poolC = [];
      (data.motor_library || []).forEach(function (mm) {
        if (motorKind(mm) !== 'servo' || Number(mm.rpm) !== hRatedC) return;
        if (data.servo_narrow !== false) {
          var fC = servoFamOf(mm.brand);
          if (fC !== 'V90' && fC !== 'S200') return;
        }
        if (!servoRpmAllowed(mm.power_kW, mm.rpm, mm.brand)) return;
        poolC.push(mm);
      });
      poolC.sort(function (a2, b2) {
        return Math.abs(a2.power_kW - (powerKw || 0)) - Math.abs(b2.power_kW - (powerKw || 0));
      });
      var mmC = poolC[0];
      if (mmC) {
        var brakeRawC = gv(mmC, 'brake', '');
        srcC = {
          brand: mmC.brand, code: mmC.code, kind: 'servo', poles: gv(mmC, 'poles', null),
          power_kW: mmC.power_kW, rpm: mmC.rpm, torque_Nm: mmC.torque_Nm,
          current_A: gv(mmC, 'current_A', null), frame: gv(mmC, 'frame', ''),
          flange: gv(mmC, 'flange', ''), voltage: gv(mmC, 'voltage', ''),
          ip: gv(mmC, 'ip', ''), insulation: gv(mmC, 'insulation', ''),
          brake: (typeof brakeRawC === 'string') ? brakeRawC : (brakeRawC ? '内置抱闸可选配' : '')
        };
      }
    }
    if (srcC) {
      var rowMC = JSON.parse(JSON.stringify(srcC));
      rowMC.gearbox = { ratio: hTagC, type: '伞齿轮换向器', out_rpm: Math.round(hRatedC / hRatioC), eff: 1 };
      rowMC.pEnd = true;
      delete rowMC.alt_underspeed; delete rowMC.overspeed; delete rowMC.torque_at_speed;
      rowMC.within_10pct = false;
      /*
*/
      var needKwMC = (powerKw === null || powerKw === undefined) ? null : powerKw;
      var needTqMC = (tMotor === null || tMotor === undefined) ? null : tMotor;
      var enoughMC = (needKwMC === null || srcC.power_kW >= needKwMC - 1e-9)
        && (needTqMC === null || srcC.torque_Nm >= needTqMC - 1e-9);
      rowMC.fit = enoughMC
        ? ((needKwMC !== null && srcC.power_kW >= needKwMC * 1.2 - 1e-9) ? '1.2' : '1.1')
        : 'over';
      if (!enoughMC) {
        /*
*/
        var biggerMC = false;
        (data.motor_library || []).forEach(function (mb) {
          if (biggerMC || motorKind(mb) !== 'servo' || Number(mb.rpm) !== hRatedC) return;
          if (data.servo_narrow !== false) {
            var fB = servoFamOf(mb.brand);
            if (fB !== 'V90' && fB !== 'S200') return;
          }
          if ((needKwMC === null || mb.power_kW >= needKwMC - 1e-9)
            && (needTqMC === null || mb.torque_Nm >= needTqMC - 1e-9)) biggerMC = true;
        });
        rowMC.note = '方案口径行（' + iN(hRatedC) + 'rpm × 1:' + iN(hRatioC) + '，与左侧计算过程同档同比）：'
          + '电机端需求 ' + fN(needKwMC, 2) + 'kW / ' + fN(needTqMC, 1) + 'Nm 超本档额定 '
          + fN(srcC.power_kW, 2) + 'kW / ' + fN(srcC.torque_Nm, 1) + 'Nm——'
          + (biggerMC
            ? '本档库内有更大功率机型但未列入（口径待核），需与厂家确认后按大机座号核价'
            : '本档库内无更大机座号，需与厂家确认更大功率伺服，或改选同档欠速备选行（电机更小、输出速度低约 1 个速比档）');
      }
      motors.unshift(rowMC);
    }
  } else if (hRatedC > 0 && hRatioC > 0 && hasMainC) {
    /*


*/
    var rowMainC = (motors || []).filter(function (x) {
      return !x.alt_underspeed && Number(x.rpm) === hRatedC
        && x.gearbox && String(x.gearbox.ratio) === hTagC;
    })[0];
    var idxMainC = (motors || []).indexOf(rowMainC);
    if (rowMainC && idxMainC > 0) motors.unshift(motors.splice(idxMainC, 1)[0]);
  }
}

    /**/
    var svRealMissingC = false, svRealNoteC = '';
    if (!isHandDrive && String(inp.drive || '').indexOf('servo') === 0) {
      var realRowsC = (motors || []).filter(function (x) { return x.fit !== 'over'; });
      if (!realRowsC.length) {
        svRealMissingC = true;
        var ovRowC = (motors || []).filter(function (x) { return x.fit === 'over'; })[0];
        svRealNoteC = ovRowC ? ('所选品牌库内无适用真机型（' + (ovRowC.note || '超出库内最大档') + '）；方案机械侧校核按需求值计算，需与厂家确认更大机座号或调整方案')
          : '所选品牌库内无适用真机型；方案机械侧校核按需求值计算，需与厂家确认更大机座号或调整方案';
        warnings.push('【电机真机型】' + svRealNoteC);
      }
    }

    var checks = { '稳定性': stab[0], '速度': speedOk, '输入转速': inputRpmOkC, '推力': thrustOk, '工作制': duty[0], '静载': staticChk[0] };
    if (isHandDrive) { delete checks['速度']; checks['扭矩'] = torqueOkC; }
    if (svRealMissingC) checks['电机真机型'] = false;
    if (life) checks['寿命'] = life.pass;
    var allPass = stab[0] !== false && speedOk !== false && inputRpmOkC !== false && thrustOk !== false && staticChk[0] !== false
      && (!life || life.pass) && (!isHandDrive || torqueOkC !== false);
    return {
      route: 'C', model: model, variant: variant, lead_mm: lead,
      steps: steps, checks: checks, all_pass: allPass, est_stab: stab[2] === 'est',
      motor_real_missing: svRealMissingC, motor_real_note: svRealNoteC,
      per_unit_load_kN: r(f1, 2), effective_load_kN: r(fEff, 2),
      screw_torque_Nm: r(tScrew, 2),
      platform_torque_Nm: tPlatform ? r(tPlatform, 2) : null,
      torque_at_jack_Nm: r(tTotal, 2),
      rev_ratio: revRatio,
      /**/
      dual_shaft: gv(inp, 'dual_shaft', false) === true ? true : null,
      planetary_ratio: plRatio || null,
      planetary_eff: plRatio ? (plEffAuto || gv(ov, 'planetary_eff', 0.95)) : null,
      planetary_auto: plAutoApplied ? true : null,
      planetary_out_torque_Nm: tPlOut != null ? r(tPlOut, 1) : null,
      safety_coef: safetyCoefUsed,
      motor_torque_Nm: r(tMotor, 2), speed_mm_s: r(vActual, 2),
      hand_torque_Nm: handTorque != null ? r(handTorque, 1) : null,
      hand_force_kg: handForceC != null ? r(handForceC, 1) : null,
      hand_force_kg_400: fpC ? fpC.f400 : null,
      hand_radius_mm: fpC ? fpC.radius : null,
      hand_force_use_kg: fpC ? fpC.force : null,
      hand_force_tolerance: fpC ? !!fpC.tolerance : false,
      hand_force_ok: fpC ? fpC.ok : null,
      eta_start: etaStartC,
      speed_ok: speedOk, speed_over_pct: (vReq > 0) ? r((vActual / vReq - 1) * 100, 1) : null,
      /*
*/
      hu_window: !!svWinC16,
      sv_rated_used: svTierC16 || null,
      sv_window_dev: svWinC16 ? r(svWinC16.dev * 100, 1) : null,
      motor_power_kW: powerKw ? r(powerKw, 2) : null,
      /*







*/
      p_out_W: (!isHandDrive && fEff != null && vActual != null) ? r(fEff * vActual, 1) : null,
      p_in_calc_kW: (!isHandDrive && fEff != null && vActual != null && eff)
        ? r(fEff * vActual / eff / 1000 * kTemp * (hasVacuumGrease(inp.special) ? 2 : 1), 3) : null,
      total_power_kW: powerKw ? r(powerKw, 2) : null,
      motor_demand_kW: powerKw ? r(powerKw, 2) : null,
      motor_run_rpm: (!isHandDrive && powerKw) ? rpm : null,
      /*

*/
      motor_sync: (!isHandDrive && isAcC0) ? rpm : (svTierC16 || null),
      env_coef: kTemp * (hasVacuumGrease(inp.special) ? 2 : 1), motor_overload_coef: kMotor,
      /*

*/
      motor_recommend: (function () {
        var mm2 = motors;
        if (/^(EHB|DHB)/i.test(String(model || '')) && driveKindOf(inp) === 'servo' && mm2 && mm2.length) {
          mm2 = mm2.map(function (x) {
            if (!x || x.kind !== 'servo') return x;
            var y = JSON.parse(JSON.stringify(x));
            y.brake = '内置抱闸（24V DC）——本方案必选（订货选带抱闸版本）';
            y.brake_must = true;
            return y;
          });
        }
        return mm2;
      })(), life: life, warnings: warnings
    };
  }

  /**/
  function runCase(inp, data) {
    var warnings = [];
    var route = gv(inp, 'route', 'A');
    /*




*/
    if ((Number(inp && inp.units) || 0) > 1 && inp && inp.sync === '电气') {
      var inpE = {}, kE;
      for (kE in inp) inpE[kE] = inp[kE];
      inpE.layout = '';
      inpE.rev_ratio = 1;
      inpE.hu_plan = null;
      inpE.dual_shaft = false;
      inp = inpE;
    }
    try {
      if (route === 'A') return calcRouteA(inp, data, warnings);
      return calcRouteC(inp, data, warnings);
    } catch (e) {
      if (C.isMissing(e)) return { error: '数据待补全，无法完成选型：' + e.message, warnings: warnings };
      throw e;
    }
  }

  g.SJScrewJack = {
    stabilityCheck: stabilityCheck, dutyCheck: dutyCheck, recommendMotor: recommendMotor,
    servoRpmAllowed: servoRpmAllowed, eulerAllowedLen: eulerAllowedLen,
    handForcePlan: handForcePlan, motorLibData: motorLibData, servoBrandPickOf: servoBrandPickOf,
    calcRouteA: calcRouteA, calcRouteC: calcRouteC, runCase: runCase,
    planetPickOf: planetPickOf, gbStageOf: gbStageOf,
    /**/
    motorShaftOf: motorShaftOf, motorMountOf: motorMountOf, shaftOfFlange: shaftOfFlange, nearestFlange: nearestFlange
  };
})(typeof window !== 'undefined' ? window : globalThis);
