/*


*/
(function (g) {
  'use strict';

  /**/

  /**/
  function pyRound(x, nd) {
    nd = nd || 0;
    if (x === null || x === undefined || !isFinite(x)) return x;
    var f = Math.pow(10, nd), s = x < 0 ? -1 : 1, a = Math.abs(x) * f;
    var lo = Math.floor(a), frac = a - lo, n;
    if (Math.abs(frac - 0.5) < 1e-9) n = (lo % 2 === 0) ? lo : lo + 1;
    else n = Math.round(a);
    return s * n / f;
  }

  /**/
  function fN(x, n) {
    if (x === null || x === undefined || (typeof x === 'number' && isNaN(x))) return 'nan';
    return Number(pyRound(x, n)).toFixed(n);
  }

  /**/
  function iN(x) {
    if (x === null || x === undefined || (typeof x === 'number' && isNaN(x))) return 'nan';
    return String(Math.trunc(Number(x)));
  }

  /**/
  function approx(a, b, tol) {
    if (a === null || a === undefined || b === null || b === undefined) return false;
    if (typeof a !== 'number' || typeof b !== 'number') return false;
    return Math.abs(a - b) <= tol * Math.max(Math.abs(a), Math.abs(b), 1e-9);
  }

  /**/
  function gv(o, k, d) {
    return (o && Object.prototype.hasOwnProperty.call(o, k) && o[k] !== undefined) ? o[k] : d;
  }

  function isTodo(v) { return typeof v === 'string' && v.indexOf('TODO') >= 0; }

  /**/
  function Missing(msg) { var e = new Error(msg); e.name = 'Missing'; return e; }
  function isMissing(e) { return !!e && e.name === 'Missing'; }

  /**/

  /**/
  function interpLinear(pts, x) {
    if (x <= pts[0][0]) return pts[0][1];
    for (var i = 0; i + 1 < pts.length; i++) {
      var x0 = pts[i][0], y0 = pts[i][1], x1 = pts[i + 1][0], y1 = pts[i + 1][1];
      if (x0 <= x && x <= x1) {
        if (x1 === x0) return Math.max(y0, y1);
        return y0 + (y1 - y0) * (x - x0) / (x1 - x0);
      }
    }
    return pts[pts.length - 1][1];
  }

  /**/

  /**/
  function pickEfficiency(modelDef, loadKn, override) {
    if (override !== null && override !== undefined) return override;
    if (modelDef === null || modelDef === undefined) throw Missing('传动效率缺失');
    var eff = modelDef.efficiency_ref;
    var byNearest = function (arr) {
      var lk = function (e) { return Math.abs(gv(e, 'load_kN', 0) - loadKn); };
      var s = arr.slice().sort(function (a, b) { return lk(a) - lk(b); });
      return s[0].value;
    };
    if (Array.isArray(eff) && eff.length) return byNearest(eff);
    if (eff && typeof eff === 'object' && !Array.isArray(eff) && Object.keys(eff).length) {
      return byNearest(Object.keys(eff).map(function (k) { return eff[k]; }));
    }
    if (typeof eff === 'number') return eff;
    throw Missing('传动效率缺失');
  }

  /*

*/
  function speedEffFactor(data, model, modelDef, rpmInput, opt) {
    var se = ((data && data._meta) || {}).speed_efficiency || {};
    var curve = null;
    var pm = se.per_model || {};
    if (Object.prototype.hasOwnProperty.call(pm, model)) curve = pm[model];
    else {
      var fb = se.fallback || {};
      var series = gv(fb, (modelDef || {}).screw_type, null);
      curve = (se.series || {})[series];
    }
    if (!curve) return null;
    if (rpmInput >= gv(se, 'ref_rpm', 1400)) return 1.0;
    var pts = curve.slice().sort(function (a, b) { return a[0] - b[0]; });
    var refR = gv(se, 'ref_rpm', 1400);
    if (rpmInput <= pts[0][0]) return pts[0][1];
    for (var i = 0; i + 1 < pts.length; i++) {
      var r0 = pts[i][0], f0 = pts[i][1], r1 = pts[i + 1][0], f1 = pts[i + 1][1];
      if (r0 <= rpmInput && rpmInput <= r1) return f0 + (f1 - f0) * (rpmInput - r0) / (r1 - r0);
    }
    /*

*/
    var last = pts[pts.length - 1];
    if (opt && opt.fillToRef && last[0] < refR && rpmInput > last[0]) {
      return last[1] + (1.0 - last[1]) * (rpmInput - last[0]) / (refR - last[0]);
    }
    return last[1];
  }

  /**/
  function evalDivisor(expr, fallback) {
    if (!expr) return fallback;
    var e = String(expr).trim().replace(/×/g, '*').replace(/ /g, '');
    if (!/^[\d.]+(\*[\d.]+)*$/.test(e)) throw Missing('非法系数表达式: ' + JSON.stringify(expr));
    var val = 1.0;
    e.split('*').forEach(function (p) { val *= parseFloat(p); });
    return val;
  }

  /**/
  function resolveFk(data, modelName, mounting, motion) {
    var rules = ((data && data.catalog_rules_2026) || {}).stability_fk || {};
    var fams = Object.keys(rules);
    /*
*/
    var mv = (motion === 'R' || motion === 'S') ? motion : 'S';
    for (var i = 0; i < fams.length; i++) {
      var fam = fams[i], tbl = rules[fam];
      if (fam === 'note' || !tbl || typeof tbl !== 'object' || Array.isArray(tbl)) continue;
      if (fam.split('/').some(function (p) { return modelName.indexOf(p) === 0; })) {
        var v = gv(tbl, mounting, null);
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          var vr = gv(v, mv, gv(v, 'S', null));
          return (vr === null || vr === undefined) ? null : vr;
        }
        return v;
      }
    }
    return null;
  }

  /*


*/
  function curveLookup(curvePts, fEff) {
    var pts = curvePts.slice().sort(function (a, b) { return a[0] - b[0]; });
    var maxLoad = pts[pts.length - 1][0];
    if (fEff > maxLoad * 1.0001) return null;
    if (fEff <= pts[0][0]) {
      var p0 = pts[0][0], k0 = pts[0][1];
      /*

*/
      var maxLen = Math.max.apply(null, pts.map(function (p) { return p[1]; }));
      if (!(p0 > 0) || !(fEff > 0)) return Math.min(k0, maxLen);
      return Math.min(4000, maxLen, k0 * Math.sqrt(p0 / fEff));
    }
    for (var i = 0; i + 1 < pts.length; i++) {
      var l0 = pts[i][0], k0 = pts[i][1], l1 = pts[i + 1][0], k1 = pts[i + 1][1];
      if (l0 <= fEff && fEff <= l1) {
        if (l1 === l0) return Math.max(k0, k1);
        return k0 + (k1 - k0) * (fEff - l0) / (l1 - l0);
      }
    }
    return null;
  }

  /**/
  function tempCoef(t) {
    if (t === null || t === undefined) return 1.0;
    if (t <= 25) return 1.0;
    if (t <= 32) return 0.85;
    return 0.65;
  }

  /**/
  function lifeCheck(ballC, leadMm, loadKn, stroke, cyclesPerDay, daysPerYear, roundTrip, reqYears) {
    if (!ballC || !leadMm || !cyclesPerDay) return null;
    var req = (typeof reqYears === 'number' && isFinite(reqYears) && reqYears > 0) ? reqYears : 5;
    var lifeKm = Math.pow(ballC / loadKn, 3) * leadMm;
    var factor = (roundTrip === false) ? 1 : 2;
    var dpy = (daysPerYear === null || daysPerYear === undefined) ? 300 : daysPerYear;
    var annualKm = stroke * factor * cyclesPerDay * dpy / 1e6;
    var years = annualKm ? (lifeKm / annualKm) : null;
    return {
      life_km: pyRound(lifeKm, 1),
      annual_km: pyRound(annualKm, 1),
      years: years ? pyRound(years, 1) : null,
      req_years: req,
      pass: years === null || years >= req,
      note: (years && years >= req) ? '理论寿命超过 ' + req + ' 年，满足要求'
        : (years ? '寿命不足 ' + req + ' 年' : '节拍缺失，仅算理论公里数')
    };
  }

  /*


*/
  function leadReqOf(specialTexts, specialChecked) {
    var tx = (specialTexts && typeof specialTexts === 'object') ? specialTexts : {};
    var checked = Array.isArray(specialChecked) ? specialChecked : [];
    if (checked.indexOf('lead') < 0) return 0;
    var nums = String(tx.lead || '').match(/\d+(?:\.\d+)?/g);
    return nums && nums.length ? Number(nums[nums.length - 1]) || 0 : 0;
  }

  g.SJCore = {
    pyRound: pyRound, fN: fN, iN: iN, approx: approx, gv: gv,
    isTodo: isTodo, Missing: Missing, isMissing: isMissing,
    interpLinear: interpLinear,
    pickEfficiency: pickEfficiency, speedEffFactor: speedEffFactor,
    evalDivisor: evalDivisor, resolveFk: resolveFk, curveLookup: curveLookup,
    tempCoef: tempCoef, lifeCheck: lifeCheck,
    leadReqOf: leadReqOf
  };
})(typeof window !== 'undefined' ? window : globalThis);
