/*
*/
var SJ_TECH = {
 "SJA": {
  "SJA5": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "5",
   "screw": "Tr18x4",
   "ratio": {
    "V1": "1:4(1:3.75)*",
    "L1": "1:16"
   },
   "mm_per_rev": {
    "V1": "1",
    "L1": "0.25"
   },
   "max_power_kW": {
    "V1": "0.3",
    "L1": "0.15"
   },
   "start_torque_Nm": {
    "V1": "4.2",
    "L1": "1.5"
   },
   "eff_startup": {
    "V1": "0.24",
    "L1": "0.16"
   },
   "eff_running": {
    "V1": "0.34",
    "L1": "0.25"
   },
   "idle_torque_Nm": {
    "V1": "0.11",
    "L1": "0.09"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "3.2",
   "per100mm_weight_kg": "0.36"
  },
  "SJA10": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "10",
   "screw": "Tr20x4",
   "ratio": {
    "V1": "1:4(1:3.75)*",
    "L1": "1:16"
   },
   "mm_per_rev": {
    "V1": "1",
    "L1": "0.25"
   },
   "max_power_kW": {
    "V1": "0.57",
    "L1": "0.27"
   },
   "start_torque_Nm": {
    "V1": "8",
    "L1": "3.1"
   },
   "eff_startup": {
    "V1": "0.25",
    "L1": "0.16"
   },
   "eff_running": {
    "V1": "0.35",
    "L1": "0.25"
   },
   "idle_torque_Nm": {
    "V1": "0.29",
    "L1": "0.18"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "5",
   "per100mm_weight_kg": "0.5"
  },
  "SJA20": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "20",
   "screw": "Tr30x6",
   "ratio": {
    "V1": "1:6(1:5.75)*",
    "L1": "1:24"
   },
   "mm_per_rev": {
    "V1": "1",
    "L1": "0.25"
   },
   "max_power_kW": {
    "V1": "1.14",
    "L1": "0.55"
   },
   "start_torque_Nm": {
    "V1": "18",
    "L1": "6.7"
   },
   "eff_startup": {
    "V1": "0.19",
    "L1": "0.12"
   },
   "eff_running": {
    "V1": "0.33",
    "L1": "0.24"
   },
   "idle_torque_Nm": {
    "V1": "0.40",
    "L1": "0.29"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "8.5",
   "per100mm_weight_kg": "0.75"
  },
  "SJA50": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "50",
   "screw": "Tr40x7",
   "ratio": {
    "V1": "1:7(1:6.75)*",
    "L1": "1:28"
   },
   "mm_per_rev": {
    "V1": "1",
    "L1": "0.25"
   },
   "max_power_kW": {
    "V1": "2.2",
    "L1": "1.1"
   },
   "start_torque_Nm": {
    "V1": "48.5",
    "L1": "20"
   },
   "eff_startup": {
    "V1": "0.18",
    "L1": "0.11"
   },
   "eff_running": {
    "V1": "0.32",
    "L1": "0.23"
   },
   "idle_torque_Nm": {
    "V1": "0.84",
    "L1": "0.59"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "21.5",
   "per100mm_weight_kg": "1.52"
  },
  "SJA80": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "80",
   "screw": "Tr50x8",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "1",
    "L1": "0.25"
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": "1.5"
   },
   "start_torque_Nm": {
    "V1": "75",
    "L1": "30"
   },
   "eff_startup": {
    "V1": "0.17",
    "L1": "0.1"
   },
   "eff_running": {
    "V1": "0.31",
    "L1": "0.22"
   },
   "idle_torque_Nm": {
    "V1": "1.85",
    "L1": "1.12"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "36",
   "per100mm_weight_kg": "2.44"
  },
  "SJA100": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "100",
   "screw": "Tr60x9",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "1.125",
    "L1": "0.281"
   },
   "max_power_kW": {
    "V1": "3",
    "L1": "2.2"
   },
   "start_torque_Nm": {
    "V1": "100",
    "L1": "41"
   },
   "eff_startup": {
    "V1": "0.18",
    "L1": "0.11"
   },
   "eff_running": {
    "V1": "0.33",
    "L1": "0.23"
   },
   "idle_torque_Nm": {
    "V1": "2.1",
    "L1": "1.4"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "58",
   "per100mm_weight_kg": "3.02"
  },
  "SJA200": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "200",
   "screw": "Tr80x12",
   "ratio": {
    "V1": "1:8.75",
    "L1": "1:35"
   },
   "mm_per_rev": {
    "V1": "1.37",
    "L1": "0.34"
   },
   "max_power_kW": {
    "V1": "4",
    "L1": "3.5"
   },
   "start_torque_Nm": {
    "V1": "265",
    "L1": "106"
   },
   "eff_startup": {
    "V1": "0.17",
    "L1": "0.11"
   },
   "eff_running": {
    "V1": "0.33",
    "L1": "0.22"
   },
   "idle_torque_Nm": {
    "V1": "2.8",
    "L1": "2.1"
   },
   "housing_material": "球墨铸铁（SJA700/SJA1000 铸钢）",
   "housing_weight_kg": "75",
   "per100mm_weight_kg": "4.5"
  },
  "SJA300": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "300",
   "screw": "Tr100x16",
   "ratio": {
    "V1": "1:10.25",
    "L1": "1:41"
   },
   "mm_per_rev": {
    "V1": "1.56",
    "L1": "0.39"
   },
   "max_power_kW": {
    "V1": "7",
    "L1": "5.5"
   },
   "start_torque_Nm": {
    "V1": "460",
    "L1": "180"
   },
   "eff_startup": {
    "V1": "0.18",
    "L1": "0.12"
   },
   "eff_running": {
    "V1": "0.33",
    "L1": "0.23"
   },
   "idle_torque_Nm": {
    "V1": "3.8",
    "L1": "3.1"
   },
   "housing_material": "球墨铸铁（SJA700/SJA1000 铸钢）",
   "housing_weight_kg": "110",
   "per100mm_weight_kg": "6.8"
  },
  "SJA450": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "450",
   "screw": "Tr120x16",
   "ratio": {
    "V1": "1:10.75",
    "L1": "1:43"
   },
   "mm_per_rev": {
    "V1": "1.49",
    "L1": "0.37"
   },
   "max_power_kW": {
    "V1": "11.5",
    "L1": "7"
   },
   "start_torque_Nm": {
    "V1": "675",
    "L1": "275"
   },
   "eff_startup": {
    "V1": "0.16",
    "L1": "0.1"
   },
   "eff_running": {
    "V1": "0.3",
    "L1": "0.2"
   },
   "idle_torque_Nm": {
    "V1": "5.5",
    "L1": "4.5"
   },
   "housing_material": "球墨铸铁（SJA700/SJA1000 铸钢）",
   "housing_weight_kg": "200",
   "per100mm_weight_kg": "9"
  },
  "SJA700": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "700",
   "screw": "Tr140x20",
   "ratio": {
    "V1": "1:13.33",
    "L1": "1:40"
   },
   "mm_per_rev": {
    "V1": "1.50",
    "L1": "0.5"
   },
   "max_power_kW": {
    "V1": "18.5",
    "L1": "7.5"
   },
   "start_torque_Nm": {
    "V1": "1050",
    "L1": "510"
   },
   "eff_startup": {
    "V1": "0.16",
    "L1": "0.11"
   },
   "eff_running": {
    "V1": "0.31",
    "L1": "0.21"
   },
   "idle_torque_Nm": {
    "V1": "8.5",
    "L1": "5.5"
   },
   "housing_material": "球墨铸铁（SJA700/SJA1000 铸钢）",
   "housing_weight_kg": "400",
   "per100mm_weight_kg": "12.5"
  },
  "SJA1000": {
   "series": "SJA",
   "page": 63,
   "rated_dynamic_kN": "1000",
   "screw": "Tr160x20",
   "ratio": {
    "V1": "1:13.33",
    "L1": "1:40"
   },
   "mm_per_rev": {
    "V1": "1.50",
    "L1": "0.5"
   },
   "max_power_kW": {
    "V1": "22",
    "L1": "9.5"
   },
   "start_torque_Nm": {
    "V1": "1620",
    "L1": "820"
   },
   "eff_startup": {
    "V1": "0.15",
    "L1": "0.1"
   },
   "eff_running": {
    "V1": "0.29",
    "L1": "0.19"
   },
   "idle_torque_Nm": {
    "V1": "11",
    "L1": "7.5"
   },
   "housing_material": "球墨铸铁（SJA700/SJA1000 铸钢）",
   "housing_weight_kg": "800",
   "per100mm_weight_kg": "16.5"
  }
 },
 "SJB": {
  "SJB10": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "10",
   "rated_dynamic_kN": "11",
   "screw": "20×5",
   "ratio": {
    "V1": "1:4(1:3.75)*",
    "L1": "1:16"
   },
   "mm_per_rev": {
    "V1": "1.25",
    "L1": "0.31"
   },
   "max_power_kW": {
    "V1": "0.57",
    "L1": "0.27"
   },
   "start_torque_Nm": {
    "V1": "4.8",
    "L1": "1.8"
   },
   "eff_startup": {
    "V1": "0.41",
    "L1": "0.27"
   },
   "eff_running": {
    "V1": "0.59",
    "L1": "0.42"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "6",
   "per100mm_weight_kg": "0.5"
  },
  "SJB20": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "20",
   "rated_dynamic_kN": "17",
   "screw": "32×5",
   "ratio": {
    "V1": "1:6(1:5.75)*",
    "L1": "1:24"
   },
   "mm_per_rev": {
    "V1": "0.83",
    "L1": "0.21"
   },
   "max_power_kW": {
    "V1": "1.14",
    "L1": "0.55"
   },
   "start_torque_Nm": {
    "V1": "8.2",
    "L1": "3.4"
   },
   "eff_startup": {
    "V1": "0.32",
    "L1": "0.2"
   },
   "eff_running": {
    "V1": "0.58",
    "L1": "0.39"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "9.5",
   "per100mm_weight_kg": "0.8"
  },
  "SJB21": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "20",
   "rated_dynamic_kN": "25",
   "screw": "32×10",
   "ratio": {
    "V1": "1:6(1:5.75)*",
    "L1": "1:24"
   },
   "mm_per_rev": {
    "V1": "1.67",
    "L1": "0.42"
   },
   "max_power_kW": {
    "V1": "1.14",
    "L1": "0.55"
   },
   "start_torque_Nm": {
    "V1": "15.3",
    "L1": "6.3"
   },
   "eff_startup": {
    "V1": "0.35",
    "L1": "0.21"
   },
   "eff_running": {
    "V1": "0.62",
    "L1": "0.42"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "9.5",
   "per100mm_weight_kg": "0.8"
  },
  "SJB22": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "20",
   "rated_dynamic_kN": "25",
   "screw": "32×20",
   "ratio": {
    "V1": "1:6(1:5.75)*",
    "L1": "1:24"
   },
   "mm_per_rev": {
    "V1": "3.33",
    "L1": "0.83"
   },
   "max_power_kW": {
    "V1": "1.14",
    "L1": "0.55"
   },
   "start_torque_Nm": {
    "V1": "29.2",
    "L1": "12.1"
   },
   "eff_startup": {
    "V1": "0.36",
    "L1": "0.22"
   },
   "eff_running": {
    "V1": "0.65",
    "L1": "0.44"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "10",
   "per100mm_weight_kg": "0.8"
  },
  "SJB50": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "50",
   "rated_dynamic_kN": "46",
   "screw": "40×10",
   "ratio": {
    "V1": "1:7(1:6.75)*",
    "L1": "1:28"
   },
   "mm_per_rev": {
    "V1": "1.43",
    "L1": "0.36"
   },
   "max_power_kW": {
    "V1": "2.2",
    "L1": "1.1"
   },
   "start_torque_Nm": {
    "V1": "34.4",
    "L1": "14.6"
   },
   "eff_startup": {
    "V1": "0.33",
    "L1": "0.2"
   },
   "eff_running": {
    "V1": "0.59",
    "L1": "0.39"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "23",
   "per100mm_weight_kg": "1.6"
  },
  "SJB51": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "35",
   "rated_dynamic_kN": "30",
   "screw": "40×20",
   "ratio": {
    "V1": "1:7(1:6.75)*",
    "L1": "1:28"
   },
   "mm_per_rev": {
    "V1": "2.86",
    "L1": "0.71"
   },
   "max_power_kW": {
    "V1": "2.2",
    "L1": "1.1"
   },
   "start_torque_Nm": {
    "V1": "47.4",
    "L1": "19.4"
   },
   "eff_startup": {
    "V1": "0.34",
    "L1": "0.21"
   },
   "eff_running": {
    "V1": "0.6",
    "L1": "0.41"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "24",
   "per100mm_weight_kg": "1.6"
  },
  "SJB80": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "60",
   "rated_dynamic_kN": "53",
   "screw": "50×10",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "1.25",
    "L1": "0.31"
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": "1.5"
   },
   "start_torque_Nm": {
    "V1": "36.8",
    "L1": "15.3"
   },
   "eff_startup": {
    "V1": "0.32",
    "L1": "0.2"
   },
   "eff_running": {
    "V1": "0.58",
    "L1": "0.39"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "38",
   "per100mm_weight_kg": "2.5"
  },
  "SJB81": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "60",
   "rated_dynamic_kN": "56",
   "screw": "50×20",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "2.50",
    "L1": "0.63"
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": "1.5"
   },
   "start_torque_Nm": {
    "V1": "72.3",
    "L1": "29.9"
   },
   "eff_startup": {
    "V1": "0.33",
    "L1": "0.2"
   },
   "eff_running": {
    "V1": "0.59",
    "L1": "0.4"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "40",
   "per100mm_weight_kg": "2.5"
  },
  "SJB100": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "80",
   "rated_dynamic_kN": "71",
   "screw": "63×10",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "1.25",
    "L1": "0.31"
   },
   "max_power_kW": {
    "V1": "3",
    "L1": "2.2"
   },
   "start_torque_Nm": {
    "V1": "49",
    "L1": "20.4"
   },
   "eff_startup": {
    "V1": "0.32",
    "L1": "0.2"
   },
   "eff_running": {
    "V1": "0.58",
    "L1": "0.39"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "62",
   "per100mm_weight_kg": "3.2"
  },
  "SJB101": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "80",
   "rated_dynamic_kN": "71",
   "screw": "63×20",
   "ratio": {
    "V1": "1:8(1:7.75)*",
    "L1": "1:32"
   },
   "mm_per_rev": {
    "V1": "2.50",
    "L1": "0.63"
   },
   "max_power_kW": {
    "V1": "3",
    "L1": "2.2"
   },
   "start_torque_Nm": {
    "V1": "97",
    "L1": "40"
   },
   "eff_startup": {
    "V1": "0.34",
    "L1": "0.21"
   },
   "eff_running": {
    "V1": "0.6",
    "L1": "0.41"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "64",
   "per100mm_weight_kg": "3.2"
  },
  "SJB200": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "90",
   "rated_dynamic_kN": "78",
   "screw": "80×10",
   "ratio": {
    "V1": "1:10.25",
    "L1": "1:35"
   },
   "mm_per_rev": {
    "V1": "1.14",
    "L1": "0.29"
   },
   "max_power_kW": {
    "V1": "4",
    "L1": "3.5"
   },
   "start_torque_Nm": {
    "V1": "53.2",
    "L1": "23.4"
   },
   "eff_startup": {
    "V1": "0.31",
    "L1": "0.18"
   },
   "eff_running": {
    "V1": "0.55",
    "L1": "0.35"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "78",
   "per100mm_weight_kg": "4.6"
  },
  "SJB201": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "160",
   "rated_dynamic_kN": "145",
   "screw": "80×20",
   "ratio": {
    "V1": "1:10.75",
    "L1": "1:35"
   },
   "mm_per_rev": {
    "V1": "2.29",
    "L1": "0.57"
   },
   "max_power_kW": {
    "V1": "4",
    "L1": "3.5"
   },
   "start_torque_Nm": {
    "V1": "200",
    "L1": "83"
   },
   "eff_startup": {
    "V1": "0.31",
    "L1": "0.18"
   },
   "eff_running": {
    "V1": "0.55",
    "L1": "0.35"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "78",
   "per100mm_weight_kg": "4.6"
  },
  "SJB300": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "240",
   "rated_dynamic_kN": "220",
   "screw": "100×20",
   "ratio": {
    "V1": "1:8.75",
    "L1": "1:41"
   },
   "mm_per_rev": {
    "V1": "1.95",
    "L1": "0.49"
   },
   "max_power_kW": {
    "V1": "7",
    "L1": "5.5"
   },
   "start_torque_Nm": {
    "V1": "260",
    "L1": "110"
   },
   "eff_startup": {
    "V1": "0.3",
    "L1": "0.18"
   },
   "eff_running": {
    "V1": "0.53",
    "L1": "0.35"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "125",
   "per100mm_weight_kg": "7.3"
  },
  "SJB450": {
   "series": "SJB",
   "page": 83,
   "max_lift_kN": "320",
   "rated_dynamic_kN": "282",
   "screw": "100×25",
   "ratio": {
    "V1": "1:8.75",
    "L1": "1:43"
   },
   "mm_per_rev": {
    "V1": "2.33",
    "L1": "0.58"
   },
   "max_power_kW": {
    "V1": "11.5",
    "L1": "7.5"
   },
   "start_torque_Nm": {
    "V1": "395",
    "L1": "165"
   },
   "eff_startup": {
    "V1": "0.27",
    "L1": "0.16"
   },
   "eff_running": {
    "V1": "0.5",
    "L1": "0.3"
   },
   "housing_material": "球墨铸铁",
   "housing_weight_kg": "230",
   "per100mm_weight_kg": "9.6"
  }
 },
 "EHB": {
  "EHB065-12x05": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "2.5",
   "rated_dynamic_kN": "6",
   "rated_static_kN": "13",
   "screw": "12x5",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "2.5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "0.25",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "1.6",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "2.5",
   "per100mm_weight_kg": "0.25"
  },
  "EHB065-15x05": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "2.5",
   "rated_dynamic_kN": "11",
   "rated_static_kN": "25",
   "screw": "15x5",
   "motion": "R",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "2.5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "0.25",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "1.6",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "2.5",
   "per100mm_weight_kg": "0.25"
  },
  "EHB095-25x05": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "15",
   "rated_dynamic_kN": "17",
   "rated_static_kN": "49",
   "screw": "25x5",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "2.5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "1.2",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "9.0",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "6.5",
   "per100mm_weight_kg": "0.58"
  },
  "EHB095-25x10": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "8",
   "rated_dynamic_kN": "20",
   "rated_static_kN": "58",
   "screw": "25x10",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "1.2",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "9.0",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "6.5",
   "per100mm_weight_kg": "0.58"
  },
  "EHB140-32x10": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "20",
   "rated_dynamic_kN": "48",
   "rated_static_kN": "122",
   "screw": "32x10",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "30.0",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "25",
   "per100mm_weight_kg": "0.8"
  },
  "EHB140-32x20": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "15",
   "rated_dynamic_kN": "19",
   "rated_static_kN": "54",
   "screw": "32x20",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "10",
    "L1": null
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "30.0",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "25",
   "per100mm_weight_kg": "0.8"
  },
  "EHB160-40x10": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "42",
   "rated_dynamic_kN": "54",
   "rated_static_kN": "155",
   "screw": "40x10",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "3",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "50",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "37",
   "per100mm_weight_kg": "1.6"
  },
  "EHB160-40x20": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "20",
   "rated_dynamic_kN": "39",
   "rated_static_kN": "107",
   "screw": "40x20",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "10",
    "L1": null
   },
   "max_power_kW": {
    "V1": "3",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "50",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "37",
   "per100mm_weight_kg": "1.6"
  },
  "EHB210-50x10": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "53",
   "rated_dynamic_kN": "60",
   "rated_static_kN": "196",
   "screw": "50x10",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "5.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "110",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "85",
   "per100mm_weight_kg": "2.5"
  },
  "EHB210-50x20": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "53",
   "rated_dynamic_kN": "71",
   "rated_static_kN": "226",
   "screw": "50x20",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "10",
    "L1": null
   },
   "max_power_kW": {
    "V1": "5.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "110",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "85",
   "per100mm_weight_kg": "2.5"
  },
  "EHB250-63x10": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "71",
   "rated_dynamic_kN": "80",
   "rated_static_kN": "317",
   "screw": "63x10",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "5",
    "L1": null
   },
   "max_power_kW": {
    "V1": "7.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "150",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "143",
   "per100mm_weight_kg": "3.2"
  },
  "EHB250-63x20": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "85",
   "rated_dynamic_kN": "85",
   "rated_static_kN": "240",
   "screw": "63x20",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "10",
    "L1": null
   },
   "max_power_kW": {
    "V1": "7.5",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "150",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.72",
    "L1": null
   },
   "eff_running": {
    "V1": "0.72",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "143",
   "per100mm_weight_kg": "3.2"
  },
  "EHB300-80x20": {
   "series": "EHB",
   "page": 105,
   "max_lift_kN": "145",
   "rated_dynamic_kN": "361",
   "rated_static_kN": "1118",
   "screw": "80x20",
   "motion": "S",
   "ratio": {
    "V1": "1:2",
    "L1": null
   },
   "mm_per_rev": {
    "V1": "10",
    "L1": null
   },
   "max_power_kW": {
    "V1": "11",
    "L1": null
   },
   "start_torque_Nm": {
    "V1": "310",
    "L1": null
   },
   "eff_startup": {
    "V1": "0.7",
    "L1": null
   },
   "eff_running": {
    "V1": "0.7",
    "L1": null
   },
   "housing_material": "球墨铸铁（不锈钢 SS316 可选）",
   "housing_weight_kg": "247",
   "per100mm_weight_kg": "4.6"
  }
 },
 "KV": {
  "KV60": {
   "series": "KV",
   "page": 134,
   "rated_dynamic_kN": "50",
   "screw": "Tr32×6",
   "ratio": {
    "V1": "1:7.25",
    "L1": "1:20"
   },
   "mm_per_rev": {
    "V1": "0.83",
    "L1": "0.3"
   },
   "max_power_kW": {
    "V1": "1.3",
    "L1": "1.0"
   },
   "start_torque_Nm": {
    "V1": "36",
    "L1": "18"
   },
   "eff_startup": {
    "V1": "0.17",
    "L1": "0.12"
   },
   "eff_running": {
    "V1": "0.25",
    "L1": "0.18"
   },
   "housing_material": "AISI316"
  },
  "KV85": {
   "series": "KV",
   "page": 134,
   "rated_dynamic_kN": "100",
   "screw": "Tr52×8",
   "ratio": {
    "V1": "1:12",
    "L1": "1:24"
   },
   "mm_per_rev": {
    "V1": "0.67",
    "L1": "0.33"
   },
   "max_power_kW": {
    "V1": "2.5",
    "L1": "2.0"
   },
   "start_torque_Nm": {
    "V1": "70",
    "L1": "50"
   },
   "eff_startup": {
    "V1": "0.14",
    "L1": "0.10"
   },
   "eff_running": {
    "V1": "0.21",
    "L1": "0.16"
   },
   "housing_material": "AISI316"
  },
  "KV100": {
   "series": "KV",
   "page": 134,
   "rated_dynamic_kN": "150",
   "screw": "Tr70×10",
   "ratio": {
    "V1": "1:18.5",
    "L1": "1:56"
   },
   "mm_per_rev": {
    "V1": "0.54",
    "L1": "0.18"
   },
   "max_power_kW": {
    "V1": "3",
    "L1": "2.5"
   },
   "start_torque_Nm": {
    "V1": "100",
    "L1": "48"
   },
   "eff_startup": {
    "V1": "0.12",
    "L1": "0.08"
   },
   "eff_running": {
    "V1": "0.18",
    "L1": "0.13"
   },
   "housing_material": "AISI316"
  },
  "KV120": {
   "series": "KV",
   "page": 134,
   "rated_dynamic_kN": "200",
   "screw": "Tr80×10",
   "ratio": {
    "V1": "1:19",
    "L1": "1:38"
   },
   "mm_per_rev": {
    "V1": "0.526",
    "L1": "0.263"
   },
   "max_power_kW": {
    "V1": "4.5",
    "L1": "3.5"
   },
   "start_torque_Nm": {
    "V1": "130",
    "L1": "90"
   },
   "eff_startup": {
    "V1": "0.12",
    "L1": "0.09"
   },
   "eff_running": {
    "V1": "0.18",
    "L1": "0.13"
   },
   "housing_material": "AISI316"
  }
 },
 "NOTES": {
  "KV": [
   "不锈钢螺旋升降机 KVL(K)60/85/100/120，载荷 5t~20t，整体 SS316（可选 SS304/SS329）",
   "环境温度 −20 ℃ ~ +40 ℃（如需 −40 ℃ ~ +70 ℃ 请咨询工程师）",
   "按安装方式分地脚安装 KVL / 耳轴安装 KVK；按运动方式分丝杠运动 S / 螺母运动 R",
   "组合系数、温度修正、输入功率公式与 SJA 系列一致；运转效率为 100rpm 口径"
  ],
  "SJA": [
   "环境工作温度 −10 ℃ ~ +40 ℃（如需 −40 ℃ ~ +70 ℃ 请咨询工程师）",
   "工作制：10 分钟内工作时间百分比，梯形丝杠 30%，滚珠丝杠 50%；实际负载低于额定负载时可适当提高",
   "最大输入转速 1800 rpm；输入功率 kW =（满载扭矩 Nm × 负载率 × 输入转速 rpm）/ 9550",
   "负载率 25%~100% 时：输入扭矩 = 负载率 × 满载扭矩",
   "行程 > 300 mm 必须按负载-行程稳定性曲线校核",
   "安全系数按负载类型：均匀负载 1.0~1.2，中度 1.3~1.5，重度 1.6~2.5",
   "温度修正：−10~25 ℃ 系数 1.0，30 ℃ 系数 0.85，40 ℃ 系数 0.65（实际最大输入功率 = 额定 × 温度系数）",
   "多台同步组合系数：2 台 0.95，3 台 0.9，4 台 0.85，6~8 台 0.8",
   "大减速比型号自锁，小减速比为不确定自锁；安全与振动场合必须配制动器",
   "普通/滚珠丝杠在 300 mm 行程上导程误差 0.1 mm",
   "避免承受侧向力，可加导轨或选调心螺母型"
  ],
  "SJB": [
   "环境温度 −20 ℃ ~ +40 ℃（如需 −40 ℃ ~ +70 ℃ 请咨询工程师）",
   "寿命主要校核滚珠丝杠 L10，其次蜗轮蜗杆磨损；高可靠度寿命需按系数折减（95% = L10×62%，99% = L10×21%）",
   "行程 > 300 mm 必须按稳定性曲线校核；避免侧向力",
   "组合系数、温度修正、输入功率公式与 SJA 系列一致"
  ],
  "EHB": [
   "环境温度 −20 ℃ ~ +40 ℃（如需 −40 ℃ ~ +70 ℃ 请咨询工程师）",
   "行程 0~500 mm 内定位精度 0.05 mm、重复精度 0.03 mm，闭环精度更高",
   "伞齿轮滚珠丝杠系列可 S1 连续工作",
   "寿命按滚珠丝杠 L10 与轴承校核，伞齿轮磨损寿命一般长于丝杠"
  ]
 },
 "sources": {
  "SJA": "综合样本 2026 p63",
  "SJB": "p83",
  "EHB": "p105",
  "KV": "综合样本 2026 p134（不锈钢 KVL/K 系列）"
 }
};
if (typeof window !== 'undefined') window.SJ_TECH = SJ_TECH;
