/*
*/
(function (g) {
  'use strict';

  /**/
  var SERIES = [
    { v: 'SJA', name: '梯形丝杠螺旋升降机 SJA', img: 'sja-main.png', img2: 'sja-cover.png',
      specs: ['推力范围：0.5-200 吨', '最大行程：可至 15m，校核稳定性', '工作制：30%（10 分钟工作）',
        '升降速度：小于 23mm/s，非标 46mm/s', '综合效率：小于 33%，减速比 L1 绝对自锁',
        '精度定位：0.1mm，机械同步精度 0.1mm', '标配附件：防转机构 AR，限位开关 FCP',
        '其他附件：可配编码器，防尘罩，安全螺母，反齿隙，防爆电机，普通电机，伺服电机等'] },
    { v: 'SJB', name: '滚珠丝杠螺旋升降机 SJB', img: 'sjb-main.png',
      specs: ['推力范围：0.5-100 吨', '最大行程：可至 15m，校核稳定性', '工作制：50%（10 分钟工作）',
        '升降速度：小于 80mm/s', '综合效率：小于 65%，减速比 L1 绝对自锁',
        '精度定位：0.05mm，机械同步精度 0.05mm', '标配附件：防转机构 AR，限位开关 FCP',
        '其他附件：可配编码器，防尘罩，安全螺母，反齿隙，防爆电机，普通电机，伺服电机等'] },
    { v: 'EHB', name: '伞齿轮螺旋升降机 EHB', img: 'ehb-main.jpg',
      specs: ['推力范围：0.25-20 吨', '最大行程：可至 8m，校核稳定性', '工作制：100%（连续工作）',
        '升降速度：小于 250mm/s', '综合效率：小于 72%',
        '精度定位：0.05mm，机械同步精度 0.05mm', '标配附件：滚珠丝杠，防转机构 AR，限位开关 FCP',
        '其他附件：可配梯形丝杠，防尘罩，防爆电机，普通电机，伺服电机等'] },
    { v: 'KV', name: '不锈钢螺旋升降机 KV', img: 'kv-main.png',
      specs: ['推力范围：2-20 吨', '最大行程：可至 8m，校核稳定性', '工作制：20%（10 分钟）',
        '升降速度：小于 23mm/s', '综合效率：小于 30%',
        '精度定位：0.1mm，机械同步精度 0.1mm', '标配附件：不锈钢 316 箱体，防转机构 AR，限位开关 FCP',
        '其他附件：编码器，防尘罩，防爆电机，普通电机，伺服电机等'] },
    { v: 'SCA', name: '梯形丝杠升降机推杆 SCA', img: 'sca-main.jpg',
      specs: ['推力范围：2-100 吨', '最大行程：可至 5m，校核稳定性', '工作制：30%（10 分钟工作）',
        '升降速度：小于 23mm/s，非标 46mm/s', '综合效率：小于 33%，减速比 L1 绝对自锁',
        '精度定位：0.1mm，机械同步精度 0.1mm', '标配附件：防转机构 AR，限位开关 FCP',
        '其他附件：可配编码器，防尘罩，安全螺母，反齿隙，防爆电机，普通电机，伺服电机等'] },
    { v: 'SCB', name: '滚珠丝杠升降机推杆 SCB', img: 'scb-main.jpg', img2: 'sja-cover.png',
      specs: ['推力范围：2-100 吨', '最大行程：可至 5m，校核稳定性', '工作制：50%（10 分钟工作）',
        '升降速度：80mm/s', '综合效率：小于 65%，减速比 L1 绝对自锁',
        '精度定位：0.05mm，机械同步精度 0.05mm', '标配附件：防转机构 AR，限位开关 FCP',
        '其他附件：可配编码器，防尘罩，安全螺母，反齿隙，防爆电机，普通电机，伺服电机等'] }
  ];
  var DEFAULT_IMAGE = 'family-default.jpg';    //

  /**/
  var MOTION_INFO = {
    hasOption: { SJA: true, SJB: true, EHB: true, KV: true },
    kvModes: [{ v: 'KVL', t: 'KVL 地脚安装' }, { v: 'KVK', t: 'KVK 耳轴安装' }],
    img: 'motion-sr.png'
  };

  /**/
  var LAYOUT_PICKS = {
    /*

*/
    1: [{ v: '无电机', img: 'lay1-nomotor.jpg', bySeries: { EHB: 'lay1-nomotor-ehb.jpg', SCA: 'lay1-nomotor-sca.jpg', SCB: 'lay1-nomotor-sca.jpg' } },
        { v: '电机一体化', img: 'lay1-motor.jpg', bySeries: { EHB: { S: 'lay1-motor-ehb.jpg', R: 'lay1-motor-ehb-r.jpg' }, SCA: 'lay1-motor-sca.jpg', SCB: 'lay1-motor-sca.jpg' },
          byMotion: { S: 'lay1-motor-s.jpg' } }],   /**/
    2: [{ v: '电机单侧', img: 'lay2-side.jpg', skill: '两台机械同步螺旋升降机单侧输入.png',
          bySeries: { EHB: { S: 'lay2-side-ehb.jpg', R: { img: 'lay2-side-ehb-r.jpg', skill: '两台EHB螺旋升降机螺母运动-电机单侧.png' } },
                      SCA: 'lay2-side-sca.jpg', SCB: 'lay2-side-sca.jpg' },   /**/
          byMotion: { R: { img: 'lay2-side-r.jpg', skill: '两台机械同步螺母运动-电机单侧.png' } } },   /**/
        { v: '电机中间', img: 'lay2-mid.jpg',  skill: '两台机械同步螺旋升降机中间输入.png',
          bySeries: { EHB: { S: 'lay2-mid-ehb.jpg', R: { img: 'lay2-mid-ehb-r.jpg', skill: '两台EHB螺旋升降机螺母运动-电机中间.png' } },
                      SCA: 'lay2-mid-sca.jpg', SCB: 'lay2-mid-sca.jpg' },   /**/
          byMotion: { R: { img: 'lay2-mid-r.jpg', skill: '两台机械同步螺母运动-电机中间.png' } } },   /**/
        { v: '导向柱一体化', img: 'lay2-guide.jpg', guideOnly: true }],   /**/
    3: [{ v: '直线布置-电机单侧', img: 'lay3-line.jpg', skill: '三台机械同步螺旋升降机一字型.png',
          bySeries: { SCA: 'lay3-line-sca.jpg', SCB: 'lay3-line-sca.jpg' },   /**/
          byMotion: { R: { img: 'lay3-line-r.jpg', skill: '三台机械同步螺母运动-直线布置-电机单侧.png' } } },   /**/
        { v: '垂直布置-电机中间', img: 'lay3-vert.jpg',
          bySeries: { SCA: 'lay3-vert-sca.jpg', SCB: 'lay3-vert-sca.jpg' },
          byMotion: { R: { img: 'lay3-vert-r.jpg', skill: '三台机械同步螺母运动-垂直布置-电机中间.png' } } }],   /**/
    4: [{ v: 'H型布置', img: 'lay4-h.jpg', skill: '四台机械同步螺旋升降机H型布置.png',
          bySeries: { EHB: { S: 'lay4-h-ehb.jpg', R: { img: 'lay4-h-ehb-r.jpg', skill: '四台EHB螺旋升降机螺母运动-H型布置.png' } },
                      SCA: 'lay4-h-sca.jpg', SCB: 'lay4-h-sca.jpg' },   /**/
          byMotion: { R: { img: 'lay4-h-r.jpg', skill: '四台机械同步螺旋升降机H型布置-螺母运动.png' } } },   /**/
        { v: 'U型布置', img: 'lay4-u.jpg', skill: '四台同步螺旋升降机U型布置-丝杠运动.png',
          bySeries: { EHB: { S: 'lay4-u-ehb.jpg', R: { img: 'lay4-u-ehb-r.jpg', skill: '四台EHB螺旋升降机螺母运动-U型布置.png' } },
                      SCA: 'lay4-u-sca.jpg', SCB: 'lay4-u-sca.jpg' },
          byMotion: { R: { img: 'lay4-u-r.jpg', skill: '四台同步螺旋升降机U型布置-螺母运动.png' } } },   /**/
        /*

*/
        { v: 'U2型布置', img: 'lay4-u2-ehb-r.jpg', skill: '四台EHB螺旋升降机螺母运动-U2型布置.png',
          byMotion: { S: { img: 'lay4-u2-ehb-s.jpg', skill: '四台EHB螺旋升降机丝杠运动-U2型布置.png' },
                      R: { img: 'lay4-u2-ehb-r.jpg', skill: '四台EHB螺旋升降机螺母运动-U2型布置.png' } } },
        /*
*/
        { v: '直线布置', byMotion: { S: { img: 'lay4-line-s.jpg', skill: '四台机械同步螺旋升降机一字布置.png' },
                                     R: { img: 'lay4-line-r.jpg', skill: '四台机械同步螺母运动-直线布置.png' } },
          bySeries: { SCA: 'lay4-line-sca.jpg', SCB: 'lay4-line-sca.jpg' } }],   /**/
    /**/
    6: [{ v: '直线布置', img: 'lay6-line.jpg', skill: '六台机械同步螺旋升降机一字布置.png',
          bySeries: { SCA: 'lay6-line-sca.jpg', SCB: 'lay6-line-sca.jpg' },   /**/
          byMotion: { S: 'lay6-line.jpg', R: { img: 'lay6-line-r.jpg', skill: '六台机械同步螺母运动-直线布置.png' } } },
        { v: 'H型布置', img: 'lay6-h.jpg', skill: '六台机械同步螺旋升降机H型布置.png',
          byMotion: { S: 'lay6-h.jpg', R: { img: 'lay6-h-r.jpg', skill: '六台机械同步螺旋升降机H型布置-螺母运动.png' } },
          bySeries: { SCA: 'lay6-h-sca.jpg', SCB: 'lay6-h-sca.jpg' } }]
    ,
    8: [{ v: '直线布置', img: 'lay8-line.jpg', skill: '八台机械同步螺旋升降机一字布置.png',
          bySeries: { SCA: 'lay8-line-sca.jpg', SCB: 'lay8-line-sca.jpg' },   /**/
          byMotion: { S: 'lay8-line.jpg', R: { img: 'lay8-line-r.jpg', skill: '八台机械同步螺母运动-直线布置.png' } } },   /**/
        { v: 'H型布置', img: 'lay8-h.jpg', skill: '八台机械同步螺旋升降机H型布置.png',
          byMotion: { S: 'lay8-h.jpg', R: { img: 'lay8-h-r.jpg', skill: '八台机械同步螺旋升降机H型布置-螺母运动.png' } },   /**/
          bySeries: { SCA: 'lay8-h-sca.jpg', SCB: 'lay8-h-sca.jpg' } }]
  };
  var UNITS = [{ v: '1', t: '单台螺旋升降机' }, { v: '2', t: '两台螺旋升降机同步' },
    { v: '3', t: '三台螺旋升降机同步' }, { v: '4', t: '四台螺旋升降机同步' },
    { v: '6', t: '六台螺旋升降机同步' }, { v: '8', t: '八台螺旋升降机同步' }, { v: 'custom', t: '非标布置（客户上传布置图）' }];
  /*

*/

  /**/
  /*

*/
  var DRIVES = [{ v: 'hand', t: '手摇' }, { v: 'none', t: '无电机' }, { v: 'ac3', t: '三相交流电机' }, { v: 'ac1', t: '单相交流电机 220VAC' },
    { v: 'dc24', t: '直流电机 24VDC' }, { v: 'servo220', t: '伺服电机 220VAC' },
    { v: 'servo380', t: '伺服电机 380VAC' }, { v: 'stepper', t: '步进电机' }];
  var DRIVE_DEFAULT = 'ac3';
  var TEMPS = [{ v: '20', t: '+20' }, { v: '0', t: '0' }, { v: '-20', t: '-20' },
    { v: '-30', t: '-30' }, { v: '-40', t: '-40' }, { v: '80', t: '+80' }];
  var SPECIALS = [{ v: 'brand_ac', t: '交流电机品牌要求', ph: '录入品牌，如 SEW / 诺德 / 三菱' },
    { v: 'ac_brake', t: '电磁制动要求', ph: '可录入制动器要求，如 制动扭矩 / 手动释放；三相交流勾选后自动切换YE3EJ 制动系列' },
    { v: 'brand_servo', t: '伺服电机品牌要求', ph: '录入品牌，如 西门子 1FK2 / 安川' },
    { v: 'screw_material', t: '丝杠材料要求', ph: '录入材质，如 不锈钢304 / 40Cr镀镍' },
    { v: 'anti_corrosion', t: '整体防腐要求', ph: '录入等级，如 达克罗 / 喷塑RAL7035' },
    { v: 'exproof', t: '防爆要求', ph: '录入防爆等级，如 ExdIIBT4' },
    { v: 'vacuum_grease', t: '真空润滑脂（真空环境）', ph: '录入真空度要求，如 1×10⁻³ Pa；价格单独计费' },
    { v: 'lead', t: '丝杠导程要求', ph: '录入导程，如 10mm / 16mm' },
    { v: 'other', t: '其他特殊要求', ph: '录入其他要求，如 涂层颜色 / 特殊包装 / 认证要求' }];

  /**/
  var SHAFT_DIRS = [{ v: 'RH', t: '右输入 RH（标配）' }, { v: 'LH', t: '左输入 LH' }];
  var SHAFT_IMGS = ['inp-p1.png', 'inp-p2.png', 'inp-p3.png', 'inp-p4.png'];

  /**/
  /*
*/
  var JOINTS = [{ v: 'std', t: '法兰端 FL', img: 'joint-fl.png' }, { v: 'TS', t: '球形铰接 TS', img: 'joint-ts.png' },
    { v: 'TF', t: '销孔端 TF', img: 'joint-tf.png' }, { v: 'FO', t: '叉销端 FO', img: 'joint-fo.png' },
    { v: 'NF', t: '外螺纹NF', img: 'joint-std.png' },
    /**/
    { v: 'FQ', t: '球形法兰 FQ', img: 'joint-fq.png' }];

  /*

*/
  var ACCESSORIES = [
    { v: 'AR', t: '防转 AR（标配）', def: true, noR: true },
    { v: 'FCP', t: '限位开关 FCP', noR: true }, { v: 'FCG', t: '限位开关 FCG', noR: true },
    { v: 'B', t: '防尘罩 B' }, { v: 'SN', t: '安全螺母 SN' }, { v: 'SS', t: '不锈钢外壳 SS' },
    { v: 'SA', t: '不锈钢丝杠 SA' }, { v: 'AB', t: '反齿隙 AB' }, { v: 'HBP', t: '耳轴安装板 HBP' },
    { v: 'IRE', t: '编码器 IRE' }, { v: 'FS', t: '离合器 FS' }, { v: 'STR', t: '外管尾端交接 STR' },
    { v: 'FMP', t: '地脚安装板 FMP' }, { v: 'XFM', t: '地脚安装箱体 XFM' }, { v: 'PM', t: '调心螺母 PM' },
    { v: 'HW', t: '手摇轮 HW' }];

  /**/
  var CAD_LINKS = [
    { t: '力姆泰克官网三维软件下载（硬盘版免登录出图）', url: 'https://cn.lim-tec.com/soft.html',
      series: ['DMB', 'SJA', 'SJB', 'LAP', 'LBP'] },
    { t: 'PartCommunity 三维数模库（limtec.partcommunity.com）', url: 'https://limtec.partcommunity.com/3d-cad-models/',
      series: ['DMB', 'SJA', 'SJB', 'LAP', 'LBP'] },
    { t: '大国工匠三维模型（力姆泰克廊坊）', url: 'https://www.global-dsc.cn/dggj',
      series: ['EMB', 'SCA', 'SCB', 'EHB', 'KV', 'GTR', 'FMR', 'LAM'] }
  ];

  /**/
  var SAMPLES_WEB = 'https://cn.lim-tec.com/video.html';
  /*
*/
  var SAMPLES_CDN = 'https://limtec-cad-models.app.workbuddy.host/assets/samples/';
  /*
*/
  var SAMPLES_VER = '202611191903';
  var SAMPLES = [
    { t: '力姆泰克螺旋升降机电动推杆综合样本2026', file: '力姆泰克螺旋升降机电动推杆综合样本2026.pdf' },
    { t: '力姆泰克伺服电缸中文2026', file: '力姆泰克伺服电缸中文2026.pdf' }
  ];
  /**/
  var SAMPLES_EN = [
    { t: 'Lim-Tec combined catalog 2026 — screw jacks & electric linear actuators', file: '2026 lim-tec screw jack & linear actuator catalog.pdf' },
    { t: 'Lim-Tec servo electric cylinders 2026', file: 'LIM-TEC servo linear actuator 2026.pdf' }
  ];
  /**/
  var SAMPLES_DE = [
    { t: 'Lim-Tec Gesamtkatalog 2026 — Spindelhubgetriebe & Linearantriebe', file: 'DE-Lim-Tec Spindelhubgetriebe & Linearantriebe Gesamtkatalog 2026.pdf' },
    { t: 'Lim-Tec Servo-Elektrozylinder Katalog 2026', file: 'DE-LIM-TEC Servo-Elektrozylinder Katalog 2026.pdf' }
  ];
  /**/
  var SAMPLES_ES = [
    { t: 'Lim-Tec Catálogo General 2026 — Elevadores de Husillo y Actuadores Lineales', file: 'SE-Lim-Tec Elevadores de Husillo y Actuadores Lineales Catalogo General 2026.pdf' },
    { t: 'LIM-TEC Catálogo Cilindro Servo Eléctrico 2026', file: 'SE-LIM-TEC Catalogo Cilindro Servo Electrico 2026.pdf' }
  ];
  /**/
  var SAMPLES_RU = [
    { t: 'Lim-Tec Общий каталог 2026 — винтовые домкраты и линейные приводы', file: 'RU-Lim-Tec Общий каталог 2026.pdf' },
    { t: 'Lim-Tec Сервоцилиндры 2026', file: 'RU-Lim-Tec Сервоцилиндры 2026.pdf' }
  ];

  /*
*/
  function samplesFor(lang) {
    lang = String(lang || 'zh').toLowerCase();
    if (lang === 'de' && SAMPLES_DE.length) return SAMPLES_DE;
    if (lang === 'es' && SAMPLES_ES.length) return SAMPLES_ES;
    if (lang === 'ru' && SAMPLES_RU.length) return SAMPLES_RU;
    if (lang !== 'zh' && SAMPLES_EN.length) return SAMPLES_EN;
    return SAMPLES;
  }

  /*
*/
  /*

*/
  var CAD_CDN_HOME = 'https://limtec-cad-models.app.workbuddy.host/cad.html';
  var CAD_CDN_BASE = 'https://limtec-cad-models.app.workbuddy.host/files';

  var CAD_LOCAL_ROOT = 'file:///storage/Users/currentUser/Download/LIMTEC 3D数模库';
  /**/

  g.SJCatalog = {
    SERIES: SERIES, DEFAULT_IMAGE: DEFAULT_IMAGE, MOTION_INFO: MOTION_INFO,
    LAYOUT_PICKS: LAYOUT_PICKS, UNITS: UNITS, DRIVES: DRIVES, DRIVE_DEFAULT: DRIVE_DEFAULT,
    TEMPS: TEMPS, SPECIALS: SPECIALS, SHAFT_DIRS: SHAFT_DIRS, SHAFT_IMGS: SHAFT_IMGS,
    JOINTS: JOINTS, ACCESSORIES: ACCESSORIES, CAD_LINKS: CAD_LINKS,
    SAMPLES: SAMPLES, SAMPLES_EN: SAMPLES_EN, SAMPLES_DE: SAMPLES_DE, SAMPLES_ES: SAMPLES_ES, SAMPLES_RU: SAMPLES_RU,
    samplesFor: samplesFor, SAMPLES_WEB: SAMPLES_WEB, SAMPLES_CDN: SAMPLES_CDN,
    SAMPLES_VER: SAMPLES_VER,
    CAD_LOCAL_ROOT: CAD_LOCAL_ROOT,
    CAD_CDN_HOME: CAD_CDN_HOME, CAD_CDN_BASE: CAD_CDN_BASE,
    img: function (file) { return (g.SJ_CATALOG_BASE || './assets/catalog/') + file; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
