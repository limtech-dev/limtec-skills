/*






*/
(function (g) {
  'use strict';
  var SJ_ROD_DATA = {
    _meta: {
      source: '综合样本2026 p6-p24 + LAM32/33/36/5 专门样本',
      version: '2026-10-29',
      notes: [
        '工作制：LAM≤30 次/日；LAP（梯形）基准 50 次/日、负载率 50%→50 次 / 20%→100 次线性插值（与 SJA 同规则）；LBP（滚珠）≤200 次/日，超 200 次建议改电缸',
        '速度：LAP/LBP ≤100 mm/s（docx 口径）；LAM 按样本档位满载速度校核',
        '稳定性：LAM 不校核，行程>300mm 提示与工程师确认；LAP/LBP 行程>300mm 按样本第 10 页稳定性曲线校核（安全系数 3）',
        '自锁：LAM 自锁；LBM 不自锁配制动器；LAP 按自锁系数 ≤0.25 自锁、>0.25 配制动器；LBP 不自锁配制动器',
        '寿命：仅 LBP 校核（L10=(C/Fm)^3×S），梯形丝杠寿命无理论计算（样本注明）',
        '两台联动：计算过程照 SCA/SCB 功率链；转速效率修正按 SJA/SJB 的转速与效率比例'
          + '（LAP 梯形走 SJA 曲线、LBP 滚珠走 SJB 曲线，基准 1400rpm）；最大输入功率 = 样本 p20-21 每档电机功率；'
          + '静载 = 该型号最大推力 ×1.5；平台总功率级损按 1 级 0.90（传动轴+2 联轴器）'
      ],
      /*

*/
      speed_efficiency: {
        ref_rpm: 1400,
        fallback: { '梯形丝杠': 'LAP', '滚珠丝杠': 'LBP' },
        series: {
          LAP: [[900, 0.9279], [700, 0.8783], [500, 0.8264], [300, 0.7497], [100, 0.6719], [50, 0.5829]],
          LBP: [[900, 0.9523], [700, 0.9151], [500, 0.8755], [300, 0.8245], [100, 0.7627], [50, 0.7384]]
        }
      },
      /*
*/
      static_load_N: {}
    },
    /**/
    series: [
      { v: 'LAM', t: '小型电动推杆 LAM', img: 'rod-lam.jpg', specs: [
        '推力范围：0.01-1.2 吨（LAM6-S5 最大 12 kN；LAM1/8 最大 9 kN）',
        '最大行程：可至 600 mm',
        '工作制：10-25%',
        '升降速度：1-67.5 mm/s',
        '精度定位：1 mm',
        '应用范围：室内家具，轻工业，医疗，工程机械',
        '标配附件：不锈钢活塞管，内置开关',
        '防护等级：IP23 / IP54 / IP55 / IP65 / IP66',
        '其他附件：限位开关输出信号，霍尔开关，电位计'
      ] },
      { v: 'LAP', t: '梯形丝杠电动推杆 LAP', img: 'rod-lap.jpg', specs: [
        '推力范围：0.05-30 吨',
        '最大行程：可至 5 m',
        '工作制：30%',
        '升降速度：小于 100 mm/s',
        '精度定位：0.1 mm',
        '其他附件：可配防转机构 AR，限位开关 FCM/FCP/FCE，防尘罩，直流/交流/步进/伺服电机',
        '自锁：按自锁系数 ≤0.25 自锁，>0.25 配制动器'
      ] },
      { v: 'LBP', t: '滚珠丝杠电动推杆 LBP', img: 'rod-lbp.jpg', specs: [
        '推力范围：0.05-30 吨',
        '最大行程：可至 5 m',
        '工作制：50-100%（可连续工作）',
        '升降速度：小于 100 mm/s',
        '精度定位：0.1 mm（0.05 mm 需滚珠丝杠）',
        '其他附件：可配防转机构 AR，限位开关 FCM/FCP/FCE，防尘罩，直流/交流/步进/伺服电机',
        '寿命：滚珠丝杠额定动载校核 L10 寿命；不自锁配制动器'
      ] }
    ],
    /*
*/
    lam_series: [
      /*




*/
      { v: 'LAM3', t: 'LAM3 系列', img: 'rod-lam3.jpg', subs: ['LAM3', 'LAM32', 'LAM33'], bullet: '◆',
        lead: 'LAM3（最大 250 kg）、LAM32（最大 100 kg）、LAM33（最大 350 kg）',
        specs: [
          '电压：12 / 24 / 48 VDC',
          '最大满载速度：40 mm/s',
          '行程范围：50-500 mm',
          '内置限位开关，外置限位开关',
          'IP 防护等级：IP65 / IP66',
          '工作制：25%',
          '工作温度：-10~65 ℃（-40 ℃ 非标）',
          '附件：电位计，磁簧开关，霍尔传感器'
        ] },
      /*

*/
      { v: 'LAM5', t: 'LAM5 系列', img: 'rod-lam5.jpg', subs: ['LAM50', 'LAM51', 'LAM52', 'LAM53', 'LAM54', 'LAM55'], bullet: '◆',
        lead: 'LAM50（最大 10 kg）、LAM51（最大 50 kg）、LAM52（最大 230 kg）、LAM53（最大 230 kg）、LAM54（最大 380 kg）、LAM55（最大 600 kg）',
        specs: [
          '电压：12 / 24 VDC',
          '最大满载速度：55 mm/s',
          '行程范围：50-500 mm（LAM50 上限 100 mm）',
          '内置限位开关，电流保护（标配）',
          'IP 防护等级：IP66 / IP67',
          '工作制：10%（20 分钟内运行 2 分钟）',
          '工作温度：-20~60 ℃（储藏 -40~70 ℃）',
          '附件：霍尔开关，内置限位开关，电流保护'
        ] },
      { v: 'LAM6', t: 'LAM6 系列', img: 'rod-lam6.jpg', subs: ['LAM6'], bullet: '◆',
        lead: 'LAM6（最大 1200 kg）',
        specs: [
          '电压：12 / 24 / 36 / 48 VDC',
          '最大满载速度：20 mm/s',
          '行程范围：30-1000 mm',
          '内置限位开关，可作信号输出',
          'IP 防护等级：IP66（动态）',
          '工作制：10%（滚珠型 LBM6 为 25%）',
          '工作温度：-25~60 ℃（-40 ℃ 非标）',
          '附件：双霍尔开关，模拟反馈 0~10 V / 4~20 mA，逻辑电平控制（可配 CAN 通讯）'
        ] },
      { v: 'LAM89', t: 'LAM8-9 系列', img: 'rod-lam89.jpg', subs: ['LAM8', 'LBM9'], bullet: '◆',
        lead: 'LAM8（最大 900 kg）、LBM9（最大 600 kg）',
        specs: [
          '电压：12 / 24 / 36 / 48 VDC；LBM9 另有 110 / 220 VAC',
          '最大满载速度：45 mm/s（LBM9-S0）',
          '行程范围：50-1000 mm（LAM8 特殊行程）；LBM9 为 100-600 mm',
          '内置限位开关（LBM9 为内置可调凸轮限位开关）',
          'IP 防护等级：LAM8 IP65；LBM9 直流 IP66 / 交流 IP65',
          '工作制：25%',
          '工作温度：LAM8 -20~65 ℃（-40 ℃ 非标）；LBM9 直流 -40~85 ℃、交流 -26~65 ℃',
          '附件：LAM8 霍尔传感器，电位计，温度过热保护器；LBM9 电位计'
        ] }
    ],
    /*





*/
    lam_code: {
      subs: ['LAM32', 'LAM33'],
      volt: [
        { v: '1', t: '1 = 12V DC' }, { v: '2', t: '2 = 24V DC' }, { v: '3', t: '3 = 36V DC' },
        { v: '4', t: '4 = 48V DC' }, { v: '5', t: '5 = 24V DC，PTC' }, { v: '6', t: '6 = 12V DC，PTC' },
        { v: '7', t: '7 = 36V DC，PTC' }, { v: '8', t: '8 = 48V DC，PTC' }
      ],
      /**/
      voltBySub: {
        LAM32: ['1', '2', '3', '4', '5', '6', '7', '8'],
        LAM33: ['1', '2', '3', '5', '6']
      },
      lower: [
        { v: '1', t: '1 = 铝压铸，无槽，孔径 6.4（下盖一体）' },
        { v: '2', t: '2 = 铝压铸，无槽，孔径 8.0（下盖一体）' },
        { v: '3', t: '3 = 铝压铸，无槽，孔径 10.0（下盖一体）' },
        { v: '4', t: '4 = 铝压铸，U 型槽 6.0×10.5，孔径 6.4（下盖一体）' },
        { v: '5', t: '5 = 铝压铸，U 型槽 6.0×10.5，孔径 8.0（下盖一体）' },
        { v: '6', t: '6 = 铝压铸，U 型槽 6.0×10.5，孔径 10.0（下盖一体）' }
      ],
      upper: [
        { v: '1', t: '1 = 铝压铸，无槽，孔径 6.4' },
        { v: '2', t: '2 = 铝压铸，无槽，孔径 8.0' },
        { v: '3', t: '3 = 铝加工，U 型槽 6.0×16.0，孔径 10.0' },
        { v: '4', t: '4 = 铝加工，U 型槽 6.0×16.0，孔径 6.4' },
        { v: '5', t: '5 = 铝加工，U 型槽 6.0×16.0，孔径 8.0' },
        { v: '6', t: '6 = 铝压铸，无槽，孔径 10.0' }
      ],
      angle: [{ v: '1', t: '1 = 90°（逆时针）' }, { v: '2', t: '2 = 0°' }],
      limit: [
        { v: '1', t: '1 = 两端点微动开关切电流' },
        { v: '2', t: '2 = 两端点切电流 + 第三个微动开关信号输出' },
        { v: '3', t: '3 = 两端点微动开关信号输出' },
        { v: '4', t: '4 = 两端点信号输出 + 第三个微动开关信号输出' }
      ],
      signal: [
        { v: '0', t: '0 = 无' }, { v: '1', t: '1 = POT 电位计' },
        { v: '3', t: '3 = 磁簧开关' }, { v: '5', t: '5 = 霍尔传感器 ×2' }
      ],
      plug: [{ v: '1', t: '1 = DIN 6P，90° 插头' }, { v: '2', t: '2 = 裸线粘锡' }],
      cable: [{ v: '1', t: '1 = 直线 300 mm' }, { v: '2', t: '2 = 直线 600 mm' }, { v: '3', t: '3 = 直线 1000 mm' }],
      ip: [
        { v: '1', t: '1 = 无' }, { v: '2', t: '2 = IP54' },
        { v: '3', t: '3 = IP66' }, { v: '6', t: '6 = IP66D' }
      ],
      /*
*/
      mountA: { 'up123|lo126': 105, 'up123|lo345': 109, 'up456|lo126': 115, 'up456|lo345': 119 },
      mountB: [[150, 0], [200, 2], [250, 2], [300, 2], [350, 12], [400, 22], [450, 32], [500, 42],
        [550, 52], [600, 62], [650, 72], [700, 82], [750, 92], [800, 102], [850, 112],
        [900, 122], [950, 132], [1000, 142]],
      /**/
      mountC: {
        LAM32: { '0': 0, '1': 30, '3': 30, '5': 30 },
        LAM33: { '0': 0, '1': 30, '3': 30, '5': 0 }
      },
      /**/
      mountB3500Extra: { LAM33: 5 }
    },
    /*

*/
    lam35_specs: {
      volt: {
        LAM3: [{ v: '12', t: 'DC 12V' }, { v: '24', t: 'DC 24V' }, { v: '36', t: 'DC 36V' }, { v: '48', t: 'DC 48V' }],
        LAM5: [{ v: '12', t: 'DC 12V' }, { v: '24', t: 'DC 24V' }]
      },
      /**/
      fb: {
        LAM3: [{ v: '无', t: '不带附件' }, { v: 'POT', t: '电位计 POT' }, { v: 'REED', t: '磁簧开关' }, { v: 'HALL', t: '霍尔传感器' }],
        LAM5: [{ v: '无', t: '不带附件' }, { v: 'HALL', t: '霍尔开关' }]
      },
      /**/
      bracket: {
        LAM52: [{ v: '35F', t: '35F 前端支架' }, { v: '35R', t: '35R 尾端支架' }, { v: '无', t: '不配支架' }],
        LAM53: [{ v: '53F', t: '53F 前端支架' }, { v: '53R', t: '53R 尾端支架' }, { v: '无', t: '不配支架' }],
        LAM55: [{ v: '55F', t: '55F 前端支架' }, { v: '55R', t: '55R 尾端支架' }, { v: '无', t: '不配支架' }]
      },
      /**/
      ctrl: {
        LAM50: ['一控一', '一控二', '一控三'],
        LAM51: ['一控一', '一控二', '一控三'],
        LAM52: ['一控一', '一控二', '一控三'],
        LAM53: ['一控一', '一控二', '一控三'],
        LAM54: ['一控一（带变压器）', '一控一（直流直入）', '一控二（不）同步（带变压器）', '一控二（不）同步（直流直入）', '一控三'],
        LAM55: ['一控一（带变压器）', '一控一（直流直入）', '一控二（不）同步（直流直入）', '一控三']
      },
      /**/
      shell: {
        LAM3: [{ v: 'AL', t: '铝合金' }],
        LAM5: [{ v: 'AL', t: '6063 铝合金' }, { v: 'SUS316', t: '316 不锈钢' }, { v: 'ST45', t: '45# 钢喷塑' }]
      },
      /*

*/
      ip: {
        LAM3: [{ v: 'IP65', t: 'IP65' }, { v: 'IP66', t: 'IP66' }, { v: 'IP66D', t: 'IP66D（动态 IP66）' }],
        LAM5: [{ v: 'IP66', t: 'IP66' }, { v: 'IP67', t: 'IP67' }],
        LAM89: [{ v: 'IP65', t: 'IP65' }, { v: 'IP66', t: 'IP66' }]
      },
      /*

*/
      limit: {
        LAM3: [{ v: 'L2', t: 'L2 内置开关' }, { v: 'XL2', t: 'XL2 内置开关外出线' }, { v: 'FCM', t: 'FCM 外置磁感应开关' }],
        LAM5: [{ v: '标配', t: '内置机械行程开关 + 电流保护（标配）' }, { v: '取消', t: '不配行程开关（非标）' }],
        LAM6: [{ v: 'L2', t: 'L2 内置开关' }, { v: 'XL2', t: 'XL2 内置开关外出线' }, { v: 'FCM', t: 'FCM 外置磁感应开关' }],
        LAM89: [{ v: 'L2', t: 'L2 内置开关' }, { v: 'XL2', t: 'XL2 内置开关外出线' }, { v: 'FCM', t: 'FCM 外置磁感应开关' }]
      },
      /*

*/
      screw: {
        LAM6: [
          { v: 'LAM6', t: '梯形丝杠 LAM6（工作制 10%｜自锁）' },
          { v: 'LBM6', t: '滚珠丝杠 LBM6（工作制 25%｜不自锁，配制动器）' }
        ]
      },
      /**/
      voltPushCap: { LAM55: { '12': 5000 } },
      /**/
      bracketPrefix: { LAM52: '35', LAM53: '53', LAM55: '55' },
      /**/
      potStrokeMax: { 'LAM3-S1': 350, 'LAM3-S2': 350 }
    },
    /**/
    temps: [
      { v: '20', t: '+20℃（常温）' }, { v: '0', t: '0℃' }, { v: '-20', t: '-20℃' },
      { v: '-30', t: '-30℃' }, { v: '-40', t: '-40℃（低温）' }, { v: '80', t: '+80℃（高温）' }
    ],
    precisions: [
      { v: '0.1', t: '0.1 mm（梯形/滚珠丝杠）' },
      { v: '0.05', t: '0.05 mm（仅滚珠丝杠可达）' }
    ],
    drives: [
      { v: 'ac3', t: '三相交流电机 380V（默认）', fams: ['LAP', 'LBP'] },
      { v: 'hand', t: '手摇', fams: ['LAP', 'LBP'] },
      { v: 'ac1', t: '单相交流电机 220VAC', fams: ['LAP', 'LBP'] },
      /**/
      { v: 'dc24', t: '直流电机 24VDC', fams: ['LAM', 'LAP', 'LBP'] },
      { v: 'dc12', t: '直流电机 12VDC', fams: ['LAM'] },
      { v: 'dc48', t: '直流电机 48VDC', fams: ['LAM'] },
      { v: 'servo220', t: '伺服电机 220VAC', fams: ['LAP', 'LBP'] },
      { v: 'servo380', t: '伺服电机 380VAC', fams: ['LAP', 'LBP'] },
      { v: 'stepping', t: '步进电机', fams: ['LAP', 'LBP'] }
    ],
    /**/
    installs: [
      { v: 'P1', t: 'P1 单输入轴', img: 'inp-p1.png' },
      { v: 'P2', t: 'P2 双输入轴', img: 'inp-p2.png' },
      { v: 'P3', t: 'P3 单电机法兰输入', img: 'inp-p3.png' },
      { v: 'P4', t: 'P4 法兰+轴输入', img: 'inp-p4.png' }
    ],
    /*


*/
    unit_counts: [
      { v: '1', t: '单台电动推杆' },
      { v: '2', t: '两台电动推杆' }
    ],
    rod_layouts: [
      { v: '电机内侧', t: '电机内侧', img: 'rod-lay2-inner.jpg' },
      { v: '电机外侧', t: '电机外侧', img: 'rod-lay2-outer.jpg' }
    ],
    input_dirs: [ { v: 'RH', t: 'RH 右输入（标配）' }, { v: 'LH', t: 'LH 左输入' } ],
    /*

*/
    joints: [
      { v: 'FL', t: 'FL 法兰端', img: 'joint-fl.png', fams: ['LAP', 'LBP'] },
      { v: 'TS', t: 'TS 球形铰接', img: 'joint-ts.png', fams: ['LAP', 'LBP'] },
      { v: 'ROE', t: 'ROE 销孔端', img: 'joint-lam-roe.jpg', fams: ['LAM', 'LAP', 'LBP'] },
      { v: 'FO', t: 'FO 叉销端', img: 'joint-fo.png', fams: ['LAM', 'LAP', 'LBP'] },
      { v: 'NF', t: 'NF 外螺纹', img: 'joint-std.png', fams: ['LAP', 'LBP'] },
      { v: 'BA', t: 'BA 标准内螺纹', img: 'joint-ba.png', fams: ['LAP', 'LBP'] }
    ],
    accessories: [
      /**/
      { v: 'LS', t: '内置限位开关', lamOnly: true },
      { v: 'CP', t: '电流保护', lamOnly: true },
      { v: 'HALL', t: '霍尔开关', lamOnly: true },
      { v: 'AR', t: '防反转装置 AR' },
      { v: 'SP', t: '尾销座 SP' },
      { v: 'FI', t: '推杆臂支撑法兰 FI' },
      { v: 'FR', t: '箱体尾端盖为法兰 FR' },
      { v: 'RPT90', t: '尾销座旋转 90° RPT90' },
      { v: 'B', t: '防尘罩 B' },
      { v: 'SN', t: '安全螺母 SN' },
      { v: 'ST', t: '不锈钢外管 ST' },
      { v: 'IRE', t: '编码器 IRE' },
      { v: 'FS', t: '安全离合器 FS' },
      { v: 'HW', t: '手摇轮 HW' }
      /*

*/
    ],
    /*

*/
    limits: [
      /*
*/
      { v: 'FCM', t: '磁感应开关 FCM', std: 'small', fams: ['LAP', 'LBP'] },
      { v: 'FCP', t: '接近开关 FCP', std: 'large', fams: ['LAP', 'LBP'] },
      { v: 'FCE', t: '机械外置开关 FCE', fams: ['LAP', 'LBP'] },
      /*
*/
      { v: 'NONE', t: '无限位开关', fams: ['LAP', 'LBP'] }
    ],
    /*






*/
    input_shaft_dia: {
      LAP22: 9, LAP25: 9, LAP28: 9, LAP32: 9, LAP35: 10, LAP40: 14, LAP56: 18,
      LAP63: 40, LAP80: 45, LAP120: 60, LAP200: 70, LAP300: 90,
      LBP25: 9, LBP32: 9, LBP35: 10, LBP40: 14, LBP56: 18, LBP120: 60, LBP200: 70, LBP300: 90
    },
    /*










*/
    models: {
      /**/
      'LAM1-S0': { fam: 'LAM', sub: 'LAM1', code: 'S0', push_N: 3000, pull_N: 3000, lock_N: 3000, v0: 8.6, v1: 6.5, iA: 0.7, stroke_max: 600, volts: ['24'], rpm: null, duty: '10%', note: '行程>300mm 承载减小，负载按曲线核对' },
      'LAM1-S1': { fam: 'LAM', sub: 'LAM1', code: 'S1', push_N: 6000, pull_N: 4000, lock_N: 6000, v0: 6.1, v1: 3.4, iA: 0.7, stroke_max: 600, volts: ['24'], rpm: null, duty: '10%', note: '行程>300mm 承载减小，负载按曲线核对' },
      /**/
      'LAM3-S0': { fam: 'LAM', sub: 'LAM3', code: 'S0', push_N: 100, pull_N: 100, lock_N: 150, v0: 66, v1: 40, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%' },
      'LAM3-S1': { fam: 'LAM', sub: 'LAM3', code: 'S1', push_N: 280, pull_N: 280, lock_N: 400, v0: 35, v1: 30, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', note: '含电位计最大行程 350mm' },
      'LAM3-S2': { fam: 'LAM', sub: 'LAM3', code: 'S2', push_N: 600, pull_N: 600, lock_N: 900, v0: 18, v1: 13, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', note: '含电位计最大行程 350mm' },
      'LAM3-S3': { fam: 'LAM', sub: 'LAM3', code: 'S3', push_N: 750, pull_N: 750, lock_N: 800, v0: 16, v1: 12, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%' },
      'LAM3-S4': { fam: 'LAM', sub: 'LAM3', code: 'S4', push_N: 1000, pull_N: 1000, lock_N: 1100, v0: 11, v1: 7, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%' },
      'LAM3-S5': { fam: 'LAM', sub: 'LAM3', code: 'S5', push_N: 2500, pull_N: 2500, lock_N: 3000, v0: 5, v1: 4, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', note: '含电位计最大行程 350mm' },
      /**/
      'LAM32-A': { fam: 'LAM', sub: 'LAM32', code: 'A', push_N: 120, pull_N: 120, lock_N: 120, v0: 44, v1: 33, iA: 1.0, stroke_max: 1000, volts: ['12', '24', '36', '48'], rpm: 4200, duty: '25%' },
      'LAM32-B': { fam: 'LAM', sub: 'LAM32', code: 'B', push_N: 240, pull_N: 240, lock_N: 240, v0: 22, v1: 16.5, iA: 1.0, stroke_max: 1000, volts: ['12', '24', '36', '48'], rpm: 4200, duty: '25%' },
      'LAM32-C': { fam: 'LAM', sub: 'LAM32', code: 'C', push_N: 500, pull_N: 500, lock_N: 500, v0: 11, v1: 8.5, iA: 0.9, stroke_max: 800, volts: ['12', '24', '36', '48'], rpm: 4200, duty: '25%' },
      'LAM32-D': { fam: 'LAM', sub: 'LAM32', code: 'D', push_N: 750, pull_N: 750, lock_N: 750, v0: 7.5, v1: 6.2, iA: 0.9, stroke_max: 800, volts: ['12', '24', '36', '48'], rpm: 4200, duty: '25%' },
      'LAM32-E': { fam: 'LAM', sub: 'LAM32', code: 'E', push_N: 1000, pull_N: 1000, lock_N: 1000, v0: 5.6, v1: 4.6, iA: 0.9, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: 4200, duty: '25%' },
      'LAM32-F': { fam: 'LAM', sub: 'LAM32', code: 'F', push_N: 120, pull_N: 120, lock_N: 120, v0: 67.5, v1: 51, iA: 1.8, stroke_max: 1000, volts: ['12', '24', '36', '48'], rpm: 6000, duty: '25%' },
      'LAM32-G': { fam: 'LAM', sub: 'LAM32', code: 'G', push_N: 240, pull_N: 240, lock_N: 240, v0: 33.5, v1: 26.5, iA: 1.7, stroke_max: 1000, volts: ['12', '24', '36', '48'], rpm: 6000, duty: '25%' },
      'LAM32-H': { fam: 'LAM', sub: 'LAM32', code: 'H', push_N: 500, pull_N: 500, lock_N: 500, v0: 17, v1: 14, iA: 1.5, stroke_max: 800, volts: ['12', '24', '36', '48'], rpm: 6000, duty: '25%' },
      'LAM32-K': { fam: 'LAM', sub: 'LAM32', code: 'K', push_N: 750, pull_N: 750, lock_N: 750, v0: 11, v1: 10, iA: 1.5, stroke_max: 800, volts: ['12', '24', '36', '48'], rpm: 6000, duty: '25%' },
      'LAM32-L': { fam: 'LAM', sub: 'LAM32', code: 'L', push_N: 1000, pull_N: 1000, lock_N: 1000, v0: 9, v1: 7.6, iA: 1.5, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: 6000, duty: '25%' },
      /**/
      'LAM33-A': { fam: 'LAM', sub: 'LAM33', code: 'A', push_N: 250, pull_N: 250, lock_N: 250, v0: 43, v1: 36, iA: 2.3, stroke_max: 1000, volts: ['12', '24', '36'], rpm: 5200, duty: '25%' },
      'LAM33-B': { fam: 'LAM', sub: 'LAM33', code: 'B', push_N: 500, pull_N: 500, lock_N: 500, v0: 25.8, v1: 23, iA: 2.5, stroke_max: 800, volts: ['12', '24', '36'], rpm: 5200, duty: '25%' },
      'LAM33-C': { fam: 'LAM', sub: 'LAM33', code: 'C', push_N: 1000, pull_N: 1000, lock_N: 1000, v0: 14, v1: 11.8, iA: 3.0, stroke_max: 600, volts: ['12', '24', '36'], rpm: 5200, duty: '25%' },
      'LAM33-D': { fam: 'LAM', sub: 'LAM33', code: 'D', push_N: 1500, pull_N: 1500, lock_N: 1500, v0: 9, v1: 8, iA: 2.8, stroke_max: 500, volts: ['12', '24', '36'], rpm: 5200, duty: '25%' },
      'LAM33-E': { fam: 'LAM', sub: 'LAM33', code: 'E', push_N: 2000, pull_N: 2000, lock_N: 2000, v0: 7.1, v1: 6.2, iA: 2.8, stroke_max: 450, volts: ['12', '24', '36'], rpm: 5200, duty: '25%' },
      'LAM33-F': { fam: 'LAM', sub: 'LAM33', code: 'F', push_N: 250, pull_N: 250, lock_N: 250, v0: 56.5, v1: 45, iA: 3.0, stroke_max: 1000, volts: ['12', '24', '36'], rpm: 6600, duty: '25%' },
      'LAM33-G': { fam: 'LAM', sub: 'LAM33', code: 'G', push_N: 500, pull_N: 500, lock_N: 500, v0: 32.5, v1: 28.5, iA: 3.0, stroke_max: 800, volts: ['12', '24', '36'], rpm: 6600, duty: '25%' },
      'LAM33-H': { fam: 'LAM', sub: 'LAM33', code: 'H', push_N: 1000, pull_N: 1000, lock_N: 1000, v0: 16.5, v1: 14.3, iA: 3.0, stroke_max: 600, volts: ['12', '24', '36'], rpm: 6600, duty: '25%' },
      'LAM33-K': { fam: 'LAM', sub: 'LAM33', code: 'K', push_N: 1500, pull_N: 1500, lock_N: 1500, v0: 11.1, v1: 10, iA: 3.0, stroke_max: 500, volts: ['12', '24', '36'], rpm: 6600, duty: '25%' },
      'LAM33-L': { fam: 'LAM', sub: 'LAM33', code: 'L', push_N: 2000, pull_N: 2000, lock_N: 2000, v0: 8.8, v1: 7.7, iA: 3.0, stroke_max: 450, volts: ['12', '24', '36'], rpm: 6600, duty: '25%' },
      'LAM33-S': { fam: 'LAM', sub: 'LAM33', code: 'S', push_N: 3500, pull_N: 2000, lock_N: 3500, v0: 3.2, v1: 2.4, iA: 2.8, stroke_max: 300, volts: ['12', '24', '36'], rpm: 3800, duty: '25%' },
      'LAM33-T': { fam: 'LAM', sub: 'LAM33', code: 'T', push_N: 2000, pull_N: 2000, lock_N: 2000, v0: 3.2, v1: 2.3, iA: 0.9, stroke_max: 450, volts: ['12', '24', '36'], rpm: 2200, duty: '25%' },
      /*
*/
      'LAM6-S0': { fam: 'LAM', sub: 'LAM6', code: 'S0', push_N: 3000, pull_N: 3000, lock_N: 4000, v0: 40, v1: 20, iA: 12, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6, note: '可配 CAN 通讯驱动，内置限位开关可信号输出' },
      'LAM6-S1': { fam: 'LAM', sub: 'LAM6', code: 'S1', push_N: 4000, pull_N: 4000, lock_N: 5000, v0: 30, v1: 15, iA: 12, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6 },
      'LAM6-S2': { fam: 'LAM', sub: 'LAM6', code: 'S2', push_N: 5000, pull_N: 5000, lock_N: 6000, v0: 25, v1: 14, iA: 12, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6 },
      'LAM6-S3': { fam: 'LAM', sub: 'LAM6', code: 'S3', push_N: 7000, pull_N: 7000, lock_N: 8000, v0: 17, v1: 9.5, iA: 13, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6 },
      'LAM6-S4': { fam: 'LAM', sub: 'LAM6', code: 'S4', push_N: 10000, pull_N: 10000, lock_N: 12000, v0: 13, v1: 7, iA: 13, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6 },
      'LAM6-S5': { fam: 'LAM', sub: 'LAM6', code: 'S5', push_N: 12000, pull_N: 12000, lock_N: 15000, v0: 6.5, v1: 4.5, iA: 13, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '10%', weight: 5.2, w100: 0.6, note: '系列最大档 12 kN（1224kg），可配 CAN 通讯驱动' },
      /**/
      'LAM50-S0': { fam: 'LAM', sub: 'LAM50', code: 'S0', push_N: 20, pull_N: 20, lock_N: 30, v0: 15, v1: 10, iA: 0.15, stroke_max: 100, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM50-S1': { fam: 'LAM', sub: 'LAM50', code: 'S1', push_N: 50, pull_N: 50, lock_N: 75, v0: 7.5, v1: 5, iA: 0.15, stroke_max: 100, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM50-S2': { fam: 'LAM', sub: 'LAM50', code: 'S2', push_N: 100, pull_N: 100, lock_N: 150, v0: 5, v1: 3, iA: 0.15, stroke_max: 100, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM51-S0': { fam: 'LAM', sub: 'LAM51', code: 'S0', push_N: 100, pull_N: 100, lock_N: 150, v0: 15, v1: 11, iA: 0.7, stroke_max: 200, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM51-S1': { fam: 'LAM', sub: 'LAM51', code: 'S1', push_N: 250, pull_N: 250, lock_N: 375, v0: 8.5, v1: 6, iA: 0.7, stroke_max: 200, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM51-S2': { fam: 'LAM', sub: 'LAM51', code: 'S2', push_N: 500, pull_N: 500, lock_N: 750, v0: 5, v1: 3.5, iA: 0.7, stroke_max: 200, volts: ['12', '24'], rpm: null, duty: '10%' },
      /*




*/
      'LAM52-S0': { fam: 'LAM', sub: 'LAM52', code: 'S0', push_N: 100, pull_N: 100, lock_N: 150, v0: 35, v1: 30, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 0.8, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S1': { fam: 'LAM', sub: 'LAM52', code: 'S1', push_N: 300, pull_N: 300, lock_N: 600, v0: 25, v1: 17, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 0.9, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S2': { fam: 'LAM', sub: 'LAM52', code: 'S2', push_N: 400, pull_N: 400, lock_N: 600, v0: 18, v1: 14, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.0, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S3': { fam: 'LAM', sub: 'LAM52', code: 'S3', push_N: 600, pull_N: 600, lock_N: 1600, v0: 12, v1: 9, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.1, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S4': { fam: 'LAM', sub: 'LAM52', code: 'S4', push_N: 800, pull_N: 800, lock_N: 1600, v0: 12, v1: 7, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.2, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S5': { fam: 'LAM', sub: 'LAM52', code: 'S5', push_N: 1200, pull_N: 1200, lock_N: 1800, v0: 6.8, v1: 4.5, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.3, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S6': { fam: 'LAM', sub: 'LAM52', code: 'S6', push_N: 1800, pull_N: 1800, lock_N: 3600, v0: 4.5, v1: 3, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.4, w100: 0.23, bracket: ['35F', '35R'] },
      'LAM52-S7': { fam: 'LAM', sub: 'LAM52', code: 'S7', push_N: 2300, pull_N: 2300, lock_N: 3450, v0: 3.5, v1: 2.3, iA: null, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', weight: 1.6, w100: 0.23, bracket: ['35F', '35R'], note: '系列最大档 2.3 kN' },
      'LAM53-S0': { fam: 'LAM', sub: 'LAM53', code: 'S0', push_N: 100, pull_N: 100, lock_N: 150, v0: 35, v1: 30, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', note: 'LAM52 升级版，内置行程开关', bracket: ['53F', '53R'] },
      'LAM53-S1': { fam: 'LAM', sub: 'LAM53', code: 'S1', push_N: 300, pull_N: 300, lock_N: 600, v0: 25, v1: 17, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S2': { fam: 'LAM', sub: 'LAM53', code: 'S2', push_N: 400, pull_N: 400, lock_N: 600, v0: 18, v1: 14, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S3': { fam: 'LAM', sub: 'LAM53', code: 'S3', push_N: 600, pull_N: 600, lock_N: 1600, v0: 12, v1: 9, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S4': { fam: 'LAM', sub: 'LAM53', code: 'S4', push_N: 800, pull_N: 800, lock_N: 1600, v0: 12, v1: 7, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S5': { fam: 'LAM', sub: 'LAM53', code: 'S5', push_N: 1200, pull_N: 1200, lock_N: 1800, v0: 6.8, v1: 4.5, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S6': { fam: 'LAM', sub: 'LAM53', code: 'S6', push_N: 1800, pull_N: 1800, lock_N: 3600, v0: 4.5, v1: 3, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM53-S7': { fam: 'LAM', sub: 'LAM53', code: 'S7', push_N: 2300, pull_N: 2300, lock_N: 3450, v0: 3.5, v1: 2.3, iA: 1.8, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['53F', '53R'] },
      'LAM54-S0': { fam: 'LAM', sub: 'LAM54', code: 'S0', push_N: 300, pull_N: 300, lock_N: 450, v0: 72, v1: 45, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM54-S1': { fam: 'LAM', sub: 'LAM54', code: 'S1', push_N: 600, pull_N: 600, lock_N: 900, v0: 38.4, v1: 24, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM54-S2': { fam: 'LAM', sub: 'LAM54', code: 'S2', push_N: 1000, pull_N: 1000, lock_N: 1500, v0: 25.6, v1: 16, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM54-S3': { fam: 'LAM', sub: 'LAM54', code: 'S3', push_N: 1600, pull_N: 1600, lock_N: 2400, v0: 17.6, v1: 11, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM54-S4': { fam: 'LAM', sub: 'LAM54', code: 'S4', push_N: 2600, pull_N: 2600, lock_N: 3900, v0: 8.8, v1: 5.5, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM54-S5': { fam: 'LAM', sub: 'LAM54', code: 'S5', push_N: 3800, pull_N: 3800, lock_N: 5700, v0: 6.4, v1: 4, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%' },
      'LAM55-S0': { fam: 'LAM', sub: 'LAM55', code: 'S0', push_N: 300, pull_N: 300, lock_N: 600, v0: 88, v1: 55, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'] },
      'LAM55-S1': { fam: 'LAM', sub: 'LAM55', code: 'S1', push_N: 1200, pull_N: 1200, lock_N: 2400, v0: 24, v1: 15, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'] },
      'LAM55-S2': { fam: 'LAM', sub: 'LAM55', code: 'S2', push_N: 1800, pull_N: 1800, lock_N: 3600, v0: 16, v1: 10, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'] },
      'LAM55-S3': { fam: 'LAM', sub: 'LAM55', code: 'S3', push_N: 3000, pull_N: 3000, lock_N: 6000, v0: 9.6, v1: 6, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'] },
      'LAM55-S4': { fam: 'LAM', sub: 'LAM55', code: 'S4', push_N: 4500, pull_N: 4500, lock_N: 8000, v0: 6.4, v1: 4.5, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'] },
      'LAM55-S5': { fam: 'LAM', sub: 'LAM55', code: 'S5', push_N: 5000, pull_N: 5000, lock_N: 7500, v0: 4.8, v1: 4, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', bracket: ['55F', '55R'], note: '12V 版最大负载 5000N（专门样本 p21）' },
      'LAM55-S6': { fam: 'LAM', sub: 'LAM55', code: 'S6', push_N: 6000, pull_N: 6000, lock_N: 8000, v0: 4.8, v1: 3, iA: 5, stroke_max: 500, volts: ['12', '24'], rpm: null, duty: '10%', note: '12V 版最大负载 5000N；自锁力按 LAM5 专门样本 p21 修正 6000→8000N', bracket: ['55F', '55R'] },
      /**/
      'LAM8-S0': { fam: 'LAM', sub: 'LAM8', code: 'S0', push_N: 2000, pull_N: 2000, lock_N: 2800, v0: 35, v1: 28.5, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', ratio: '10:1' },
      'LAM8-S1': { fam: 'LAM', sub: 'LAM8', code: 'S1', push_N: 5000, pull_N: 5000, lock_N: 7000, v0: 10, v1: 8.5, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', ratio: '20:1' },
      'LAM8-S2': { fam: 'LAM', sub: 'LAM8', code: 'S2', push_N: 9000, pull_N: 9000, lock_N: 11000, v0: 5, v1: 3.5, iA: null, stroke_max: 600, volts: ['12', '24', '36', '48'], rpm: null, duty: '25%', ratio: '40:1' },
      /**/
      'LBM9-S0': { fam: 'LAM', sub: 'LBM9', code: 'S0', push_N: 2300, pull_N: 2300, lock_N: 0, v0: 65, v1: 45, iA: 10, stroke_max: 600, volts: ['12', '24'], rpm: null, duty: '25%', ball: true, note: '直流型；内部滚珠丝杠不自锁，电机配制动器' },
      'LBM9-S1': { fam: 'LAM', sub: 'LBM9', code: 'S1', push_N: 3500, pull_N: 3500, lock_N: 0, v0: 36, v1: 22, iA: 8.5, stroke_max: 600, volts: ['12', '24'], rpm: null, duty: '25%', ball: true, note: '直流型；内部滚珠丝杠不自锁，电机配制动器' },
      'LBM9-S2': { fam: 'LAM', sub: 'LBM9', code: 'S2', push_N: 4500, pull_N: 4500, lock_N: 0, v0: 22, v1: 13, iA: 6.5, stroke_max: 600, volts: ['12', '24'], rpm: null, duty: '25%', ball: true, note: '直流型；内部滚珠丝杠不自锁，电机配制动器' },
      'LBM9-A0': { fam: 'LAM', sub: 'LBM9', code: 'S0', push_N: 2300, pull_N: 2300, lock_N: 0, v0: 50, v1: 40, iA: 1.5, stroke_max: 600, volts: ['110', '220'], rpm: null, duty: '25%', ball: true, ac: true, note: '交流型 110/220V；内部滚珠丝杠不自锁，电机配制动器' },
      'LBM9-A1': { fam: 'LAM', sub: 'LBM9', code: 'S1', push_N: 4500, pull_N: 4500, lock_N: 0, v0: 24, v1: 20, iA: 1.4, stroke_max: 600, volts: ['110', '220'], rpm: null, duty: '25%', ball: true, ac: true, note: '交流型 110/220V；内部滚珠丝杠不自锁，电机配制动器' },
      'LBM9-A2': { fam: 'LAM', sub: 'LBM9', code: 'S2', push_N: 6000, pull_N: 6000, lock_N: 0, v0: 13, v1: 11, iA: 1.4, stroke_max: 600, volts: ['110', '220'], rpm: null, duty: '25%', ball: true, ac: true, note: '交流型 110/220V；内部滚珠丝杠不自锁，电机配制动器' },

      /**/
      'LAP22-N2-DC': { fam: 'LAP', sub: 'LAP22', code: 'N2', speed: 36, load_N: 400, motor: { kind: 'dc24', A: 4.5 }, lock: 0.35, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-L2-DC': { fam: 'LAP', sub: 'LAP22', code: 'L2', speed: 18, load_N: 750, motor: { kind: 'dc24', A: 4.2 }, lock: 0.27, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-N1-DC': { fam: 'LAP', sub: 'LAP22', code: 'N1', speed: 13.5, load_N: 950, motor: { kind: 'dc24', A: 4.2 }, lock: 0.22, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-L1-DC': { fam: 'LAP', sub: 'LAP22', code: 'L1', speed: 6.5, load_N: 1400, motor: { kind: 'dc24', A: 4.5 }, lock: 0.16, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP25-N2-DC': { fam: 'LAP', sub: 'LAP25', code: 'N2', speed: 40, load_N: 1000, motor: { kind: 'dc24', A: 9.8 }, lock: 0.35, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-L2-DC': { fam: 'LAP', sub: 'LAP25', code: 'L2', speed: 20, load_N: 1600, motor: { kind: 'dc24', A: 9.5 }, lock: 0.28, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-N1-DC': { fam: 'LAP', sub: 'LAP25', code: 'N1', speed: 15, load_N: 2000, motor: { kind: 'dc24', A: 9.6 }, lock: 0.22, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-L1-DC': { fam: 'LAP', sub: 'LAP25', code: 'L1', speed: 7.5, load_N: 3000, motor: { kind: 'dc24', A: 9.5 }, lock: 0.17, weight: 3.2, w100: 0.4, stroke_max: 500 },
      /**/
      'LBP25-N1-DC': { fam: 'LBP', sub: 'LBP25', code: 'N1', speed: 20, load_N: 2000, motor: { kind: 'dc24', A: 9.6 }, lock: 0.49, weight: 3.2, w100: 0.4, stroke_max: 500, ball: true },
      'LBP25-L1-DC': { fam: 'LBP', sub: 'LBP25', code: 'L1', speed: 10, load_N: 2700, motor: { kind: 'dc24', A: 9.5 }, lock: 0.37, weight: 3.2, w100: 0.4, stroke_max: 500, ball: true },

      /**/
      'LAP22-N2': { fam: 'LAP', sub: 'LAP22', code: 'N2', speed: 30, load_N: 500, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.35, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-L2': { fam: 'LAP', sub: 'LAP22', code: 'L2', speed: 15, load_N: 750, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.27, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-N1': { fam: 'LAP', sub: 'LAP22', code: 'N1', speed: 11, load_N: 900, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.22, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP22-L1': { fam: 'LAP', sub: 'LAP22', code: 'L1', speed: 5.5, load_N: 1400, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.16, weight: 2, w100: 0.3, stroke_max: 300 },
      'LAP25-N2': { fam: 'LAP', sub: 'LAP25', code: 'N2', speed: 37, load_N: 1000, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.35, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-L2': { fam: 'LAP', sub: 'LAP25', code: 'L2', speed: 18.5, load_N: 1600, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.28, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-N1': { fam: 'LAP', sub: 'LAP25', code: 'N1', speed: 14, load_N: 2000, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.22, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP25-L1': { fam: 'LAP', sub: 'LAP25', code: 'L1', speed: 7, load_N: 3000, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.17, weight: 3.2, w100: 0.4, stroke_max: 500 },
      'LAP28-H2a': { fam: 'LAP', sub: 'LAP28', code: 'H2', speed: 93, load_N: 600, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.40, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-V2a': { fam: 'LAP', sub: 'LAP28', code: 'V2', speed: 60, load_N: 1000, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.41, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-H2b': { fam: 'LAP', sub: 'LAP28', code: 'H2', speed: 46, load_N: 850, motor: { kind: 'ac3', kw: 0.09, rpm: 1400 }, lock: 0.40, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-H1': { fam: 'LAP', sub: 'LAP28', code: 'H1', speed: 35, load_N: 1100, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.25, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-N2': { fam: 'LAP', sub: 'LAP28', code: 'N2', speed: 30, load_N: 1750, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.35, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-V1': { fam: 'LAP', sub: 'LAP28', code: 'V1', speed: 22, load_N: 1500, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.25, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-L2a': { fam: 'LAP', sub: 'LAP28', code: 'L2', speed: 15, load_N: 3000, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.27, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-N1': { fam: 'LAP', sub: 'LAP28', code: 'N1', speed: 11, load_N: 3600, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.22, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-L2b': { fam: 'LAP', sub: 'LAP28', code: 'L2', speed: 7.5, load_N: 4000, motor: { kind: 'ac3', kw: 0.09, rpm: 1400 }, lock: 0.27, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-L1a': { fam: 'LAP', sub: 'LAP28', code: 'L1', speed: 5.5, load_N: 4000, motor: { kind: 'ac3', kw: 0.12, rpm: 2800 }, lock: 0.16, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-L1b': { fam: 'LAP', sub: 'LAP28', code: 'L1', speed: 2.8, load_N: 4000, motor: { kind: 'ac3', kw: 0.09, rpm: 1400 }, lock: 0.16, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP28-XL1': { fam: 'LAP', sub: 'LAP28', code: 'XL1', speed: 1.9, load_N: 4000, motor: { kind: 'ac3', kw: 0.09, rpm: 1400 }, lock: 0.11, weight: 5.1, w100: 0.3, stroke_max: 1500 },
      'LAP32-H2': { fam: 'LAP', sub: 'LAP32', code: 'H2', speed: 93, load_N: 830, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.38, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-V2a': { fam: 'LAP', sub: 'LAP32', code: 'V2', speed: 60, load_N: 1250, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.38, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-H1a': { fam: 'LAP', sub: 'LAP32', code: 'H1', speed: 46, load_N: 1300, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.27, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-N2a': { fam: 'LAP', sub: 'LAP32', code: 'N2', speed: 30, load_N: 2200, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.33, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-H1b': { fam: 'LAP', sub: 'LAP32', code: 'H1', speed: 23, load_N: 1650, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.27, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-L2': { fam: 'LAP', sub: 'LAP32', code: 'L2', speed: 15, load_N: 3750, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.25, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-L1a': { fam: 'LAP', sub: 'LAP32', code: 'L1', speed: 7.5, load_N: 5550, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.18, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-L1b': { fam: 'LAP', sub: 'LAP32', code: 'L1', speed: 3.5, load_N: 6000, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.18, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP32-XL1': { fam: 'LAP', sub: 'LAP32', code: 'XL1', speed: 1.9, load_N: 6000, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.12, weight: 5.8, w100: 0.5, stroke_max: 1500 },
      'LAP35-V2': { fam: 'LAP', sub: 'LAP35', code: 'V2', speed: 93, load_N: 1300, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.37, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-V1': { fam: 'LAP', sub: 'LAP35', code: 'V1', speed: 46, load_N: 2100, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.25, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-N2': { fam: 'LAP', sub: 'LAP35', code: 'N2', speed: 23, load_N: 4300, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.28, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-L2': { fam: 'LAP', sub: 'LAP35', code: 'L2', speed: 15, load_N: 6000, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.22, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-N1a': { fam: 'LAP', sub: 'LAP35', code: 'N1', speed: 11, load_N: 6300, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.20, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-L1': { fam: 'LAP', sub: 'LAP35', code: 'L1', speed: 7.5, load_N: 10000, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.16, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-N1b': { fam: 'LAP', sub: 'LAP35', code: 'N1', speed: 5.5, load_N: 9000, motor: { kind: 'ac3', kw: 0.18, rpm: 1400 }, lock: 0.20, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP35-L1b': { fam: 'LAP', sub: 'LAP35', code: 'L1', speed: 4, load_N: 10000, motor: { kind: 'ac3', kw: 0.18, rpm: 1400 }, lock: 0.16, weight: 7.4, w100: 0.8, stroke_max: 1500 },
      'LAP40-V2': { fam: 'LAP', sub: 'LAP40', code: 'V2', speed: 93, load_N: 3000, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.37, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-V1': { fam: 'LAP', sub: 'LAP40', code: 'V1', speed: 46, load_N: 4400, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.26, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-N2a': { fam: 'LAP', sub: 'LAP40', code: 'N2', speed: 23, load_N: 10000, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.25, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-L2a': { fam: 'LAP', sub: 'LAP40', code: 'L2', speed: 18, load_N: 12000, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.24, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-N1a': { fam: 'LAP', sub: 'LAP40', code: 'N1', speed: 11, load_N: 12000, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.18, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-L2b': { fam: 'LAP', sub: 'LAP40', code: 'L2', speed: 9, load_N: 12000, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.24, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-N1b': { fam: 'LAP', sub: 'LAP40', code: 'N1', speed: 5.5, load_N: 12000, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.18, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP40-L1': { fam: 'LAP', sub: 'LAP40', code: 'L1', speed: 4.5, load_N: 12000, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.17, weight: 12.9, w100: 0.9, stroke_max: 1500 },
      'LAP56-V2a': { fam: 'LAP', sub: 'LAP56', code: 'V2', speed: 93, load_N: 11000, motor: { kind: 'ac3', kw: 2.2, rpm: 2800 }, lock: 0.35, weight: 50, w100: 2, stroke_max: 1500 },
      'LAP56-V2b': { fam: 'LAP', sub: 'LAP56', code: 'V2', speed: 46, load_N: 15000, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.35, weight: 50, w100: 2, stroke_max: 1500 },
      'LAP56-N2a': { fam: 'LAP', sub: 'LAP56', code: 'N2', speed: 30, load_N: 20000, motor: { kind: 'ac3', kw: 2.2, rpm: 2800 }, lock: 0.26, weight: 50, w100: 2, stroke_max: 1500 },
      'LAP56-V1': { fam: 'LAP', sub: 'LAP56', code: 'V1', speed: 23, load_N: 18000, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.24, weight: 50, w100: 2, stroke_max: 1500 },
      'LAP56-N2b': { fam: 'LAP', sub: 'LAP56', code: 'N2', speed: 15, load_N: 25000, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.26, weight: 50, w100: 2, stroke_max: 1500 },
      'LAP56-L2': { fam: 'LAP', sub: 'LAP56', code: 'L2', speed: 11, load_N: 25000, motor: { kind: 'ac3', kw: 0.75, rpm: 1400 }, lock: 0.23, weight: 40, w100: 2, stroke_max: 1500 },
      'LAP56-N1': { fam: 'LAP', sub: 'LAP56', code: 'N1', speed: 7.5, load_N: 25000, motor: { kind: 'ac3', kw: 0.75, rpm: 1400 }, lock: 0.18, weight: 40, w100: 2, stroke_max: 1500 },
      'LAP56-L1': { fam: 'LAP', sub: 'LAP56', code: 'L1', speed: 5.5, load_N: 25000, motor: { kind: 'ac3', kw: 0.75, rpm: 1400 }, lock: 0.15, weight: 40, w100: 2, stroke_max: 1500 },
      'LAP63-V2a': { fam: 'LAP', sub: 'LAP63', code: 'V2', speed: 89, load_N: 15000, motor: { kind: 'ac3', kw: 3.0, rpm: 2800 }, lock: 0.34, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-V2b': { fam: 'LAP', sub: 'LAP63', code: 'V2', speed: 44, load_N: 30000, motor: { kind: 'ac3', kw: 3.0, rpm: 1400 }, lock: 0.34, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-N2a': { fam: 'LAP', sub: 'LAP63', code: 'N2', speed: 30, load_N: 40000, motor: { kind: 'ac3', kw: 3.0, rpm: 2800 }, lock: 0.26, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-V1': { fam: 'LAP', sub: 'LAP63', code: 'V1', speed: 22, load_N: 42000, motor: { kind: 'ac3', kw: 3.0, rpm: 1400 }, lock: 0.21, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-N2b': { fam: 'LAP', sub: 'LAP63', code: 'N2', speed: 15, load_N: 50000, motor: { kind: 'ac3', kw: 2.2, rpm: 1400 }, lock: 0.26, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-L2': { fam: 'LAP', sub: 'LAP63', code: 'L2', speed: 11, load_N: 50000, motor: { kind: 'ac3', kw: 2.2, rpm: 1400 }, lock: 0.23, weight: 80, w100: 4, stroke_max: 1500 },
      'LAP63-N1': { fam: 'LAP', sub: 'LAP63', code: 'N1', speed: 7.5, load_N: 50000, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.18, weight: 70, w100: 4, stroke_max: 1500 },
      'LAP63-L1': { fam: 'LAP', sub: 'LAP63', code: 'L1', speed: 5.5, load_N: 50000, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.15, weight: 70, w100: 4, stroke_max: 1500 },
      'LAP80-V2a': { fam: 'LAP', sub: 'LAP80', code: 'V2', speed: 134, load_N: 14000, motor: { kind: 'ac3', kw: 4.0, rpm: 2800 }, lock: 0.35, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-XV2a': { fam: 'LAP', sub: 'LAP80', code: 'XV2', speed: 77, load_N: 20000, motor: { kind: 'ac3', kw: 4.0, rpm: 2800 }, lock: 0.32, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-V2b': { fam: 'LAP', sub: 'LAP80', code: 'V2', speed: 67, load_N: 28000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.35, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-N2a': { fam: 'LAP', sub: 'LAP80', code: 'N2', speed: 46, load_N: 35000, motor: { kind: 'ac3', kw: 4.0, rpm: 2800 }, lock: 0.24, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-XV2b': { fam: 'LAP', sub: 'LAP80', code: 'XV2', speed: 38, load_N: 40000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.32, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-V1': { fam: 'LAP', sub: 'LAP80', code: 'V1', speed: 33, load_N: 40000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.24, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-N2b': { fam: 'LAP', sub: 'LAP80', code: 'N2', speed: 23, load_N: 70000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.24, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-XV1': { fam: 'LAP', sub: 'LAP80', code: 'XV1', speed: 19, load_N: 65000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.20, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-L2': { fam: 'LAP', sub: 'LAP80', code: 'L2', speed: 17, load_N: 80000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.22, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-N1': { fam: 'LAP', sub: 'LAP80', code: 'N1', speed: 11, load_N: 80000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.16, weight: 150, w100: 6, stroke_max: 1000 },
      'LAP80-L1': { fam: 'LAP', sub: 'LAP80', code: 'L1', speed: 8.5, load_N: 80000, motor: { kind: 'ac3', kw: 3.0, rpm: 1400 }, lock: 0.15, weight: 140, w100: 6, stroke_max: 1000 },
      'LAP120-H2a': { fam: 'LAP', sub: 'LAP120', code: 'H2', speed: 77, load_N: 35000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.35, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-H2b': { fam: 'LAP', sub: 'LAP120', code: 'H2', speed: 52, load_N: 37000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.35, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-H1a': { fam: 'LAP', sub: 'LAP120', code: 'H1', speed: 45, load_N: 45000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.23, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-N2a': { fam: 'LAP', sub: 'LAP120', code: 'N2', speed: 38.5, load_N: 66000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.30, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-H1b': { fam: 'LAP', sub: 'LAP120', code: 'H1', speed: 30.5, load_N: 48000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.23, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-N2b': { fam: 'LAP', sub: 'LAP120', code: 'N2', speed: 26, load_N: 75000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.24, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-N1a': { fam: 'LAP', sub: 'LAP120', code: 'N1', speed: 22.5, load_N: 85000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.24, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-L2a': { fam: 'LAP', sub: 'LAP120', code: 'L2', speed: 19, load_N: 114000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.22, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-N1b': { fam: 'LAP', sub: 'LAP120', code: 'N1', speed: 15, load_N: 90000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.18, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-L2b': { fam: 'LAP', sub: 'LAP120', code: 'L2', speed: 13, load_N: 118000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.22, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-L1a': { fam: 'LAP', sub: 'LAP120', code: 'L1', speed: 11, load_N: 125000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.16, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP120-L1b': { fam: 'LAP', sub: 'LAP120', code: 'L1', speed: 7.5, load_N: 125000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.16, weight: 310, w100: 9.2, stroke_max: 1500 },
      'LAP200-H2a': { fam: 'LAP', sub: 'LAP200', code: 'H2', speed: 77, load_N: 48000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.34, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-H2b': { fam: 'LAP', sub: 'LAP200', code: 'H2', speed: 52, load_N: 48000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.34, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-H1a': { fam: 'LAP', sub: 'LAP200', code: 'H1', speed: 45, load_N: 60000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.23, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-N2a': { fam: 'LAP', sub: 'LAP200', code: 'N2', speed: 38, load_N: 90000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.26, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-H1b': { fam: 'LAP', sub: 'LAP200', code: 'H1', speed: 30, load_N: 60000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.23, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-N2b': { fam: 'LAP', sub: 'LAP200', code: 'N2', speed: 26, load_N: 90000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.26, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-N1a': { fam: 'LAP', sub: 'LAP200', code: 'N1', speed: 22, load_N: 112000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.16, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-L2a': { fam: 'LAP', sub: 'LAP200', code: 'L2', speed: 19, load_N: 160000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.22, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-N1b': { fam: 'LAP', sub: 'LAP200', code: 'N1', speed: 15, load_N: 112000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.16, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-L2b': { fam: 'LAP', sub: 'LAP200', code: 'L2', speed: 13, load_N: 160000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.22, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-L1a': { fam: 'LAP', sub: 'LAP200', code: 'L1', speed: 11, load_N: 200000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.14, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP200-L1b': { fam: 'LAP', sub: 'LAP200', code: 'L1', speed: 7.5, load_N: 200000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.14, weight: 450, w100: 13, stroke_max: 2000 },
      'LAP300-H2a': { fam: 'LAP', sub: 'LAP300', code: 'H2', speed: 70.6, load_N: 85000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.36, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-H2b': { fam: 'LAP', sub: 'LAP300', code: 'H2', speed: 47.9, load_N: 100000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.35, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-H1a': { fam: 'LAP', sub: 'LAP300', code: 'H1', speed: 40.3, load_N: 105000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.26, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-N2a': { fam: 'LAP', sub: 'LAP300', code: 'N2', speed: 35.3, load_N: 160000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.31, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-H1b': { fam: 'LAP', sub: 'LAP300', code: 'H1', speed: 27.3, load_N: 125000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.24, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-N2b': { fam: 'LAP', sub: 'LAP300', code: 'N2', speed: 23.9, load_N: 185000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.24, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-N1a': { fam: 'LAP', sub: 'LAP300', code: 'N1', speed: 20, load_N: 200000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.21, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-L2a': { fam: 'LAP', sub: 'LAP300', code: 'L2', speed: 17.6, load_N: 280000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.21, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-N1b': { fam: 'LAP', sub: 'LAP300', code: 'N1', speed: 13.6, load_N: 235000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.18, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-L2b': { fam: 'LAP', sub: 'LAP300', code: 'L2', speed: 11.9, load_N: 300000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.18, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-L1a': { fam: 'LAP', sub: 'LAP300', code: 'L1', speed: 10.1, load_N: 300000, motor: { kind: 'ac3', kw: 18.5, rpm: 1400 }, lock: 0.16, weight: 725, w100: 21, stroke_max: 2000 },
      'LAP300-L1b': { fam: 'LAP', sub: 'LAP300', code: 'L1', speed: 6.8, load_N: 300000, motor: { kind: 'ac3', kw: 15, rpm: 950 }, lock: 0.15, weight: 725, w100: 21, stroke_max: 2000 },

      /**/
      'LBP25-N1': { fam: 'LBP', sub: 'LBP25', code: 'N1', speed: 18.6, load_N: 2000, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.49, weight: 3.2, w100: 0.4, stroke_max: 500, ball: true },
      'LBP25-L1': { fam: 'LBP', sub: 'LBP25', code: 'L1', speed: 9.3, load_N: 2700, motor: { kind: 'ac3', kw: 0.09, rpm: 2800 }, lock: 0.37, weight: 3.2, w100: 0.4, stroke_max: 500, ball: true },
      'LBP32-H1a': { fam: 'LBP', sub: 'LBP32', code: 'H1', speed: 58, load_N: 1500, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.56, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP32-V1a': { fam: 'LBP', sub: 'LBP32', code: 'V1', speed: 37, load_N: 2200, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.56, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP32-H1b': { fam: 'LBP', sub: 'LBP32', code: 'H1', speed: 29, load_N: 2400, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.56, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP32-N1a': { fam: 'LBP', sub: 'LBP32', code: 'N1', speed: 18.5, load_N: 3500, motor: { kind: 'ac3', kw: 0.18, rpm: 2800 }, lock: 0.48, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP32-N1b': { fam: 'LBP', sub: 'LBP32', code: 'N1', speed: 9.3, load_N: 4400, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.48, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP32-L1': { fam: 'LBP', sub: 'LBP32', code: 'L1', speed: 4.6, load_N: 4500, motor: { kind: 'ac3', kw: 0.12, rpm: 1400 }, lock: 0.37, weight: 5.8, w100: 0.5, stroke_max: 1500, ball: true },
      'LBP35-V1a': { fam: 'LBP', sub: 'LBP35', code: 'V1', speed: 58, load_N: 2600, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.56, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP35-V1b': { fam: 'LBP', sub: 'LBP35', code: 'V1', speed: 29, load_N: 3400, motor: { kind: 'ac3', kw: 0.18, rpm: 1400 }, lock: 0.56, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP35-N1a': { fam: 'LBP', sub: 'LBP35', code: 'N1', speed: 14.5, load_N: 4500, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.43, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP35-L1a': { fam: 'LBP', sub: 'LBP35', code: 'L1', speed: 9.7, load_N: 5400, motor: { kind: 'ac3', kw: 0.25, rpm: 2800 }, lock: 0.34, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP35-N1b': { fam: 'LBP', sub: 'LBP35', code: 'N1', speed: 7.2, load_N: 5400, motor: { kind: 'ac3', kw: 0.18, rpm: 1400 }, lock: 0.43, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP35-L1b': { fam: 'LBP', sub: 'LBP35', code: 'L1', speed: 4.8, load_N: 5500, motor: { kind: 'ac3', kw: 0.18, rpm: 1400 }, lock: 0.34, weight: 7.4, w100: 0.8, stroke_max: 1500, ball: true },
      'LBP40-V1a': { fam: 'LBP', sub: 'LBP40', code: 'V1', speed: 46.6, load_N: 4800, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.56, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP40-V1b': { fam: 'LBP', sub: 'LBP40', code: 'V1', speed: 23.3, load_N: 5800, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.56, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP40-N1a': { fam: 'LBP', sub: 'LBP40', code: 'N1', speed: 11.6, load_N: 7200, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.38, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP40-L1a': { fam: 'LBP', sub: 'LBP40', code: 'L1', speed: 9.3, load_N: 7600, motor: { kind: 'ac3', kw: 0.55, rpm: 2800 }, lock: 0.36, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP40-N1b': { fam: 'LBP', sub: 'LBP40', code: 'N1', speed: 5.8, load_N: 8000, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.38, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP40-L1b': { fam: 'LBP', sub: 'LBP40', code: 'L1', speed: 4.6, load_N: 8000, motor: { kind: 'ac3', kw: 0.37, rpm: 1400 }, lock: 0.36, weight: 13, w100: 0.9, stroke_max: 1500, ball: true },
      'LBP56-V1a': { fam: 'LBP', sub: 'LBP56', code: 'V1', speed: 78, load_N: 12500, motor: { kind: 'ac3', kw: 1.5, rpm: 2800 }, lock: 0.56, weight: 50, w100: 2, stroke_max: 1500, ball: true },
      'LBP56-V1b': { fam: 'LBP', sub: 'LBP56', code: 'V1', speed: 39, load_N: 15500, motor: { kind: 'ac3', kw: 1.5, rpm: 1400 }, lock: 0.56, weight: 50, w100: 2, stroke_max: 1500, ball: true },
      'LBP56-N1a': { fam: 'LBP', sub: 'LBP56', code: 'N1', speed: 26, load_N: 18000, motor: { kind: 'ac3', kw: 1.5, rpm: 2800 }, lock: 0.43, weight: 50, w100: 2, stroke_max: 1500, ball: true },
      'LBP56-L1a': { fam: 'LBP', sub: 'LBP56', code: 'L1', speed: 18.5, load_N: 20000, motor: { kind: 'ac3', kw: 1.1, rpm: 2800 }, lock: 0.37, weight: 40, w100: 2, stroke_max: 1500, ball: true },
      'LBP56-N1b': { fam: 'LBP', sub: 'LBP56', code: 'N1', speed: 13, load_N: 22000, motor: { kind: 'ac3', kw: 0.75, rpm: 1400 }, lock: 0.43, weight: 40, w100: 2, stroke_max: 1500, ball: true },
      'LBP56-L1b': { fam: 'LBP', sub: 'LBP56', code: 'L1', speed: 9.3, load_N: 25000, motor: { kind: 'ac3', kw: 0.75, rpm: 1400 }, lock: 0.37, weight: 40, w100: 2, stroke_max: 1500, ball: true },
      'LBP120-H2a': { fam: 'LBP', sub: 'LBP120', code: 'H2', speed: 64, load_N: 52000, motor: { kind: 'ac3', kw: 5.5, rpm: 1400 }, lock: 0.53, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-H1a': { fam: 'LBP', sub: 'LBP120', code: 'H1', speed: 51.5, load_N: 62000, motor: { kind: 'ac3', kw: 5.5, rpm: 1400 }, lock: 0.53, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-H2b': { fam: 'LBP', sub: 'LBP120', code: 'H2', speed: 43.5, load_N: 54000, motor: { kind: 'ac3', kw: 4.0, rpm: 950 }, lock: 0.51, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-H1b': { fam: 'LBP', sub: 'LBP120', code: 'H1', speed: 35, load_N: 66000, motor: { kind: 'ac3', kw: 4.0, rpm: 950 }, lock: 0.48, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-N2a': { fam: 'LBP', sub: 'LBP120', code: 'N2', speed: 32, load_N: 70000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.45, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-N1a': { fam: 'LBP', sub: 'LBP120', code: 'N1', speed: 25.5, load_N: 86000, motor: { kind: 'ac3', kw: 4.0, rpm: 1400 }, lock: 0.45, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-N2b': { fam: 'LBP', sub: 'LBP120', code: 'N2', speed: 21.5, load_N: 74000, motor: { kind: 'ac3', kw: 3.0, rpm: 950 }, lock: 0.44, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-N1b': { fam: 'LBP', sub: 'LBP120', code: 'N1', speed: 17, load_N: 88000, motor: { kind: 'ac3', kw: 3.0, rpm: 950 }, lock: 0.44, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-L2a': { fam: 'LBP', sub: 'LBP120', code: 'L2', speed: 16, load_N: 88000, motor: { kind: 'ac3', kw: 3.0, rpm: 1400 }, lock: 0.42, weight: 275, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-L1a': { fam: 'LBP', sub: 'LBP120', code: 'L1', speed: 12.5, load_N: 90000, motor: { kind: 'ac3', kw: 3.0, rpm: 1400 }, lock: 0.42, weight: 275, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-L2b': { fam: 'LBP', sub: 'LBP120', code: 'L2', speed: 10.5, load_N: 90000, motor: { kind: 'ac3', kw: 2.2, rpm: 950 }, lock: 0.42, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP120-L1b': { fam: 'LBP', sub: 'LBP120', code: 'L1', speed: 8.5, load_N: 90000, motor: { kind: 'ac3', kw: 2.2, rpm: 950 }, lock: 0.42, weight: 295, w100: 9.2, stroke_max: 1500, ball: true },
      'LBP200-H2a': { fam: 'LBP', sub: 'LBP200', code: 'H2', speed: 80, load_N: 85000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.55, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-H1a': { fam: 'LBP', sub: 'LBP200', code: 'H1', speed: 64, load_N: 103000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.55, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-H2b': { fam: 'LBP', sub: 'LBP200', code: 'H2', speed: 54, load_N: 103000, motor: { kind: 'ac3', kw: 9.2, rpm: 950 }, lock: 0.55, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-H1b': { fam: 'LBP', sub: 'LBP200', code: 'H1', speed: 43, load_N: 125000, motor: { kind: 'ac3', kw: 9.2, rpm: 950 }, lock: 0.55, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-N2a': { fam: 'LBP', sub: 'LBP200', code: 'N2', speed: 40, load_N: 132000, motor: { kind: 'ac3', kw: 9.2, rpm: 1400 }, lock: 0.46, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-N1a': { fam: 'LBP', sub: 'LBP200', code: 'N1', speed: 32, load_N: 165000, motor: { kind: 'ac3', kw: 9.2, rpm: 1400 }, lock: 0.46, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-N2b': { fam: 'LBP', sub: 'LBP200', code: 'N2', speed: 27, load_N: 155000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.46, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-N1b': { fam: 'LBP', sub: 'LBP200', code: 'N1', speed: 21.5, load_N: 185000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.46, weight: 470, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-L2a': { fam: 'LBP', sub: 'LBP200', code: 'L2', speed: 20, load_N: 185000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.42, weight: 450, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-L1a': { fam: 'LBP', sub: 'LBP200', code: 'L1', speed: 16, load_N: 185000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.42, weight: 450, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-L2b': { fam: 'LBP', sub: 'LBP200', code: 'L2', speed: 13.5, load_N: 185000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.42, weight: 450, w100: 13, stroke_max: 2000, ball: true },
      'LBP200-L1b': { fam: 'LBP', sub: 'LBP200', code: 'L1', speed: 10.5, load_N: 185000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.42, weight: 450, w100: 13, stroke_max: 2000, ball: true },
      'LBP300-H2a': { fam: 'LBP', sub: 'LBP300', code: 'H2', speed: 80, load_N: 115000, motor: { kind: 'ac3', kw: 15, rpm: 1400 }, lock: 0.56, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-H1a': { fam: 'LBP', sub: 'LBP300', code: 'H1', speed: 63, load_N: 105000, motor: { kind: 'ac3', kw: 11, rpm: 1400 }, lock: 0.56, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-H2b': { fam: 'LBP', sub: 'LBP300', code: 'H2', speed: 54.6, load_N: 120000, motor: { kind: 'ac3', kw: 11, rpm: 950 }, lock: 0.55, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-H1b': { fam: 'LBP', sub: 'LBP300', code: 'H1', speed: 42.5, load_N: 150000, motor: { kind: 'ac3', kw: 11, rpm: 950 }, lock: 0.55, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-N2a': { fam: 'LBP', sub: 'LBP300', code: 'N2', speed: 40, load_N: 130000, motor: { kind: 'ac3', kw: 9.2, rpm: 1400 }, lock: 0.46, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-N1a': { fam: 'LBP', sub: 'LBP300', code: 'N1', speed: 31.5, load_N: 160000, motor: { kind: 'ac3', kw: 9.2, rpm: 1400 }, lock: 0.46, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-N2b': { fam: 'LBP', sub: 'LBP300', code: 'N2', speed: 27.3, load_N: 185000, motor: { kind: 'ac3', kw: 9.2, rpm: 950 }, lock: 0.44, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-N1b': { fam: 'LBP', sub: 'LBP300', code: 'N1', speed: 21, load_N: 230000, motor: { kind: 'ac3', kw: 9.2, rpm: 950 }, lock: 0.44, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-L2a': { fam: 'LBP', sub: 'LBP300', code: 'L2', speed: 20, load_N: 230000, motor: { kind: 'ac3', kw: 9.2, rpm: 1400 }, lock: 0.41, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-L1a': { fam: 'LBP', sub: 'LBP300', code: 'L1', speed: 15.5, load_N: 235000, motor: { kind: 'ac3', kw: 7.5, rpm: 1400 }, lock: 0.41, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-L2b': { fam: 'LBP', sub: 'LBP300', code: 'L2', speed: 13.6, load_N: 235000, motor: { kind: 'ac3', kw: 7.5, rpm: 950 }, lock: 0.41, weight: 715, w100: 16, stroke_max: 2000, ball: true },
      'LBP300-L1b': { fam: 'LBP', sub: 'LBP300', code: 'L1', speed: 10.5, load_N: 235000, motor: { kind: 'ac3', kw: 5.5, rpm: 950 }, lock: 0.41, weight: 715, w100: 16, stroke_max: 2000, ball: true }
    },
    /**/
    ball_life: {
      'LBP25': { C_kN: 4.25, lead_mm: 4 },
      'LBP32': { C_kN: 7.8, lead_mm: 5 },
      'LBP35': { C_kN: 11.3, lead_mm: 5 },
      'LBP40': { C_kN: 18.0, lead_mm: 5 },
      'LBP56': { C_kN: 25.7, lead_mm: 10 },
      'LBP120': { C_kN: 90, lead_mm: 16 },
      'LBP200': { C_kN: 185, lead_mm: 25 },
      'LBP300': { C_kN: 235, lead_mm: 25 }
    },
    /*


*/
    stability: {
      'LAP25': [[1000, 915], [1100, 730], [4100, 365]],
      'LBP25': [[1000, 915], [1100, 730], [4100, 365]],
      'LAP28': [[1400, 730], [6100, 315]],
      'LBP28': [[1450, 730], [6100, 365]],
      'LBP32': [[2550, 730], [7800, 455]],
      'LAP32': [[2100, 730], [9400, 350]],
      'LBP35': [[3350, 730], [9400, 550]],
      'LAP35': [[3600, 730], [12100, 435]],
      'LBP40': [[4850, 915], [7100, 730], [12100, 640]],
      'LAP40': [[6200, 915], [7550, 730], [15100, 500]],
      'LAP56': [[7000, 1500], [25000, 900]],
      'LBP56': [[7000, 1500], [25000, 900]],
      'LAP63': [[25000, 1500], [50000, 950]],
      'LBP63': [[25000, 1500], [50000, 950]],
      'LAP80': [[49000, 1500], [80000, 1050]],
      'LBP80': [[49000, 1500], [80000, 1050]],
      'LAP120': [[33000, 2400], [124000, 1300]],
      'LBP120': [[33000, 2400], [124000, 1300]],
      'LAP200': [[54000, 2800], [200000, 1600]],
      'LBP200': [[54000, 2800], [200000, 1600]],
      'LAP300': [[148000, 2800], [300000, 2000]],
      'LBP300': [[148000, 2800], [300000, 2000]]
    },
    /**/
    lam_sub_list: ['LAM1', 'LAM3', 'LAM32', 'LAM33', 'LAM50', 'LAM51', 'LAM52', 'LAM53', 'LAM54', 'LAM55', 'LAM8', 'LBM9']
  };
  SJ_ROD_DATA._meta.model_count = Object.keys(SJ_ROD_DATA.models).length;
  if (typeof window !== 'undefined') { window.SJ_ROD_DATA = SJ_ROD_DATA; }
  g.SJ_ROD_DATA = SJ_ROD_DATA;
})(typeof window !== 'undefined' ? window : globalThis);
