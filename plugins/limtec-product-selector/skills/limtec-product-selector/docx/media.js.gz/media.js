/* 力姆泰克《选型方案书》插图包（瘦身版，2026-11-13）
   原版把 38 张布置图以 base64 内嵌（3.4MB），与 assets/*.png 内容完全相同。
   市场单包上限 3MB，故改为「运行时按需读图」：
     SJ_MEDIA_REF[name]  → 内容 hash
     SJ_MEDIA_BIN[hash]  → 对应 assets 图片的 base64（Node 侧同步读取并缓存）
   docx-builder 的取图接口保持不变（refs[name] → bins[hash] → base64）。
   注意：本文件的图片源为 assets（扁平目录，市场要求两级结构），改图后重跑 tools/build_limtec_skill.py。 */
(function (g) {
'use strict';
var REF = {"logo-limtec-white.png":"400596a40690dd73","三台机械同步螺旋升降机一字型.png":"4144bc09d5d09cf6","三台机械同步螺旋升降机垂直布置-电机中间.png":"c65e664304c582f6","三台机械同步螺母运动-垂直布置-电机中间.png":"b90637689eb6e51d","三台机械同步螺母运动-直线布置-电机单侧.png":"1f8f3f52dbbb4e61","三台机械同步螺母运动.png":"f8efa9c9e1c0c1f2","两台EHB螺旋升降机单侧输入.png":"8a17d4783070eaac","两台EHB螺旋升降机螺母运动-电机中间.png":"996c7dd21952fe81","两台EHB螺旋升降机螺母运动-电机单侧.png":"3b9a6ef127bf1d1e","两台机械同步螺旋升降机中间输入.png":"2ac78b885cbcd62f","两台机械同步螺旋升降机单侧输入.png":"5af62e258e4ef8e0","两台机械同步螺母运动-电机中间.png":"be8de40a9b2d673d","两台机械同步螺母运动-电机单侧.png":"6790b637c965b468","两台机械同步螺母运动.png":"b043850d486df952","八台机械同步螺旋升降机H型2.png":"776835df53c0e0d8","八台机械同步螺旋升降机H型布置-螺母运动.png":"7fb411a3609d00bc","八台机械同步螺旋升降机H型布置.png":"d5084e92744c826f","八台机械同步螺旋升降机一字布置.png":"1f3d130a1b679c74","八台机械同步螺母运动-直线布置.png":"f3f8fd99a1e7f442","六台机械同步螺旋升降机H型布置-螺母运动.png":"54092b675d46b393","六台机械同步螺旋升降机H型布置.png":"29da3982f682d156","六台机械同步螺旋升降机一字布置.png":"e06bd21b5364eb8d","六台机械同步螺母运动-直线布置.png":"803b378b72824378","单台螺旋升降机螺母运动匹配交流电机.png":"493addf4e8a9f6ed","单台螺旋升降机螺母运动匹配伺服电机.png":"0696dba6a62a2e3d","四台EHB螺旋升降机丝杠运动-U2型布置.png":"e19f6c39d5276224","四台EHB螺旋升降机螺母运动-H型布置.png":"2035c0d69c4fe943","四台EHB螺旋升降机螺母运动-U2型布置.png":"341e9d136b5058bb","四台EHB螺旋升降机螺母运动-U型布置.png":"081eaeb1c311cf7f","四台同步螺旋升降机U型布置-丝杠运动.png":"d2f4fde0d89417ce","四台同步螺旋升降机U型布置-螺母运动.png":"f1d37c01d5fd069a","四台推杆直线布置.png":"38b7f7207531ec8e","四台机械同步螺旋升降机H型布置-螺母运动.png":"ea126594e9d76f49","四台机械同步螺旋升降机H型布置.png":"da99b878622997c5","四台机械同步螺旋升降机H型布置2.png":"da99b878622997c5","四台机械同步螺旋升降机U型布置-螺母运动.png":"dc8d998cfb54180f","四台机械同步螺旋升降机一字布置.png":"eb1df37d65162e5f","四台机械同步螺母运动-直线布置.png":"5ef49182c578ffdf","稳定性曲线图-2026样本.png":"4f37c9ee997fc205"};
g.SJ_MEDIA_REF = REF;

var hasNode = (typeof require === 'function' && typeof __dirname === 'string');
if (!hasNode) {
  g.SJ_MEDIA_BIN = {};
  return;
}
var fs = require('fs');
var path = require('path');
var DIR = path.join(__dirname, '..', 'assets');
var byHash = {};
for (var name in REF) {
  if (Object.prototype.hasOwnProperty.call(REF, name)) byHash[REF[name]] = name;
}
var cache = {};
g.SJ_MEDIA_BIN = new Proxy({}, {
  get: function (t, key) {
    if (typeof key !== 'string') return undefined;
    if (Object.prototype.hasOwnProperty.call(cache, key)) return cache[key];
    var fname = byHash[key];
    if (!fname) return undefined;
    try {
      cache[key] = fs.readFileSync(path.join(DIR, fname)).toString('base64');
      return cache[key];
    } catch (e) {
      return undefined;
    }
  },
  has: function (t, key) {
    return typeof key === 'string' && Object.prototype.hasOwnProperty.call(byHash, key);
  }
});
})(typeof window !== 'undefined' ? window : globalThis);
