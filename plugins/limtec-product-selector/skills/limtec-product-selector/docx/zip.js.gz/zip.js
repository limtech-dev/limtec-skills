/*


*/
(function (g) {
  'use strict';

  var CRC = (function () {
    var t = new Int32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c;
    }
    return t;
  })();

  function crc32(u8) {
    var c = -1;
    for (var i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ -1) >>> 0;
  }

  function utf8(str) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
    var out = [];
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xC0 | (c >> 6), 0x80 | (c & 63));
      else out.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    return new Uint8Array(out);
  }

  function b64ToBytes(b64) {
    if (typeof atob === 'function') {
      var s = atob(b64), out = new Uint8Array(s.length);
      for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
      return out;
    }
    var buf = Buffer.from(b64, 'base64');
    return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
  }

  function bytesToB64(u8) {
    if (typeof btoa === 'function') {
      var s = '';
      for (var i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
      return btoa(s);
    }
    return Buffer.from(u8).toString('base64');
  }

  /**/
  function dosTime(d) {
    return {
      t: ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF,
      d: (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF
    };
  }

  function w16(a, v) { a.push(v & 0xFF, (v >>> 8) & 0xFF); }
  function w32(a, v) { a.push(v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF); }

  /*



*/
  function store(entries, date) {
    var now = date || new Date(), ts = dosTime(now);
    var chunks = [], offset = 0, central = [];
    entries.forEach(function (e) {
      var name = utf8(e.name);
      var data = (typeof e.data === 'string') ? utf8(e.data) : e.data;
      var crc = crc32(data);
      var lh = [];
      w32(lh, 0x04034B50);          //
      w16(lh, 20);                  //
      w16(lh, 0x0800);              //
      w16(lh, 0);                   //
      w16(lh, ts.t); w16(lh, ts.d);
      w32(lh, crc); w32(lh, data.length); w32(lh, data.length);
      w16(lh, name.length); w16(lh, 0);
      chunks.push(new Uint8Array(lh), name, data);

      var ch = [];
      w32(ch, 0x02014B50);          //
      w16(ch, 20); w16(ch, 20);
      w16(ch, 0x0800); w16(ch, 0);
      w16(ch, ts.t); w16(ch, ts.d);
      w32(ch, crc); w32(ch, data.length); w32(ch, data.length);
      w16(ch, name.length); w16(ch, 0); w16(ch, 0);
      w16(ch, 0); w16(ch, 0); w32(ch, 0);
      w32(ch, offset);
      central.push(new Uint8Array(ch), name);

      offset += lh.length + name.length + data.length;
    });

    var cdSize = central.reduce(function (s, x) { return s + x.length; }, 0);
    var eo = [];
    w32(eo, 0x06054B50);
    w16(eo, 0); w16(eo, 0);
    w16(eo, entries.length); w16(eo, entries.length);
    w32(eo, cdSize); w32(eo, offset);
    w16(eo, 0);

    var total = offset + cdSize + eo.length;
    var out = new Uint8Array(total), p = 0, all = chunks.concat(central, [new Uint8Array(eo)]);
    all.forEach(function (c) { out.set(c, p); p += c.length; });
    return out;
  }

  g.SJZip = { crc32: crc32, utf8: utf8, store: store, b64ToBytes: b64ToBytes, bytesToB64: bytesToB64 };
})(typeof window !== 'undefined' ? window : globalThis);
