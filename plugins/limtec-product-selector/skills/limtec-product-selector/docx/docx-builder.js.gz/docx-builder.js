/*










*/
(function (g) {
  'use strict';

  var R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  var A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main';
  var WP_NS = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing';
  var PIC_NS = 'http://schemas.openxmlformats.org/drawingml/2006/picture';
  var W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';

  /**/
  var HEADING_RE_CN = /^\s*[0-9]+\s*[，、]/;
  var HEADING_RE_DOT = /^\s*[0-9]+\s*\./;
  var HEADING_MAX_LEN = 30, DOT_HEADING_MAX_LEN = 12;
  var HEADING_KEYS = ['客户应用要求', '客户参数要求', '选择普通丝杠升降机计算步骤', '选择伞齿轮升降机计算步骤',
    '电机选型', '配置清单', '商务条款', '力姆泰克公司介绍', '与国内同行业的特点',
    '升降机同步方案', '升降机方案', '方案书'];
  var ZONE_STARTS = ['客户应用要求', '客户参数要求'];
  var LIST_PREFIXES = ['CLIENT', 'PARAM', 'STEP', 'MOTOR', 'CALC', 'SPEC', 'COMM', 'ASSUME', 'NOTE', 'ABOUT'];
  var DRAW = '@@DRAWING@@';
  var DRAW_T = '<w:t xml:space="preserve">' + DRAW + '</w:t>';

  function isHeading(txt) {
    return (HEADING_RE_CN.test(txt) && txt.length <= HEADING_MAX_LEN)
      || (HEADING_RE_DOT.test(txt) && txt.length <= DOT_HEADING_MAX_LEN)
      || HEADING_KEYS.some(function (k) { return txt.indexOf(k) >= 0; });
  }
  /*
*/
  function hideRows(xml) {
    if (xml.indexOf('[[HIDE]]') < 0) return xml;
    return xml.replace(/<w:tr(?:\s[^>]*)?>[\s\S]*?<\/w:tr>/g, function (tr) {
      return tr.indexOf('[[HIDE]]') >= 0 ? '' : tr;
    });
  }
  /*

*/
  function escText(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\r\n?/g, '\n')
      .replace(/\n/g, '</w:t></w:r></w:p>'
        + '<w:p><w:pPr><w:spacing w:before="30" w:after="30" w:line="240" w:lineRule="auto" /></w:pPr>'
        + '<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="微软雅黑" w:cs="Arial" />'
        + '<w:sz w:val="14" /><w:szCs w:val="14" /></w:rPr><w:t xml:space="preserve">');
  }
  function drawingXml(rid, cx, cy, docPr) {
    return '<w:drawing xmlns:w="' + W + '" xmlns:r="' + R_NS + '" xmlns:a="' + A_NS
      + '" xmlns:wp="' + WP_NS + '" xmlns:pic="' + PIC_NS + '">'
      + '<wp:inline distT="0" distB="0" distL="0" distR="0">'
      + '<wp:extent cx="' + cx + '" cy="' + cy + '"/>'
      + '<wp:docPr id="' + docPr + '" name="layout' + docPr + '"/>'
      + '<a:graphic><a:graphicData uri="' + PIC_NS + '">'
      + '<pic:pic><pic:nvPicPr><pic:cNvPr id="' + docPr + '" name="layout' + docPr + '"/>'
      + '<pic:cNvPicPr/></pic:nvPicPr>'
      + '<pic:blipFill><a:blip r:embed="' + rid + '"/>'
      + '<a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
      + '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm>'
      + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
      + '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>';
  }

  /**/
  var imageBase = './assets/';
  function imageBytes(name) {
    return new Promise(function (resolve, reject) {
      var refs = g.SJ_MEDIA_REF, bins = g.SJ_MEDIA_BIN;
      if (refs && bins && refs[name] && bins[refs[name]]) {
        resolve(g.SJZip.b64ToBytes(bins[refs[name]]));
        return;
      }
      if (typeof fetch !== 'function') { reject(new Error('插图 ' + name + ' 未内嵌，且当前环境不支持加载')); return; }
      fetch(imageBase + encodeURIComponent(name)).then(function (r) {
        if (!r.ok) throw new Error('插图加载失败（HTTP ' + r.status + '）：' + name);
        return r.arrayBuffer();
      }).then(function (b) { resolve(new Uint8Array(b)); }).catch(reject);
    });
  }

  /**/
  function applyTokens(xml, toks, scalars) {
    (toks || []).forEach(function (t) {
      xml = xml.split('{{' + t + '}}').join(escText(scalars[t] || ''));
    });
    return xml;
  }

  function buildArchive(plan, items, scalars) {
    var a = plan.archive, out = a.pre;
    a.headRows.forEach(function (r) { out += r; });
    var no = 0;
    (items || []).forEach(function (it) {
      var desc = String(it && it.desc != null ? it.desc : '');
      var qty = String(it && it.qty != null ? it.qty : '');
      if (!desc.trim() && !qty.trim()) return;      //
      no += 1;
      var rowXml = a.proto.split('{{ITEM_NO}}').join(String(no))
        .split('{{ITEM_DESC}}').join(escText(desc))
        .split('{{ITEM_SPEC}}').join(escText(String(it && it.spec != null ? it.spec : '')))
        .split('{{ITEM_QTY}}').join(escText(qty))
        /**/
        .split('{{ITEM_UP}}').join(escText(String(it && it.unit_price != null ? it.unit_price : '暂无价格')))
        .split('{{ITEM_TP}}').join(escText(String(it && it.total_price != null ? it.total_price : '暂无价格')));
      /**/
      if (it && it.red) rowXml = rowXml.split('</w:rPr>').join('<w:color w:val="C00000"/></w:rPr>');
      out += rowXml;
    });
    a.postRows.forEach(function (r) { out += r; });
    /*
*/
    var sc2 = scalars;
    if (!sc2.ITEM_PRICE_TOTAL) {
      sc2 = {};
      Object.keys(scalars).forEach(function (k) { sc2[k] = scalars[k]; });
      sc2.ITEM_PRICE_TOTAL = '暂无价格';
    }
    return applyTokens(out + a.post, a.toks, sc2)
      .split('{{ITEM_PRICE_TOTAL}}').join(escText(sc2.ITEM_PRICE_TOTAL));
  }

  /*




*/
  function i18nOn() {
    var I = g.LANG_I18N;
    return !!(I && typeof I.tr === 'function' && I.lang && I.lang !== 'zh');
  }
  function escXmlText(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  /*
*/
  var FOOTER_WORDS = {
    '第': ['Page ', 'Seite ', 'Стр. ', 'Pág. '],
    '页，共': [' of ', ' von ', ' из ', ' de '],
    '页': ['', '', '', '']
  };
  function i18nFooterWords(xml) {
    if (!i18nOn()) return xml;
    var idx = { en: 0, de: 1, ru: 2, es: 3 }[g.LANG_I18N.lang];
    if (idx === undefined) return xml;
    return String(xml).replace(/(<w:t(?:\s[^>]*[^/>])?>)([^<]*)(<\/w:t>)/g, function (m, open, body, close) {
      var k = body.trim();
      if (!FOOTER_WORDS[k]) return m;
      return open + FOOTER_WORDS[k][idx] + close;
    });
  }
  function i18nXml(xml) {
    if (!i18nOn()) return xml;
    var tr = g.LANG_I18N.tr;
    /*
*/
    return String(xml).replace(/(<w:t(?:\s[^>]*[^/>])?>)([\s\S]*?)(<\/w:t>)/g, function (m, open, body, close) {
      if (!/[\u4e00-\u9fff]/.test(body)) return m;
      var plain = body.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
      var out;
      try { out = tr(plain); } catch (e) { return m; }
      if (!out || out === plain) return m;
      return open + escXmlText(String(out).replace(/[\r\n]+/g, ' ')) + close;
    });
  }

  /**/
  function build(spec) {
    return new Promise(function (resolve, reject) {
      try { resolve(buildInner(spec)); } catch (e) { reject(e); }
    });
  }

  function buildInner(spec) {
    spec = spec || {};
    /**/
    var tag = (spec.template === 'C') ? 'C' : (spec.template === 'CY' ? 'CY' : 'A');
    var plan = (g.SJ_TPL || {})[tag];
    if (!plan) throw new Error('方案书模板未加载（缺 docx/templates.js）');
    if (!g.SJ_PKG) throw new Error('方案书模板内容未加载（缺 docx/templates.js）');

    var fields = spec.fields || {};
    var docItems = fields.ITEMS || spec.items || [];
    var scalars = {};
    Object.keys(fields).forEach(function (k) { if (typeof fields[k] === 'string') scalars[k] = fields[k]; });

    /*


*/
    var featKeep = parseInt(fields.FEAT_KEEP, 10);
    var planItems = plan.items;
    if (featKeep === 0) {
      planItems = planItems.filter(function (e) {
        if (e.k === 'text' && String(e.t || '').indexOf('07') === 0 && String(e.t || '').indexOf('产品特点') >= 0) return false;
        if (e.k === 'table' && typeof e.x === 'string' && e.x.indexOf('{{FEAT_') >= 0) return false;
        return true;
      });
    } else if (featKeep > 0 && featKeep < 5) {
      planItems = plan.items.map(function (e) {
        if (e.k !== 'table' || typeof e.x !== 'string' || e.x.indexOf('{{FEAT_') < 0) return e;
        var trs = e.x.match(/<w:tr[ >][\s\S]*?<\/w:tr>/g) || [];
        if (trs.length <= featKeep) return e;
        var nx = e.x;
        for (var ti = featKeep; ti < trs.length; ti++) nx = nx.split(trs[ti]).join('');
        var c = {};
        Object.keys(e).forEach(function (k2) { c[k2] = e[k2]; });
        c.x = nx;
        return c;
      });
    }

    /**/
    var arr = [];
    planItems.forEach(function (e) {
      if (e.k === 'tok') {
        /*

*/
        if (e.tok === 'QUOTE_NOTE' && !String(scalars.QUOTE_NOTE == null ? '' : scalars.QUOTE_NOTE).trim()) return;
        arr.push({ kind: 'p', tok: e.tok, x: e.x || null, r: e.r || null, b: e.b || null, h: e.h || null,
          text: (e.tok in scalars) ? scalars[e.tok] : '', draw: false, zoneStart: false });
      } else if (e.k === 'text') {
        arr.push({ kind: 'p', x: e.x, text: e.t, draw: false, zoneStart: !!e.zoneStart });
      } else if (e.k === 'blank') {
        arr.push({ kind: 'p', x: e.x, text: '', draw: false, zoneStart: false });
      } else if (e.k === 'layout') {
        arr.push({ kind: 'layout' });
      } else if (e.k === 'archive') {
        arr.push({ kind: 'table', x: buildArchive(plan, docItems, scalars) });
      } else if (e.k === 'table') {
        arr.push({ kind: 'table', x: applyTokens(e.x, e.toks, scalars) });
      } else {
        arr.push({ kind: 'raw', x: e.x });
      }
    });

    /**/
    var mediaAdd = [], relsAdd = [], extsNeeded = {};

    /**/
    function imgSize(bytes) {
      if (bytes[0] === 0x89 && bytes[1] === 0x50) {          //
        return { w: ((bytes[16] << 24 | bytes[17] << 16 | bytes[18] << 8 | bytes[19]) >>> 0),
                 h: ((bytes[20] << 24 | bytes[21] << 16 | bytes[22] << 8 | bytes[23]) >>> 0) };
      }
      if (bytes[0] === 0xFF && bytes[1] === 0xD8) {          //
        var p = 2;
        while (p + 9 < bytes.length) {
          if (bytes[p] !== 0xFF) { p++; continue; }
          var m = bytes[p + 1];
          if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) {
            return { h: (bytes[p + 5] << 8) | bytes[p + 6], w: (bytes[p + 7] << 8) | bytes[p + 8] };
          }
          p += 2 + ((bytes[p + 2] << 8) | bytes[p + 3]);
        }
      }
      return null;
    }

    var li = -1;
    for (var i0 = 0; i0 < arr.length; i0++) if (arr[i0].kind === 'layout') { li = i0; break; }
    /*
*/
    /**/
    var MAX_CX_IMG = 4700000, MAX_CY_IMG = 2400000;
    /*
*/
    var CY_MAX_CX_IMG = Math.round(MAX_CX_IMG * 0.7), CY_MAX_CY_IMG = Math.round(MAX_CY_IMG * 0.7);
    function clampDims(cx, cy) {
      /**/
      var mX = (tag === 'CY') ? CY_MAX_CX_IMG : MAX_CX_IMG;
      var mY = (tag === 'CY') ? CY_MAX_CY_IMG : MAX_CY_IMG;
      if (cx > mX) { cy = Math.round(mX * cy / cx); cx = mX; }
      if (cy > mY) { cx = Math.round(mY * cx / cy); cy = mY; }
      return [cx, cy];
    }
    if (li >= 0) {
      var lname = fields.LAYOUT_IMAGE;
      /**/
      var customM = /^data:(image\/(png|jpeg))\s*;\s*base64,([\s\S]+)$/i.exec(String(lname || ''));
      var meta = (!customM && lname) ? plan.images[lname] : null;
      if (customM) {
        var cbytes = g.SJZip.b64ToBytes(customM[3].replace(/\s+/g, ''));
        var dim = imgSize(cbytes);
        if (!dim || !dim.w || !dim.h) throw new Error('客户图例尺寸读取失败（仅支持 PNG / JPG）');
        var px = 9525;                                       // 96 dpi → EMU
        var cd = clampDims(Math.round(dim.w * px), Math.round(dim.h * px));
        var ext = (customM[2].toLowerCase() === 'png') ? 'png' : 'jpeg';
        var slot = plan.layoutSlot;
        arr[li] = { kind: 'p', x: plan.layoutPara.split(DRAW_T).join(
          drawingXml(slot.rid, cd[0], cd[1], slot.docPr)),
          text: '', draw: true, zoneStart: false };
        mediaAdd.push({ name: slot.part.replace(/\.[a-z0-9]+$/i, '.' + ext), bytes: cbytes });
        relsAdd.push({ rid: slot.rid, target: slot.target.replace(/\.[a-z0-9]+$/i, '.' + ext) });
        extsNeeded[ext] = 1;
      } else if (meta) {
        var slot2 = plan.layoutSlot;
        var md = clampDims(meta.cx, meta.cy);
        arr[li] = { kind: 'p', x: plan.layoutPara.split(DRAW_T).join(
          drawingXml(slot2.rid, md[0], md[1], slot2.docPr)), text: '', draw: true, zoneStart: false };
        mediaAdd.push({ name: slot2.part, src: lname });
        relsAdd.push({ rid: slot2.rid, target: slot2.target });
        extsNeeded.png = 1;
      } else {
        arr.splice(li, 1);   //
      }
    }

    /*



*/
    var stabRef = String(fields.STABILITY_IMAGE || '');
    var sMeta = stabRef ? plan.images[stabRef] : null;
    if (sMeta) {
      var ai = -1;
      for (var i1 = 0; i1 < arr.length; i1++) {
        if (arr[i1].kind !== 'p') continue;
        var t1 = String(arr[i1].text || '').trim();
        if (t1 && (t1.indexOf('稳定系数校核') >= 0 || t1.indexOf('稳定性校核') >= 0) && t1.length <= 30) { ai = i1; break; }
      }
      if (ai >= 0) {
        var at = ai;
        for (var j = ai + 1; j < arr.length; j++) {
          var it2 = arr[j];
          if (it2.kind !== 'p') break;
          var t2 = String(it2.text || '').trim();
          if (t2 && isHeading(t2)) break;
          if (hasContent(it2)) at = j;
        }
        var sSlot = plan.stabSlot;
        arr.splice(at + 1, 0, { kind: 'p', x: plan.stabPara.split(DRAW).join(
          drawingXml(sSlot.rid, sMeta.cx, sMeta.cy, sSlot.docPr)), text: '', draw: true, zoneStart: false });
        mediaAdd.push({ name: sSlot.part, src: stabRef });
        relsAdd.push({ rid: sSlot.rid, target: sSlot.target });
        extsNeeded.png = 1;
      }
    }

    /**/
    LIST_PREFIXES.forEach(function (pfx) {
      var lines = fields[pfx] || fields[pfx + 'S'] || [];
      var paras = arr.filter(function (it) { return it.kind === 'p' && it.tok && it.tok.indexOf(pfx + '_') === 0; });
      if (!paras.length) return;
      while (lines.length > paras.length) {
        var base = paras[paras.length - 1];
        var clone = { kind: 'p', tok: base.tok, x: base.x, r: base.r, b: base.b, h: base.h,
          text: '', draw: false, zoneStart: false };
        arr.splice(arr.indexOf(base) + 1, 0, clone);
        paras.push(clone);
      }
      paras.forEach(function (para, i) {
        if (i < lines.length) para.text = lines[i];
        else arr.splice(arr.indexOf(para), 1);
      });
    });

    /**/
    arr.forEach(function (it) {
      if (it.kind !== 'p') return;
      if (it.x === null || it.x === undefined) {
        var txt = String(it.text || '').trim();
        if (!txt) it.x = it.r || it.b;
        else it.x = isHeading(txt) ? it.h : it.b;
      }
      if (!it.x) throw new Error('模板段落数据缺失（' + (it.tok || '') + '）');
      if (it.tok) it.x = it.x.split('{{' + it.tok + '}}').join(escText(it.text));
    });

    /*


*/

    /**/
    var xml = plan.head + arr.map(function (it) { return it.x; }).join('') + plan.tail;

    /*


*/
    ['GAP_TITLE_IMG', 'GAP_IMG_INFO', 'GAP_INFO_01', 'P1_ROWH'].forEach(function (t) {
      xml = xml.split('{{' + t + '}}').join(String(scalars[t] || ''));
    });

    /*
*/
    xml = hideRows(xml);

    /**/
    xml = i18nXml(xml);

    /**/
    var entries = plan.zip.map(function (z) { return { name: z.n, data: g.SJZip.b64ToBytes(g.SJ_PKG[z.h]) }; });
    /**/
    if (i18nOn()) {
      for (var ei = 0; ei < entries.length; ei++) {
        if (!/^word\/(header|footer)[^/]*\.xml$/.test(entries[ei].name)) continue;
        var hx = bytesToStr(entries[ei].data);
        var hx2 = i18nFooterWords(i18nXml(hx));
        if (hx2 !== hx) entries[ei] = { name: entries[ei].name, data: g.SJZip.utf8(hx2) };
      }
    }
    var at2 = plan.docIndex == null ? entries.length : plan.docIndex;
    entries.splice(at2, 0, { name: 'word/document.xml', data: g.SJZip.utf8(xml) });

    var relsXml = plan.rels;
    /*

*/
    if (relsAdd.length) {
      var ins = relsAdd.map(function (r) { return plan.relsTpl.replace('%s', r.rid).replace('%s', r.target); }).join('');
      relsXml = relsXml.replace(/<\/[A-Za-z0-9_]*:?Relationships>\s*$/, function (m) { return ins + m; });
    }
    replaceEntry(entries, 'word/_rels/document.xml.rels', relsXml);
    var extList = Object.keys(extsNeeded);
    if (extList.length) {
      var ct = plan.contentTypes, ct2 = ct;
      extList.forEach(function (ext) {
        if (ct2.indexOf('Extension="' + ext + '"') < 0) {
          ct2 = ct2.replace('</Types>', '<Default Extension="' + ext + '" ContentType="image/' + ext + '"/></Types>');
        }
      });
      if (ct2 !== ct) replaceEntry(entries, '[Content_Types].xml', ct2);
    }
    var mediaQueue = mediaAdd.map(function (m) { return { name: m.name, src: m.src, bytes: m.bytes }; });

    return new Promise(function (resolve, reject) {
      var out = [];
      (function next() {
        if (!mediaQueue.length) {
          mediaQueue = null;
          entries = entries.concat(out);
          /**/
          var fixed = pruneDanglingRels(entries, xml);
          if (fixed !== xml) { xml = fixed; replaceEntry(entries, 'word/document.xml', xml); }
          pruneUnusedImageRels(entries, xml);
          verifyPackage(entries);
          /*
*/
          var zipDate = spec.zipDate ? new Date(spec.zipDate) : new Date(1980, 0, 1);
          var bytes = g.SJZip.store(entries, zipDate);
          var blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
          resolve({ blob: blob, bytes: bytes, xml: xml, entries: entries });
          return;
        }
        var q = mediaQueue.shift();
        if (q.bytes) {                                       //
          var isPng = q.bytes[0] === 0x89 && q.bytes[1] === 0x50;
          var isJpg = q.bytes[0] === 0xFF && q.bytes[1] === 0xD8;
          if (!isPng && !isJpg) { reject(new Error('客户图例不是 PNG / JPG：' + q.name)); return; }
          out.push({ name: q.name, data: q.bytes });
          next();
          return;
        }
        imageBytes(q.src).then(function (b) {
          if (b[0] !== 0x89 || b[1] !== 0x50) { reject(new Error('插图不是 PNG：' + q.src)); return; }
          out.push({ name: q.name, data: b });
          next();
        }).catch(reject);
      })();
    });
  }

  function hasContent(it) {
    return it.kind === 'p' && (String(it.text == null ? '' : it.text).trim() !== '' || !!it.draw);
  }
  function replaceEntry(entries, name, text) {
    for (var i = 0; i < entries.length; i++) {
      if (entries[i].name === name) { entries[i] = { name: name, data: g.SJZip.utf8(text) }; return; }
    }
    entries.push({ name: name, data: g.SJZip.utf8(text) });
  }

  /*





*/
  function bytesToStr(u8) {
    if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(u8);
    if (typeof Buffer !== 'undefined') return Buffer.from(u8).toString('utf8');
    /**/
    var out = '', i = 0;
    while (i < u8.length) {
      var c = u8[i++];
      if (c < 0x80) out += String.fromCharCode(c);
      else if (c < 0xE0) out += String.fromCharCode(((c & 0x1F) << 6) | (u8[i++] & 0x3F));
      else if (c < 0xF0) out += String.fromCharCode(((c & 0x0F) << 12) | ((u8[i++] & 0x3F) << 6) | (u8[i++] & 0x3F));
      else {
        var cp = ((c & 0x07) << 18) | ((u8[i++] & 0x3F) << 12) | ((u8[i++] & 0x3F) << 6) | (u8[i++] & 0x3F);
        cp -= 0x10000;
        out += String.fromCharCode(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
      }
    }
    return out;
  }
  function normPart(base, target) {
    var t = String(target || '');
    try { t = decodeURIComponent(t); } catch (e) { /**/ }
    if (t.charAt(0) === '/') return t.slice(1);
    var segs = (base ? base.split('/') : []).concat(t.split('/')), out = [];
    for (var i = 0; i < segs.length; i++) {
      var s = segs[i];
      if (!s || s === '.') continue;
      if (s === '..') out.pop(); else out.push(s);
    }
    return out.join('/');
  }
  function relsOf(entries) {
    for (var i = 0; i < entries.length; i++) {
      if (entries[i].name === 'word/_rels/document.xml.rels') return { i: i, text: bytesToStr(entries[i].data) };
    }
    return null;
  }
  function pruneDanglingRels(entries, xml) {
    var r = relsOf(entries);
    if (!r) return xml;
    var have = {};
    entries.forEach(function (e) { have[e.name] = 1; });
    var dropped = [];
    var rels = r.text.replace(/<Relationship\b[^>]*\/>/g, function (tag) {
      if (/TargetMode="External"/i.test(tag)) return tag;
      var id = (/\bId="([^"]+)"/.exec(tag) || [])[1];
      var tg = (/\bTarget="([^"]+)"/.exec(tag) || [])[1];
      if (!tg || have[normPart('word', tg)]) return tag;
      if (id) dropped.push(id);
      return '';
    });
    if (!dropped.length) return xml;
    dropped.forEach(function (id) {
      ['r:embed="', 'r:id="'].some(function (pre) {
        var key = pre + id + '"', at = xml.indexOf(key);
        while (at >= 0) {
          var s = xml.lastIndexOf('<w:drawing', at), e = xml.indexOf('</w:drawing>', at);
          if (s < 0 || e < 0) break;
          xml = xml.slice(0, s) + xml.slice(e + 12);
          at = xml.indexOf(key);
        }
        return xml.indexOf(key) < 0;
      });
    });
    entries[r.i] = { name: entries[r.i].name, data: g.SJZip.utf8(rels) };
    return xml;
  }
  /*
*/
  function pruneUnusedImageRels(entries, xml) {
    var r = relsOf(entries);
    if (!r) return;
    var refd = {};
    String(xml).replace(/r:(?:embed|link|id)="([^"]+)"/g, function (m, id) { refd[id] = 1; return m; });
    var rels = bytesToStr(entries[r.i].data);
    var rels2 = rels.replace(/<Relationship\b[^>]*\/>/g, function (tag) {
      if (!/\/relationships\/image"/.test(tag)) return tag;
      var id = (/\bId="([^"]+)"/.exec(tag) || [])[1];
      if (!id || refd[id]) return tag;
      return '';
    });
    if (rels2 !== rels) entries[r.i] = { name: entries[r.i].name, data: g.SJZip.utf8(rels2) };
  }
  function verifyPackage(entries) {
    var r = relsOf(entries);
    if (!r) return;
    var have = {};
    entries.forEach(function (e) { have[e.name] = 1; });
    var bad = [];
    r.text.replace(/<Relationship\b[^>]*\/>/g, function (tag) {
      if (/TargetMode="External"/i.test(tag)) return tag;
      var tg = (/\bTarget="([^"]+)"/.exec(tag) || [])[1];
      if (tg && !have[normPart('word', tg)]) bad.push(tg);
      return tag;
    });
    if (bad.length) throw new Error('方案书包结构不完整（关系指向不存在的部件：' + bad.join('、') + '）');
  }

  function download(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename || '';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      if (a.parentNode) a.parentNode.removeChild(a);
      URL.revokeObjectURL(url);
    }, 4000);
  }

  g.SJDocx = {
    build: build, download: download, imageBytes: imageBytes,
    isHeading: isHeading, drawingXml: drawingXml,
    get imageBase() { return imageBase; },
    set imageBase(v) { imageBase = v; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
