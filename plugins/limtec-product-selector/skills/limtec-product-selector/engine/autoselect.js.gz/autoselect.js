/*




*/
(function (g) {
  'use strict';

  /*





*/
  function autoSelect(o) {
    var seq = o.sequence || [];
    var maxIter = o.maxIter || 30;
    var history = [], warnings = [], errs = [];
    if (!seq.length) {
      return { chosen: null, chosenResult: null, history: history, warnings: warnings, exhausted: true };
    }
    var i = 0, n = 0;
    while (i !== null && i >= 0 && i < seq.length && n < maxIter) {
      n++;
      var cand = seq[i];
      var ev = o.evalOne(cand, i);
      (ev.warnings || []).forEach(function (w) { if (warnings.indexOf(w) < 0) warnings.push(w); });
      history.push({
        index: i, cand: cand, label: ev.label || '',
        result: ev.result || null, checks: ev.checks || null,
        allPass: !!ev.allPass, reason: ev.reason || '', fatal: !!ev.fatal,
        note: ev.note || ''
      });
      if (ev.fatal) {
        return { chosen: null, chosenResult: null, history: history, warnings: warnings,
                 error: ev.reason, exhausted: false };
      }
      if (ev.allPass) {
        return { chosen: cand, chosenResult: ev.result, history: history,
                 warnings: warnings, exhausted: false };
      }
      var nx = o.advance ? o.advance(i, history[history.length - 1]) : (i + 1);
      i = (nx === undefined) ? (i + 1) : nx;
    }
    //
    var best = null, bestScore = -1e9;
    history.forEach(function (h) {
      if (h.fatal) return;
      var sc = o.score ? o.score(h) : 0;
      if (sc > bestScore) { bestScore = sc; best = h; }
    });
    return {
      chosen: null, chosenResult: null, history: history, warnings: warnings,
      exhausted: true, bestEffort: best,
      unresolved: best ? unmetList(best.checks) : []
    };
  }

  function unmetList(checks) {
    var out = [];
    if (!checks) return out;
    Object.keys(checks).forEach(function (k) {
      if (checks[k] === false) out.push(k);
      else if (checks[k] === null) out.push(k + '（数据待补全）');
    });
    return out;
  }

  g.SJAutoSelect = { autoSelect: autoSelect };
})(typeof window !== 'undefined' ? window : globalThis);
