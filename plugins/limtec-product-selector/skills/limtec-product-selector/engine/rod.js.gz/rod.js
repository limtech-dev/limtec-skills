/*













*/
(function (g) {
  'use strict';
  var C = g.SJCore;
  if (!C) throw new Error('engine/rod.js 依赖 engine/core.js（SJCore）');

  /**/
  var TAU_N = { 't': 9806.65, 'kg': 9.80665, 'kN': 1000, 'kgf': 9.80665, 'N': 1 };   // → N
  var SPEED_CAP_LAP_LBP = 100;                            //
  var CYC = { LAM: 30, LAP: 50, LBP: 200 };               //

  function fN(x, n) { return C.fN(x, n === undefined ? 2 : n); }
  function iN(x) { return C.iN(x); }
  /**/
  function fKw(x) {
    var v = Number(x) || 0;
    var s = v.toFixed(2).replace(/\.?0+$/, '');
    return s === '' ? '0' : s;
  }
  function num(v) { return (typeof v === 'number' && isFinite(v)) ? v : null; }

  /* ---------------- toCalc ---------------- */
  function toCalc(inp, data) {
    inp = inp || {};
    var u = TAU_N[inp.load_unit] || TAU_N.t;
    var loadN = num(inp.load) != null ? num(inp.load) * u : 0;
    /*

*/
    var pullN = num(inp.load_pull) != null ? num(inp.load_pull) * (TAU_N[inp.load_pull_unit || inp.load_unit] || u) : 0;
    /*

*/
    var units = (String(inp.series || 'LAP') === 'LAM') ? 1
      : (String(inp.units) === '2' ? 2 : 1);
    var totalLoadN = loadN, totalPullN = pullN;
    var staticN = num(inp.static_load) != null ? num(inp.static_load) * (TAU_N[inp.static_load_unit || inp.load_unit] || u) : null;
    var totalStaticN = staticN;
    if (units > 1) {
      loadN = loadN / units;
      pullN = pullN / units;
      if (staticN != null) staticN = staticN / units;
    }
    var cal = {
      fam: inp.series || 'LAP',
      lam_group: inp.lam_group || '',
      /**/
      units: units,
      layout: (units > 1) ? (inp.layout || '电机内侧') : '',
      /**/
      sync: (units > 1) ? (inp.sync || '机械') : '机械',
      platform_L: (num(inp.platform_L) > 0) ? num(inp.platform_L) : null,
      total_load_N: totalLoadN, total_pull_N: totalPullN, total_static_N: totalStaticN,
      load_N: loadN, pull_N: pullN,
      load_kN: C.pyRound(loadN / 1000, 3), pull_kN: C.pyRound(pullN / 1000, 3),
      static_N: staticN,
      stroke: num(inp.stroke) || null,
      speed_req: num(inp.speed) || null,
      cycles_per_day: num(inp.cycles_per_day) || null,
      hours_per_day: num(inp.hours_per_day) != null ? num(inp.hours_per_day) : 8,
      days_per_year: num(inp.days_per_year) != null ? num(inp.days_per_year) : 300,
      drive: inp.drive || 'ac3',
      temp: inp.temp || '20',
      precision: inp.precision || '0.1',
      special: Array.isArray(inp.special) ? inp.special.slice() : [],
      special_texts: inp.special_texts || {},
      install: inp.install || 'P1',
      input_dir: inp.input_dir || 'RH',
      joint: inp.joint || 'ROE',
      /**/
      lam2_volt: inp.lam2_volt || '24',
      lam2_fb: inp.lam2_fb || '无',
      lam2_bracket: inp.lam2_bracket || '无',
      lam2_ctrl: inp.lam2_ctrl || '不带',
      lam2_shell: inp.lam2_shell || 'AL',
      lam2_ip: inp.lam2_ip || 'IP65',
      lam2_limit: inp.lam2_limit || '标配',
      /**/
      lam2_screw: inp.lam2_screw || 'LAM6',
      lam2_can: inp.lam2_can || '否',
      /*

*/
      lam_volt: inp.lam_volt || '2',
      lam_lower: inp.lam_lower || '1',
      lam_upper: inp.lam_upper || '1',
      lam_angle: inp.lam_angle || '1',
      lam_limit: inp.lam_limit || '3',
      lam_signal: inp.lam_signal || '0',
      lam_plug: inp.lam_plug || '1',
      lam_cable: inp.lam_cable || '3',
      lam_ip: inp.lam_ip || '3',
      /*
*/
      limit_sw: inp.limit_sw || 'STD',
      servo_brand: Array.isArray(inp.servo_brand) ? inp.servo_brand.slice() : [],
      accessories: Array.isArray(inp.accessories) ? inp.accessories.slice() : [],
      quick_model: inp.quick_model || ''
    };
    /*




*/
    if (cal.units > 1) {
      cal.sync = (String(cal.sync || '').indexOf('电气') >= 0) ? '电气' : '机械';
      if (cal.sync === '电气' && String(cal.drive || '').indexOf('servo') !== 0) cal.drive = 'servo380';
    }
    return cal;
  }
  function cal_famIs(s, fam) { return String(s || '') === fam; }

  /**/
  function dutyCheck(fam, sub, cycles, speedReq, ratedN, loadN) {
    var probs = [], ext = '';
    var loadRate = (ratedN && loadN != null && ratedN > 0) ? (loadN / ratedN) : null;
    var base = CYC[fam];
    if (fam === 'LAP' && cycles != null && cycles > 50) {
      /**/
      var lr = (loadRate != null) ? Math.min(0.5, Math.max(0.2, loadRate)) : null;
      var maxCyc = (lr != null) ? 50 + (0.5 - lr) / 0.3 * 50 : 50;
      if (cycles <= maxCyc + 1e-9) {
        ext = '每日 ' + iN(cycles) + ' 次（负载率 ' + fN(loadRate * 100, 0) + '%，按负载率插值可用至 '
          + fN(maxCyc, 0) + ' 次/日：负载率 50%→50 次、20%→100 次）';
      } else {
        var lrTxt = (loadRate != null) ? (fN(loadRate * 100, 0) + '%') : '未知';
        probs.push('每日 ' + iN(cycles) + ' 次超过当前负载率（' + lrTxt + '）允许上限 ' + fN(maxCyc, 0)
          + ' 次/日；梯形丝杠次数超限，优先改选滚珠丝杠系列（LBP）');
      }
    } else if (cycles != null && cycles > base) {
      probs.push('每日 ' + iN(cycles) + ' 次超过 ' + famName(fam) + '基准 ' + base + ' 次/日'
        + (fam === 'LBP' ? '；超过 200 次/日建议改选伺服电缸' : ''));
    }
    if ((fam === 'LAP' || fam === 'LBP') && speedReq != null && speedReq >= SPEED_CAP_LAP_LBP) {
      probs.push('速度 ' + fN(speedReq, 1) + ' mm/s ≥ 100 mm/s 上限');
    }
    var tag = famName(fam) + '系列（' + sub + '）';
    if (probs.length) return [false, tag + ' 超出选择原则：' + probs.join('；') + '；建议改选系列或与厂家技术确认', loadRate];
    if (ext) return [true, tag + '：' + ext + '，符合选择原则', loadRate];
    var cycTxt = (cycles != null) ? ('每日 ' + iN(cycles) + ' 次') : '次数未填';
    var spdTxt = (speedReq != null) ? ('速度 ' + fN(speedReq, 1) + ' mm/s') : '速度未填';
    return [true, tag + '：' + cycTxt + '、' + spdTxt + '，符合选择原则', loadRate];
  }
  function famName(fam) {
    return fam === 'LAM' ? '小型电动推杆 LAM' : fam === 'LAP' ? '梯形丝杠电动推杆 LAP' : '滚珠丝杠电动推杆 LBP';
  }

  /**/
  function selfLockOf(mdef, fam) {
    if (fam === 'LAM') return mdef.ball ? false : true;      //
  if (fam === 'LBP') return false;
  return (num(mdef.lock) != null && mdef.lock <= 0.25);    //
}

/*



*/
function rodDcBase233(model) {
  var mm = /^LAP(\d+)/.exec(String(model || ''));
  if (mm) { var n1 = Number(mm[1]); return (n1 >= 22 && n1 <= 56) ? n1 : null; }
  mm = /^LBP(\d+)/.exec(String(model || ''));
  if (mm) { var n2 = Number(mm[1]); return (n2 >= 25 && n2 <= 56) ? n2 : null; }
  return null;
}

  /**/
  function stabilityCheck(data, sub, loadN, stroke) {
    var pts = (data.stability || {})[sub];
    if (!pts || !stroke || stroke <= 300) return { ok: true, msg: null, lk: null };
    if (loadN == null || loadN <= 0) return { ok: true, msg: null, lk: null };
    var lk = C.curveLookup(pts, loadN);
    if (lk == null) return { ok: false, msg: '稳定性不足：压载 ' + fN(loadN, 0) + ' N 超出样本稳定性曲线上限（' + sub + '）', lk: null };
    if (stroke > lk * 1.001) return { ok: false, msg: '稳定性不足：压载 ' + fN(loadN, 0) + ' N 时样本曲线允许行程 ' + fN(lk, 0) + ' mm ＜ 要求行程 ' + fN(stroke, 0) + ' mm（安全系数 3）', lk: lk };
    return { ok: true, msg: '压载 ' + fN(loadN, 0) + ' N 时允许行程 ' + fN(lk, 0) + ' mm ≥ 要求 ' + fN(stroke, 0) + ' mm（样本曲线，安全系数 3）', lk: lk };
  }

  /**/
  function lifeCheck(data, m, sub, loadN, stroke, cycles, days) {
    var li = (data.ball_life || {})[sub] || {};
    var C_kN = num(m.ball_ca) || li.C_kN;
    var lead = num(m.lead) || li.lead_mm;
    if (!C_kN || !lead || !loadN) return null;
    var lkN = loadN / 1000;
    var r = C.lifeCheck(C_kN, lead, lkN, stroke || 0, cycles, days, true, 5);
    if (!r) {
      var lifeKm = Math.pow(C_kN / lkN, 3) * lead;
      return { life_km: C.pyRound(lifeKm, 1), annual_km: null, years: null, pass: true, note: '节拍未填，仅出理论公里数 L10=' + fN(lifeKm, 0) + ' km' };
    }
    return r;
  }

  /*










*/
  var ROD_SAFETY = 1.2;                                          //
  var ROD_SAFETY_LOW = 1.1;                                      //
  var ROD_SAFETY_ELEC = 1.5;                                     //
  /*


*/
  function rodSafetyOf(cal) {
    return (cal && Number(cal.units) > 1 && cal.sync === '电气') ? ROD_SAFETY_ELEC : ROD_SAFETY;
  }
  function rodSafetyTry(cal) {
    var s0 = rodSafetyOf(cal);
    return (s0 > ROD_SAFETY + 1e-9) ? [s0] : [ROD_SAFETY, ROD_SAFETY_LOW];
  }
  var ROD_GEAR_STD = [3, 4, 5, 7, 10, 12, 15, 16, 20, 25, 28];    //
  var ROD_SERVO_MIN_RPM = 30;                                    //
  var ROD_SERVO_MAX_RPM = 3000;                                  //
  function rodGearEta(g) { return g > 1 ? (g >= 12 ? 0.8 : 0.9) : 1; }

  /*

*/
  function envCoefOf(temp) {
    if (temp === null || temp === undefined || temp === '') return 1;
    var t = Number(temp);
    if (!isFinite(t)) return 1;
    if (t <= -40 + 1e-9) return 2;
    if (t <= -30 + 1e-9) return 1.5;
    if (t >= 80 - 1e-9) return 2;
    return 1;
  }
  function envNoteOf(temp) {
    var t = Number(temp);
    if (!isFinite(t)) return '';
    if (t <= -40 + 1e-9) return '低温 -40℃：润滑脂凝固、传动效率约降 50%';
    if (t <= -30 + 1e-9) return '低温 -30℃：润滑脂黏度上升、传动效率约降 30%';
    if (t >= 80 - 1e-9) return '高温 +80℃：高温润滑脂黏稠、传动阻力上升';
    return '';
  }

  function servoCalc(data, m, fam, cand, cal, reqLoad) {
    if (fam === 'LAM') return null;
    var d = cal.drive;
    if (d !== 'servo220' && d !== 'servo380' && d !== 'stepping') return null;
    var dp = (data.drive_params || {})[cand.model];
    /*
*/
    var out = { drive: d, model: cand.model, units: cal.units || 1, sync: cal.sync || '机械' };
    if (!dp || !num(dp.i) || !num(dp.lead)) {
      out.warn = '该型号伺服计算参数（减速比/导程/效率）待样本确认，按样本表格电机参数选配';
      return out;
    }
    var vOp = (cal.speed_req != null) ? Math.min(cal.speed_req, m.speed) : m.speed;  //
    var iS = Number(dp.i), lead = Number(dp.lead), eff = num(dp.eff);
    var mo = m.motor || {};
    var nScrew = vOp * 60 / lead;                        //
    var tScrew = reqLoad * lead / (2 * Math.PI * 1000);   //
    /**/
    var tSample = (num(mo.kw) && num(mo.rpm)) ? 9550 * mo.kw / mo.rpm : null;
    /*
*/
    var kEnv = envCoefOf(cal.temp);
    var tBase = (eff != null) ? (tScrew / iS / eff) : null;   //
    if (tBase != null && kEnv !== 1) tBase *= kEnv;
    out.v_mm_s = C.pyRound(vOp, 2);
    out.i = iS; out.lead = lead; out.screw = dp.screw || '';
    out.eff = eff;
    out.t_screw_nm = C.pyRound(tScrew, 2);
    out.t_base_nm = (tBase != null) ? C.pyRound(tBase, 2) : null;
    out.env_coef = kEnv;
    out.temp = cal.temp;
    out.t_base_raw_nm = (tBase != null && kEnv !== 1) ? C.pyRound(tBase / kEnv, 2) : out.t_base_nm;
    out.n_screw_rpm = C.pyRound(nScrew, 0);
    out.sample_motor = m.motor ? (mo.kw + 'kW/' + mo.rpm + 'rpm') : null;
    out.t_src = (tBase != null) ? 'calc' : 'sample';

    /**/
    var lib = (g.SJ_DATA && g.SJ_DATA.motor_library) || [];
    var wantKind = (d === 'stepping') ? 'stepping' : 'servo';
    var wantVolt = d === 'servo220' ? '220VAC' : d === 'servo380' ? '380VAC' : null;
    /*
*/
    var ROD_BRAND_MATCH = { '汇川': '汇川', 'V90': '西门子 V90', 'S200': '西门子 S200', 'S120': '西门子 S120',
      '台达': '台达', '雷赛': '雷赛', '惠斯通': '惠斯通' };
    var wantBrand = (cal.servo_brand || []).map(function (v) { return ROD_BRAND_MATCH[v] || v; });
    var BRAND_ORDER = ['西门子 V90', '西门子 S200', '西门子 S120', '汇川', '台达', '雷赛', '惠斯通'];
    function brandRank(b) {
      var s = String(b || '');
      for (var i = 0; i < BRAND_ORDER.length; i++) {
        if (s.indexOf(BRAND_ORDER[i]) === 0) return i;
      }
      return 9;
    }
    function brandHit(b) {
      var s = String(b || '');
      if (!wantBrand.length) return s.indexOf('惠斯通') !== 0;   //
      return wantBrand.some(function (p) { return s.indexOf(p) === 0; });
    }
    function screen(nMot, tMot) {
      var ok = [], over = [];
      lib.forEach(function (x) {
        if (x.kind !== wantKind) return;
        /*

*/
        if (wantVolt && x.voltage !== wantVolt
          && !(wantVolt === '380VAC' && x.voltage === '220VAC')) return;
        if (!brandHit(x.brand)) return;
        /*
*/
        var nTop = num(x.rpm) != null ? num(x.rpm) : num(x.nmax_rpm);
        if (nTop == null || nTop < nMot - 1e-6) return;
        if (tMot != null && num(x.torque_Nm) != null) {
          var tRated = Number(x.torque_Nm);
          if (tRated >= tMot - 1e-9) {
            ok.push(x);
          } else if (tRated >= tMot * (1 - ROD_TQ_UNDER) - 1e-9) {
            /**/
            var cTol = {};
            for (var kk in x) { if (Object.prototype.hasOwnProperty.call(x, kk)) cTol[kk] = x[kk]; }
            cTol.tq_under = (tMot - tRated) / tMot;
            ok.push(cTol);
          } else {
            over.push(x);
          }
        }
        else ok.push(x);
      });
      return { ok: ok, over: over };
    }
    var seq = [1].concat(ROD_GEAR_STD);
    /*

*/
    var rpmCap = (cal.units > 1 && cal.sync !== '电气') ? 1500 : ROD_SERVO_MAX_RPM;   /**/
    function inBand(n) { return n >= 500 - 1e-9 && n <= 1000 + 1e-9; }
    var seqTry = seq;
    if (cal.units > 1) {
      var bandSeq = seq.filter(function (g) { var n = nScrew * iS * g; return n <= rpmCap + 1e-9 && inBand(n); });
      var restSeq = seq.filter(function (g) { return bandSeq.indexOf(g) < 0; });
      seqTry = bandSeq.concat(restSeq);
    }
    var plan = null, okList = [], overPlan = null, overList = [], lowDirect = false;
    var lowPlan = null, lowOk = [];
    var safetyStd = rodSafetyOf(cal);
    [].concat(rodSafetyTry(cal)).forEach(function (safety) {
      if (plan) return;
      for (var k = 0; k < seqTry.length; k++) {
        var gg = seqTry[k], etaG = rodGearEta(gg);
        var nMot = nScrew * iS * gg;
        if (nMot > rpmCap + 1e-9) continue;   /**/
        var tMot = (tBase != null) ? (tBase * safety / gg / etaG)
          : (tSample != null ? (tSample / gg / etaG) : null);
        var pn = { gear: gg, eta_g: etaG, n_mot: nMot, t_mot: tMot, safety: safety };
        /**/
        if (nMot < ROD_SERVO_MIN_RPM - 1e-9) {
          if (gg === 1) lowDirect = true;
          if (!lowPlan) { var rl = screen(nMot, tMot); if (rl.ok.length) { lowPlan = pn; lowOk = rl.ok; } }
          continue;
        }
        var r = screen(nMot, tMot);
        if (r.ok.length) { plan = pn; okList = r.ok; return; }
        if (!overPlan && r.over.length) { overPlan = pn; overList = r.over; }
      }
    });
    /**/
    if (!plan && lowPlan) { plan = lowPlan; okList = lowOk; out.warn = '工作速度过低：全部标准速比下电机转速仍低于伺服稳定下限 30rpm，已取最大可行速比，须与厂家确认低速稳定性'; }
    if (!plan && overPlan) {
      plan = overPlan; okList = overList;
      out.warn = '按额定转速覆盖未找到额定扭矩达标的机型，以下按功率覆盖推荐，额定转速已满足、扭矩需复核（建议加行星减速机或与厂家确认）';
    }
    out.brands = wantBrand.slice();
    if (!plan) {
      /**/
      out.gear = 1; out.gear_eta = 1; out.i_total = C.pyRound(iS, 2);
      out.safety = safetyStd;
      out.n_motor_rpm = C.pyRound(nScrew * iS, 0);
      out.n_req_rpm = out.n_motor_rpm;
      out.t_motor_nm = (tBase != null) ? C.pyRound(tBase * safetyStd, 2)
        : (tSample != null ? C.pyRound(tSample, 2) : null);
      out.t_req_nm = out.t_motor_nm;
      out.p_req_kw = (out.t_motor_nm != null) ? C.pyRound(out.t_motor_nm * out.n_motor_rpm / 9550, 3) : null;
      /**/
      out.rpm_cap = rpmCap;
      out.in_band = (cal.units > 1) ? false : null;
      out.rpm_over = (nScrew * iS > rpmCap + 1e-9);
      out.warn = (nScrew * iS > rpmCap + 1e-9)
        ? ('所需输入转速 ' + fN(nScrew * iS, 0) + ' rpm 已超'
           + (cal.units > 1 ? '两台联动的 1500rpm 上限' : '伺服额定 3000rpm 上限')
           + '（加行星减速机只会更高），建议加大导程或降低速度要求')
        : ('电机库中暂无额定转速 ≥ ' + fN(nScrew * iS, 0) + ' rpm 的'
           + (wantBrand.length ? ('所选品牌（' + wantBrand.join('/') + '）') : '')
           + (wantKind === 'stepping' ? '步进' : '伺服') + '机型（选伺服按额定转速卡，不靠弱磁超速），请调整品牌或与厂家确认');
      return out;
    }
    var tMotF = plan.t_mot;
    var pReq = (tMotF != null && plan.n_mot > 0) ? tMotF * plan.n_mot / 9550 : null;
    out.gear = plan.gear;
    out.gear_eta = plan.eta_g;
    out.i_total = C.pyRound(iS * plan.gear, 2);
    out.t_motor_nm = (tMotF != null) ? C.pyRound(tMotF, 2) : null;
    out.safety = plan.safety;
    out.fit_low = (plan.safety < safetyStd - 1e-9) ? '1.1' : null;   //
    out.n_motor_rpm = C.pyRound(plan.n_mot, 0);
    out.n_req_rpm = out.n_motor_rpm;          //
    out.rpm_cap = rpmCap;
    out.in_band = (cal.units > 1) ? inBand(out.n_motor_rpm) : null;   //
    out.p_req_kw = (pReq != null) ? C.pyRound(pReq, 3) : null;
    out.t_req_nm = out.t_motor_nm;            //
    out.low_direct = lowDirect;
    /*

*/
    if (plan.gear > 1) {
      var sj = g.SJScrewJack;
      out.gear_pick = (sj && typeof sj.planetPickOf === 'function')
        ? sj.planetPickOf(g.SJ_DATA || null, plan.gear, tMotF || null, plan.n_mot,
            (sj.motorShaftOf ? sj.motorShaftOf((okList && okList[0]) || null) : 0)) : null;
    }
    /**/
    function rodRowsWithPrice(list, pReqKw, drv) {
      var MAXR = 5;
      if (drv !== 'servo220' && drv !== 'servo380') return list.slice(0, MAXR);   //
      var prod = g.SJScrewJackProduct;
      if (!prod || typeof prod.motorDrivePriceOf !== 'function') return list.slice(0, MAXR);
      function isRefRow(r) { return /参考档/.test(String(r.code || '')); }
      function hasPrice(r) {
        try {
          var md = prod.motorDrivePriceOf(
            { kind: 'servo', code: r.code, brand: r.brand, power_kW: r.power_kW, rpm: r.rpm },
            { drive: drv });
          return !!(md && md.hasPrice);
        } catch (e) { return false; }
      }
      var priced = list.filter(hasPrice);
      var picked = [];
      if (priced.length) {
        var byNear = priced.slice().sort(function (a, b) {
          var da = (pReqKw != null) ? Math.abs(Number(a.power_kW) - pReqKw) : Number(a.power_kW);
          var db = (pReqKw != null) ? Math.abs(Number(b.power_kW) - pReqKw) : Number(b.power_kW);
          return (da - db) || (Number(a.power_kW) - Number(b.power_kW));
        });
        picked = byNear.slice(0, Math.min(2, MAXR));
      }
      var rest = list.filter(function (r) { return picked.indexOf(r) < 0; });
      var final = picked.concat(rest.filter(function (r) { return !isRefRow(r); }))
        .concat(rest.filter(isRefRow)).slice(0, MAXR);
      final.sort(function (a, b) {
        return (Number(a.power_kW) - Number(b.power_kW))
          || ((isRefRow(a) ? 1 : 0) - (isRefRow(b) ? 1 : 0))   //
          || (brandRank(a.brand) - brandRank(b.brand))
          || ((a.rpm || 0) - (b.rpm || 0)) || String(a.code).localeCompare(String(b.code));
      });
      return final;
    }

    /*


*/
    function rodRowsByPowerStep(list, pReqKw, drv) {
      var MAXSTEP = 3;
      if (drv !== 'servo220' && drv !== 'servo380') return list.slice(0, 5);
      var groups = {}, steps = [];
      list.forEach(function (r) {
        var k = Number(r.power_kW);
        if (!(k > 0)) return;
        if (!groups[k]) { groups[k] = []; steps.push(k); }
        groups[k].push(r);
      });
      if (!steps.length) return list.slice(0, 5);
      /**/
      function stepAllTol(k) {
        return groups[k].every(function (r) { return r.tq_under != null; });
      }
      steps.sort(function (a, b) {
        return ((stepAllTol(a) ? 1 : 0) - (stepAllTol(b) ? 1 : 0)) || (a - b);
      });
      var prod = g.SJScrewJackProduct;
      var priceCache = {};
      function hasPrice(r) {
        var key = String(r.code) + '|' + String(r.brand);
        if (key in priceCache) return priceCache[key];
        var hit = false;
        if (prod && typeof prod.motorDrivePriceOf === 'function') {
          try {
            var md = prod.motorDrivePriceOf(
              { kind: 'servo', code: r.code, brand: r.brand, power_kW: r.power_kW, rpm: r.rpm },
              { drive: drv });
            hit = !!(md && md.hasPrice);
          } catch (e) { hit = false; }
        }
        priceCache[key] = hit;
        return hit;
      }
      var picked = [];
      steps.slice(0, MAXSTEP).forEach(function (k) {
        var g2 = groups[k].slice().sort(function (a, b) {
          return ((hasPrice(b) ? 1 : 0) - (hasPrice(a) ? 1 : 0))          //
            || ((a.need220 ? 1 : 0) - (b.need220 ? 1 : 0))                //
            || (brandRank(a.brand) - brandRank(b.brand))
            || ((a.rpm || 0) - (b.rpm || 0)) || String(a.code).localeCompare(String(b.code));
        });
        if (g2.length) picked.push(g2[0]);
      });
      return picked;
    }

    /**/
    var rows = okList.map(function (x) {
      return {
        brand: x.brand, code: x.code, power_kW: x.power_kW, rpm: num(x.rpm),
        nmax_rpm: num(x.nmax_rpm), torque_Nm: num(x.torque_Nm), voltage: x.voltage || '',
        current_A: num(x.current_A), frame: x.frame || '', flange: x.flange || '',
        /**/
        need220: (wantVolt === '380VAC' && x.voltage === '220VAC') ? true : null,
        /**/
        tq_under: (x.tq_under != null) ? C.pyRound(x.tq_under * 100, 1) : null,
        rpm_margin: (num(x.rpm) != null) ? C.pyRound(num(x.rpm) - plan.n_mot, 0) : null,
        fit_low: out.fit_low
      };
    });
    rows.sort(function (a, b) {
      return ((a.tq_under != null) ? 1 : 0) - ((b.tq_under != null) ? 1 : 0)   //
        || (a.power_kW - b.power_kW) || (brandRank(a.brand) - brandRank(b.brand))
        || ((a.rpm || 0) - (b.rpm || 0)) || String(a.code).localeCompare(String(b.code));
    });
    var rowsSorted = rows.slice();
    var isServoDrive = (d === 'servo220' || d === 'servo380');
    /*
*/
    if (!isServoDrive && pReq != null && pReq > 0) {
      var kept = rows.filter(function (r) { return !(Number(r.power_kW) > pReq * 3 + 1e-9); });
      /**/
      rows = kept.length ? kept : rowsSorted.slice(0, 2);
    }
    /*




*/
    rows = isServoDrive ? rodRowsByPowerStep(rows, pReq, d) : rodRowsWithPrice(rows, pReq, d);
    out.recommend = rows;
    if (eff == null) {
      /*
*/
      out.warn2 = (out.t_src === 'sample' && out.t_req_nm != null)
        ? ('该型号效率参数样本未印（「(效率)自锁系数」括号为空），所需功率/扭矩无法按 P=F·v/η 计算；'
           + '以下电机表仅按转速覆盖给出，扭矩 ≈ ' + fN(out.t_req_nm, 1)
           + ' N·m 为临时折算值，正式报价前须与厂家确认效率后重算')
        : '该型号效率参数待样本确认，所需功率/扭矩无法计算，电机表仅按转速覆盖给出，须与厂家确认';
    }
    return out;
  }
  /**/
  function servoSteps(s) {
    if (s.n_req_rpm == null) return [['伺服电机计算', s.warn || '伺服计算参数待样本确认，按样本表格电机参数选配']];
    var out = [];
    /*
*/
    var twoUnits = (Number(s.units) === 2 && s.sync !== '电气');
    var rpmCapOf = twoUnits ? 1500 : ROD_SERVO_MAX_RPM;
    out.push(['丝杠与减速比', '样本参数：减速比 i=' + s.i + '，导程 ' + s.lead + ' mm'
      + (s.screw ? '（丝杠 ' + s.screw + '）' : '')
      + '，整体效率 ' + (s.eff != null ? Math.round(s.eff * 100) + '%' : '待样本确认（「(效率)自锁系数」括号为空）')]);
    if (s.env_coef && s.env_coef !== 1) {
      out.push(['环境系数', (envNoteOf(s.temp) || ('工作温度 ' + s.temp + '℃ 非标工况'))
        + ' → 电机端扭矩与所需功率 ×' + fN(s.env_coef, 1)]);
    }
    var tq = '丝杠端 T = ' + fN(s.t_screw_nm, 2) + ' N·m（= F×导程÷2π）；配样本减速比 i=' + s.i
      + (s.eff != null ? '（效率 ' + Math.round(s.eff * 100) + '%）' : '')
      + ' 折算电机端 T = ' + fN(s.t_base_raw_nm != null ? s.t_base_raw_nm : s.t_base_nm, 2) + ' N·m'
      + (s.env_coef && s.env_coef !== 1
        ? '；环境系数 ×' + fN(s.env_coef, 1) + ' → ' + fN(s.t_base_nm, 2) + ' N·m' : '');
    if (s.t_base_nm == null) {
      tq = '丝杠端 T = ' + fN(s.t_screw_nm, 2) + ' N·m（= F×导程÷2π）；效率样本未印 → 电机端需求待样本确认，'
        + '临时按额定扭矩反推 T ≈ ' + fN(s.t_motor_nm, 1) + ' N·m';
    } else {
      tq += '；安全系数 ' + s.safety + ' → 需求 ' + fN(s.t_motor_nm, 2) + ' N·m';
    }
    out.push(['驱动扭矩', tq]);
    if (s.gear > 1) {
      var gpk = s.gear_pick;
      out.push(['减速机效率', '行星减速机 i=' + s.gear + ':1（HV 标准速比档），效率 ' + s.gear_eta
        + (gpk ? '；选 ' + gpk.model + '（额定输出 ' + fN(gpk.C, 0) + ' N·m / 最大 ' + fN(gpk.D, 0) + ' N·m，' + gpk.level
          + (gpk.price != null ? '，牌价 ' + gpk.price + ' 元' : '，待询价') + '）' : '；型号待询')
        + '；校核口径：减速机输出扭矩 = 电机额定扭矩 × 减速比 ≤ 额定输出扭矩']);
    }
    var nTxt = '所需转速 n = ' + fN(s.v_mm_s, 2) + ' × 60 × ' + s.i
      + (s.gear > 1 ? ' × ' + s.gear : '') + ' ÷ ' + s.lead + ' mm = ' + fN(s.n_req_rpm, 0) + ' rpm'
      + (s.n_req_rpm <= rpmCapOf + 1e-9
        ? (twoUnits ? '（≤ 两台联动 1500rpm 上限' + (s.in_band ? '，落在 500~1000rpm 优先区间）' : '，调速运行）')
          : '（≤ 伺服额定 3000rpm，调速运行）')
        : ((twoUnits ? '（> 两台联动 1500rpm 上限' : '（> 伺服额定 3000rpm') + '，须与厂家确认）'));
    out.push(['速度校核', nTxt + '；对应输出速度 v = ' + fN(s.n_req_rpm, 0) + ' ÷ 60 × ' + s.lead + ' mm ÷ '
      + (s.i_total || s.i) + ' = ' + fN(s.n_req_rpm / 60 * s.lead / (s.i_total || s.i), 2) + ' mm/s'
      + '；按伺服口径选型：电机额定转速须 ≥ ' + fN(s.n_req_rpm, 0) + ' rpm（不套样本交流电机参数，不靠弱磁超速）']);
    return out;
  }

  /*









*/
  var ROD_COMBO_COEF = 0.95;   /**/
  var ROD_AMP_COEF = 1.2;      /**/
  /*

*/
  var ROD_AMP_COEF_DC = 1.5;
  var ROD_STAGE_REV = 0.90;    /**/
  var ROD_STATIC_FACTOR = 1.5; /**/
  /*




*/
  var ROD_MOTOR_LADDER = [0.37, 0.55, 0.75, 1.1, 1.5, 2.2, 3, 4, 5.5, 7.5, 11, 15, 18.5, 22, 30, 37, 45, 55, 75, 90];
  function rodStdKw(need) {
    for (var i = 0; i < ROD_MOTOR_LADDER.length; i++) {
      if (ROD_MOTOR_LADDER[i] + 1e-9 >= need) return ROD_MOTOR_LADDER[i];
    }
    return null;
  }
  function rodFloorCoef(fam) { return fam === 'LBP' ? 0.15 : 0.20; }  /**/

  /*


*/
  function rodSubMaxKw(data, fam, sub) {
    var mx = 0;
    Object.keys(data.models).forEach(function (k) {
      var mm = data.models[k];
      if (mm.fam !== fam || mm.sub !== sub) return;
      var mt = mm.motor || {};
      if (mt.kind !== 'ac3') return;                 /**/
      var kw = num(mt.kw);
      if (kw > mx) mx = kw;
    });
    return mx;
  }

  /**/
  function rodMaxLoadOfSub(data, sub) {
    var ov = (data._meta || {}).static_load_N || {};
    if (ov[sub] != null) return num(ov[sub]) || 0;
    var mx = 0;
    Object.keys(data.models).forEach(function (k) {
      var mm = data.models[k];
      if (mm.sub === sub && mm.load_N != null && mm.load_N > mx) mx = mm.load_N;
    });
    return mx;
  }

  function evalTwoPower(cand, cal, data) {
    var m = cand.mdef, fam = cand.fam;
    var steps = [], checks = {}, warnings = [];
    var isDc = (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48');   /**/
    var ampCoef = isDc ? ROD_AMP_COEF_DC : ROD_AMP_COEF;
    var motorKwActual = null;   /**/
    var reqLoad = cal.load_N || 0, reqPull = cal.pull_N || 0;
    var ratedN0 = m.load_N;
    var dp = (data.drive_params || {})[cand.model] || {};
    var leadN = num(dp.lead) || num(m.lead) || 0;
    var iR = num(dp.i) || 0;
    var eff0 = num(dp.eff) || 0;
    var vSamp = m.speed;
    var nIn = (leadN > 0 && iR > 0 && vSamp > 0) ? vSamp * 60 / leadN * iR : null;
    var extraStroke = !!(cal.stroke && cal.stroke > 800 + 1e-6);

    /**/
    if (ratedN0 == null || ratedN0 < reqLoad - 1e-6) {
      var shortPct0 = (ratedN0 != null && reqLoad > 0) ? (reqLoad - ratedN0) / reqLoad : 1;
      if (ratedN0 == null || shortPct0 > ROD_LOAD_UNDER + 1e-9) {
        return { fatal: '额定推力不足', rated: ratedN0, req: reqLoad };
      }
    }
    if (cal.speed_req != null && vSamp + 1e-9 < cal.speed_req * (1 - ROD_SPEED_UNDER)) {
      return { fatal: '速度超限', v_sample: vSamp, v_req: cal.speed_req };
    }
    checks['速度'] = true;
    if (nIn == null) return { fatal: '输入转速数据缺失（导程/减速比待样本）' };
    if (nIn > 1500 + 1e-9) {
      return { fatal: '输入转速超限（两台联动 1500rpm）', n_input_rpm: Math.round(nIn) };
    }
    var inBand = (nIn >= 500 - 1e-9 && nIn <= 1000 + 1e-9);

    /**/
    steps.push(['单台负载', '总负载 ' + fN(cal.total_load_N != null ? cal.total_load_N : reqLoad, 0) + ' N ÷ ' + iN(cal.units) + ' 台 = '
      + fN(reqLoad, 0) + ' N（每台）'
      + (reqPull > 0 ? '；总拉力 ' + fN(cal.total_pull_N != null ? cal.total_pull_N : reqPull, 0) + ' N ÷ ' + iN(cal.units) + ' = ' + fN(reqPull, 0) + ' N（每台）' : '')
      + '；两台机械同步（' + (cal.layout || '电机内侧') + '）：电机侧 1 台主机经 1 根传动轴带动从动台 P2（双输入轴）'
      + '；速度要求为系统速度，两台相同']);

    /**/
    var floorC = rodFloorCoef(fam);
    var floorN = (ratedN0 != null) ? ratedN0 * floorC : null;
    var fCalcN = reqLoad;
    if (floorN != null && reqLoad < floorN - 1e-9) fCalcN = floorN;
    steps.push([Math.round(floorC * 100) + '%动载率下限', (fCalcN > reqLoad + 1e-9
      ? '载荷 ' + fN(reqLoad / 1000, 2) + 'kN 小于额定载荷 ' + fN(ratedN0 / 1000, 1) + 'kN 的 '
        + Math.round(floorC * 100) + '%（' + fN(floorN / 1000, 2) + 'kN），功率计算按 ' + Math.round(floorC * 100) + '% 下限取 '
        + fN(fCalcN / 1000, 2) + 'kN'
      : '载荷 ' + fN(reqLoad / 1000, 2) + 'kN ≥ 额定载荷 ' + fN(ratedN0 / 1000, 1) + 'kN 的 ' + Math.round(floorC * 100)
        + '%，按实际载荷计算')]);

    /**/
    var pOut = fCalcN * vSamp / 1000;
    steps.push(['输出功率', 'P出 = ' + fN(fCalcN / 1000, 2) + 'kN × ' + fN(vSamp, 2) + 'mm/s ÷ 1000 = ' + fN(pOut, 1)
      + 'W（速度 = 型号档位速度 ' + fN(vSamp, 2) + 'mm/s 口径）']);

    /**/
    var eta = eff0, fRpmV = null;
    if (eff0 <= 0) return { fatal: '样本效率数据缺失' };
    fRpmV = C.speedEffFactor(data, '', { screw_type: fam === 'LBP' ? '滚珠丝杠' : '梯形丝杠' }, nIn, { fillToRef: true });
    if (fRpmV != null && Math.abs(fRpmV - 1) > 1e-9) eta = eff0 * fRpmV;
    steps.push(['转速效率修正', '推杆输入转速 ' + fN(nIn, 0) + 'rpm（= 速度 ' + fN(vSamp, 2) + 'mm/s × 60 ÷ 导程 '
      + fN(leadN, 1) + 'mm × 减速比 ' + iR + '）'
      + (fRpmV != null && Math.abs(fRpmV - 1) > 1e-9
        ? '，按 ' + (fam === 'LBP' ? 'SJB' : 'SJA') + ' 转速效率比例 ×' + fN(fRpmV, 3)
          + '：η = ' + fN(eff0, 3) + '×' + fN(fRpmV, 3) + ' = ' + fN(eta, 3)
        : '，转速在 1400rpm 基准及以上，不做转速修正：η = ' + fN(eta, 3))
      + '（≤1500rpm 上限，' + (inBand ? '落在 500~1000rpm 优先区间）' : '未落在 500~1000rpm 优先区间）')]);

    /**/
    var pIn = pOut / eta;
    var kTemp = envCoefOf(cal.temp);
    var pInCalc = pIn * (kTemp !== 1 ? kTemp : 1);
    /**/
    steps.push(['输入功率', 'P入 = ' + fN(pOut, 1) + 'W ÷ η(' + fN(eta, 3) + ') = ' + fN(pIn, 1)
      + 'W ≈ ' + fKw(pIn / 1000) + 'kW'
      + (kTemp !== 1 ? '；' + (envNoteOf(cal.temp) || ('工作温度 ' + cal.temp + '℃ 非标工况'))
        + ' → × ' + fN(kTemp, 1) + ' = ' + fKw(pInCalc / 1000) + 'kW' : '')]);

    /*



*/
    var kwSlotOwn = (m.motor && num(m.motor.kw) > 0) ? num(m.motor.kw) : null;
    var kwMax = rodSubMaxKw(data, fam, cand.sub);
    if (!(kwMax > 0)) kwMax = kwSlotOwn;
    if (kwMax == null) return { fatal: '最大输入功率数据缺失（样本电机参数待补）' };
    var pInOk = pInCalc / 1000 <= kwMax + 1e-9;
    /**/
    steps.push(['最大输入功率校核', 'P入 ' + fKw(pInCalc / 1000) + 'kW ' + (pInOk ? '≤' : '>')
      + ' 最大输入功率 ' + fN(kwMax, 2) + 'kW'
      + (pInOk ? '，校核通过' : '，校核失败')]);
    if (!pInOk) {
      return { fatal: '输入功率超限（最大输入功率）', detail: 'P入 ' + fKw(pInCalc / 1000) + 'kW > 最大输入功率 '
        + fN(kwMax, 2) + 'kW（' + cand.sub + ' 基座样本上限）' };
    }
    checks['最大输入功率'] = true;

    /*
*/
    var plat = pInCalc / 1000 * 2 / (ROD_COMBO_COEF * ROD_STAGE_REV);
    steps.push(['平台总功率', 'P平 = ' + fKw(pInCalc / 1000) + 'kW × 2 ÷ (组合系数' + fN(ROD_COMBO_COEF, 2)
      + '×' + fN(ROD_STAGE_REV, 2) + '^1) = ' + fKw(plat) + 'kW']);

    /**/
    var totalPower = plat * ampCoef;
    steps.push(['放大系数', '总功率 = ' + fKw(plat) + 'kW × ' + fN(ampCoef, 1) + ' = ' + fKw(totalPower)
      + 'kW'
      + (isDc ? '；直流电机按 1.5 安全系数取' : '')]);

    /**/
    var vUnder = (cal.speed_req != null && vSamp + 1e-9 < cal.speed_req);
    var devPct = cal.speed_req ? (vSamp - cal.speed_req) / cal.speed_req * 100 : 0;
    steps.push(['速度校核', (isDc ? '直流电机按型号档位速度驱动，' : '交流电机不可调速，')
      + '型号档位速度 ' + fN(vSamp, 2) + 'mm/s'
      + (cal.speed_req != null ? '（要求 ' + fN(cal.speed_req, 2) + 'mm/s，偏差 ' + (devPct >= 0 ? '+' : '') + fN(devPct, 1) + '%）' : '')
      + (vUnder ? '，欠速 ≤' + Math.round(ROD_SPEED_UNDER * 100) + '% 按接近口径放行，满足使用要求'
        : '，按最接近速度档使用，满足使用要求')]);
    if (vUnder) {
      warnings.push('所选型号样本档位速度 ' + fN(vSamp, 1) + ' mm/s 低于要求 '
        + fN(cal.speed_req, 1) + ' mm/s（差 ' + fN(-devPct, 1) + '%），按「接近口径」放行；如需完全达到要求请上调一档或与厂家确认。');
    }

    /*

*/
    var kwMotor = rodStdKw(totalPower);
    /**/
    if (kwMotor != null && kwSlotOwn != null && kwMotor < kwSlotOwn) kwMotor = kwSlotOwn;
    if (kwMotor == null) {
      return { fatal: '总功率超出标准电机档范围（>90kW）', detail: '总功率 ' + fKw(totalPower) + 'kW' };
    }
    var tNeed = 9550 * totalPower / nIn;
    var tRated = 9550 * kwMotor / nIn;
    /**/
    steps.push(['电机扭矩', '按总功率 ' + fKw(totalPower) + 'kW 选标准电机档 ' + fN(kwMotor, 2) + 'kW'
      + '；T = 9550 × ' + fKw(totalPower) + 'kW ÷ ' + fN(nIn, 0) + 'rpm = '
      + fN(tNeed, 1) + 'Nm ≤ 电机额定 ' + fN(tRated, 1) + 'Nm，校核通过']);
    checks['电机扭矩'] = true;
    motorKwActual = kwMotor;
    if (m.derived_4p) {
      /*
*/
      var dRpmTxt = m.derived_rpm || 1400;
      var wHead = (dRpmTxt === 1400) ? '本档为同减速比 4 极（1400rpm）配置：样本该档 '
        : ((dRpmTxt === 950) ? '本档为同减速比 6 极（950rpm）配置：样本该档 '
          : '本档为同减速比 8 极（700rpm）配置：样本该档 ');
      var wSwap = (dRpmTxt === 1400) ? '换 4 极电机后速度降为 '
        : ((dRpmTxt === 950) ? '换 6 极电机后速度降为 ' : '换 8 极电机后速度降为 ');
      var wRpmTail = (dRpmTxt === 1400) ? '/1400rpm' : ((dRpmTxt === 950) ? '/950rpm' : '/700rpm');
      warnings.push(wHead + fN(m.derived_src_speed, 1) + ' mm/s 为 2800rpm 行，'
        + wSwap + fN(vSamp, 1) + ' mm/s；档位判档按单台 P入 ' + fKw(pInCalc / 1000)
        + 'kW ≤ 该基座样本最大配电机 ' + fN(kwMax, 2) + 'kW'
        + (kwSlotOwn != null && Math.abs(kwSlotOwn - kwMax) > 1e-9 ? '（本档样本 ' + fN(kwSlotOwn, 2) + 'kW）' : '')
        + (kwSlotOwn != null && Math.abs(num(m.derived_src_kw) - kwSlotOwn) > 1e-9 ? '（样本 2800rpm 行为 ' + fN(m.derived_src_kw, 2) + 'kW）' : '')
        + '；实配电机按两台总功率 ' + fKw(totalPower) + 'kW 另选 ' + fN(kwMotor, 2) + 'kW' + wRpmTail
        + (kwSlotOwn != null && Math.abs(kwMotor - kwSlotOwn) > 1e-9 ? '（不受同基座功率阶梯限制）' : '') + '。');
    }

    /**/
    var stab = stabilityCheck(data, cand.sub, reqLoad, cal.stroke);
    checks['稳定性'] = stab.ok;
    var strokeSeg = (cal.stroke && m.stroke_max != null)
      ? '；型号最大行程 ' + iN(m.stroke_max) + ' mm ≥ 要求 ' + fN(cal.stroke, 0) + ' mm'
        + (extraStroke ? '（>800mm 属加长行程，护管及伸缩管 +200mm，样本尺寸页注）' : '')
      : (cal.stroke ? '；型号最大行程待样本确认（要求 ' + fN(cal.stroke, 0) + ' mm）' : '');
    steps.push(['稳定性校核', (stab.msg || '行程 ≤300mm 或拉力工况，按样本不校核稳定性') + strokeSeg]);
    if (!stab.ok) return { fatal: '稳定性不足', stability_Lk_mm: stab.lk, stab_msg: stab.msg };
    if (!(data.stability || {})[cand.sub] && cal.stroke && cal.stroke > 300) {
      warnings.push('该型号（' + cand.sub + '）稳定性曲线未收录，行程 >300mm 请与力姆泰克工程师确认稳定性');
    }

    /**/
    var maxLoadSub = rodMaxLoadOfSub(data, cand.sub);
    var staticN = maxLoadSub * ROD_STATIC_FACTOR;
    var stOk = reqLoad <= staticN + 1e-6;
    /**/
    steps.push(['静载校核', '未单独提供静载，按动载需求 ' + fN(reqLoad, 0) + ' N 计 ≤ 额定静载 ' + fN(staticN, 0)
      + ' N' + (stOk ? '，静载校核通过' : '，静载校核失败')]);
    if (!stOk) return { fatal: '静载超限', detail: '需求 ' + fN(reqLoad, 0) + ' N > 额定静载 ' + fN(staticN, 0) + ' N' };
    checks['静载'] = true;

    /**/
    checks['推力'] = true;
    steps.push(['推拉力校核', '单台需求 ' + fN(reqLoad / 1000, 2) + 'kN ≤ 额定推拉力（提升力）' + fN(ratedN0 / 1000, 1) + 'kN'
      + (reqPull > 0 && m.pull_N != null ? '；额定拉力 ' + fN(m.pull_N, 0) + ' N ≥ 要求 ' + fN(reqPull, 0) + ' N' : '')
      + '，校核通过'
      + (ratedN0 < reqLoad - 1e-6
        ? '（欠 ' + fN((reqLoad - ratedN0) / reqLoad * 100, 1) + '%，≤' + Math.round(ROD_LOAD_UNDER * 100)
          + '% 按「备选口径」放行——只能做备选方案，须客户确认）' : '')]);
    if (ratedN0 < reqLoad - 1e-6) {
      warnings.push('额定推力 ' + fN(ratedN0, 0) + ' N 低于需求 ' + fN(reqLoad, 0) + ' N（欠 '
        + fN((reqLoad - ratedN0) / reqLoad * 100, 1) + '%），仅作备选；如实际工况有冲击/偏载请上调一档。');
    }

    /**/
    var life = null;
    if (fam === 'LBP') {
      life = lifeCheck(data, m, cand.sub, reqLoad, cal.stroke, cal.cycles_per_day, cal.days_per_year);
      if (life) {
        checks['寿命'] = life.pass;
        steps.push(['寿命校核', '滚珠丝杠 L10 理论寿命 ' + fN(life.life_km, 0) + ' km'
          + (life.annual_km != null ? '，年用 ' + fN(life.annual_km, 0) + ' km' : '')
          + (life.years != null ? '，约 ' + fN(life.years, 1) + ' 年（要求 ≥5 年）' : '')
          + '；' + life.note]);
        if (!life.pass) return { fatal: '寿命不足', life: life };
      }
    }

    /**/
    var duty = dutyCheck(fam, cand.sub, cal.cycles_per_day, cal.speed_req, ratedN0, reqLoad);
    checks['工作制'] = duty[0];
    steps.push(['工作制校核', duty[1]]);
    if (duty[0] === false) warnings.push('【系列选择原则警告】' + duty[1]);

    /**/
    var selfLock = selfLockOf(m, fam);
    var brakeNeeded = !selfLock;
    steps.push(['自锁校核', selfLock
      ? '该型号自锁（自锁系数 ' + m.lock + ' ≤ 0.25），电机可不加制动器'
      : '自锁系数 ' + m.lock + ' > 0.25，不自锁，电机须配制动器']);
    /*
*/
    if (brakeNeeded) warnings.push('该型号不自锁，制动器随电机内置（清单不另列 BRE）。');

    /**/
    if (cal.temp === '-40' || cal.temp === '-30' || cal.temp === '80') {
      warnings.push(Number(cal.temp) >= 80
        ? '工作温度 ' + cal.temp + '℃ 为非标工况，须按高温定制（高温电机、高温润滑脂），与厂家确认。'
        : '工作温度 ' + cal.temp + '℃ 为非标工况，须按低温/高温定制（低温电机、特种润滑脂），与厂家确认。');
    }
    if (extraStroke) {
      warnings.push('行程 ' + fN(cal.stroke, 0) + ' mm 属加长行程（>800mm）：样本要求护管及伸缩管各加长 200mm，'
        + '外形总长与安装空间请按加长后尺寸确认。');
    }
    if (String(cal.limit_sw || 'STD') === 'NONE') {
      warnings.push('已选「无限位开关」：本机不配行程限位开关，行程两端保护需外置限位开关或由客户控制系统实现，'
        + '请确认使用端已做限位/过载保护。');
    }

    var allPass = Object.keys(checks).every(function (k) { return checks[k] !== false; });
    var res = {
      model: cand.model, fam: fam, sub: cand.sub, code: cand.code, family: famName(fam),
      mdef: m, checks: checks, steps: steps, warnings: warnings,
      rated_N: ratedN0, rated_kN: C.pyRound(ratedN0 / 1000, 2),
      v0: m.v0, v1: m.v1, speed_mm_s: vSamp,
      speed_req: (cal.speed_req != null) ? cal.speed_req : null,
      speed_under_max: Math.round(ROD_SPEED_UNDER * 100),
      speed_under_pct: (cal.speed_req != null && vUnder) ? C.pyRound(-devPct, 1) : null,
      load_under_pct: (ratedN0 < reqLoad - 1e-6) ? C.pyRound((reqLoad - ratedN0) / reqLoad * 100, 1) : null,
      load_under_max: Math.round(ROD_LOAD_UNDER * 100),
      load_req_N: reqLoad,
      units: cal.units || 1,
      layout: cal.layout || '',
      sync: cal.sync || '机械',   /**/
      platform_L: cal.platform_L || null,
      n_input_rpm: Math.round(nIn),
      input_in_band: inBand,
      total_load_N: cal.total_load_N != null ? cal.total_load_N : reqLoad,
      total_pull_N: cal.total_pull_N != null ? cal.total_pull_N : reqPull,
      load_short: ratedN0 < reqLoad - 1e-6,
      stroke_max: m.stroke_max,
      /**/
      motor: m.motor ? (function () {
        var o = {};
        Object.keys(m.motor).forEach(function (kk) { o[kk] = m.motor[kk]; });
        if (motorKwActual != null) o.kw = motorKwActual;
        return o;
      })() : null,
      extra_stroke: extraStroke,
      duty: m.duty || null, lock: (fam === 'LAP') ? m.lock : null,
      self_lock: selfLock, brake_required: brakeNeeded,
      stability_Lk_mm: stab.lk,
      life: life, life_km: life ? life.life_km : null, annual_km: life ? life.annual_km : null,
      load_rate: duty[2],
      accessories: cal.accessories.slice(),
      install: cal.install, input_dir: cal.input_dir, joint: cal.joint,
      servo_calc: null,
      /*

*/
      dc_motor: isDc ? (function () {
        var kwD = (motorKwActual != null) ? motorKwActual : num((m.motor || {}).kw);
        var rpmD = num((m.motor || {}).rpm) || 1400;
        if (!(kwD > 0)) return null;
        return {
          src: 'ac', via: 'two',
          p_kw: kwD, rpm_main: rpmD,
          t_nm: Math.ceil(9550 * kwD / rpmD * 10) / 10,
          volts: [String({ dc12: 12, dc24: 24, dc48: 48 }[cal.drive] || 24)]
        };
      })() : null,
      env_coef: kTemp, env_ok: true, env_short: null,
      /**/
      temp: cal.temp,
      /**/
      motor_torque_Nm: C.pyRound(tNeed, 1),
      motor_power_kW: C.pyRound(totalPower, 2),
      motor_sync: Math.round(nIn),
      gear_ratio: null, gear_eta: null,
      screw_torque_Nm: C.pyRound(reqLoad * leadN / 2 / Math.PI / 1000, 2),
      static_N: C.pyRound(staticN, 0),
      p_out_W: C.pyRound(pOut, 1), p_in_kW: C.pyRound(pInCalc / 1000, 3),
      platform_kW: C.pyRound(plat, 2), total_power_kW: C.pyRound(totalPower, 2),
      /**/
      motor_kW_actual: motorKwActual, motor_kW_slot: kwMax,
      four_pole: !!m.derived_4p,
      /**/
      derived_pole: m.derived_pole || null,
      derived_rpm: m.derived_rpm || null,
      derived_sync_rpm: m.derived_sync_rpm || null,
      four_pole_src_speed: m.derived_4p ? m.derived_src_speed : null,
      four_pole_src_kw: m.derived_4p ? m.derived_src_kw : null,
      all_pass: allPass
    };
    return { result: res };
  }

  /**/
  function evalCandidate(cand, cal, data) {
    var m = cand.mdef, fam = cand.fam;
    /*







*/
    if (cal.units > 1 && fam !== 'LAM' && cal.sync !== '电气'
      && (cal.drive === 'ac3' || cal.drive === 'ac1'
        || cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48')
      && m.motor && m.motor.kind === 'ac3') {
      return evalTwoPower(cand, cal, data);
    }
    var steps = [], checks = {}, warnings = [];
    var reqLoad = cal.load_N || 0, reqPull = cal.pull_N || 0;
    /**/
    var nInputRpm = null, inputInBand = null;
    /*
*/
    if (cal.units > 1) {
      /*
*/
      steps.push(['台数与布置', cal.sync === '电气'
        ? ('两台电气同步（' + (cal.layout || '电机内侧') + '）：每台 1 台电机独立直驱，'
          + '无传动轴与从动台，共 2 台同型号推杆')
        : ('两台机械同步（' + (cal.layout || '电机内侧') + '）：'
          + '电机侧 1 台主机经 1 根传动轴带动从动台 P2（双输入轴），共 2 台同型号推杆')]);
      steps.push(['单台负载', '总负载 ' + fN(cal.total_load_N, 0) + ' N ÷ ' + iN(cal.units) + ' 台 = '
        + fN(reqLoad, 0) + ' N（每台）'
        + (reqPull > 0 ? '；总拉力 ' + fN(cal.total_pull_N, 0) + ' N ÷ ' + iN(cal.units) + ' = ' + fN(reqPull, 0) + ' N（每台）' : '')
        + '；速度要求为系统速度，两台相同']);
    }

    /**/
    var ratedN0 = (fam === 'LAM') ? m.push_N : m.load_N;
    var loadUnder = 0;                       /**/
    if (ratedN0 == null || ratedN0 < reqLoad - 1e-6) {
      /*
*/
      var shortPct = (ratedN0 != null && reqLoad > 0) ? (reqLoad - ratedN0) / reqLoad : 1;
      if (fam === 'LAM' || ratedN0 == null || shortPct > ROD_LOAD_UNDER + 1e-9) {
        return { fatal: '额定推力不足', rated: ratedN0, req: reqLoad };
      }
      loadUnder = shortPct;
    }
    if (fam === 'LAM' && m.pull_N != null && reqPull > m.pull_N + 1e-6) {
      return { fatal: '额定拉力不足', rated: m.pull_N, req: reqPull };
    }
    checks['推力'] = true;
    steps.push(['推力校核', loadUnder
      ? ('额定 ' + fN(ratedN0, 0) + ' N ＜ 要求 ' + fN(reqLoad, 0) + ' N（欠 '
        + fN(loadUnder * 100, 1) + '%，≤' + Math.round(ROD_LOAD_UNDER * 100)
        + '% 按「备选口径」放行——只能做备选方案，须客户确认）')
      : ('额定 ' + fN(ratedN0, 0) + ' N ≥ 要求 ' + fN(reqLoad, 0) + ' N'
        + (reqPull > 0 ? '；额定拉力 ' + fN(m.pull_N, 0) + ' N ≥ 要求 ' + fN(reqPull, 0) + ' N' : ''))]);
    if (loadUnder) {
      warnings.push('额定推力 ' + fN(ratedN0, 0) + ' N 低于需求 ' + fN(reqLoad, 0) + ' N（欠 '
        + fN(loadUnder * 100, 1) + '%），仅作备选；如实际工况有冲击/偏载请上调一档。');
    }

    /**/
    if (fam === 'LAM' && cal.lam2_volt) {
      var vcap = (((data.lam35_specs || {}).voltPushCap || {})[cand.sub] || {})[String(cal.lam2_volt)];
      if (vcap != null && reqLoad > vcap + 1e-6) {
        return { fatal: 'DC' + cal.lam2_volt + 'V 下负载超限', detail: '该子系列 DC' + cal.lam2_volt + 'V 最大负载 '
          + fN(vcap, 0) + ' N（样本 p21），要求 ' + fN(reqLoad, 0) + ' N' };
      }
      if (vcap != null) {
        steps.push(['电压口径', 'DC' + cal.lam2_volt + 'V 下该子系列最大负载 ' + fN(vcap, 0) + ' N ≥ 要求 '
          + fN(reqLoad, 0) + ' N（LAM5 专门样本 p21）']);
      }
    }

    /**/
    var strokeMax = m.stroke_max;
    var potCut = (fam === 'LAM' && cal.lam2_fb === 'POT')
      ? (((data.lam35_specs || {}).potStrokeMax || {})[cand.sub + '-' + m.code]) : null;
    if (potCut != null) strokeMax = potCut;
    if (cal.stroke && strokeMax != null && cal.stroke > strokeMax + 1e-6) return { fatal: '行程超限' };
    checks['行程'] = true;
    /*
*/
    var extraStroke = !!(cal.stroke && cal.stroke > 800 + 1e-6);
    steps.push(['行程校核', strokeMax != null
      ? '型号最大行程 ' + iN(strokeMax) + ' mm ≥ 要求 ' + fN(cal.stroke, 0) + ' mm'
        + (potCut != null ? '（含电位计 POT 时该档上限 350 mm，样本 p12）' : '')
        + (extraStroke ? '；行程 >800mm 属加长行程（护管及伸缩管 +200mm，样本尺寸页注）' : '')
      : (cal.stroke ? '型号最大行程待样本确认（要求 ' + fN(cal.stroke, 0) + ' mm，超标准行程需与厂家确认）' : '型号最大行程待样本确认')]);

    /*
*/
    var vSampleTxt = '';
    if (fam === 'LAM') {
      /*



*/
      if (cal.speed_req != null) {
        var vMin = cal.speed_req * 0.8;
        if (m.v1 + 1e-9 < vMin) {
          return { fatal: '速度超限（满载 ' + fN(m.v1, 1) + ' mm/s 低于要求的 80%）' };
        }
      }
      checks['速度'] = true;
      var vShort = (cal.speed_req != null && m.v1 + 1e-9 < cal.speed_req);
      steps.push(['速度校核', vShort
        ? '档位满载速度 ' + fN(m.v1, 1) + ' mm/s（空载 ' + fN(m.v0, 1) + '）低于要求 '
          + fN(cal.speed_req, 1) + ' mm/s，差 ' + fN((cal.speed_req - m.v1) / cal.speed_req * 100, 1)
          + '%（≤20% 按接近口径放行）'
        : '档位满载速度 ' + fN(m.v1, 1) + ' mm/s（空载 ' + fN(m.v0, 1) + '）≥ 要求 '
          + fN(cal.speed_req, 1) + ' mm/s；是否超出型号最高速度已核对']);
      if (vShort) warnings.push('所选档位满载速度 ' + fN(m.v1, 1) + ' mm/s 略低于要求 '
        + fN(cal.speed_req, 1) + ' mm/s（差 ' + fN((cal.speed_req - m.v1) / cal.speed_req * 100, 1)
        + '%），按「接近口径」放行；如需完全达到要求请上调一档或与厂家确认。');
    } else {
      /*


*/
      if (cal.speed_req != null && m.speed + 1e-9 < cal.speed_req * (1 - ROD_SPEED_UNDER)) {
        return { fatal: '速度超限', v_sample: m.speed, v_req: cal.speed_req };
      }
      checks['速度'] = true;
      var vUnderLap = (cal.speed_req != null && m.speed + 1e-9 < cal.speed_req);
      vSampleTxt = vUnderLap
        ? '型号样本档位速度 ' + fN(m.speed, 1) + ' mm/s 低于要求 ' + fN(cal.speed_req, 1) + ' mm/s，差 '
          + fN((cal.speed_req - m.speed) / cal.speed_req * 100, 1) + '%（≤'
          + Math.round(ROD_SPEED_UNDER * 100) + '% 按接近口径放行）'
        : '型号样本档位速度 ' + fN(m.speed, 1) + ' mm/s ≥ 要求 ' + fN(cal.speed_req, 1) + ' mm/s';
      if (vUnderLap) warnings.push('所选型号样本档位速度 ' + fN(m.speed, 1) + ' mm/s 略低于要求 '
        + fN(cal.speed_req, 1) + ' mm/s（差 ' + fN((cal.speed_req - m.speed) / cal.speed_req * 100, 1)
        + '%），按「接近口径（≤' + Math.round(ROD_SPEED_UNDER * 100) + '%）」放行；如需完全达到要求请上调一档或与厂家确认。');
    }

    /*

*/
    if (cal.units > 1 && cal.sync !== '电气' && cal.speed_req != null) {   /**/
      var dpN = (data.drive_params || {})[cand.model] || {};
      var iSN = num(dpN.i), leadN = num(dpN.lead) || num(m.lead);
      if (iSN && leadN) {
        var nIn = cal.speed_req * 60 / leadN * iSN;
        var inBandN = (nIn >= 500 - 1e-9 && nIn <= 1000 + 1e-9);
        nInputRpm = Math.round(nIn); inputInBand = inBandN;
        steps.push(['输入转速', '要求速度 ' + fN(cal.speed_req, 2) + ' mm/s × 60 ÷ 导程 ' + fN(leadN, 1)
          + ' mm × 减速比 ' + iSN + ' = ' + fN(nIn, 0) + ' rpm'
          + (nIn > 1500 + 1e-9
            ? '（> 1500rpm 上限，两台联动不可用——须加大导程或降低速度）'
            : (inBandN ? '（≤1500rpm 上限，落在 500~1000rpm 优先区间）' : '（≤1500rpm 上限，未落在 500~1000rpm 优先区间）'))]);
        if (nIn > 1500 + 1e-9
          && cal.drive !== 'servo220' && cal.drive !== 'servo380' && cal.drive !== 'stepping') {
          return { fatal: '输入转速超限（两台联动 1500rpm）', n_input_rpm: Math.round(nIn) };
        }
      }
    }

    /*

*/
    var servo = servoCalc(data, m, fam, cand, cal, reqLoad);
    /*
*/
    if (cal.units > 1 && servo && servo.rpm_over) {
      return { fatal: '输入转速超限（' + (cal.sync === '电气' ? ('伺服额定 ' + Math.round(servo.rpm_cap || 3000) + 'rpm')
        : '两台联动 1500rpm') + '，需 '
        + (servo.n_screw_rpm ? Math.round(servo.n_screw_rpm * servo.i) : '') + 'rpm）' };
    }

    /**/
    var stab = { ok: true, msg: null, lk: null };
    if (fam === 'LAM') {
      checks['稳定性'] = null;
      var lamNote = (cal.stroke && cal.stroke > 300)
        ? 'LAM 系列行程 >300mm，样本要求稳定性与力姆泰克工程师确认（本方案不自动校核）'
        : 'LAM 系列按口径不做稳定性校核（行程 ≤300mm）';
      steps.push(['稳定性校核', lamNote]);
      if (cal.stroke && cal.stroke > 300) warnings.push(lamNote);
    } else {
      stab = stabilityCheck(data, cand.sub, reqLoad, cal.stroke);
      checks['稳定性'] = stab.ok;
      steps.push(['稳定性校核', stab.msg || '行程 ≤300mm 或拉力工况，按样本不校核稳定性']);
      if (!stab.ok) return { fatal: '稳定性不足', stability_Lk_mm: stab.lk, stab_msg: stab.msg };
      if (!(data.stability || {})[cand.sub] && cal.stroke && cal.stroke > 300) {
        var noCurve = '该型号（' + cand.sub + '）稳定性曲线未收录，行程 >300mm 请与力姆泰克工程师确认稳定性';
        warnings.push(noCurve);
        steps.push(['稳定性校核（补充）', noCurve]);
      }
    }

    /**/
    var duty = dutyCheck(fam, cand.sub, cal.cycles_per_day, cal.speed_req, ratedN0, reqLoad);
    checks['工作制'] = duty[0];
    steps.push(['工作制校核', duty[1]]);
    if (duty[0] === false) warnings.push('【系列选择原则警告】' + duty[1]);
    /*

*/
    if (fam === 'LAM' && cal.cycles_per_day != null && cal.cycles_per_day > 50) {
      warnings.push('【系列选择原则警告】每日工作次数 ' + iN(cal.cycles_per_day)
        + ' 次已超小型推杆（LAM）50 次/日上限，建议改选 LAP 梯形丝杠或 LBP 滚珠丝杠系列（可承受更高使用频次）。');
    }

    /**/
    var selfLock = selfLockOf(m, fam);
    var brakeNeeded = !selfLock;
    steps.push(['自锁校核', selfLock
      ? '该型号自锁（' + (fam === 'LAP' ? '自锁系数 ' + m.lock + ' ≤ 0.25' : '样本自锁') + '），电机可不加制动器'
      : (fam === 'LAP' ? '自锁系数 ' + m.lock + ' > 0.25，不自锁，电机须配制动器'
        : fam === 'LBP' ? '滚珠丝杠不自锁，电机须配制动器' : '滚珠丝杠结构不自锁，电机配制动器')]);
    /*
*/
    if (brakeNeeded) warnings.push('该型号不自锁，制动器随电机内置（清单不另列 BRE）。');

    /**/
    var life = null;
    if (fam === 'LBP') {
      life = lifeCheck(data, m, cand.sub, reqLoad, cal.stroke, cal.cycles_per_day, cal.days_per_year);
      if (life) {
        checks['寿命'] = life.pass;
        steps.push(['寿命校核', '滚珠丝杠 L10 理论寿命 ' + fN(life.life_km, 0) + ' km'
          + (life.annual_km != null ? '，年用 ' + fN(life.annual_km, 0) + ' km' : '')
          + (life.years != null ? '，约 ' + fN(life.years, 1) + ' 年（要求 ≥5 年）' : '')
          + '；' + life.note]);
        if (!life.pass) return { fatal: '寿命不足', life: life };
      } else {
        checks['寿命'] = null;
        steps.push(['寿命校核', '梯形丝杠寿命无理论计算（LAP 系列同口径）；本型号动载参数待样本确认']);
      }
    } else {
      checks['寿命'] = null;
      steps.push(['寿命校核', fam === 'LAM' ? 'LAM 小型推杆按样本寿命（约 1 万次）与工作制核对，不做 L10 计算'
        : '梯形丝杠寿命无理论计算（样本注明），按工作制与维护确认']);
    }

    /**/
    if (servo) {
      checks['伺服计算'] = true;
      var sSteps = servoSteps(servo);
      sSteps.forEach(function (x) { steps.push(x); });
      if (vSampleTxt && servo.n_req_rpm != null) steps[steps.length - 1][1] += '；' + vSampleTxt;
      if (servo.warn) warnings.push(servo.warn);
      if (servo.warn2) warnings.push(servo.warn2);
    } else if (vSampleTxt) {
      steps.push(['速度校核', vSampleTxt]);
    }

    /*




*/
    var dcM233 = null;
    var isDcDrv233 = (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48');
    if (!servo && isDcDrv233
      && (fam === 'LAM' || (m.motor && m.motor.kind === 'dc24')
        || ((fam === 'LAP' || fam === 'LBP') && rodDcBase233(cand.model)))) {
      /*



*/
      var mAc233 = (fam === 'LAP' || fam === 'LBP') && rodDcBase233(cand.model) && m.motor
        && m.motor.kind !== 'dc24' && num(m.motor.kw) > 0 && num(m.motor.rpm) > 0 ? m.motor : null;
      if (mAc233) {
        var kwA233 = num(mAc233.kw), rpmA233 = num(mAc233.rpm);
        dcM233 = {
          src: 'ac',
          p_kw: kwA233, rpm_main: rpmA233,
          t_nm: Math.ceil(9550 * kwA233 / rpmA233 * 10) / 10,
          volts: [String({ dc12: 12, dc24: 24, dc48: 48 }[cal.drive] || 24)]
        };
        /*
*/
        var dcTwinA233 = data.models[String(cand.model) + '-DC'];
        if (dcTwinA233 && dcTwinA233.motor && dcTwinA233.motor.A != null) {
          dcM233.amp_a = Number(dcTwinA233.motor.A);
        }
      } else {
        var dpD233 = (data.drive_params || {})[cand.model] || {};
        var effD233 = num(dpD233.eff);
        /**/
        var vSmpD233 = (fam === 'LAM') ? m.v1 : m.speed;
        var vD233 = (cal.speed_req != null) ? Math.min(cal.speed_req, vSmpD233) : vSmpD233;
        var pMech233 = reqLoad * vD233 / 1000;                                        //
        var pNeed233 = (effD233 > 0 && effD233 <= 1) ? pMech233 / effD233 : pMech233; //
        /*


*/
        var kEnv233 = envCoefOf(cal.temp);
        var dcVar233 = (fam === 'LAP' || fam === 'LBP') && m.motor && m.motor.kind === 'dc24';
        var pNeedK233 = (dcVar233 && kEnv233 !== 1) ? pNeed233 * kEnv233 : pNeed233;
        var pKw233 = Math.max(0.1, Math.ceil(pNeedK233 / 100 - 1e-9) / 10);           //
        var rpmMain233 = (pKw233 <= 0.4 + 1e-9) ? 1500 : 3000;
        var rpmAlt233 = (rpmMain233 === 1500) ? 3000 : 1500;
        var pAlt233 = Math.round((pKw233 + 0.1) * 10) / 10;
        dcM233 = {
          src: 'calc',
          p_kw: pKw233, rpm_main: rpmMain233,
          t_nm: Math.ceil(9550 * pKw233 / rpmMain233 * 10) / 10,
          p_kw_alt: pAlt233, rpm_alt: rpmAlt233,
          t_nm_alt: Math.ceil(9550 * pAlt233 / rpmAlt233 * 10) / 10,
          volts: [String({ dc12: 12, dc24: 24, dc48: 48 }[cal.drive] || 24)],
          eff_src: (effD233 > 0 && effD233 <= 1) ? 'sample' : 'mech',
          p_kw_base: (dcVar233 && kEnv233 !== 1) ? Math.max(0.1, Math.ceil(pNeed233 / 100 - 1e-9) / 10) : null,
          env_coef: (dcVar233 && kEnv233 !== 1) ? kEnv233 : null
        };
      }
    }

    /*

*/
    var kEnv = envCoefOf(cal.temp);
    var envOk = true, envShort = null;
    /*



*/
    var dcCalcF = !!(dcM233 && dcM233.src === 'calc');
    /*




*/
    var dcVarF = !!(m.motor && m.motor.kind === 'dc24' && (fam === 'LAP' || fam === 'LBP'));
    if (kEnv !== 1 && !servo && (!dcCalcF || dcVarF)) {
      var dpE = (data.drive_params || {})[cand.model] || {};
      var effE = num(dpE.eff);
      var kwE = (m.motor && num(m.motor.kw)) || 0;
      if (dcVarF && !(kwE > 0)) {
        var twinKeyE = String(cand.model).replace(/-DC$/i, '');
        var twinE = data.models[twinKeyE];
        if (twinE && twinE.motor) {
          kwE = num(twinE.motor.kw) || 0;
          if (!(effE > 0)) effE = num(((data.drive_params || {})[twinKeyE] || {}).eff);
        }
      }
      if (kwE > 0 && effE) {
        var vEnv = (cal.speed_req != null) ? Math.min(cal.speed_req, m.speed) : m.speed;
        var pShaft = reqLoad * vEnv / 1000 / effE;      //
        var pNeed = pShaft * kEnv;
        var pMot = kwE * 1000;
        if (pNeed > pMot + 1e-6) {
          envOk = false;
          envShort = { need_kw: C.pyRound(pNeed / 1000, 3), motor_kw: kwE };
          warnings.push('工作温度 ' + cal.temp + '℃：按 ×' + fN(kEnv, 1) + ' 后所需轴功率 '
            + fN(pNeed / 1000, 3) + ' kW ＞ 样本标配电机 ' + kwE
            + (Number(cal.temp) >= 80
              ? ' kW，本档电机容量不足——建议上调基型或定制高温电机，与厂家确认'
              : ' kW，本档电机容量不足——建议上调基型或定制低温电机，与厂家确认'));
        }
        steps.push(['环境系数', (envNoteOf(cal.temp) || ('工作温度 ' + cal.temp + '℃ 非标工况'))
          + ' → 所需轴功率 ' + fN(pShaft / 1000, 3) + ' kW ×' + fN(kEnv, 1) + ' = ' + fN(pNeed / 1000, 3)
          + ' kW' + (envOk ? ' ≤ 样本标配电机 ' + kwE + ' kW' : ' ＞ 样本标配电机 ' + kwE + ' kW（容量不足）')]);
      }
    }
    if (cal.temp === '-40' || cal.temp === '-30' || cal.temp === '80') {
      /**/
      warnings.push(Number(cal.temp) >= 80
        ? '工作温度 ' + cal.temp + '℃ 为非标工况，须按高温定制（高温电机、高温润滑脂），与厂家确认。'
        : '工作温度 ' + cal.temp + '℃ 为非标工况，须按低温/高温定制（低温电机、特种润滑脂），与厂家确认。');
    }
    /**/
    if (extraStroke) {
      warnings.push('行程 ' + fN(cal.stroke, 0) + ' mm 属加长行程（>800mm）：样本要求护管及伸缩管各加长 200mm，'
        + '外形总长与安装空间请按加长后尺寸确认。');
    }
    /**/
    if (String(cal.limit_sw || 'STD') === 'NONE') {
      warnings.push('已选「无限位开关」：本机不配行程限位开关，行程两端保护需外置限位开关或由客户控制系统实现，'
        + '请确认使用端已做限位/过载保护。');
    }

    var allPass = Object.keys(checks).every(function (k) { return checks[k] !== false; });
    var res = {
      model: cand.model, fam: fam, sub: cand.sub, code: cand.code, family: famName(fam),
      mdef: m, checks: checks, steps: steps, warnings: warnings,
      rated_N: ratedN0, rated_kN: C.pyRound(ratedN0 / 1000, 2),
      v0: m.v0, v1: m.v1, speed_mm_s: (fam === 'LAM') ? m.v1 : m.speed,
      /*
*/
      speed_req: (fam === 'LAM') ? null : (cal.speed_req != null ? cal.speed_req : null),
      speed_under_max: (fam === 'LAM') ? null : Math.round(ROD_SPEED_UNDER * 100),
      speed_under_pct: (fam === 'LAM') ? null
        : ((cal.speed_req != null && m.speed + 1e-9 < cal.speed_req)
          ? C.pyRound((cal.speed_req - m.speed) / cal.speed_req * 100, 1) : null),
      /**/
      load_under_pct: loadUnder ? C.pyRound(loadUnder * 100, 1) : null,
      load_under_max: (fam === 'LAM') ? null : Math.round(ROD_LOAD_UNDER * 100),
      load_req_N: reqLoad,
      /**/
      units: cal.units || 1,
      layout: cal.layout || '',
      sync: cal.sync || '机械',   /**/
      platform_L: cal.platform_L || null,
      n_input_rpm: nInputRpm,
      input_in_band: inputInBand,
      total_load_N: cal.total_load_N != null ? cal.total_load_N : reqLoad,
      total_pull_N: cal.total_pull_N != null ? cal.total_pull_N : reqPull,
      load_short: loadUnder > 0,
      stroke_max: m.stroke_max, motor: m.motor || null,
      /**/
      extra_stroke: extraStroke,
      duty: m.duty || null, lock: (fam === 'LAP') ? m.lock : null,
      self_lock: selfLock, brake_required: brakeNeeded,
      stability_Lk_mm: stab.lk,
      life: life, life_km: life ? life.life_km : null, annual_km: life ? life.annual_km : null,
      load_rate: duty[2],
      accessories: cal.accessories.slice(),
      install: cal.install, input_dir: cal.input_dir, joint: cal.joint,
      servo_calc: servo,
      /**/
      dc_motor: dcM233,
      /**/
      env_coef: kEnv, env_ok: envOk, env_short: envShort,
      /*
*/
      temp: cal.temp,
      /**/
      motor_torque_Nm: servo ? servo.t_motor_nm : null,
      motor_power_kW: servo ? servo.p_req_kw : null,
      motor_sync: servo ? servo.n_motor_rpm : null,
      gear_ratio: servo ? servo.gear : null,
      gear_eta: servo ? servo.gear_eta : null,
      screw_torque_Nm: servo ? servo.t_screw_nm : null,
      all_pass: allPass
    };
    return { result: res };
  }

  /**/
  function driveAllowed(mdef, cal) {
    var d = cal.drive;
    /**/
    if (d === 'dc24' || d === 'dc12' || d === 'dc48') {
      if (mdef.motor ? mdef.motor.kind === 'dc24' : !mdef.ac) return true;
      /*


*/
      if (d === 'dc24') {
        var nDc = /^LAP(\d+)$/.exec(String(mdef.sub || ''));
        if (nDc) return Number(nDc[1]) >= 22 && Number(nDc[1]) <= 56;
        nDc = /^LBP(\d+)$/.exec(String(mdef.sub || ''));
        if (nDc) return Number(nDc[1]) >= 25 && Number(nDc[1]) <= 56;
      }
      return false;
    }
    if (d === 'ac1' || d === 'ac3') return mdef.motor ? mdef.motor.kind === 'ac3' : !!mdef.ac;  //
    if (d === 'hand') return mdef.motor ? mdef.motor.kind === 'ac3' : !!mdef.ac;   //
    /**/
    if (d === 'servo220' || d === 'servo380' || d === 'stepping') return mdef.motor ? mdef.motor.kind === 'ac3' : false;
    return true;
  }

  /*






*/
  /*






*/
  var ROD_SPEED_UNDER = 0.20;
  /*


*/
  var ROD_SPEED_OVER = 0.2;
  /**/
  function speedBand(spd, req) {
    if (req == null || !(req > 0)) return 0;              /**/
    if (spd + 1e-9 >= req) return (spd <= req * (1 + ROD_SPEED_OVER) + 1e-9) ? 0 : 1;
    return ((req - spd) / req <= ROD_SPEED_UNDER + 1e-9) ? 0 : 1;
  }
  /*


*/
  var ROD_LOAD_UNDER = 0.10;
  /*



*/
  var ROD_TQ_UNDER = 0.02;
  function sortKey(cand, cal) {
    var m = cand.mdef;
    var ratedN = (cand.fam === 'LAM') ? m.push_N : m.load_N;
    var marg = ratedN - (cal.load_N || 0);
    var spd = (cand.fam === 'LAM') ? m.v1 : m.speed;
    var dSpd = cal.speed_req != null ? Math.abs(spd - cal.speed_req) : 0;
    if (cand.fam === 'LAM') return [dSpd, marg, 0, 0, cand.model];
    /*





*/
    var band = speedBand(spd, cal.speed_req);
    /*

*/
    var poleRank = 0;
    if (m.derived_4p) poleRank = (m.derived_rpm === 1400) ? 1 : ((m.derived_rpm === 950) ? 2 : 3);
    return [band, marg, dSpd, poleRank, cand.model];
  }
  function cmpKey(a, b) {
    for (var i = 0; i < a.length; i++) {
      if (a[i] < b[i]) return -1;
      if (a[i] > b[i]) return 1;
    }
    return 0;
  }

  /*

*/
  function rodUnmetTxt(f) {
    var why = String((f && f.fatal) || '');
    if (!why) return '';
    /**/
    if (why === '行程超限' || why === '额定推力不足') return '';
    if (why === '额定拉力不足') {
      return why + '（额定拉力 ' + fN(f.rated, 0) + ' N < 要求 ' + fN(f.req, 0) + ' N）';
    }
    if (why === '稳定性不足') {
      if (f.stability_Lk_mm != null) return why + '（允许行程约 ' + fN(f.stability_Lk_mm, 0) + ' mm）';
      return why + (f.stab_msg ? '（' + f.stab_msg + '）' : '');
    }
    if (why === '寿命不足') {
      var lf = f.life || {};
      var need = (lf.annual_km != null && lf.req_years) ? lf.annual_km * lf.req_years : null;
      return why + '（理论寿命 ' + fN(lf.life_km, 0) + ' km'
        + (need != null ? ' < 需要 ' + fN(need, 0) + ' km（' + lf.req_years + ' 年）' : '') + '）';
    }
    if (why === '速度超限' && f.v_sample != null && f.v_req != null) {
      return '速度达不到（样本档位速度 ' + fN(f.v_sample, 1) + ' mm/s < 要求 ' + fN(f.v_req, 1)
        + ' mm/s，差 ' + fN((f.v_req - f.v_sample) / f.v_req * 100, 1) + '%）';
    }
    if (f.detail) return why + '（' + f.detail + '）';
    return why;
  }
  /*
*/
  function rodPartialTxt(res) {
    var keys = Object.keys(res.checks || {}).filter(function (k) { return res.checks[k] === false; });
    if (!keys.length) return '部分校核未通过';
    return '部分校核未通过：' + keys.map(function (k) {
      var txt = '';
      (res.steps || []).forEach(function (s) {
        if (!txt && String(s[0]).indexOf(k) === 0) txt = String(s[1] || '');
      });
      txt = String(txt).replace(/^[^：]*超出选择原则：/, '').replace(/[；;]建议改选系列或与厂家技术确认$/, '');
      return k + (txt ? '（' + txt + '）' : '');
    }).join('；');
  }

  /* ---------------- autoSelect ---------------- */
  function autoSelect(inp, data) {
    var cal = toCalc(inp, data);
    var out = { cal: cal, schemes: [], skipped: [], processUnmet: [], warnings: [] };
    if (!cal.load_N && !cal.pull_N) { out.error = '请至少填写总负载推力或总负载拉力'; return out; }

    /**/
    var lamSubs = null;
    if (cal.fam === 'LAM' && cal.lam_group) {
      var grp = (data.lam_series || []).filter(function (x) { return x.v === cal.lam_group; })[0];
      if (grp && Array.isArray(grp.subs) && grp.subs.length) lamSubs = grp.subs;
    }

    /*

*/
    var mainTrials = [];
    var trialsBySize = null;
    /*

*/
    var leadReqRod = C.leadReqOf(cal.special_texts, cal.special);
    function leadRodOk(lead) { return !(leadReqRod > 0) || (lead > 0 && Math.abs(lead - leadReqRod) < 1e-9); }
    /*












*/
    var ROD_DERIVED_RPM = [1400, 950, 700];   /**/
    /*



*/
    var ROD_DERIVED_MAIN = [1400, 950];
    var ROD_DERIVED_BACKUP = [700];
    function derivedPoleOf(k, m) {
      if (!(Number(cal.units) > 1)) return null;
      if (m.fam !== 'LAP' && m.fam !== 'LBP') return null;
      var mt = m.motor || {};
      if (mt.kind !== 'ac3' || !(Number(mt.rpm) >= 2800)) return null;
      var dpA = (data.drive_params || {})[k] || {};
      var leadA = num(dpA.lead) || 0, iA = num(dpA.i) || 0;
      if (!leadA || !iA || !(num(m.speed) > 0)) return null;
      var srcRpm = Number(mt.rpm) || 2800;
      var speedReq = (cal.speed_req != null && cal.speed_req > 0) ? cal.speed_req : null;
      /**/
      function hasNativeAt(rpm) {
        return Object.keys(data.models).some(function (kk) {
          var mm = data.models[kk], dd = (data.drive_params || {})[kk] || {};
          if (mm.fam !== m.fam || mm.sub !== m.sub || !mm.motor) return false;
          if (Math.abs((num(dd.lead) || 0) - leadA) > 1e-9) return false;
          if (Math.abs((num(dd.i) || 0) - iA) > 1e-9) return false;
          var r0 = Number(mm.motor.rpm);
          return r0 > 0 && Math.abs(r0 - rpm) / rpm <= 0.05;
        });
      }
      /*



*/
      var P4_OVERRIDE = { 'LAP32-H1a': 1 };
      /**/
      function buildOn(rpmList) {
      /*
*/
      var pick = null, bestGap = Infinity;
      for (var ii = 0; ii < rpmList.length; ii++) {
        var rpm = rpmList[ii];
        var v = num(m.speed) * rpm / srcRpm;
        if (!(v > 0)) continue;
        if (hasNativeAt(rpm) && !(P4_OVERRIDE[k] && rpm === 1400)) continue;
        if (speedReq != null && v + 1e-9 < speedReq * (1 - ROD_SPEED_UNDER)) continue;
        var gap = (speedReq != null) ? Math.abs(v - speedReq) : 0;
        if (gap < bestGap - 1e-12) { bestGap = gap; pick = { rpm: rpm, speed: v }; }
      }
      if (!pick) return null;
      /*




*/
      var baseMax = 0;
      Object.keys(data.models).forEach(function (kk) {
        var mm = data.models[kk];
        if (mm.fam === m.fam && mm.sub === m.sub && num(mm.load_N) > baseMax) baseMax = num(mm.load_N);
      });
      var kwSlot = num(mt.kw);   /**/
      var clone = {};
      Object.keys(m).forEach(function (kk) { clone[kk] = m[kk]; });
      clone.speed = pick.speed;
      clone.derived_4p = true;                     /**/
      clone.derived_rpm = pick.rpm;
      clone.derived_sync_rpm = (pick.rpm === 1400) ? 1500 : ((pick.rpm === 950) ? 1000 : 750);
      clone.derived_pole = (pick.rpm === 1400) ? '4 极' : ((pick.rpm === 950) ? '6 极' : '8 极');
      clone.derived_src_speed = num(m.speed);
      clone.derived_src_kw = num(mt.kw);
      clone.derived_src_load = num(m.load_N);
      clone.motor = { kind: 'ac3', kw: kwSlot, rpm: pick.rpm };
      var cand0 = { model: k, fam: m.fam, sub: m.sub, code: m.code, mdef: clone, family: famName(m.fam),
        derived4p: true, derived_pole: pick.rpm };
      /*
*/
      var trialLoad = Math.max(num(m.load_N) || 0, num(cal.load_N) || 0);
      if (!(trialLoad > 0)) return null;
      clone.load_N = trialLoad;
      var r0 = evalCandidate(cand0, cal, data);
      if (!r0 || r0.fatal || !r0.result || !(r0.result.p_in_kW > 0)) return null;
      var etaUsed = r0.result.p_out_W / (r0.result.p_in_kW * 1000);
      if (!(etaUsed > 0)) return null;
      /*
*/
      var fCap = kwSlot * 1000 * etaUsed * 1000 / clone.speed;
      if (baseMax > 0 && fCap > baseMax) fCap = baseMax;
      var r1 = null;
      for (var gt = 0; gt < 5; gt++) {
        clone.load_N = fCap;
        r1 = evalCandidate(cand0, cal, data);
        if (r1 && !r1.fatal) break;
        /**/
        if (!(r1 && /输入功率超限/.test(r1.fatal))) break;
        fCap = fCap * 0.98;
      }
      if (!r1 || r1.fatal) return null;
      return { cand: cand0, res: r1 };
      }
      /**/
      return buildOn(ROD_DERIVED_MAIN) || buildOn(ROD_DERIVED_BACKUP);
    }
    function candidatesOf(famFilter) {
      var list = [], trials = [];
      Object.keys(data.models).forEach(function (k) {
        var m = data.models[k];
        if (m.fam !== famFilter) return;
        if (famFilter === 'LAM' && lamSubs && lamSubs.indexOf(m.sub) < 0) return;
        if (!driveAllowed(m, cal)) return;
        /*




*/
        if (/-DC$/i.test(k) && data.models[String(k).replace(/-DC$/i, '')]) return;
        var dp0 = (data.drive_params || {})[k] || {};
        var lead0 = num(dp0.lead) || num(m.lead) || 0;
        /**/
        if (leadReqRod > 0 && lead0 > 0 && !leadRodOk(lead0)) {
          out.skipped.push({ model: k, why: '导程 ' + lead0 + 'mm 非要求的 ' + leadReqRod + 'mm（样本固定导程型号）' });
          return;
        }
        var cand = { model: k, fam: m.fam, sub: m.sub, code: m.code, mdef: m, family: famName(m.fam) };
        var r = evalCandidate(cand, cal, data);
        var dp = (data.drive_params || {})[k] || {};
        var it = {
          cand: cand, key: sortKey(cand, cal), rec: null, fatal: null,
          rated: (cand.fam === 'LAM') ? m.push_N : m.load_N,
          size: Number(String(cand.sub).replace(/[^0-9]/g, '')) || 0,
          lead: num(dp.lead) || num(m.lead) || 0,
          ratio: num(dp.i) || 0
        };
        if (r.fatal) { out.skipped.push({ model: k, why: r.fatal }); it.fatal = r; }
        else {
          it.rec = { result: r.result, allPass: r.result.all_pass };
          /**/
          it.envOk = (r.result.env_ok !== false);
          /**/
          it.inBand = (r.result.input_in_band === true);
          list.push(it);
        }
        trials.push(it);
        /*
*/
        var fp = derivedPoleOf(k, m);
        if (fp && !fp.res.fatal) {
          var itd = {
            cand: fp.cand, key: sortKey(fp.cand, cal), rec: null, fatal: null,
            rated: m.load_N, size: it.size, lead: it.lead, ratio: it.ratio, derived4p: true,
            derived_pole: fp.cand.derived_pole
          };
          itd.rec = { result: fp.res.result, allPass: fp.res.result.all_pass };
          itd.envOk = (fp.res.result.env_ok !== false);
          itd.inBand = (fp.res.result.input_in_band === true);
          list.push(itd);
        }
      });
      list.sort(function (a, b) {
        var two = cal.units > 1;
        return ((a.envOk === false ? 1 : 0) - (b.envOk === false ? 1 : 0))
          || (two ? ((a.inBand ? 0 : 1) - (b.inBand ? 0 : 1)) : 0)
          || cmpKey(a.key, b.key);
      });
      trials.sort(function (a, b) { return cmpKey(a.key, b.key); });
      if (famFilter === cal.fam) {
        mainTrials = trials;
        /*
*/
        trialsBySize = trials.slice().sort(function (a, b) {
          return (a.size - b.size) || (a.lead - b.lead) || String(a.cand.code).localeCompare(String(b.cand.code));
        });
      }
      return list;
    }

    var main = candidatesOf(cal.fam);

    /*








*/
    var rodForcedLock = false;
    var ROD_FOREIGN_RE = /(^|[^A-Za-z0-9])(SJA|SJB|SCA|SCB|KV|EHB|DHB|DMB|EMB|FMR|GTR)(?![0-9]*[A-Za-z])/;
    var forcedRod = (function () {
      var tx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
      var checked = Array.isArray(cal.special) ? cal.special : [];
      var joined = Object.keys(tx)
        .filter(function (k) { return checked.indexOf(k) >= 0; })
        .map(function (k) { return String(tx[k] || ''); }).join(' ').toUpperCase();
      if (!joined) return { subs: [], multi: false };
      var fForeign = ROD_FOREIGN_RE.exec(joined);
      var foreign = fForeign ? fForeign[2] : null;
      var subs = [];
      Object.keys(data.models).forEach(function (k) {
        var s = data.models[k].sub;
        if (!s || subs.indexOf(s) >= 0) return;
        if (new RegExp('(^|[^A-Za-z0-9])' + s + '(?![0-9A-Za-z])').test(joined)) subs.push(s);
      });
      if (subs.length <= 1) return { subs: subs, multi: false, foreign: foreign };
      subs.sort(function (a, b) {
        return (Number(String(b).replace(/[^0-9]/g, '')) || 0) - (Number(String(a).replace(/[^0-9]/g, '')) || 0);
      });
      return { subs: [subs[0]], multi: true, foreign: foreign };
    })();
    if (forcedRod.foreign) {
      out.warnings.push('特殊要求中的型号 ' + forcedRod.foreign
        + ' 不属于推杆产品线，无法执行——请检查特殊要求');
    }
    if (forcedRod.subs.length) {
      var subF = forcedRod.subs[0];
      var subFam = null, subWhy = '';
      Object.keys(data.models).forEach(function (k) {
        if (data.models[k].sub === subF && !subFam) subFam = data.models[k].fam;
      });
      if (subFam && subFam !== cal.fam) {
        out.warnings.push('特殊要求指定型号 ' + subF + ' 属于 ' + famName(subFam)
          + ' 系列，与当前所选系列（' + famName(cal.fam) + '）不一致，已忽略——请切换型号系列后重新选型');
      } else {
        var fList = [];
        Object.keys(data.models).forEach(function (k) {
          var m = data.models[k];
          if (m.sub !== subF) return;
          if (!driveAllowed(m, cal)) return;
          var dpF = (data.drive_params || {})[k] || {};
          var leadF = num(dpF.lead) || num(m.lead) || 0;
          /*
*/
          if (leadReqRod > 0 && leadF > 0 && !leadRodOk(leadF)) {
            if (!subWhy) subWhy = k + '：无导程 ' + leadReqRod + 'mm 档（样本固定 ' + leadF + 'mm）';
            return;
          }
          var candF = { model: k, fam: m.fam, sub: m.sub, code: m.code, mdef: m, family: famName(m.fam) };
          var rF = evalCandidate(candF, cal, data);
          var itF = {
            cand: candF, key: sortKey(candF, cal), rec: null, fatal: null,
            rated: (candF.fam === 'LAM') ? m.push_N : m.load_N,
            size: Number(String(candF.sub).replace(/[^0-9]/g, '')) || 0,
            lead: num(dpF.lead) || num(m.lead) || 0,
            ratio: num(dpF.i) || 0
          };
          if (rF.fatal) { itF.fatal = rF; if (!subWhy) subWhy = k + '：' + rF.fatal; }
          else {
            itF.rec = { result: rF.result, allPass: rF.result.all_pass };
            if (!itF.rec.allPass && !subWhy) {
              subWhy = k + '：部分校核未通过（' + Object.keys(rF.result.checks || {})
                .filter(function (kk) { return rF.result.checks[kk] === false; }).join('、') + '）';
            }
          }
          fList.push(itF);
        });
        var fPass = fList.filter(function (it) { return it.rec && it.rec.allPass; });
        if (forcedRod.multi) out.warnings.push('特殊要求中出现多个型号代号，按规格最大者执行：' + subF);
        if (fPass.length) {
          out.warnings.push('已按特殊要求指定型号选型：' + subF);
          main = fPass;
          rodForcedLock = true;
        } else {
          out.warnings.push('特殊要求指定型号 ' + subF + '：'
            + (fList.length ? '没有通过全部校核的档位' + (subWhy ? '（' + subWhy + '）' : '')
              : '当前驱动方式下无可用档位')
            + '，已按通用规则选型，请与厂家技术确认');
        }
      }
    }

    if (!main.length) {
      /**/
      var famHasLead = false;
      Object.keys(data.models).forEach(function (k) {
        if (famHasLead) return;
        var m = data.models[k];
        if (m.fam !== cal.fam) return;
        var dpE = (data.drive_params || {})[k] || {};
        if ((num(dpE.lead) || num(m.lead) || 0) > 0) famHasLead = true;
      });
      out.error = '在 ' + famName(cal.fam) + (cal.fam === 'LAM' && cal.lam_group ? '（' + cal.lam_group + ' 系列）' : '')
        + (leadReqRod > 0 && famHasLead
          ? ' 系列中未找到导程为 ' + leadReqRod + 'mm 的型号（该系列现有导程档见选型过程）：'
            + '请核对导程要求或与力姆泰克工程师沟通非标导程'
          : ' 系列中未找到满足（推力/速度/行程/稳定性/寿命）要求的型号，'
            + '请调整参数或改选其它系列');
      return out;
    }

    /*

*/
    var passList = main.filter(function (it) { return it.rec.allPass; });
    var failList = main.filter(function (it) { return !it.rec.allPass; });
    var picked = [], seenSub = {};
    var tierNames;
    if (cal.fam === 'LAM') {
      /**/
      var lamKinds = [];
      function pickFrom(list, kind) {
        list.forEach(function (it) {
          if (picked.length >= 3) return;
          if (picked.length < 2 && seenSub[it.cand.sub]) return;
          seenSub[it.cand.sub] = true;
          picked.push(it);
          lamKinds.push(kind);
        });
      }
      pickFrom(passList, 'in');
      pickFrom(failList, 'fail');
      /*


*/
      if (picked.length < 3 && !rodForcedLock && lamSubs && lamSubs.length && cal.fam === 'LAM') {
        var lamOther = [];
        Object.keys(data.models).forEach(function (k) {
          var m = data.models[k];
          if (m.fam !== 'LAM' || lamSubs.indexOf(m.sub) >= 0) return;
          if (!driveAllowed(m, cal)) return;
          var cand2 = { model: k, fam: m.fam, sub: m.sub, code: m.code, mdef: m, family: famName(m.fam) };
          var r2 = evalCandidate(cand2, cal, data);
          if (r2.fatal || !r2.result || !r2.result.all_pass) return;
          lamOther.push({ cand: cand2, key: sortKey(cand2, cal), rec: { result: r2.result, allPass: true } });
        });
        function okSpeed(it) {
          return (cal.speed_req == null || it.cand.mdef.v1 + 1e-9 >= cal.speed_req) ? 0 : 1;
        }
        function lamMarg(it) { return it.cand.mdef.push_N - (cal.load_N || 0); }
        function lamDSpd(it) { return cal.speed_req != null ? Math.abs(it.cand.mdef.v1 - cal.speed_req) : 0; }
        lamOther.sort(function (a, b) {
          return (okSpeed(a) - okSpeed(b)) || (lamMarg(a) - lamMarg(b))
            || (lamDSpd(a) - lamDSpd(b)) || String(a.cand.model).localeCompare(String(b.cand.model));
        });
        for (var loi = 0; loi < lamOther.length && picked.length < 3; loi++) {
          if (seenSub[lamOther[loi].cand.sub] && picked.length < 2) continue;
          picked.push(lamOther[loi]);
          lamKinds.push('cross');
        }
      }
      var lamNames = ['速度最接近（同速度下取负载裕度最小）', '备选方案二（其它子系列的相近档位）', '备选方案三（裕度更大）'];
      var lamNum = ['一', '二', '三'];
      tierNames = picked.map(function (it, i) {
        if (lamKinds[i] !== 'cross') return lamNames[i] || ('备选方案' + (i + 1));
        return '备选方案' + (lamNum[i] || (i + 1)) + '（跨系列：' + it.cand.sub + ' 系列，满载 '
          + fN(it.cand.mdef.v1, 1) + ' mm/s）';
      });
    } else {
      /*




*/
      /*
*/
      var qEnv = passList.filter(function (it) { return it.envOk !== false; });
      var q = (qEnv.length ? qEnv : passList.slice()).sort(function (a, b) { return cmpKey(a.key, b.key); });
      function isUnder(it) { return !!it.rec.result.load_short; }
      function dSpdOf(it) { return cal.speed_req != null ? Math.abs(it.cand.mdef.speed - cal.speed_req) : 0; }
      /**/
      function pickRank(a, b) {
        return (speedBand(a.cand.mdef.speed, cal.speed_req) - speedBand(b.cand.mdef.speed, cal.speed_req))
          || (dSpdOf(a) - dSpdOf(b)) || (isUnder(a) - isUnder(b));
      }
      function funcSize(s) {
        var n = Number(String(s).replace(/[^0-9]/g, ''));
        return isNaN(n) ? 99999 : n;
      }
      var fit = q.filter(function (it) { return !isUnder(it); });
      var first = fit[0] || q[0];
      var kinds = [];
      if (!first) {
        /**/
        failList.slice(0, 3).forEach(function (it) { picked.push(it); kinds.push('fill'); });
      } else {
      picked.push(first); kinds.push('main');
      var baseSub = first.cand.sub;
      function inBand(it) { return speedBand(it.cand.mdef.speed, cal.speed_req) === 0; }
      /*
*/
      var sameRest = q.filter(function (it) { return it !== first && it.cand.sub === baseSub && inBand(it); }).sort(pickRank);
      if (sameRest.length) { picked.push(sameRest[0]); kinds.push('same'); }
      var subs = [];
      q.forEach(function (it) { if (subs.indexOf(it.cand.sub) < 0) subs.push(it.cand.sub); });
      subs.sort(function (a, b) { return funcSize(a) - funcSize(b); });
      var at = subs.indexOf(baseSub);
      /**/
      if (at > 0 && picked.length < 3) {
        var smallGrp = q.filter(function (it) { return it.cand.sub === subs[at - 1] && inBand(it); }).sort(pickRank);
        if (smallGrp.length) { picked.push(smallGrp[0]); kinds.push('small'); }
      }
      /**/
      for (var si = at + 1; si < subs.length && picked.length < 3; si++) {
        var grp = q.filter(function (it) { return it.cand.sub === subs[si] && inBand(it); }).sort(pickRank);
        if (grp.length) { picked.push(grp[0]); kinds.push('big'); }
      }
      /**/
      q.slice().sort(function (a, b) {
        return (speedBand(a.cand.mdef.speed, cal.speed_req) - speedBand(b.cand.mdef.speed, cal.speed_req))
          || (dSpdOf(a) - dSpdOf(b)) || (isUnder(a) - isUnder(b));
      }).forEach(function (it) {
        if (picked.length >= 3 || picked.indexOf(it) >= 0) return;
        picked.push(it); kinds.push('fill');
      });
      failList.forEach(function (it) {
        if (picked.length >= 3 || picked.indexOf(it) >= 0) return;
        picked.push(it); kinds.push('fill');
      });
      }
      var kindLabel = {
        main: '推力足且速度够、推力最省',
        same: '同基座换档（速度更接近，推力略欠会标注）',
        small: '小一号基座（更便宜一档，推力略欠会标注）',
        big: '加大一号基座（该基座里速度最接近的档）',
        fill: '备选（带外或软约束未过的档）'
      };
      /*

*/
      tierNames = kinds.map(function (k, i) {
        var r = (picked[i] && picked[i].rec && picked[i].rec.result) || {};
        var u = r.speed_under_pct;
        var lim = Math.round(ROD_SPEED_UNDER * 100) + '%';
        if (k === 'main' && u != null && u > 0) {
          return '推力足、速度欠 ' + fN(u, 1) + '%（≤' + lim + ' 接近口径放行）、推力最省';
        }
        if (k !== 'main' && u != null && u > 0) {
          return kindLabel[k] + '，速度欠 ' + fN(u, 1) + '%';
        }
        return kindLabel[k] || '备选方案';
      });
    }
    picked.forEach(function (it, i) {
      out.schemes.push({ cand: it.cand, rec: it.rec, tierLabel: tierNames[i] || ('备选方案' + (i + 1)) });
    });

    /*





*/
    out.processUnmetHint = '自额定推力覆盖客户要求的基座号起，按「同基座号换减速比（导程）→ 加大基座号」逐台试算，列到推荐方案为止：';
    var puChosen = out.schemes.length ? out.schemes[0].cand.model : null;
    var puReq = cal.load_N || 0;
    var puSeq = trialsBySize || mainTrials;
    /**/
    var puStart = null;
    for (var ps = 0; ps < puSeq.length; ps++) {
      if (puSeq[ps].rated != null && puSeq[ps].rated >= puReq - 1e-9) { puStart = puSeq[ps].size; break; }
    }
    if (puStart != null) {
      for (var pi = 0; pi < puSeq.length; pi++) {
        var pit = puSeq[pi];
        if (pit.size < puStart) continue;
        if (puChosen ? (pit.cand.model === puChosen) : (pit.rec && pit.rec.allPass)) break;
        if (pit.rated == null || !(pit.rated >= puReq - 1e-9)) continue;
        if (pit.fatal) {
          var puTxt = rodUnmetTxt(pit.fatal);
          /*
*/
          if (puTxt) out.processUnmet.push({ model: pit.cand.model, lead: pit.lead, text: puTxt, order: pi });
        } else if (pit.rec && pit.rec.result && !pit.rec.allPass) {
          out.processUnmet.push({ model: pit.cand.model, lead: pit.lead, text: rodPartialTxt(pit.rec.result), order: pi });
        }
      }
    }
    /**/
    out.puOrder = {};
    puSeq.forEach(function (x, xi) { out.puOrder[x.cand.model] = xi; });

    /**/
    if (cal.fam === 'LAP' && cal.load_N < 9806.65 && cal.pull_N < 9806.65
      && (cal.cycles_per_day == null || cal.cycles_per_day <= 100)) {
      var lams = candidatesOf('LAM').filter(function (it) {
        var spd = it.cand.mdef.v1, spdOk = cal.speed_req == null || Math.abs(spd - cal.speed_req) / Math.max(spd, cal.speed_req) < 0.5;
        return spdOk;
      });
      if (lams.length) {
        var lam0 = lams[0];
        out.schemes.push({ cand: lam0.cand, rec: lam0.rec, tierLabel: '替代方案：小型电动推杆 LAM（推拉力 <1 吨且频次 ≤100 次/日，速度/推力/行程相近）' });
      }
    }

    out.chosen = out.schemes[0].cand;
    out.chosenResult = out.schemes[0].rec.result;
    return out;
  }

  /**/
  function quickLookup(code, data) {
    var s = String(code || '').trim().toUpperCase();
    if (!s) return null;
    var keys = Object.keys(data.models);
    /**/
    var exact = keys.filter(function (k) { return k === s; });
    var pre = keys.filter(function (k) { return k.indexOf(s) === 0 && (!exact.length || true) && k !== s; });
    var hit = exact.length ? exact : pre;
    if (!hit.length) return null;
    hit.sort();
    return hit.slice(0, 24).map(function (k) {
      var m = data.models[k];
      return {
        model: k, fam: m.fam, sub: m.sub, code: m.code,
        rated: (m.fam === 'LAM') ? m.push_N : m.load_N,
        pull: m.pull_N || null, lock: (m.fam === 'LAP') ? m.lock : (m.fam === 'LAM' ? m.lock_N : null),
        speed: (m.fam === 'LAM') ? (m.v0 + '-' + m.v1) : m.speed,
        stroke: m.stroke_max, motor: m.motor || null, duty: m.duty || null, note: m.note || ''
      };
    });
  }

  g.SJ_RodEngine = {
    toCalc: toCalc,
    autoSelect: autoSelect,
    evalCandidate: evalCandidate,
    stabilityCheck: stabilityCheck,
    dutyCheck: dutyCheck,
    lifeCheck: lifeCheck,
    servoCalc: servoCalc,
    servoSteps: servoSteps,
    selfLockOf: selfLockOf,
    quickLookup: quickLookup,
    SPEED_CAP: SPEED_CAP_LAP_LBP,
    CYC: CYC
  };
})(typeof window !== 'undefined' ? window : globalThis);
