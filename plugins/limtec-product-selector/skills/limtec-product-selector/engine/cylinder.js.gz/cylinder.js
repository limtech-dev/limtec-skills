/*





















*/
(function (g) {
  'use strict';

  var PI2 = 2 * Math.PI;
  var TAU_KN = { t: 9.81, kN: 1, kgf: 0.00981, N: 0.001 };        //
  var ETA_BALL = 0.8, ETA_ROLLER = 0.8, ETA_ACME = 0.3; //
  var LIFE_YEARS_DEFAULT = 5;                           //

  /**/
  var RPM_TIERS = [3000, 2000, 1500, 2500];

  /*






*/
 var GB_STD = [3, 4, 5, 7, 10, 12, 15, 16, 20, 25, 28, 60, 64, 75, 80, 100, 125, 140, 160, 175];
 function gbEffOf(i) { return i >= 12 ? 0.80 : 0.90; }

  /*

*/
  function pgCodeOf(formV, belt, ip) {
    var gseg = ip > 1 ? (ip < 10 ? 'G0' + ip : 'G' + ip) : '';
    /**/
    if (/P10|P20|P15/.test(String(formV || ''))) return (Number(belt) === 2 ? 'P20' : (Number(belt) === 1.5 ? 'P15' : 'P10')) + (gseg ? '-' + gseg : '');
    return gseg;
  }

  function num(x, d) { var n = Number(x); return isFinite(n) ? n : (d || 0); }
  function r1(x) { return Math.round(x * 10) / 10; }
  function r2(x) { return Math.round(x * 100) / 100; }

  /**/
  function stabilityCheck(mdef, fKN, stroke) {
    var curve = mdef.stability_curve || {};
    var cpts = (curve && curve.points) || null;
    if (!cpts || !cpts.length || !fKN || !stroke) return { ok: null, msg: null, lk: null };
    var pts = cpts.slice().sort(function (a, b) { return a[0] - b[0]; });
    var maxLoad = pts[pts.length - 1][0];
    if (fKN > maxLoad * 1.0001) {
      return { ok: false, msg: '载荷 ' + r1(fKN) + 'kN 超出稳定性曲线范围（曲线最大 ' + Math.round(maxLoad) + 'kN），稳定性不足，需升大一号', lk: null };
    }
    var lk;
    if (fKN <= pts[0][0]) {
      lk = Math.max.apply(null, pts.map(function (q) { return q[1]; }));
    } else {
      lk = null;
      for (var i = 0; i < pts.length - 1; i++) {
        var a = pts[i], b = pts[i + 1];
        if (fKN >= a[0] && fKN <= b[0]) { lk = a[1] + (b[1] - a[1]) * (fKN - a[0]) / (b[0] - a[0]); break; }
      }
      if (lk == null) lk = pts[pts.length - 1][1];
    }
    var lkR = Math.round(lk);
    if (stroke <= lk) {
      return { ok: true, msg: '按2026样本稳定性曲线（前后铰接安装口径），载荷 ' + r1(fKN) + 'kN 下允许行程约 ' + lkR + 'mm ≥ 要求 ' + Math.round(stroke) + 'mm；如非铰接安装，请与力姆泰克工程师确认', lk: lkR };
    }
    var ms = mdef.max_stroke_mm;
    if (fKN <= pts[0][0] * 1.0001) {
      return { ok: false, msg: '行程 ' + Math.round(stroke) + 'mm 超出样本稳定性曲线绘制范围（该载荷下曲线绘至约 ' + lkR + 'mm' + (ms && stroke <= ms ? '，未超型号最大行程 ' + ms + 'mm' : '') + '），按样本注请与力姆泰克工程师确认稳定性', lk: lkR };
    }
    if (ms && stroke <= ms) {
      return { ok: false, msg: '稳定性不足：载荷 ' + r1(fKN) + 'kN 下允许行程约 ' + lkR + 'mm < 要求 ' + Math.round(stroke) + 'mm（型号最大行程 ' + ms + 'mm），需升大一号或减小行程；非铰接安装请与力姆泰克工程师确认', lk: lkR };
    }
    return { ok: false, msg: '稳定性不足：载荷 ' + r1(fKN) + 'kN 下允许行程约 ' + lkR + 'mm < 要求 ' + Math.round(stroke) + 'mm，且超出型号最大行程 ' + ms + 'mm，需升大一号', lk: lkR };
  }

  /**/
  function toCalc(inp, data) {
    var D = data || g.SJ_CYL_DATA || {};
    var forms = (D.input_forms || []);
    var form = forms.filter(function (f) { return f.v === inp.input_form; })[0];
    if (!form) {
      /*
*/
      if (inp.input_form === 'P10') form = { v: 'P10', ratio: 1, gear_eta: 1 };
      else if (inp.input_form === 'P20') form = { v: 'P20', ratio: 2, gear_eta: 1 };
      else if (inp.input_form === 'P15') form = { v: 'P15', ratio: 1.5, gear_eta: 1 };
      else form = forms[0] || { v: 'SC', ratio: 1, gear_eta: 1 };
    }
    var temp = String(inp.ambient_temp || '20');
    var uN = Math.max(1, Math.round(num(inp.units, 1)));
    var sync = uN > 1 ? String(inp.sync || '电气') : '单台';   //
    var cal = {
      series: inp.series || 'auto',
      units: Math.max(1, Math.round(num(inp.units, 1))),
      load_kN: num(inp.load, 0) * (TAU_KN[inp.load_unit] || 9.81),
      /*
*/
      load_pull_kN: num(inp.load_pull, 0) * (TAU_KN[inp.load_pull_unit] || 9.81),
      static_kN: num(inp.static_load, 0) * (TAU_KN[inp.static_load_unit] || 9.81),
      /**/
      stroke: num(inp.stroke_mm, 0),
      speed_req: num(inp.speed_mm_s, 0),
      cycles_per_day: num(inp.cycles_per_day, 0),
      hours_per_day: num(inp.hours_per_day, 24),
      days_per_year: num(inp.days_per_year, 300),
      life_years: num(inp.life_years, LIFE_YEARS_DEFAULT) || LIFE_YEARS_DEFAULT,
      avg_load_kN: num(inp.avg_load, 0) * (TAU_KN[inp.avg_load_unit] || 9.81),   //
      form: form,
      ratio: form.ratio || 1,
      gear_eta: form.gear_eta != null ? form.gear_eta : 1,
      belt_auto: !!form.belt_auto,   //
      sync: sync,
      /**/
      low_coef: lowCoefOf(temp),
      low_temp: lowCoefOf(temp) > 1,
      temp: temp,
      install: inp.install || 'FF',
      joint: inp.joint || 'FM',
      /*
*/
      accessories: (function () {
        var a = Array.isArray(inp.accessories) ? inp.accessories.slice()
          : (inp.series === 'GTR' ? [] : ['AR']);
        var okG = { AR: 1, L2: 1, RB: 1, B: 1, PF: 1 };
        var okP = { AR: 1, FCP: 1, FCM: 1, B: 1, PF: 1, PL: 1, FZ: 1, SS: 1, HW: 1 };
        /**/
        if (inp.series === 'DMB' || inp.series === 'FMR') okP.OS = 1;
        var ok = (inp.series === 'GTR') ? okG : okP;
        var out = a.filter(function (x) { return ok[x]; });
        /*
*/
        if (Number(temp) >= 80) out = out.filter(function (x) { return x !== 'FCM'; });
        return out;
      })(),
      /*

*/
      precision: (inp.series === 'FMR' || inp.series === 'GTR') ? '0.02'
        : (inp.series === 'EMB') ? '0.05'
        : (inp.precision_mm || ({ '轧制': '0.05', '磨制': '0.02', '梯形': '梯形' })[inp.screw_sel] || '0.05'),
      ip: inp.ip || 'IP65',
      motor_rpm_forced: num(inp.motor_rpm, 0),        //
      motor_torque_override: num(inp.motor_torque_Nm, 0), //
      brands: Array.isArray(inp.servo_brand) ? inp.servo_brand.filter(Boolean) : [],
      encoder: (inp.series === 'GTR') ? '' : (inp.encoder || '增量型'),
      /**/
      gtr_drive: inp.gtr_drive || 'Siemens',
      gtr_fb: inp.gtr_fb || ((inp.gtr_drive || 'Siemens') === 'Siemens' ? 'SM2' : 'EL1'),
      special: Array.isArray(inp.special) ? inp.special.slice() : [],
      special_texts: inp.special_texts || {},
      guide: inp.guide || '无',
      drive: inp.drive || 'servo380'
    };
    return cal;
  }

  /**/
  function lifeCheck(mdef, v, lead, pKN, cal, steps, checks) {
    var C = (v && v.C_kN != null) ? v.C_kN : mdef.C_kN;
    var screw = String(mdef.screw_type || mdef.screw || '');
    if (!C || !lead) return null;
    var life = Math.pow(C / pKN, 3) * lead;              // km
    var cyc = cal.cycles_per_day;
    var annual = cyc ? cal.stroke * 2 * cyc * cal.days_per_year / 1e6 : null;
    var pSrc = cal.avg_load_kN ? '平均推拉力（客户给定 ' + r2(cal.avg_load_kN) + 'kN）' : '单缸设计负载（未填平均推拉力）';
    if (annual != null && annual > 0) {
      var ok = life >= annual * cal.life_years;
      checks['寿命'] = ok;
      steps.push(['寿命校核', '理论寿命 (C/P)³×导程 = (' + C + '/' + r2(pKN) + ')³×' + lead + ' = ' + Math.round(life) + 'km（P=' + pSrc + '）；'
        + '客户年用 ' + r2(annual) + 'km（行程×2×' + cyc + '次/日×' + cal.days_per_year + '日），'
        + (ok ? '满足 ' + cal.life_years + ' 年以上' : '低于 ' + cal.life_years + ' 年（需 ' + Math.round(annual * cal.life_years) + 'km），需升大一号或降频')]);
      return { life_km: Math.round(life), annual_km: r2(annual), ok: ok, C: C, pKN: r2(pKN) };
    }
    steps.push(['寿命校核', '理论寿命 ' + Math.round(life) + 'km（P=' + pSrc + '）；每日工作次数未填，未做年限判断']);
    return { life_km: Math.round(life), annual_km: null, ok: null, C: C, pKN: r2(pKN) };
  }

  /*




*/
  function trapDutyCheck(cal, fDesign, rated_kN, steps, warnings) {
    var cyc = Number(cal.cycles_per_day) || 0;
    var lr = (rated_kN > 0) ? (fDesign / rated_kN) : null;
    var lrTxt = (lr != null) ? (Math.round(lr * 100) + '%') : '未知';
    var noLife = '；梯形丝杠不做 L10 寿命校核';
    if (!(cyc > 0)) {
      steps.push(['工作制校核', '梯形丝杠：每日工作次数未填（基准 50 次/日，未填不做判定）' + noLife]);
      return { ok: null, max_cyc: 50, cycles_per_day: null };
    }
    if (cyc <= 50) {
      steps.push(['工作制校核', '梯形丝杠：每日 ' + cyc + ' 次 ≤ 基准 50 次/日（负载率 ' + lrTxt + '），符合梯形丝杠工作制' + noLife]);
      return { ok: true, max_cyc: 50, cycles_per_day: cyc };
    }
    var lrN = (lr != null) ? Math.min(0.5, Math.max(0.2, lr)) : null;
    var maxCyc = (lrN != null) ? 50 + (0.5 - lrN) / 0.3 * 50 : 50;
    maxCyc = Math.round(maxCyc);
    if (cyc <= maxCyc + 1e-9) {
      steps.push(['工作制校核', '梯形丝杠：每日 ' + cyc + ' 次 > 基准 50 次/日，按负载率 ' + lrTxt
        + ' 插值可用至 ' + maxCyc + ' 次/日（负载率 50%→50 次、20%→100 次），符合工作制' + noLife]);
      return { ok: true, max_cyc: maxCyc, cycles_per_day: cyc };
    }
    steps.push(['工作制校核', '梯形丝杠：每日 ' + cyc + ' 次超过负载率 ' + lrTxt + ' 允许上限 ' + maxCyc
      + ' 次/日（负载率 50%→50 次、20%→100 次 线性插值），超出梯形丝杠工作制，建议改选滚珠丝杠' + noLife]);
    warnings.push('【工作制】梯形丝杠每日 ' + cyc + ' 次超过当前负载率 ' + lrTxt + ' 允许上限 ' + maxCyc
      + ' 次/日（负载率 50%→50 次、20%→100 次 线性插值）；梯形丝杠每日次数超限，建议改选滚珠丝杠（重复精度 0.05 轧制 / 0.02 磨制）');
    return { ok: false, max_cyc: maxCyc, cycles_per_day: cyc };
  }

  /**/

  /**/
  var BRAND_PREFIX = ['西门子', '汇川', '台达', '雷赛', '惠斯通'];
  /*
*/
  var BRAND_MATCH = { '汇川': '汇川', 'V90': '西门子 V90', 'S200': '西门子 S200', 'S120': '西门子 S120',
    '台达': '台达', '雷赛': '雷赛', '惠斯通': '惠斯通' };
  function brandMatchers(cal) {
    return (cal.brands || []).map(function (v) { return BRAND_MATCH[v] || v; });
  }
  function isWesternBrand(cal) {   //
    return brandMatchers(cal).some(function (b) { return b.indexOf('西门子') === 0; });
  }
  /*

*/
  function lowCoefOf(temp) {
    var t = Number(temp);
    if (!isFinite(t)) return 1;
    if (t <= -40 + 1e-9) return 2;
    if (t <= -30 + 1e-9) return 1.5;
    return 1;
  }
  function motorRecommend(lib, cal, tier, T_req, P_req, opts) {
    opts = opts || {};
    /**/
    var hot80 = isFinite(Number(cal.temp)) && Number(cal.temp) >= 80;
    var wants = brandMatchers(cal);
    /*

*/
    function cylBrakePolicy(rows) {
      var hasG1 = rows.some(function (x) { return String(x.code || '').indexOf('ISMG1') === 0; });
      var outB = [];
      rows.forEach(function (x) {
        if (String(x.code || '').indexOf('ISMG2') === 0) {
          if (hasG1) return;
          x.brake = '不带制动（该系列无抱闸选配）；制动须与汇川确认或另行解决';
          x.brake_warn = true;
        }
        outB.push(x);
      });
      return outB;
    }
    /*



*/
    function cylSvClassRank(rpm, brand) {
      var r = Number(rpm) || 0;
      var b = String(brand || '');
      var sie = /^(V90|S200|S120)$/.test(b) || b.indexOf('西门子') >= 0;
      var small = (P_req !== null && P_req !== undefined) ? (P_req < 0.85 - 1e-9) : false;
      var pref = small ? (sie ? [3000, 2000] : [3000, 2000, 1500])
                       : (sie ? [2000, 3000] : [1500, 2000, 2500, 3000]);
      for (var i = 0; i < pref.length; i++) {
        if (Math.abs(r - pref[i]) < 1e-6) return i;
      }
      return 9;
    }
    /*

*/
    var CYL_TQ_UNDER = 0.02;
    function scan(wantArr) {
      var want = (wantArr && wantArr.length) ? wantArr : null;
      var out = [];
      (lib || []).forEach(function (m) {
        if (m.kind !== 'servo') return;
        var b = String(m.brand || '');
        var hit = BRAND_PREFIX.filter(function (p) { return b.indexOf(p) === 0; })[0];
        if (!hit) return;
        if (want && !want.some(function (p) { return b.indexOf(p) === 0; })) return;
        if (opts.exactRpm ? m.rpm !== tier : false) return;
        if (m.torque_Nm == null || m.power_kW == null) return;
        /*
*/
        /*

*/
        var tAvail = m.torque_Nm, overSpd = false;
        if (opts.nReq > tier + 1e-9) {
          var nOp2 = opts.nReq;
          if (m.rpm >= nOp2 - 1e-9) { tAvail = m.torque_Nm; }
          else if (nOp2 <= (Number(m.nmax_rpm) || 3000) + 1e-9) {
            tAvail = m.torque_Nm * m.rpm / nOp2; overSpd = true;
          } else return;
        } else if (m.rpm !== tier) return;
        /*

*/
        /*





*/
        var s11 = false, tqUnder = 0;
        var tOk191 = tAvail + 1e-9 >= T_req;
        if (!tOk191) {
          /*


*/
          if (!hot80 && T_req != null && isFinite(T_req) && P_req != null && isFinite(P_req)
            && P_req > 0.75 + 1e-9 && !opts.all && !overSpd
            && tAvail + 1e-9 >= T_req * 1.1 / 1.2) {
            s11 = true;
          } else if (T_req != null && isFinite(T_req) && T_req > 0
            && tAvail + 1e-9 >= T_req * (1 - CYL_TQ_UNDER)) {
            tqUnder = (T_req - tAvail) / T_req;
          } else {
            return;
          }
        }
        if (s11) {
          if (m.power_kW + 1e-9 < P_req * 1.1 / 1.2 - 1e-9) return;
        } else if (!overSpd
          && m.power_kW + 1e-9 < P_req * (tqUnder > 0 ? (1 - CYL_TQ_UNDER) : 1) - 1e-9) {
          /*
*/
          return;
        }
        /*
*/
        var fitV;
        if (s11) fitV = 's11';
        else if (!overSpd && m.power_kW > P_req * 2.5) fitV = 'far';
        else if (!overSpd && tAvail >= T_req * 1.2 - 1e-9 && m.power_kW >= P_req * 1.2 - 1e-9) fitV = '1.2';
        else if (!overSpd && tAvail >= T_req * 1.1 - 1e-9 && m.power_kW >= P_req * 1.1 - 1e-9) fitV = '1.1';
        else fitV = 'ok';
        out.push({
          kind: 'servo', brand: hit, brandFull: b, code: m.code,
          power_kW: m.power_kW, rpm: m.rpm, torque_Nm: m.torque_Nm,
          current_A: m.current_A != null ? m.current_A : null,
          frame: m.frame || '—', flange: m.flange || '—',
          voltage: m.voltage || '', ip: m.ip || '', brake: m.brake || '',
          overspeed: overSpd, torque_at_speed: overSpd ? Math.round(tAvail * 100) / 100 : null,
          fit: fitV, within_10pct: fitV === '1.1',
          tq_under: tqUnder > 0 ? tqUnder : null   /**/
        });
      });
      /*


*/
      function pwrCostRank(p) {
        var seq = [0.2, 0.4, 0.1, 0.05, 0.75];
        for (var q = 0; q < seq.length; q++) if (Math.abs(p - seq[q]) < 1e-6) return q;
        return 5 + (Number(p) || 0);
      }
      function voltRank(v) { return /220/.test(String(v || '')) ? 0 : 1; }
      out.sort(function (a, b) {
        /**/
        var ta = (a.tq_under != null) ? 1 : 0, tb = (b.tq_under != null) ? 1 : 0;
        if (ta !== tb) return ta - tb;
        var sa = a.power_kW <= 0.75 + 1e-9, sb = b.power_kW <= 0.75 + 1e-9;
        if (sa && sb) {
          var ca = pwrCostRank(a.power_kW) - pwrCostRank(b.power_kW);
          if (ca !== 0) return ca;
          var va = voltRank(a.voltage) - voltRank(b.voltage);
          if (va !== 0) return va;
          var ra = cylSvClassRank(a.rpm, a.brand) - cylSvClassRank(b.rpm, b.brand);
          if (ra !== 0) return ra;
          return a.torque_Nm - b.torque_Nm;
        }
        return (a.power_kW - b.power_kW)
          || (cylSvClassRank(a.rpm, a.brand) - cylSvClassRank(b.rpm, b.brand))
          || (a.torque_Nm - b.torque_Nm);
      });
      /*
*/
      if (opts.all) return cylBrakePolicy(out);
      var seen = {}, picked = [];
      for (var i = 0; i < out.length && picked.length < 3; i++) {
        if (seen[out[i].brandFull]) continue;
        seen[out[i].brandFull] = 1;
        picked.push(out[i]);
      }
      return picked;
    }
    var picked = scan(wants);
    /*
*/
    var hasS120 = (cal.brands || []).indexOf('S120') >= 0;
    var sieDomain = !wants.length || wants.some(function (b) { return b.indexOf('西门子') === 0; });
    if (!picked.length && !hasS120 && sieDomain) {
      picked = scan(wants.length ? wants.concat(['西门子 S120']) : ['西门子 S120']).map(function (m) {
        m.s120_fallback = true; return m;
      });
    }
    return cylBrakePolicy(picked);
  }

  /*





*/
  function stdLimitOf(series, model) {
    if (!series || !model) return null;
    if (series === 'FMR') {
      var fn = parseInt(String(model).replace(/^FMR/i, ''), 10);
      return (isFinite(fn) && fn <= 50) ? 'FCM' : 'FCP';
    }
    if (series === 'EMB') return 'FCM';
    if (series === 'DMB') {
      var n = parseInt(String(model).replace(/^DMB/i, ''), 10);
      if (!isFinite(n)) return null;
      return n <= 40 ? 'FCM' : 'FCP';
    }
    return null;
  }

  /*
*/
  function stdLimitAltOf(series, model) {
    if (series !== 'FMR') return null;
    var n = parseInt(String(model).replace(/^FMR/i, ''), 10);
    return (isFinite(n) && n <= 50) ? 'FCP' : null;
  }

  /**/
  function candidatesOf(data, seriesKey) {
    var out = [];
    Object.keys(data.models).forEach(function (k) {
      var m = data.models[k];
      if (seriesKey && seriesKey !== 'auto' && m.series !== seriesKey) return;
      if (m.todo) return;   //
      if (m.variants && m.variants.length) {
        m.variants.forEach(function (v, vi) {
          out.push({
            model: k, mdef: m, variant: '导程 ' + v.lead + 'mm', vi: vi,
            lead: v.lead, rated_kN: v.rated_kN, max_speed_mm_s: v.max_speed_mm_s,
            C_kN: v.C_kN, eta: (String(m.screw_type || '').indexOf('行星') >= 0 ? (v.eta || ETA_ROLLER) : ETA_BALL),
            max_stroke_mm: m.max_stroke_mm, integrated: false
          });
        });
        /*

*/
        if (m.trapezoid && m.trapezoid.lead_mm) {
          out.push({
            model: k, mdef: m, variant: '梯形丝杠 直径 ' + m.trapezoid.dia_mm + '×导程 ' + m.trapezoid.lead_mm + 'mm', vi: -2,
            lead: m.trapezoid.lead_mm, rated_kN: m.trapezoid.rated_kN, max_speed_mm_s: 100,
            C_kN: null, eta: ETA_ACME, max_stroke_mm: m.max_stroke_mm, integrated: false, is_trap: true
          });
        }
      } else if (m.models && m.models.length) {           //
        m.models.forEach(function (gm) {
          var cf = gm.cont_force_N || [];
          /*

*/
          var wi = (cf.length > 1 && cf[1]) ? 1 : (cf[0] ? 0 : 2);
          var rated = cf[wi] ? cf[wi] / 1000 : null;
          out.push({
            model: k + '-' + gm.code, mdef: m, variant: '行程 ' + gm.stroke + 'mm / 导程 ' + gm.lead + 'mm',
            vi: -1, lead: gm.lead, rated_kN: rated, max_speed_mm_s: gm.max_speed_mm_s,
            C_kN: gm.C_N ? gm.C_N / 1000 : null, eta: ETA_ROLLER,
            max_stroke_mm: gm.stroke, integrated: true,
            winding: wi + 1,
            static_sample_kN: gm.static_N ? gm.static_N / 1000 : null,
            winding_note: wi === 1 ? '推力按 2 匝绕组校核（样本 3 匝推力更大，如需选用与厂家确认）'
              : (wi === 0 ? '推力按 1 匝绕组校核（本型号样本仅 1 匝参数，2/3 匝空缺）' : '推力按 3 匝绕组校核'),
            /*
*/
            torque_sample_Nm: (gm.torque_Nm || [])[wi] != null ? gm.torque_Nm[wi] : null,
            inertia_kgm2: gm.inertia_kgm2 != null ? gm.inertia_kgm2 : null,
            current400_A: (gm.current400_A || [])[wi] != null ? gm.current400_A[wi] : null,
            weight_kg: gm.weight_kg != null ? gm.weight_kg : null
          });
        });
      }
    });
    return out;
  }

  function seriesOrder(cal) {
    if (cal.series && cal.series !== 'auto') return [cal.series];
    return ['DMB', 'EMB', 'FMR', 'GTR'];                  //
  }

  /**/
  function evalCandidate(cand, cal, lib) {
    var steps = [], checks = {}, warnings = [];
    /*
*/
    var fPushUnit = (cal.load_kN || 0) / cal.units;       //
    var fPullUnit = (cal.load_pull_kN || 0) / cal.units;  //
    var pullDom = fPullUnit > 0 && fPullUnit > fPushUnit; //
    var fDesign = Math.max(fPushUnit, fPullUnit);   //
    /*
*/
    var elecSel = cal.sync === '电气';
    var fSel = elecSel ? fDesign * 1.5 : fDesign;
    steps.push(['单缸负载', (cal.load_pull_kN > 0
      ? '总负载推力 ' + r2(cal.load_kN) + 'kN / 总负载拉力 ' + r2(cal.load_pull_kN) + 'kN，按大者（' + (pullDom ? '拉力' : '推力') + '）' + r2(Math.max(fPushUnit, fPullUnit)) + 'kN'
      : '总负载 ' + r2(cal.load_kN) + 'kN') + ' ÷ ' + cal.units + ' 台'
      + ' = 单缸设计负载 ' + r2(fDesign * 1000) + 'N'
      + (elecSel ? '；电气同步偏载选型 ×1.5 = ' + r2(fSel * 1000) + 'N 选缸（2026-11-03 批复），扭矩计算仍按单缸设计负载' : '')]);

    /**/
    if (!(cand.rated_kN > 0)) {
      return { fatal: '额定推力数据待补全', steps: steps, checks: checks };
    }
    var okF = fSel <= cand.rated_kN * 1.0001;
    checks['额定推力'] = okF;
    steps.push(['额定推力校核', '要求 ' + Math.round(fSel * 1000) + 'N'
      + (elecSel ? '（单缸 ' + Math.round(fDesign * 1000) + 'N ×1.5 偏载）' : '')
      + ' ' + (okF ? '≤' : '>') + ' 额定 ' + (cand.rated_kN * 1000) + 'N（' + cand.model + ' ' + cand.variant + '），' + (okF ? '通过' : '不满足，需升大一号')]);
    if (!okF) return { fatal: '额定推力不足', steps: steps, checks: checks };

    /**/
    var okStroke = true;
    if (cand.max_stroke_mm) {
      okStroke = cal.stroke <= cand.max_stroke_mm * 1.0001;
      checks['最大行程'] = okStroke;
      steps.push(['最大行程校核', '行程 ' + Math.round(cal.stroke) + 'mm ' + (okStroke ? '≤' : '>') + ' 样本最大 ' + cand.max_stroke_mm + 'mm，' + (okStroke ? '通过' : '超限，需与厂家确认')]);
      if (!okStroke) return { fatal: '行程超限', steps: steps, checks: checks };
    }

    /*


*/
    var stab = null;
    if (cand.integrated) {
      steps.push(['稳定性校核', 'GTR 一体化行星丝杠结构，样本无稳定性曲线要求，不校核稳定性']);
    } else if (fPushUnit > 0 && cal.stroke > 0) {
      /*
*/
      var fPushStab = elecSel ? fPushUnit * 1.5 : fPushUnit;
      stab = stabilityCheck(cand.mdef, fPushStab, cal.stroke);
      if (stab.ok !== null) {
        checks['稳定性'] = stab.ok;
        steps.push(['稳定性校核', (elecSel ? '电气同步偏载选型，按 单缸推力 ' + r1(fPushUnit) + 'kN ×1.5 = ' + r1(fPushStab) + 'kN 校核；' : (pullDom ? '拉力工况（总负载拉力大于推力），按推力 ' + r1(fPushUnit) + 'kN 校核稳定性；' : '')) + stab.msg]);
        if (!stab.ok) return { fatal: '稳定性不足', steps: steps, checks: checks, stability_Lk_mm: stab.lk };
      }
    } else if (fPullUnit > 0 && cal.stroke > 0) {
      steps.push(['稳定性校核', '拉力工况且推力为 0，丝杠受拉无压弯风险，按选择规则不校核稳定性']);
    }

    /*

*/
    var ratedStatic = null, staticSrc = '';
    if (cand.static_sample_kN != null) {
      ratedStatic = cand.static_sample_kN;
      staticSrc = '样本最大静载 ' + r1(ratedStatic) + 'kN';
    } else if (cand.mdef && cand.mdef.rated_load_kN != null) {
      ratedStatic = cand.mdef.rated_load_kN * 1.5;
      staticSrc = '样本额定载荷 ' + r1(cand.mdef.rated_load_kN) + 'kN ×1.5';
    }
    if (ratedStatic != null) {
      /**/
      var stNeed0 = cal.static_kN > 0 ? cal.static_kN / cal.units : fDesign;
      var stNeed = elecSel ? stNeed0 * 1.5 : stNeed0;
      var okStatic = stNeed <= ratedStatic * 1.001;
      steps.push(['静载校核', (cal.static_kN > 0 ? '静载 ' + r2(cal.static_kN) + 'kN（单台 ' + r2(cal.static_kN / cal.units) + 'kN' + (elecSel ? ' ×1.5 偏载 = ' + r2(stNeed) + 'kN' : '') + '）'
        : '未单独提供静载，按动载需求 ' + r2(stNeed0) + 'kN' + (elecSel ? ' ×1.5 偏载 = ' + r2(stNeed) + 'kN（2026-11-03 批复）' : '') + ' 计') + ' ≤ 型号最大静载 ' + r1(ratedStatic)
        + 'kN（' + staticSrc + '），' + (okStatic ? '静载校核通过' : '静载超限，需放大型号')]);
      if (!okStatic) warnings.push('【静载校核】' + cand.model + ' 静载需求 ' + r2(stNeed) + 'kN 超过型号最大静载 ' + r1(ratedStatic) + 'kN（' + staticSrc + '），请放大型号或与厂家确认');
    }

    /*


*/
    var screwSel = null, gbAuto = false;
    if (cand.mdef && cand.mdef.series === 'DMB') {
      screwSel = ({ '0.05': '轧制', '0.02': '磨制', '0.01': '磨制', '梯形': '梯形' })[cal.precision] || '轧制';
      if (screwSel === '轧制' && cal.speed_req >= 100) { screwSel = '磨制'; gbAuto = true; }
    }
    var etaScrew = (screwSel === '梯形') ? 0.30 : cand.eta;

    /*

*/
    var pKN = cal.avg_load_kN > 0 ? cal.avg_load_kN : fDesign;
    var life = null, trapDuty = null;
    if (screwSel === '梯形') {
      trapDuty = trapDutyCheck(cal, fDesign, cand.rated_kN, steps, warnings);
    } else if (cand.C_kN && cand.lead && pKN > 0) {
      life = lifeCheck(cand.mdef, cand, cand.lead, pKN, cal, steps, checks);
      if (life && life.ok === false) return { fatal: '寿命不足', steps: steps, checks: checks, life: life };
    }

    /**/
    if (gbAuto) {
      steps.push(['丝杠选择', '最高速度 ' + cal.speed_req + 'mm/s 超过 100mm/s：轧制滚珠丝杠（精度 0.05mm）自动改为磨制滚珠丝杠（0.02mm，速度不限），型号加 GB']);
    }
    if (screwSel === '梯形') {
      steps.push(['丝杠选择', '梯形丝杠（重复精度 0.1mm，自锁）：整缸效率按 30% 计，扭矩公式丝杠效率项 η ' + cand.eta + ' → 0.30；自锁机构，制动器按需求选配；梯形丝杠不做滚珠 L10 寿命校核，按每日工作次数判定工作制']);
    }

    var res = {
      model: cand.model, variant: cand.variant, lead_mm: cand.lead, family: cand.mdef.series,
      route: 'E', integrated: cand.integrated,
      checks: checks, steps: steps, warnings: warnings,
      effective_load_kN: r2(fDesign),
      rated_kN: cand.rated_kN, eta: etaScrew, screw_sel: screwSel, gb: screwSel === '磨制',
      max_speed_of_variant: cand.max_speed_mm_s,
      stability_Lk_mm: stab ? stab.lk : null,
      life_km: life ? life.life_km : null, annual_km: life ? life.annual_km : null,
      life_C: life ? life.C : null, life_P_kN: life ? life.pKN : null,
      /**/
      trap_duty: trapDuty,
      form_v: cal.form.v, ratio: cal.ratio, gear_eta: cal.gear_eta,
      units: cal.units, sync: cal.sync, install: cal.install, joint: cal.joint,
      accessories: cal.accessories, precision: cal.precision, ip: cal.ip,
      temp: cal.temp, encoder: cal.encoder
    };

    /*
*/
    res.std_limit = stdLimitOf(cand.mdef.series, cand.model);
    res.std_limit_alt = stdLimitAltOf(cand.mdef.series, cand.model);
    /**/
    res.static_kN = ratedStatic != null ? r2(ratedStatic) : null;
    var accPicked = (res.accessories || []).filter(function (a) { return a === 'FCP' || a === 'FCM'; })[0] || null;
    if (res.std_limit && accPicked && accPicked !== res.std_limit && accPicked !== res.std_limit_alt) {
      warnings.push('限位开关 ' + accPicked + ' 与型号标配 ' + res.std_limit + ' 不一致（按用户选择出单，请与客户确认）');
    }
    /*
*/
    res.std_limit_hot_off = (Number(cal.temp) >= 80 && res.std_limit === 'FCM');
    if (res.std_limit_hot_off) {
      warnings.push('+80℃ 高温工况不匹配 FCM 磁感应限位开关（已在附件中取消；' + cand.model
        + ' 的样本标配 FCM 仅作常温口径，高温请按 FCP 接近开关或耐高温型另行确认）');
    }

    /*
*/
    /*
*/
    var fCalc = fDesign;
    if (cand.rated_kN > 0 && fDesign > 0 && fDesign < cand.rated_kN * 0.10 - 1e-9) {
      fCalc = cand.rated_kN * 0.10;
      steps.push(['负载率下限（10%）', '实际负载 ' + r2(fDesign) + 'kN 低于额定载荷 ' + r2(cand.rated_kN)
        + 'kN 的 10%（' + r2(cand.rated_kN * 0.10) + 'kN）—— 扭矩/功率按额定载荷的 10% 即 '
        + r2(fCalc) + 'kN 计算（2026-10-30 批复）；各项校核仍按实际负载']);
    }
    var T0 = fCalc * 1000 * cand.lead / (PI2 * 1000 * etaScrew);
    /*


*/
    var hot80 = isFinite(Number(cal.temp)) && Number(cal.temp) >= 80;
    var elecSync = cal.sync === '电气';
    var safety = (hot80 || !elecSync) ? (hot80 ? 2 : 1.2) : 1;
    var T_s = T0 * safety;
    /*


*/
    if (!cand.integrated) {
      steps.push(['驱动扭矩', 'T = ' + Math.round(fCalc * 1000) + 'N×' + cand.lead + 'mm/(2×3.14×1000×' + etaScrew + ') = ' + r2(T0) + 'Nm'
        + '（η丝杠=' + etaScrew + (screwSel === '梯形' ? '，梯形丝杠整缸效率 30%' : '')
        + (fCalc !== fDesign ? '；实际负载 ' + r2(fDesign) + 'kN 低于额定 10%，按额定载荷 10% 计算' : '') + '）']);
      if (elecSync && !hot80) {
        steps[steps.length - 1][1] += '（电气同步工况不取 1.2 安全裕量——×1.5 即唯一放大，2026-11-03 批复）';
      } else {
        steps[steps.length - 1][1] += '，×' + safety + ' = ' + r2(T_s) + 'Nm（单台安全裕量，唯一次放大；'
          + (hot80
            ? '高温 +80℃ 放大系数取 2（2026-10-30 批复），不再取 1.2/1.1'
            : '安全系数一般取 1.2，为凑电机标准功率档可取 1.1，须在方案中注明') + '）';
      }
    }
    var T_m = T_s;
    if (cal.sync === '机械' && cal.units > 1) {
      T_m = T_s * cal.units;
      steps.push(['机械同步', cal.units + ' 台共轴驱动 ×' + cal.units + ' = ' + r2(T_m) + 'Nm']);
    }
    if (cal.low_temp) {
      T_m = T_m * cal.low_coef;
      steps.push(['低温系数', cal.temp + '℃ 工况 ×' + cal.low_coef + ' = ' + r2(T_m) + 'Nm'
        + (cal.low_coef === 1.5
          ? '（-30℃ 档低温放大系数取 1.5，）'
          : '（-40℃ 及以下低温放大系数取 2）')]);
    }
    var T_f0 = T_m;
    if (cal.sync === '电气') {
      T_f0 = T_m * 1.5;
      steps.push(['电气同步（电气偏载系数）', '每缸一台电机，功率计算放大 ×1.5 = ' + r2(T_f0) + 'Nm'
        + (hot80 ? '（高温 ×2 后再 ×1.5，2026-10-30 + 2026-11-03 批复）' : '（电气同步唯一放大，2026-11-03 批复：常温不取 1.2 安全裕量）')
        + '；偏载选型同步按 总负载/' + cal.units + '×1.5 选缸']);
    }

    if (cand.integrated) {
      /**/
      var vAct0 = null;
      if (cal.speed_req > 0) {
        var okSpd0 = cal.speed_req <= cand.max_speed_mm_s * 1.001;
        checks['速度'] = okSpd0;
        vAct0 = cal.speed_req;
        steps.push(['速度校核', '要求 ' + cal.speed_req + 'mm/s ≤ 型号最大 ' + cand.max_speed_mm_s + 'mm/s（一体化内置电机，行程/导程码订货），' + (okSpd0 ? '通过' : '超速，需选大导程码')]);
        if (!okSpd0) return { fatal: '速度超限', steps: steps, checks: checks, result: res };
      }
      res.speed_mm_s = cal.speed_req || cand.max_speed_mm_s;
      /**/
      res.form_v = ''; res.ratio = 1; res.gear_eta = 1; res.planetary = null;
      /**/
      if (res.accessories.indexOf('L2') >= 0 && res.accessories.indexOf('AR') < 0) res.accessories.push('AR');
      res.motor_power_kW = null; res.total_power_kW = null;
      res.motor_recommend = [];
      /*
*/
      res.T_base_Nm = r2(T0);
      res.T_safety_Nm = r2(T_s);
      res.torque_sample_Nm = cand.torque_sample_Nm != null ? cand.torque_sample_Nm : null;
      res.inertia_kgm2 = cand.inertia_kgm2 != null ? cand.inertia_kgm2 : null;
      res.current400_A = cand.current400_A != null ? cand.current400_A : null;
      res.weight_kg = cand.weight_kg != null ? cand.weight_kg : null;
      /**/
      res.winding = cand.winding || 2;
      res.all_pass = Object.keys(checks).every(function (k) { return checks[k] !== false; });
      return { result: res };
    }

    /*





*/
    var nScrew = cal.speed_req > 0 ? cal.speed_req * 60 / cand.lead : 0;   //
    var libM = lib || (g.SJ_DATA && g.SJ_DATA.motor_library);
    var overrideMode = (cal.motor_torque_override > 0 || cal.motor_rpm_forced > 0);
    /*
*/
    var beltList = cal.belt_auto
      ? ((cal.series === 'DMB' || cal.series === 'FMR') ? [1, 1.5, 2] : [1, 2])
      : [cal.ratio];
    var vReq = cal.speed_req;
    var pick = null;    // {belt, ip, etaP, tier, Tm, P, nReq, rec}
    var motor_options = null;   //

    function comboOf(belt, ip, tier, nReqOver, allowNoMotor) {
      var etaP = ip > 1 ? gbEffOf(ip) : 1;
      var nReq = nScrew * belt * ip;
      if (!(nReq > 0) || nReq > 3000 + 1e-9) return null;
      var Tm = r2(T_f0 / (belt * cal.gear_eta * ip * etaP));              //
      var P = cal.motor_torque_override > 0 ? tier * cal.motor_torque_override / 9550 : tier * Tm / 9550;
      var Treq = cal.motor_torque_override > 0 ? T_f0 / (belt * cal.gear_eta) : Tm;   //
      /**/
      var rec = motorRecommend(libM, cal, tier, Treq, P, { nReq: (nReqOver > 0 ? nReqOver : nReq) });
      /*
*/
      if (!rec.length && !allowNoMotor) return null;
      return { belt: belt, ip: ip, etaP: etaP, tier: tier, Tm: Tm, P: P, nReq: nReq, rec: rec,
        overspeed: nReqOver > tier + 1e-9, noMotor: !rec.length };
    }

    if (overrideMode) {
      /*

*/
      if (cal.motor_rpm_forced > 0 && cal.motor_belt_forced > 0 && cal.motor_ip_forced > 0) {
        var cF = comboOf(cal.motor_belt_forced, cal.motor_ip_forced, cal.motor_rpm_forced)
          || comboOf(cal.motor_belt_forced, cal.motor_ip_forced, cal.motor_rpm_forced, 0, true);
        if (cF) {
          pick = cF;
          steps.push(['额定转速', '按所选电机额定转速 ' + cal.motor_rpm_forced + 'rpm 与所选速比'
            + (cal.motor_belt_forced > 1 ? '（同步带 i=' + cal.motor_belt_forced : '')
            + (cal.motor_belt_forced > 1 && cal.motor_ip_forced > 1 ? ' × ' : '')
            + (cal.motor_ip_forced > 1 ? (cal.motor_belt_forced > 1 ? '' : '（') + '行星减速机 i=' + cal.motor_ip_forced + ':1' + (cal.motor_belt_forced > 1 ? '）' : '）') : (cal.motor_belt_forced > 1 ? '' : '（直连）'))
            + '整案重算（点选电机，速比不重配）']);
        }
      }
      for (var bi = 0; bi < beltList.length && !pick; bi++) {
        var tkf = pickTier(nScrew * beltList[bi], cal, T_f0 / (beltList[bi] * cal.gear_eta));
        if (tkf.fatal) continue;
        if (tkf.forced) steps.push(['额定转速', '按客户指定电机额定转速 ' + tkf.tier + 'rpm 计算（所需 ≥' + Math.round(nScrew * beltList[bi]) + 'rpm）']);
        pick = comboOf(beltList[bi], 1, tkf.tier);
      }
      if (!pick) {
        /**/
        var belt0 = beltList[0] || 1;
        var pm = planetAutoMatch(cal, libM, nScrew * belt0, T_f0 / (belt0 * cal.gear_eta));
        if (pm) pick = { belt: belt0, ip: pm.ip, etaP: pm.eta, tier: pm.tier, Tm: pm.T, P: pm.P, nReq: pm.nReq, rec: pm.rec };
      }
    } else {
      /*







*/
      var isSie3 = (!cal.brands.length) || isWesternBrand(cal);
      var tierList3 = isSie3 ? [2000, 3000] : [1500, 2000, 3000];
      motor_options = [];
      /*





*/
      var SV_MIN_RPM = 30, P_SWEET = 0.4;
      for (var ti3 = 0; ti3 < tierList3.length; ti3++) {
        var t3 = tierList3[ti3];
        var combos = [];
        for (var b3 = 0; b3 < beltList.length; b3++) {
          for (var k3 = 0; k3 <= GB_STD.length; k3++) {
            var ip3 = k3 === 0 ? 1 : GB_STD[k3 - 1];
            /*
*/
            var c3 = comboOf(beltList[b3], ip3, t3, 0, true);
            if (!c3) continue;
            if (c3.nReq < SV_MIN_RPM - 1e-9) continue;                  //
            if (c3.nReq > t3 + 1e-9) continue;                           //
            if (c3.P <= 0.75 + 1e-9 && t3 !== 3000) continue;            //
            combos.push(c3);
          }
        }
        combos.sort(function (a, b) {
          /*
*/
          return (a.belt * a.ip - b.belt * b.ip) || (a.P - b.P) || (a.ip - b.ip);
        });
        var okSweet = null, maxTot = null, okAny = null;
        var maxTotal = 0;
        combos.forEach(function (c) {
          var tot3 = c.belt * c.ip;
          if (tot3 > maxTotal) maxTotal = tot3;
          if (!(c.rec && c.rec.length)) return;                        //
          if (!okAny) okAny = c;
          if (!okSweet && c.P <= P_SWEET + 1e-9) okSweet = c;            //
        });
        /*

*/
        for (var mi3 = 0; mi3 < combos.length; mi3++) {
          if (combos[mi3].belt * combos[mi3].ip === maxTotal) { maxTot = combos[mi3]; break; }
        }
      var bestT = okSweet || maxTot || okAny || (combos.length ? combos[0] : null);
      /*






*/
      if (bestT && bestT.belt === 1.5) {
        var maxPw216 = (cand.mdef && cand.mdef.max_power_kw != null) ? cand.mdef.max_power_kw : null;
        function pwOf216(c) {
          return (c.rec && c.rec.length && c.rec[0] && c.rec[0].power_kW != null) ? Number(c.rec[0].power_kW) : c.P;
        }
        var sub15 = combos.filter(function (c) {
          return c.belt !== 1.5 && (maxPw216 == null || pwOf216(c) <= maxPw216 + 1e-9);
        });
        if (sub15.length) {
          var okSweet15 = null, okAny15 = null, maxTot15 = null, maxTotT15 = 0;
          sub15.forEach(function (c) {
            var tot15 = c.belt * c.ip;
            if (tot15 > maxTotT15) maxTotT15 = tot15;
            if (!(c.rec && c.rec.length)) return;
            if (!okAny15) okAny15 = c;
            if (!okSweet15 && c.P <= P_SWEET + 1e-9) okSweet15 = c;
          });
          for (var m15 = 0; m15 < sub15.length; m15++) {
            if (sub15[m15].belt * sub15[m15].ip === maxTotT15) { maxTot15 = sub15[m15]; break; }
          }
          bestT = okSweet15 || maxTot15 || okAny15 || sub15[0];
        }
      }
      /*



*/
      if (bestT) {
        var totB3 = bestT.belt * bestT.ip, weakC3 = null;
        for (var bW = 0; bW < beltList.length; bW++) {
          for (var kW2 = 0; kW2 < GB_STD.length; kW2++) {
            var ipW = GB_STD[kW2], totW = beltList[bW] * ipW;
            if (totW <= totB3 + 1e-9) continue;
            if (weakC3 && totW > weakC3.tot) break;   /**/
            var cW3 = comboOf(beltList[bW], ipW, t3, nScrew * totW, true);
            if (cW3 && cW3.rec && cW3.rec.length
              && (!weakC3 || totW < weakC3.tot || (totW === weakC3.tot && beltList[bW] < weakC3.belt)))
              weakC3 = cW3;
          }
        }
        if (weakC3) bestT.weak = weakC3;
        motor_options.push(bestT);
      }
      }
      /*


*/
      var covOpts = motor_options.filter(function (o) { return o.rec && o.rec.length; });
      var sweetOpt = covOpts.filter(function (o) { return o.P <= P_SWEET + 1e-9; })[0];
      /*




*/
      var minPOpt = covOpts.slice().sort(function (a, b) {
        var pa = (a.rec && a.rec[0] && a.rec[0].power_kW != null) ? Number(a.rec[0].power_kW) : Infinity;
        var pb = (b.rec && b.rec[0] && b.rec[0].power_kW != null) ? Number(b.rec[0].power_kW) : Infinity;
        return (pa - pb) || (a.P - b.P) || (a.tier - b.tier);
      })[0];
      pick = sweetOpt || minPOpt || motor_options[0] || null;
      /**/
      if (!pick && nScrew > 0) {
        var totNeed = SV_MIN_RPM / nScrew;
        if (totNeed >= 1 - 1e-9) {
          return { fatal: '速度过慢：伺服稳定下限 30rpm 时需总速比 ≥' + Math.ceil(totNeed) + ':1，'
            + '超标准减速比上限（同步带 2 × 行星 100 = 200:1）。建议加大导程或与厂家确认非标减速比',
            steps: steps, checks: checks };
        }
        return { fatal: '速度过快：直连丝杠需 ' + Math.round(nScrew) + 'rpm，已超伺服额定 3000rpm 上限'
          + '（下限 30rpm 的组合亦不可行）。建议加大导程或降低速度要求', steps: steps, checks: checks };
      }
    }

    var belt, ip, etaP, tier, nReq, P, rec;
    if (pick) {
      belt = pick.belt; ip = pick.ip; etaP = pick.etaP;
      tier = pick.tier; nReq = pick.nReq; P = pick.P; rec = pick.rec;
      res.ratio = belt;
      res.planetary = ip > 1 ? { ratio: ip, eta: etaP } : null;
      /*

*/
      if (res.planetary && typeof window !== 'undefined' && window.SJScrewJack
        && typeof window.SJScrewJack.planetPickOf === 'function'
        && typeof SJ_DATA !== 'undefined' && SJ_DATA && SJ_DATA.planetary_hv) {
        res.planetary.hv = window.SJScrewJack.planetPickOf(SJ_DATA, ip, (pick && pick.Tm) || null, tier);
      }
      res.T_base_Nm = r2(T0 / (belt * cal.gear_eta));
      res.T_safety_Nm = r2(T0 / (belt * cal.gear_eta) * safety);
      res.T_mech_Nm = r2(T_m / (belt * cal.gear_eta));
      res.T_final_Nm = r2(pick.Tm); res.motor_torque_Nm = r2(pick.Tm);
      /**/
      res.T_screw_Nm = r2(T_f0);
      /**/
      if (belt * ip > 1) {
        for (var si8 = 0; si8 < steps.length; si8++) {
          if (steps[si8][0] === '驱动扭矩') {
            /**/
            steps[si8][1] += '；配' + (belt > 1 ? '同步带 i=' + belt + (ip > 1 ? '＋' : '') : '')
              + (ip > 1 ? '行星减速机 i=' + ip + ':1（效率 ' + etaP + '）' : '')
              + '（输入形式标注 ' + pgCodeOf(cal.form.v, belt, ip) + '）'
              + '折算电机端：T = ' + r2(T_f0) + 'Nm ÷ ' + (belt * ip) + (ip > 1 ? ' ÷ ' + etaP : '') + ' = ' + pick.Tm + 'Nm';
            break;
          }
        }
      }
      if (cal.belt_auto && beltList.length > 1) {
        /**/
        steps.push(['同步带定比', '本工况选同步带 i=' + belt
          + (ip > 1 ? ' + 行星减速机 i=' + ip + ':1' : '') + '（输入形式标注 ' + pgCodeOf(cal.form.v, belt, ip) + '），电机 ' + r2(P) + 'kW']);
      }
      if (ip > 1) {
        /*
*/
        steps.push(['减速机效率', '行星减速机 i=' + ip + ':1，效率 ' + etaP]);
      }
    } else {
      /**/
      belt = beltList[0] || 1; ip = 1; etaP = 1;
      var tk0 = pickTier(nScrew * belt, cal, T_f0 / (belt * cal.gear_eta));
      if (tk0.fatal) return { fatal: tk0.fatal, steps: steps, checks: checks };
      if (tk0.forced) steps.push(['额定转速', '按客户指定电机额定转速 ' + tk0.tier + 'rpm 计算（所需 ≥' + Math.round(nScrew * belt) + 'rpm）']);
      tier = tk0.tier; nReq = nScrew * belt;
      res.ratio = belt; res.planetary = null;
      res.T_base_Nm = r2(T0 / (belt * cal.gear_eta));
      res.T_safety_Nm = r2(T0 / (belt * cal.gear_eta) * safety);
      res.T_mech_Nm = r2(T_m / (belt * cal.gear_eta));
      var Tf0 = r2(T_f0 / (belt * cal.gear_eta));
      res.T_final_Nm = Tf0; res.motor_torque_Nm = Tf0;
      P = (cal.motor_torque_override > 0 ? tier * cal.motor_torque_override / 9550 : tier * Tf0 / 9550);
      rec = [];
    }

    /*


*/
    var maxPw = cand.mdef && cand.mdef.max_power_kw != null ? cand.mdef.max_power_kw : null;
    if (maxPw != null) {
      var mRow0 = (rec && rec.length && rec[0] && rec[0].power_kW != null) ? rec[0] : null;
      var pChk = mRow0 ? mRow0.power_kW : P;
      var pBasis = mRow0 ? '选出电机额定功率 ' + r2(pChk) + 'kW'
        : '需求功率 ' + r2(P) + 'kW（库内无覆盖真机型，按需求口径）';
      var okPw = pChk <= maxPw + 1e-9;
      steps.push(['最大功率校核', pBasis + ' ≤ 型号上限 ' + maxPw + 'kW，' + (okPw ? '通过' : '超上限，换更大型号电缸（2026-11-09 批复）')]);
      if (!okPw) {
        /**/
        if (cal.motor_rpm_forced > 0) {
          warnings.push('点选电机 ' + (mRow0 && mRow0.code || '') + '：额定功率 ' + r2(pChk) + 'kW 超过上限 ' + maxPw + 'kW，请换更大型号电缸（2026-11-09 批复）');
        } else {
          return { fatal: '输入功率超限：' + pBasis + ' > 型号上限 ' + maxPw + 'kW，换更大型号电缸（2026-11-09 批复）', steps: steps, checks: checks, result: res };
        }
      }
    }

    /*


*/
    var iTotal = belt * ip;
    var overSpdPick = !!(pick && pick.overspeed);
    var okSpd = ((tier + 1e-9 >= nReq) || overSpdPick) && (vReq <= cand.max_speed_mm_s * 1.001);
    checks['速度'] = okSpd;
    var maxSuffix = '；要求 ' + vReq + 'mm/s ' + (vReq <= cand.max_speed_mm_s * 1.001 ? '≤' : '>') + ' 型号最大 ' + cand.max_speed_mm_s + 'mm/s，'
      + (okSpd ? '满足使用要求' : '不满足（超速，需加大导程/换输入形式或升型号）');
    if (iTotal > 1 && !overSpdPick && nScrew > 0) {
      /*
*/
      var outRpmV = Math.round(tier / iTotal);
      var devP = Math.round((outRpmV / nScrew - 1) * 1000) / 10;
      steps.push(['速度校核', '伺服电机调速 + ' + (belt > 1 && ip > 1 ? '同步带＋行星减速机' : (ip > 1 ? '行星减速机' : '同步带'))
        + '：按电机额定转速匹配 ' + (belt > 1 && ip > 1 ? '总速比 i=' + iTotal + ':1（同步带 i=' + belt + ' × 行星减速机 i=' + ip + ':1，行星效率 ' + etaP + '）'
          : (ip > 1 ? 'i=' + ip + ':1（效率 ' + etaP + '）' : '同步带 i=' + belt))
        + '，丝杠输入转速 ' + outRpmV + 'rpm：v = ' + outRpmV + '÷60×' + cand.lead + 'mm = ' + r2(outRpmV / 60 * cand.lead) + 'mm/s'
        + '（要求 ' + vReq + 'mm/s，偏差 ' + (devP >= 0 ? '+' : '') + devP + '%'
        + (devP >= 0 && devP <= 20.05 ? '，1.0~1.2 倍内' : '，电机调速运行至所需转速') + '）' + maxSuffix]);
    } else {
      steps.push(['速度校核', '所需转速 = ' + vReq + '×60×' + iTotal + (iTotal > 1 ? '（' + (belt > 1 ? '同步带 i=' + belt : '') + (belt > 1 && ip > 1 ? '×' : '') + (ip > 1 ? '行星 i=' + ip : '') + '）' : '') + '/' + cand.lead + ' = ' + Math.round(nReq) + 'rpm'
        + (overSpdPick ? ' > 额定 ' + tier + 'rpm（弱磁升速运行，≤3000rpm 上限，可用扭矩已按恒功率折算，须与厂家确认）' : ' ≤ 电机额定 ' + tier + 'rpm（伺服调速运行）') + maxSuffix]);
    }
    if (!okSpd) return { fatal: '速度不满足', steps: steps, checks: checks, result: res };
    /*
*/

    res.motor_recommend = rec;
    /*





*/
    if (overrideMode && pick && rec && rec.length) {
      var recFull = rec.slice();
      var recAll2 = motorRecommend(libM, cal, tier,
        (cal.motor_torque_override > 0 ? T_f0 / (belt * cal.gear_eta) : pick.Tm), P,
        { nReq: nReq, all: true });
      recAll2.forEach(function (m2) {
        if (!recFull.some(function (x) { return x.code === m2.code; })) recFull.push(m2);
      });
      recFull.forEach(function (m2) {
        m2.belt = belt; m2.ip = ip; m2.tier = tier;
        m2.gearbox = { type: ip > 1 ? '行星减速机' : '同步带', ratio: (belt * ip) + ':1', out_rpm: Math.round(tier / (belt * ip)) };
      });
      res.motor_recommend = recFull;
    }
    /*

*/
    if (motor_options && motor_options.length) {
      /*
*/
      /*





*/
      var SV_MIN = (typeof SV_MIN_RPM === 'number' && SV_MIN_RPM > 0) ? SV_MIN_RPM : 30;
      var flat = [];
      if (pick && pick.tier === 3000 && pick.P <= 0.75 + 1e-9) {
        (pick.rec || []).forEach(function (m2) {
          var row = Object.assign({}, m2);
          row.gearbox = { type: pick.ip > 1 ? '行星减速机' : '同步带', ratio: (pick.belt * pick.ip) + ':1', out_rpm: Math.round(pick.tier / (pick.belt * pick.ip)) };
          row.belt = pick.belt; row.ip = pick.ip; row.tier = pick.tier;
          flat.push(row);
        });
        var LADDER = [0.05, 0.1, 0.2, 0.4, 0.55, 0.75];
        /**/
        var ratioCands = [];
        for (var bL = 0; bL < beltList.length; bL++) {
          for (var kL = 0; kL <= GB_STD.length; kL++) {
            var ipL0 = kL === 0 ? 1 : GB_STD[kL - 1];
            var totL0 = beltList[bL] * ipL0;
            var nReqL0 = nScrew * totL0;
            if (!(nReqL0 > 0) || nReqL0 < SV_MIN - 1e-9 || nReqL0 > 3000 + 1e-9) continue;
            ratioCands.push({ belt: beltList[bL], ip: ipL0, tot: totL0, nReq: nReqL0,
              Tm: T_f0 / (totL0 * (ipL0 > 1 ? gbEffOf(ipL0) : 1)) });
          }
        }
        ratioCands.sort(function (a, b) { return (a.tot - b.tot) || (a.ip - b.ip); });
        LADDER.forEach(function (pL) {
          for (var rL = 0; rL < ratioCands.length; rL++) {
            var rc = ratioCands[rL];
            var recL = motorRecommend(libM, cal, 3000, rc.Tm, 3000 * rc.Tm / 9550, { nReq: rc.nReq, all: true });
            var hitL = null;
            for (var qL = 0; qL < recL.length; qL++) {
              if (Math.abs(recL[qL].power_kW - pL) < 1e-6) { hitL = recL[qL]; break; }
            }
            if (!hitL) continue;
            var dupL = flat.some(function (x) { return x.code === hitL.code && x.belt === rc.belt && x.ip === rc.ip; });
            if (!dupL) {
              var rowL = Object.assign({}, hitL);
              rowL.gearbox = { type: rc.ip > 1 ? '行星减速机' : '同步带', ratio: rc.tot + ':1', out_rpm: Math.round(3000 / rc.tot) };
              rowL.belt = rc.belt; rowL.ip = rc.ip; rowL.tier = 3000;
              flat.push(rowL);
            }
            break;
          }
        });
      } else {
        var ordered = motor_options.slice();
        var pi0 = ordered.indexOf(pick);
        if (pi0 > 0) { ordered.splice(pi0, 1); ordered.unshift(pick); }
        ordered.forEach(function (o) {
          (o.rec || []).forEach(function (m2) {
            var row = Object.assign({}, m2);
            row.gearbox = { type: o.ip > 1 ? '行星减速机' : '同步带', ratio: (o.belt * o.ip) + ':1', out_rpm: Math.round(o.tier / (o.belt * o.ip)) };
            row.belt = o.belt; row.ip = o.ip; row.tier = o.tier;
            flat.push(row);
          });
        });
      }
      if (flat.length) res.motor_recommend = flat;
  /*

*/
  var weakRows3 = [];
  if (!(pick && pick.tier === 3000 && pick.P <= 0.75 + 1e-9)) {
  (motor_options || []).forEach(function (o) {
    if (!o.weak || !o.weak.rec || !o.weak.rec.length) return;
    var wkTot = o.weak.belt * o.weak.ip;
    o.weak.rec.forEach(function (m2) {
      if (weakRows3.some(function (x) { return x.code === m2.code && x.tier === o.tier; })) return;
      if (m2.power_kW != null && pick && pick.P != null && m2.power_kW > pick.P * 3 + 1e-9) return;
      var row = Object.assign({}, m2);
      row.gearbox = { type: o.weak.ip > 1 ? '行星减速机' : '同步带', ratio: wkTot + ':1', out_rpm: Math.round(o.tier / wkTot) };
      row.belt = o.weak.belt; row.ip = o.weak.ip; row.tier = o.tier;
      row.weak = true; row.weak_nreq = Math.round(o.weak.nReq);
      weakRows3.push(row);
    });
  });
  }
  /*
*/
  if (weakRows3.length > 2) {
    var weakKept5 = [], weakSeen5 = {};
    for (var wi5 = 0; wi5 < weakRows3.length && weakKept5.length < 2; wi5++) {
      var cW5 = String(weakRows3[wi5].code);
      if (weakSeen5[cW5]) continue;
      weakSeen5[cW5] = 1;
      weakKept5.push(weakRows3[wi5]);
    }
    weakRows3 = weakKept5;
  }
  if (weakRows3.length) res.motor_weak = weakRows3;
    }
    /*
*/
    res.motor_options = (motor_options || []).map(function (o, i) {
      return {
        idx: i + 1,
        tier: o.tier, belt: o.belt, ip: o.ip, etaP: o.etaP,
        total: o.belt * o.ip, nReq: Math.round(o.nReq), P: r2(o.P), Tm: r2(o.Tm),
        rec: o.rec, recommended: o === pick, overspeed: !!o.overspeed, noMotor: !!o.noMotor
      };
    });
    res.motor_sync = tier; res.rpm_needed = Math.round(nReq);
    res.motor_power_kW = r2(P); res.total_power_kW = r2(P * (cal.sync === '电气' ? cal.units : 1));
    res.speed_mm_s = r1(vReq);
    res.motor_real_missing = !rec.length;
    if (!rec.length) {
      /*
*/
      var capT = 0, capP = 0;
      var wantsB = brandMatchers(cal);
      (libM || []).forEach(function (m) {
        if (m.kind !== 'servo') return;
        var b = String(m.brand || '');
        if (wantsB.length && !wantsB.some(function (p) { return b.indexOf(p) === 0; })) return;
        if (m.torque_Nm != null) capT = Math.max(capT, m.torque_Nm);
        if (m.power_kW != null) capP = Math.max(capP, m.power_kW);
      });
      res.motor_real_note = '已按螺旋升降机口径逐档配出减速比（转速档 × 同步带 × 行星标准比），但所选品牌库内无覆盖本工况的真机型：'
        + '本工况电机端需 ≥' + r2(res.T_final_Nm) + 'Nm @' + Math.round(nReq) + 'rpm、≥' + r2(res.motor_power_kW) + 'kW'
        + (capT > 0 ? '；所选品牌库内最大仅 ' + r2(capT) + 'Nm/' + r2(capP) + 'kW' : '')
        + '。请勾选大功率品牌（汇川 ISMG/ESMG/MEG；西门子域已自动接棒 S120 仍无解）或加大导程/降低速度，或与力姆泰克工程师确认。';
      warnings.push(res.motor_real_note);
    }
    /*
*/
    (function () {
      var idxT = -1, iR, mov = [], rest = [];
      for (iR = 0; iR < steps.length; iR++) { if (steps[iR][0] === '驱动扭矩') { idxT = iR; break; } }
      if (idxT > 0) {
        for (iR = idxT; iR < steps.length; iR++) {
          if (steps[iR][0] === '同步带定比' || steps[iR][0] === '减速机效率') mov.push(steps[iR]);
          else rest.push(steps[iR]);
        }
        if (mov.length) steps.splice.apply(steps, [idxT, steps.length - idxT].concat(mov).concat(rest));
      }
    })();
    res.all_pass = Object.keys(checks).every(function (k) { return checks[k] !== false; });
    return { result: res };
  }

  /*



*/
  function planetAutoMatch(cal, libM, nReq0, T0) {
    var best = null;
    for (var k = 0; k < GB_STD.length; k++) {
      var ip = GB_STD[k];
      var nReqP = nReq0 * ip;
      if (nReqP > 3000 + 1e-9) break;
      var eta = gbEffOf(ip);
      var Tp = r2(T0 / (ip * eta));
      var tk = pickTier(nReqP, cal, Tp);
      if (tk.fatal) continue;
      var tierP = tk.tier;
      var Pp = cal.motor_torque_override > 0 ? tierP * cal.motor_torque_override / 9550 : tierP * Tp / 9550;
      var recP = motorRecommend(libM, cal, tierP, Tp, Pp);
      if (!recP.length) continue;
      if (!best || Pp < best.P - 1e-9) {
        best = { ip: ip, eta: eta, tier: tierP, T: Tp, P: Pp, nReq: nReqP, rec: recP };
      }
    }
    if (!best) return null;
    best.note = '直连接口下电机库无覆盖 ' + r2(T0) + 'Nm 的真机型：按螺旋升降机标准减速比自动配行星减速机 i=' + best.ip
      + ':1（效率 ' + best.eta + '，减速比 3~10 档 0.90 / ≥15 档 0.80；可行标准比中取选出电机功率最小者）；电机端需求 T = '
      + r2(T0) + 'Nm ÷ ' + best.ip + ' ÷ ' + best.eta + ' = ' + best.T + 'Nm，所需转速 ' + Math.round(best.nReq)
      + 'rpm ≤ 额定 ' + best.tier + 'rpm，选出 ' + best.rec[0].brandFull + ' ' + best.rec[0].code;
    return best;
  }

  function motorRpmNote(pW, brands) {
    if (!(pW > 0)) return null;
    var tail = '伺服电机一般匹配制动器（带制动，立式/断电保持必配）；编码器按需求选择（增量/多圈绝对/旋转变压器）';
    if (pW >= 100 && pW <= 750) {
      return '功率 ' + Math.round(pW) + 'W 段：电机额定转速按 3000rpm 计算；尽量不配减速机，优先 P10/P20 同步带（该功率段伺服驱动器价格接近）；' + tail;
    }
    if (pW >= 850) {
      return '功率 ' + r2(pW / 1000) + 'kW 段：按螺旋升降机口径匹配（2026-10-28 ）——额定转速档品牌优先（西门子 2000→3000，国产 1500→2000→3000），每档把同步带 i=1/2 与行星标准比合成总速比，只取输出转速落在所需~所需×1.2 窗口内的组合、窗口内取最大速比（电机运行点最贴近额定），逐档出方案取第一可行档；客户指定转速/扭矩时按指定值计算；' + tail;
    }
    return tail;
  }

  /*


*/
  function pickTier(nReq, cal, T_f) {
    if (nReq > 3000 + 1e-9) {
      return { fatal: '速度无法覆盖：所需转速 ' + Math.round(nReq) + 'rpm 超 3000rpm，需加大导程或减小减速比' };
    }
    function Pof(rpm) { return rpm * T_f / 9550; }
    if (cal.motor_rpm_forced > 0) {
      if (cal.motor_rpm_forced + 1e-9 < nReq) {
        return { fatal: '指定电机额定转速 ' + cal.motor_rpm_forced + 'rpm 无法覆盖所需 ' + Math.round(nReq) + 'rpm（要求速度下）' };
      }
      return { tier: cal.motor_rpm_forced, forced: true };
    }
    var isSiemens = (!cal.brands.length) || isWesternBrand(cal);
    var tiers = RPM_TIERS.filter(function (t) { return t >= nReq - 1e-9 && t <= 3000; })
      .sort(function (a, b) { return a - b; });
    if (!tiers.length) {
      return { fatal: '速度无法覆盖：所需转速 ' + Math.round(nReq) + 'rpm 超 3000rpm' };
    }
    var tier = tiers[0];
    if (Pof(3000) <= 0.75 && tiers.indexOf(3000) >= 0) {
      tier = 3000;                                     //
    } else {
      var pref = isSiemens ? [2000, 3000, 1500] : [1500, 2000, 3000];
      for (var i0 = 0; i0 < pref.length; i0++) if (tiers.indexOf(pref[i0]) >= 0) { tier = pref[i0]; break; }
    }
    return { tier: tier };
  }

/**/

  /*





*/
  var CYL_FOREIGN_RE = /(^|[^A-Za-z0-9])(SJA|SJB|SCA|SCB|KV|EHB|DHB|LAM|LAP|LBP)(?![0-9]*[A-Za-z])/;
  function forcedModelsOf(cal, data) {
    var tx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
    var checked = Array.isArray(cal.special) ? cal.special : [];
    var joined = Object.keys(tx)
      .filter(function (k) { return checked.indexOf(k) >= 0; })
      .map(function (k) { return String(tx[k] || ''); }).join(' ');
    if (!joined) return { models: [], multi: false };
    var up = joined.toUpperCase();
    var fm = CYL_FOREIGN_RE.exec(up);
    var foreign = fm ? fm[2] : null;
    var hits = [];
    Object.keys(data.models).forEach(function (mid) {
      if (new RegExp('(^|[^A-Za-z0-9])' + mid + '(?![0-9A-Za-z])').test(up)) hits.push(mid);
    });
    if (hits.length <= 1) return { models: hits, multi: false, foreign: foreign };
    hits.sort(function (a, b) {
      return (Number(String(b).replace(/[^0-9]/g, '')) || 0) - (Number(String(a).replace(/[^0-9]/g, '')) || 0);
    });
    return { models: [hits[0]], multi: true, foreign: foreign };
  }

  function autoSelect(inp, data) {
    var cal = toCalc(inp, data);
    /*

*/
    var wantTrap = String(cal.precision) === '梯形';
    var out = { cal: cal, schemes: [], skipped: [], processUnmet: [], warnings: [] };
    if (!(cal.load_kN > 0 || cal.load_pull_kN > 0)) {
      out.error = '总负载推力 / 总负载拉力至少填写一项。';
      return out;
    }
    if (!(cal.stroke > 0) || !(cal.speed_req > 0)) {
      out.error = '行程与速度为必填项。';
      return out;
    }
    /*


*/
    var forcedInfo = forcedModelsOf(cal, data);
    var forcedNotes = [];
    /**/
    if (forcedInfo.foreign) {
      out.warnings.push('特殊要求中的型号 ' + forcedInfo.foreign
        + ' 不属于电缸产品线，无法执行——请检查特殊要求');
    }
    if (forcedInfo.models.length) {
      if (forcedInfo.multi) forcedNotes.push('特殊要求中出现多个型号代号，按规格最大者执行：' + forcedInfo.models[0]);
      var midF = forcedInfo.models[0];
      var famF = midF.replace(/[0-9].*$/, '');
      /**/
      var fCands = candidatesOf(data, famF).filter(function (c) {
        /**/
        if (wantTrap !== !!c.is_trap) return false;
        return c.model === midF || String(c.model).indexOf(midF + '-') === 0;
      });
      fCands.sort(function (a, b) { return a.lead - b.lead; });
      var fSchemes = [], fUnmet = '';
      fCands.forEach(function (c) {
        var rF = evalCandidate(c, cal);
        if (rF.fatal) { if (!fUnmet) fUnmet = c.model + ' ' + c.variant + '：' + rF.fatal; return; }
        if (!rF.result.all_pass) {
          if (!fUnmet) fUnmet = c.model + ' ' + c.variant + '：部分校核未通过（'
            + Object.keys(rF.result.checks).filter(function (k) { return rF.result.checks[k] === false; }).join('、') + '）';
          return;
        }
        fSchemes.push({ cand: c, rec: { result: rF.result, allPass: true },
          tierLabel: fSchemes.length === 0 ? '特殊要求指定型号' : '指定型号 · ' + c.variant + '（放大档）' });
      });
      if (fSchemes.length) {
        forcedNotes.push('已按特殊要求指定型号选型：' + midF);
        fSchemes.forEach(function (s) {
          forcedNotes.forEach(function (w) { if (s.rec.result.warnings.indexOf(w) < 0) s.rec.result.warnings.push(w); });
        });
        out.schemes = fSchemes;
        out.chosen = fSchemes[0].cand;
        out.chosenResult = fSchemes[0].rec.result;
        return out;
      }
      forcedNotes.push('特殊要求指定型号 ' + midF + '：'
        + (fCands.length ? '没有通过全部校核的档位' + (fUnmet ? '（' + fUnmet + '）' : '')
          : '型号库中无可用导程档（样本标注待厂家确认的型号不参与自动选型）')
        + '，已按通用规则选型，请与厂家技术确认');
    }
    var cands = [];
    seriesOrder(cal).forEach(function (s) {
      cands = cands.concat(candidatesOf(data, s));
    });
    /*


*/
    cands.sort(function (a, b) {
      var na = Number(String(a.model).replace(/[^0-9]/g, '')) || 0;
      var nb = Number(String(b.model).replace(/[^0-9]/g, '')) || 0;
      return (na - nb) || (a.lead - b.lead) || (a.model < b.model ? -1 : 1);
    });
    /*

*/
    var fReqSingle = Math.max(cal.load_kN || 0, cal.load_pull_kN || 0) / (cal.units || 1);
    /**/
    var fReqSingleDisp = fReqSingle;
    if (cal.sync === '电气') fReqSingle = fReqSingle * 1.5;
    cands = cands.filter(function (c) { return c.rated_kN > 0 && c.rated_kN >= fReqSingle - 1e-9; });
    /**/
    cands = cands.filter(function (c) { return wantTrap ? !!c.is_trap : !c.is_trap; });
    if (!cands.length) {
      out.error = '所选系列内无额定推力 ≥ ' + r2(fReqSingle) + 'kN'
        + (cal.sync === '电气' ? '（单缸 ' + r2(fReqSingleDisp) + 'kN ×1.5 偏载选型，2026-11-03 批复）' : '（单缸要求）')
        + '的型号：请更换系列或与厂家技术确认特殊规格。';
      /**/
      if (forcedNotes.length) out.warnings = out.warnings.concat(forcedNotes);
      return out;
    }
    var seenScheme = {};
    /*

*/
    var passedOnce = false;
    for (var i = 0; i < cands.length && out.schemes.length < 3; i++) {
      var c = cands[i];
      /*
*/
      var calList = [cal];
      var r = null;
      for (var ci = 0; ci < calList.length; ci++) {
        r = evalCandidate(c, calList[ci]);
        if (!r.fatal) break;
      }
      if (r.fatal) {
        /*
*/
        if (r.fatal === '行程超限') continue;
        var txt = c.model + ' ' + c.variant + '：' + r.fatal;
        var det = [];
        if (r.life && r.life.life_km != null) det.push('理论寿命 ' + r.life.life_km + 'km < 需要 ' + (r.life.annual_km ? Math.round(r.life.annual_km * cal.life_years) + 'km（' + cal.life_years + ' 年）' : '—'));
        if (r.stability_Lk_mm != null) det.push('允许行程约 ' + r.stability_Lk_mm + 'mm');
        if (r.steps && r.steps.length) {
          var last = r.steps[r.steps.length - 1];
          if (det.length && last) txt += '（' + det.join('；') + '）';
        }
        if (!passedOnce) out.processUnmet.push({ model: c.model + ' ' + c.variant, text: txt });
        continue;
      }
      var res = r.result;
      if (!res.all_pass) {
        if (!passedOnce) out.processUnmet.push({ model: c.model + ' ' + c.variant, text: '部分校核未通过：' + Object.keys(res.checks).filter(function (k) { return res.checks[k] === false; }).join('、') });
        continue;
      }
      var key = res.model + '|' + res.variant;
      if (seenScheme[key]) continue;
      seenScheme[key] = 1;
      passedOnce = true;
      out.schemes.push({
        cand: c,   /**/
        rec: { result: res, allPass: true },
        tierLabel: out.schemes.length === 0 ? '最小可行（额定推力覆盖即可）'
          : out.schemes.length === 1 ? '放大一号（寿命/稳定性裕量更足）' : '裕量型（高频/长寿命工况推荐）'
      });
    }
    if (out.schemes.length) {
      out.chosen = out.schemes[0].cand;
      out.chosenResult = out.schemes[0].rec.result;
      /**/
      forcedNotes.forEach(function (w) {
        out.schemes.forEach(function (s) {
          if (s.rec.result.warnings.indexOf(w) < 0) s.rec.result.warnings.push(w);
        });
      });
    } else {
      out.error = '四个系列内没有全部校核通过的型号：请放宽行程/速度/寿命要求，或与厂家技术确认特殊工况。';
    }
    return out;
  }

  g.SJ_CylEngine = {
    toCalc: toCalc,
    autoSelect: autoSelect,
    evalCandidate: evalCandidate,
    stabilityCheck: stabilityCheck,
    motorRecommend: motorRecommend,
    stdLimitOf: stdLimitOf,
    stdLimitAltOf: stdLimitAltOf,
    LIFE_YEARS_DEFAULT: LIFE_YEARS_DEFAULT
  };
})(typeof window !== 'undefined' ? window : globalThis);
