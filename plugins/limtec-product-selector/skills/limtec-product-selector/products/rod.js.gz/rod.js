/*


*/
(function (g) {
  'use strict';
  var D = function () { return g.SJ_ROD_DATA || {}; };
  var ENG = function () { return g.SJ_RodEngine; };
  var C = g.SJCore;

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  /**/
  function cleanNote(s) {
    if (s == null) return s;
    return String(s)
      .replace(/20\d{2}-\d{2}-\d{2}\s*第\s*[0-9㊀-㊉]+\s*轮\s*总经理(?:定稿|批复|口径|指令)?\s*[：:]?\s*/g, '')
      .replace(/第\s*[0-9㊀-㊉]+\s*轮\s*总经理(?:定稿|批复|口径|指令)?\s*[：:]?\s*/g, '')
      .replace(/20\d{2}-\d{2}-\d{2}\s*总经理(?:定稿|批复|口径|指令)?\s*[：:]?\s*/g, '')
      .replace(/\s*(?:定稿|批复|口径|指令|确认)?\s*[：:]?\s*/g, '')
      .replace(/(?:批复|定稿)\s*[：:]?\s*/g, '')
      .replace(/[（(]\s*[）)]/g, '')
      .replace(/\s{2,}/g, ' ')
      .trim();
  }
  function fN(x, n) { return C ? C.fN(x, n === undefined ? 2 : n) : String(x); }
  function iN(x) { return C ? C.iN(x) : String(x); }
  function catSrc(file) {
    var bin = g.SJ_CATALOG_BIN;
    if (bin && bin[file]) {
      return 'data:image/' + (/\.jpe?g$/i.test(file) ? 'jpeg' : 'png') + ';base64,' + bin[file];
    }
    return (g.SJ_CATALOG_BASE || './assets/catalog/') + encodeURIComponent(file);
  }

  /**/
  function sVer() {
    var v = (g.SJCatalog && g.SJCatalog.SAMPLES_VER) || '';
    return v ? '?v=' + encodeURIComponent(v) : '';
  }
  function famName(fam) {
    return fam === 'LAM' ? '小型电动推杆 LAM' : fam === 'LAP' ? '梯形丝杠电动推杆 LAP' : '滚珠丝杠电动推杆 LBP';
  }
  function seriesMeta(v) {
    var s = (D().series || []).filter(function (x) { return x.v === v; })[0] || {};
    s.t = s.t || famName(v);
    return s;
  }
  function nameOf(list, v) {
    var h = (list || []).filter(function (x) { return x.v === v; })[0];
    return h ? h.t : (v || '');
  }
  function isLam(fam) { return fam === 'LAM'; }
  /*
*/
  function isLamSub(sub) {
    var s = String(sub || '');
    return s.indexOf('LAM') === 0 || s.indexOf('LBM') === 0;
  }
  function jointText(joint, sub) {
    return nameOf(D().joints, joint);
  }
  function jointCode(joint, sub) {
    return joint;
  }
  /*
*/
  /**/
  function lsGroup(inp) {
    var g = String((inp && inp.lam_group) || 'LAM3');
    if (g === 'LAM5') return 'LAM5';
    if (g === 'LAM6') return 'LAM6';
    if (g === 'LAM89') return 'LAM89';
    return 'LAM3';
  }
  function ls(inp) {
    var spec = (D().lam35_specs || {});
    var key = lsGroup(inp);
    var out = {};
    ['volt', 'fb', 'shell', 'ip', 'limit', 'screw'].forEach(function (k) {
      out[k] = (spec[k] || {})[key] || [];
    });
    return out;
  }
  /**/
  function bracketCode(sub, side) {
    if (!side || side === '无') return '';
    var pre = ((D().lam35_specs || {}).bracketPrefix || {})[sub];
    return pre ? (pre + side) : '';
  }

  /* ================= SCHEMA ================= */
  var SCHEMA = [
    { key: 'series', label: '型号系列', type: 'cards', def: 'LAP', group: '选择1 · 型号系列', required: true,
      optionsFn: function () { return (D().series || []).map(function (s) { return { v: s.v, t: s.t, img: s.img }; }); },
      hint: '选择系列后，下方显示该系列图片与技术参数说明；右侧快捷通道可直接输入详细型号查参数' },
    /**/
    { key: 'lam_group', label: '小型推杆系列', type: 'cards', def: 'LAM3', group: '选择1 · 型号系列',
      showWhen: { seriesIn: ['LAM'] },
      optionsFn: function () { return (D().lam_series || []).map(function (s) { return { v: s.v, t: s.t, img: s.img }; }); },
      hint: 'LAM3 / LAM5 / LAM6 / LAM8-9 四个系列，点选后按该系列型号范围选型' },

    /*

*/
    { key: 'units', label: '台数 / 布置', type: 'select', def: '1', group: '选择2 · 台数与布置',
      showWhen: function () { return true; },
      optionsFn: function (inp) {
        var arr = D().unit_counts || [{ v: '1', t: '单台电动推杆' }];
        /**/
        if (inp && inp.series === 'LAM') arr = arr.filter(function (o) { return String(o.v) === '1'; });
        return arr;
      },
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '小型推杆（LAM）按单台供货；两台联动请选 LAP / LBP'
          : '两台按机械同步：一台带电机（P4 法兰+轴输入）经传动轴带另一台（P2 双输入轴），负载按 2 台平摊';
      } },
    { key: 'layout', label: '布置形式', type: 'imgpick', def: '', group: '选择2 · 台数与布置',
      showWhen: { units: '2' },
      optionsFn: function () {
        return (D().rod_layouts || []).map(function (o) { return { v: o.v, t: o.t, img: o.img }; });
      },
      hint: '电机内侧：电机在两台之间；电机外侧：电机在最外侧。两种均为 1 根传动轴 + 2 个联轴器' },
    /*

*/
    { key: 'sync', label: '同步方式', type: 'select', def: '机械', group: '选择2 · 台数与布置',
      showWhen: { units: '2' },
      optionsFn: function () { return [{ v: '机械', t: '机械同步（默认）' }, { v: '电气', t: '电气同步' }]; },
      hint: '机械同步：1 台电机经 1 根传动轴带 2 台（传动轴 + 2 个联轴器）；电气同步：每台 1 台伺服电机独立直驱，无传动轴/联轴器' },
    { key: 'platform_L', label: '平台长度', type: 'number', unit: 'mm', step: 'any', def: null, group: '选择2 · 台数与布置',
      showWhen: function (inp) { return !!(inp && String(inp.units) === '2' && inp.sync !== '电气'); },
      hint: '选填：填写后传动轴按平台中心距出实际长度（电气同步无传动轴，不显示）' },

    { key: 'load', label: '负载推力', type: 'number', unit: '', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'load_unit',
      hint: '负载拉力工况可不填（按 0 计算）；负载推力 / 负载拉力至少填写一项' },
    { key: 'load_pull', label: '负载拉力', type: 'number', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'load_pull_unit',
      unit: function (inp) { return unitSuffix(inp && inp.load_pull_unit, inp && inp.series); },
      hint: '拉力工况不校核稳定性（按 0 计算）；单位独立可选（默认随界面语言）' },
    { key: 'static_load', label: '静载', type: 'number', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'static_load_unit',
      unit: function (inp) { return unitSuffix(inp && inp.static_load_unit, inp && inp.series); },
      hint: '静态保持载荷（如长期压住工件），用于核对自锁与制动器配置' },
    { key: 'speed', label: '速度', type: 'number', unit: 'mm/s', step: 'any', def: null, group: '选择3 · 基本参数',
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '请填负载（满载）速度：按所选档位的满载速度校核，先取速度最接近的档位、再取推力大于要求的最小档；满载速度低于要求 ≤10% 按接近放行'
          : '≤100 mm/s';
      } },
    { key: 'stroke', label: '行程', type: 'number', unit: 'mm', step: 'any', def: null, group: '选择3 · 基本参数',
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '按型号最大行程校核；超标准行程按非标与厂家确认'
          : '行程 >300mm 时按样本稳定性曲线校核（压载工况）';
      } },
    /*

*/
    { key: 'cycles_per_day', label: '每日工作次数', type: 'number', unit: '次', step: 'any', group: '选择3 · 基本参数',
      def: function (inp) { return (inp && inp.series === 'LAM') ? 10 : 50; },
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '默认 10 次/日；基准 ≤30 次/日（10% 工作制：20 分钟内运行 2 分钟），超过 50 次会提示改选 LAP / LBP'
          : '超过 200 次/日建议改电缸；基准 50 次/日、负载率低可放宽（与 SJA 同规则）';
      } },
    { key: 'hours_per_day', label: '每日工作小时', type: 'number', unit: '小时', step: 'any', def: 8, group: '选择3 · 基本参数' },
    { key: 'days_per_year', label: '每年工作天数', type: 'number', unit: '日', step: 'any', def: 300, group: '选择3 · 基本参数' },
    /*


*/
    { key: 'limit_sw', label: '限位开关', type: 'select', def: 'STD',
      group: '选择3 · 基本参数',
      showWhen: function (inp) { return !!(inp && (inp.series === 'LAP' || inp.series === 'LBP')); },
      optionsFn: function (inp) {
        var sub = limitSub(inp);
        var std = limitStd(sub);
        var out = [{ v: 'STD', t: '标配（按基座号自动：22~40 用 FCM，56 以上用 FCP）' }];
        limitAllowed(inp, sub).forEach(function (x) {
          out.push({ v: x.v, t: x.t + (std === x.v ? '　← 本机标配' : '') });
        });
        return out;
      },
      hint: function (inp) {
        var sub = limitSub(inp);
        var base = '样本 p9：22~40 标配 FCM 磁感应开关（可选 FCP 接近开关 / FCE 机械外置开关）；'
          + '56 以上标配 FCP 接近开关（可选 FCE，不能选 FCM）';
        if (sub) return base + '；当前工况落 ' + sub + '，标配 ' + (limitStd(sub) || '—');
        if (hasAR(inp)) return base + '；已选 AR 防反转装置 → FCM 不可选（互斥）';
        return base + '；填好负载/速度/行程后按选定基座号自动定标配';
      } },
    /**/
    { key: 'drive', label: '驱动选择', type: 'select', def: 'ac3', group: '选择3 · 基本参数',
      showWhen: function (inp) { return !(inp.series === 'LAM' && inp.lam_group === 'LAM5'); },
      optionsFn: function (inp) {
        var fam = (inp && inp.series) || 'LAP';
        /**/
        var bkw = ((fam === 'LAP' || fam === 'LBP') ? ac1BaseKw(inp) : null);
        var over = (bkw != null && bkw > AC1_KW_MAX);
        /**/
        var elecSync = !!(inp && String(inp.units) === '2' && inp.sync === '电气');
        return (D().drives || []).filter(function (d) { return (d.fams || []).indexOf(fam) >= 0; })
          .map(function (d) {
            if (elecSync && String(d.v).indexOf('servo') !== 0) return { v: d.v, t: d.t + '（电气同步须配伺服电机）', dis: true };
            if (d.v === 'ac1' && over) return { v: d.v, t: d.t + '（超单相上限 5.5kW，不可选）', dis: true };
            return { v: d.v, t: d.t };
          });
      },
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '直流电机 12 / 24 / 48 VDC，标配 24VDC'
          : '可配交流 / 直流 24VDC / 伺服 / 步进——伺服与步进按样本电机参数选配，报价与厂家确认';
      } },
    /*
*/
    { key: 'servo_brand', label: '伺服电机品牌（可多选）', type: 'checks', def: [],
      group: '选择3 · 基本参数',
      showWhen: function (inp) {
        return !!(inp && (inp.series === 'LAP' || inp.series === 'LBP')
          && (inp.drive === 'servo220' || inp.drive === 'servo380'));
      },
      optionsFn: function () {
        return [
          { v: '汇川', t: '汇川（SV630 / SV660 + MS1 系列，1500 / 3000rpm）' },
          { v: 'V90', t: '西门子 V90（1FL6）' },
          { v: 'S200', t: '西门子 S200（1FL2）' },
          { v: 'S120', t: '西门子 S120（1FK7 / 1FT7，大功率段）' },
          { v: '台达', t: '台达（ASDA-A3 + ECMA 系列，220V 为主）' },
          { v: '雷赛', t: '雷赛（L7 / ACM2 系列，380V 1500rpm 为主）' },
          { v: '惠斯通', t: '惠斯通防爆（ST-EX 系列，隔爆 Ex d IIB T4 Gb，3000rpm 为主 + 折算档）' }
        ];
      },
      hint: '不勾选 = 西门子 V90 → S200 → S120 优先（与电缸一致），惠斯通防爆只在显式勾选时进选型；'
        + '勾选后电机表只在所选品牌内选型，结果页给出所需功率/转速/扭矩与可配套机型' },
    { key: 'temp', label: '工作温度要求', type: 'select', def: '20', group: '选择3 · 基本参数',
      optionsFn: function (inp) {
        var isLam = inp && inp.series === 'LAM';
        return (D().temps || []).filter(function (t) { return !(isLam && String(t.v) === '80'); })
          .map(function (t) { return { v: t.v, t: t.t }; });
      },
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? '-30℃ 及以下为非标定制，选型结果会给出定制提示（LAM 无 +80℃ 档）'
          : '-30℃ 及以下、+80℃ 为非标定制，选型结果会给出定制提示';
      } },
    /*
*/
    { key: 'special', label: '特殊要求', type: 'checks', def: [], group: '选择3 · 基本参数', textable: true,
      options: [{ v: '防腐要求', t: '防腐要求', ph: '如 316 不锈钢、盐雾等级' }, { v: '防爆要求', t: '防爆要求', ph: '如 Ex d IIB T4' },
                { v: '真空要求', t: '真空要求', ph: '如 10^-5 Pa、真空润滑脂' },
                { v: '其他特殊要求', t: '其他特殊要求', ph: '可注明型号，如 LAP56' }] },
    /*


*/
    { key: 'install', label: '安装方式（输入形式）', type: 'imgpick', def: 'P3', group: '选择4 · 安装方式与接头',
      showWhen: { seriesIn: ['LAP', 'LBP'] },
      optionsFn: function (inp) {
        var two = String(inp && inp.units) === '2';
        /**/
        var sy = String((inp && inp.sync) || '').indexOf('电气') >= 0;
        return (D().installs || []).filter(function (x) {
          if (!two) return true;
          /*

*/
          return sy ? x.v === 'P3' : true;
        }).map(function (x) {
          if (two) return { v: x.v, t: x.t, img: x.img, std: sy && x.v === 'P3' };
          return { v: x.v, t: x.t, img: x.img, std: x.v === 'P3' };
        });
      },
      hint: function (inp) {
        if (String(inp && inp.units) !== '2') {
          return 'P3 单电机法兰输入为标配；P2 双输入轴不用选择输入轴方向，其余输入形式需选择 RH / LH';
        }
        return String((inp && inp.sync) || '').indexOf('电气') >= 0
          ? '两台联动（电气同步）：每台 P3 单电机法兰输入、各自配电机直驱，无传动轴与从动台'
          : '两台联动（机械同步）：主机 P1~P4 任选 + 从动台 P2（双输入轴），传动轴 1 根 + 联轴器 2 个；P2 不写输入轴方向';
      } },
    { key: 'input_dir', label: '轴和电机法兰方向', type: 'select', def: 'RH', group: '选择4 · 安装方式与接头',
      showWhen: { seriesIn: ['LAP', 'LBP'], installNot: 'P2' },
      optionsFn: function () { return (D().input_dirs || []).map(function (x) { return { v: x.v, t: x.t }; }); } },
    { key: 'joint', label: '接头形式', type: 'imgpick', def: 'ROE', group: '选择4 · 安装方式与接头',
      optionsFn: function (inp) {
        var fam = (inp && inp.series) || 'LAP';
        var lg = (inp && inp.series === 'LAM') ? String(inp.lam_group || '') : '';
        /**/
        var lamOne = (lg === 'LAM6' || lg === 'LAM89');
        var lamCard = lamOne || lg === 'LAM3' || lg === 'LAM5';   /**/
        return (D().joints || []).filter(function (x) {
          if ((x.fams || []).indexOf(fam) < 0) return false;
          if (lamOne && x.v !== 'ROE') return false;
          return true;
        }).map(function (x) {
          /*





*/
          var img = (lamCard && x.v === 'FO') ? 'joint-lam-fo.jpg' : x.img;
          var z = lamCard ? 0.5 : (x.v === 'ROE' ? 0.45 : 0.85);
          return { v: x.v, t: x.t, img: img, z: z };
        });
      },
      hint: function (inp) {
        if (!(inp && inp.series === 'LAM')) return '接头 6 种：FL 法兰端 / TS 球形铰接 / ROE 销孔端 / FO 叉销端 / NF 外螺纹 / BA 标准内螺纹（推杆样本 p25）';
        var lg = String((inp && inp.lam_group) || '');
        if (lg === 'LAM6' || lg === 'LAM89') return '该组仅 ROE 销孔端 一种接头';
        return '按专门样本仅 ROE 销孔端 / FO 叉销端 两种';
      } },
    /**/
    { key: 'accessories', label: '附件选择', type: 'checks', def: [], group: '选择4 · 安装方式与接头',
      /**/
      /*
*/
      showWhen: function (inp) {
        if (!(inp && inp.series === 'LAM')) return true;
        var lg = String(inp.lam_group || '');
        return !(lg === 'LAM3' || lg === 'LAM6');
      },
      optionsFn: function (inp) {
        var fam = (inp && inp.series) || 'LAP';
        return (D().accessories || []).filter(function (a) {
          return fam === 'LAM' ? !!a.lamOnly : !a.lamOnly;
        }).map(function (a) { return { v: a.v, t: a.t }; });
      },
      hint: function (inp) {
        return (inp && inp.series === 'LAM')
          ? 'LAM 只列 内置限位开关 / 电流保护 / 霍尔开关；不自锁型号（LBM9）制动器由方案书提示必配'
          : '不自锁型号的制动器随电机内置（清单不另列 BRE）；行程>800mm 时伸缩管与护管加长 200mm';
      } },

    /*


*/
    { key: 'lam_volt', label: '① 电压代码', type: 'select', def: '2', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).volt || []).slice(); },
      hint: '规格码第 1 段（样本 p6/p8）。注意 LAM33 只有 1 / 2 / 3 / 5 / 6（无 48V、无 36V PTC）' },
    { key: 'lam_lower', label: '⑤ 下端型式', type: 'select', def: '1', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).lower || []).slice(); },
      hint: '1~3 铝压铸无槽（孔径 6.4/8.0/10.0）；4~6 铝压铸 U 型槽 6×10.5（孔径 6.4/8.0/10.0），齿轮箱下盖一体成型' },
    { key: 'lam_upper', label: '⑥ 上端型式', type: 'select', def: '1', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).upper || []).slice(); },
      hint: '1/2/6 铝压铸无槽（孔径 6.4/8.0/10.0）；3/4/5 铝加工 U 型槽 6×16（孔径 10.0/6.4/8.0）' },
    { key: 'lam_angle', label: '⑦ 下端角度', type: 'select', def: '1', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).angle || []).slice(); },
      hint: '逆时针方向的角度（样本 p6/p8）' },
    { key: 'lam_limit', label: '⑧ 极限开关功能', type: 'select', def: '3', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).limit || []).slice(); },
      hint: '1/2 切电流（两端断电）；3/4 信号输出（两端给信号）。带第三个微动开关的为 2 / 4' },
    { key: 'lam_signal', label: '⑨ 信号输出', type: 'select', def: '0', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).signal || []).slice(); },
      hint: '0 无 / 1 POT 电位计 / 3 磁簧开关 / 5 霍尔×2；选 1·3·5 时样本要求安装尺寸 +30mm（已计入标注）' },
    { key: 'lam_plug', label: '⑩ 插头 / 插座', type: 'select', def: '1', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).plug || []).slice(); } },
    { key: 'lam_cable', label: '⑪ 线长', type: 'select', def: '3', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).cable || []).slice(); } },
    { key: 'lam_ip', label: '⑫ IP 等级', type: 'select', def: '3', group: '选择5 · 型号规格码（LAM32/33）',
      showWhen: specCodeActive, keepGroupDom: true,
      optionsFn: function () { return ((D().lam_code || {}).ip || []).slice(); },
      hint: '1 无 / 2 IP54 / 3 IP66 / 6 IP66D（动态 IP66）' },

    /*

*/
    /*
*/
    { key: 'lam2_volt', label: '工作电压', type: 'select', def: '24', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM5'] },
      optionsFn: function (inp) { return (ls(inp).volt || []).slice(); },
      hint: 'LAM5：12 / 24 VDC；选 12V 时 LAM55 最大负载降为 5000N（专门样本 p21）' },
    { key: 'lam2_fb', label: '反馈附件', type: 'select', def: '无', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM3'] },
      optionsFn: function (inp) { return (ls(inp).fb || []).slice(); },
      hint: 'LAM3 选电位计 POT 时，S1 / S2 档最大行程由 600mm 降为 350mm（样本 p12）；LAM5 附件为霍尔开关' },
    { key: 'lam2_bracket', label: '安装支架', type: 'select', def: '无', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM5'] },
      optionsFn: function () {
        return [{ v: '无', t: '不配支架' }, { v: 'F', t: '前端支架（35F / 53F / 55F）' }, { v: 'R', t: '尾端支架（35R / 53R / 55R）' }];
      },
      hint: '支架代号随子系列：LAM52→35F/35R、LAM53→53F/53R、LAM55→55F/55R（专门样本各页「安装支架」）；LAM50/51/54 样本未列支架，按非标确认' },
    { key: 'lam2_ctrl', label: '适配控制器', type: 'select', def: '不带', group: '选择3 · 基本参数',
      /**/
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM5', 'LAM6', 'LAM89'] },
      optionsFn: function () {
        return [
          { v: '不带', t: '不配控制器' },
          { v: '一控一', t: '一控一' },
          { v: '一控二', t: '一控二' },
          { v: '一控三', t: '一控三' },
          { v: '一控一带变压器', t: '一控一（带变压器）' },
          { v: '一控一直流直入', t: '一控一（直流直入）' },
          { v: '一控二带变压器', t: '一控二（不）同步（带变压器）' },
          { v: '一控二直流直入', t: '一控二（不）同步（直流直入）' }
        ];
      },
      hint: function (inp) {
        return ((inp && inp.lam_group) === 'LAM5')
          ? '专门样本页脚：LAM50/52/53 只有一控一/二/三；LAM54/55 另分「带变压器 / 直流直入 /（不）同步」，选项不匹配时按样本可选清单提示'
          : '样本 p16：配置控制器可 2-6 台推杆同步驱动；LAM50/52/53 只有一控一/二/三，LAM54/55 另分带变压器 / 直流直入';
      } },
    { key: 'lam2_shell', label: '外壳材料', type: 'select', def: 'AL', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM5'] },
      optionsFn: function (inp) { return (ls(inp).shell || []).slice(); },
      hint: 'LAM52 页写 6063 铝 / 316 不锈钢' },
    { key: 'lam2_ip', label: '防护等级', type: 'select', def: 'IP65', group: '选择3 · 基本参数',
      /**/
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM3', 'LAM5', 'LAM89'] },
      optionsFn: function (inp) { return (ls(inp).ip || []).slice(); },
      hint: function (inp) {
        var g = (inp && inp.lam_group) || '';
        if (g === 'LAM3') return 'IP65 / IP66 / IP66D（IP66D 为动态 IP66）';
        if (g === 'LAM89') return 'LAM8 样本 p17 为 IP65；LBM9 直流 IP66 / 交流 IP65（样本 p18）';
        return 'IP66 / IP67';
      } },
    { key: 'lam2_limit', label: '限位开关', type: 'select', def: '标配', group: '选择3 · 基本参数',
      /**/
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM3', 'LAM6', 'LAM89'] },
      optionsFn: function (inp) { return (ls(inp).limit || []).slice(); },
      hint: function (inp) {
        return ((inp && inp.lam_group) === 'LAM5')
          ? '内置机械行程开关 + 电流保护（标配）；选「取消」按非标处理'
          : 'L2 内置开关 / XL2 内置开关外出线 / FCM 外置磁感应开关（同 LAM3 样本）';
      } },
    { key: 'lam2_screw', label: '丝杠种类', type: 'select', def: 'LAM6', group: '选择3 · 基本参数',
      /**/
      showWhen: { seriesIn: ['LAM'], lam_group: ['LAM6'] },
      optionsFn: function (inp) { return (ls(inp).screw || []).slice(); },
      hint: '样本 p16：LAM6 梯形丝杠工作制 10%、LBM6 滚珠丝杠 25%（滚珠型不自锁，需配制动器）；LBM6 独立档位表尚待样本，选中后按 LAM6 六档推力选型' }
  ];

  /**/
  function defaultInput() {
    var inp = {};
    SCHEMA.forEach(function (f) {
      /*
*/
      var dv = (typeof f.def === 'function') ? f.def(inp) : f.def;
      inp[f.key] = (dv === undefined || dv === null) ? null
        : (typeof dv === 'object' ? JSON.parse(JSON.stringify(dv)) : dv);
      if (f.type === 'checks') inp[f.key] = [];
      if (f.type === 'number' && dv == null) inp[f.key] = null;
    });
    inp.load_unit = defLoadUnit(inp.series);
    inp.load_pull_unit = defLoadUnit(inp.series);
    inp.static_load_unit = defLoadUnit(inp.series);
    inp.hours_per_day = 8;
    inp.days_per_year = 300;
    return inp;
  }

  /*

*/
  function langIsZh() { try { var L = g.LANG_I18N && g.LANG_I18N.lang; return !L || L === 'zh'; } catch (e) { return true; } }
  function defLoadUnit(series) {
    if (series === 'LAM') return langIsZh() ? 'kg' : 'N';
    return langIsZh() ? 't' : 'kN';
  }
  function loadUnitOptions(inp) {
    if (inp && inp.series === 'LAM') return [{ v: 'kg', t: '公斤力（kgf）' }, { v: 'N', t: '牛（N）' }];
    return [{ v: 't', t: '吨（t）' }, { v: 'kN', t: '千牛（kN）' }, { v: 'kgf', t: '公斤力（kgf）' }, { v: 'N', t: '牛（N）' }];
  }

  /**/
  function unitSuffix(u, series) {
    if (u === 't') return langIsZh() ? 't' : 'tons';
    if (u) return u;
    return series === 'LAM' ? (langIsZh() ? 'kg' : 'N') : (langIsZh() ? 't' : 'kN');
  }
  /**/
  function unitText(inp) {
    var u = inp && inp.load_unit;
    if (inp && inp.series === 'LAM') return u === 'N' ? 'N' : 'kg';
    return unitSuffix(u, inp && inp.series);
  }

  function sanitizeInput(inp) {
    if (!inp) return;
    var d = D();
    /**/
    if ((d.series || []).map(function (s) { return s.v; }).indexOf(inp.series) < 0) inp.series = 'LAP';
    var fam = inp.series;
    /*

*/
    var VALID_U = (fam === 'LAM') ? ['kg', 'N'] : ['t', 'kN', 'kgf', 'N', 'kg'];
    if (VALID_U.indexOf(inp.load_unit) < 0) inp.load_unit = defLoadUnit(fam);
    ['load_pull_unit', 'static_load_unit'].forEach(function (uk) {
      if (VALID_U.indexOf(inp[uk]) < 0) inp[uk] = defLoadUnit(fam);
    });
    /**/
    var lg = (d.lam_series || []).map(function (s) { return s.v; });
    if (lg.indexOf(inp.lam_group) < 0) inp.lam_group = lg[0] || '';
    /*


*/
    var cycDef = (fam === 'LAM') ? 10 : 50;
    var prevFam = inp.__cycFam;
    if (prevFam && prevFam !== fam) {
      var prevDef = (prevFam === 'LAM') ? 10 : 50;
      if (inp.cycles_per_day == null || Number(inp.cycles_per_day) === prevDef) inp.cycles_per_day = cycDef;
    } else if (inp.cycles_per_day == null) {
      inp.cycles_per_day = cycDef;
    }
    inp.__cycFam = fam;
    /**/
    var dv = (d.drives || []).filter(function (x) { return x.v === inp.drive && (x.fams || []).indexOf(fam) >= 0; })[0];
    if (!dv) inp.drive = fam === 'LAM' ? 'dc24' : 'ac3';
    /**/
    var jt = (d.joints || []).filter(function (x) { return x.v === inp.joint && (x.fams || []).indexOf(fam) >= 0; })[0];
    if (!jt) inp.joint = 'ROE';
    /**/
    if (fam === 'LAM' && (inp.lam_group === 'LAM6' || inp.lam_group === 'LAM89') && inp.joint !== 'ROE') inp.joint = 'ROE';
    /**/
    var lc = d.lam_code || {};
    var LC_DEF = { volt: '2', lower: '1', upper: '1', angle: '1', limit: '3', signal: '0', plug: '1', cable: '3', ip: '3' };
    Object.keys(LC_DEF).forEach(function (k) {
      var opts = (lc[k] || []).map(function (o) { return o.v; });
      if (!opts.length) return;
      if (opts.indexOf(String(inp['lam_' + k])) < 0) inp['lam_' + k] = LC_DEF[k];
    });
    /**/
    var L35_DEF = { volt: '24', fb: '无', bracket: '无', ctrl: '不带', shell: 'AL', ip: 'IP65', limit: '标配', screw: 'LAM6' };
    var L35_OPT = {
      volt: function () { return (ls(inp).volt || []).map(function (o) { return o.v; }); },
      fb: function () { return (ls(inp).fb || []).map(function (o) { return o.v; }); },
      shell: function () { return (ls(inp).shell || []).map(function (o) { return o.v; }); },
      ip: function () { return (ls(inp).ip || []).map(function (o) { return o.v; }); },
      limit: function () { return (ls(inp).limit || []).map(function (o) { return o.v; }); },
      /**/
      screw: function () { return (ls(inp).screw || []).map(function (o) { return o.v; }); },
      bracket: function () { return ['无', 'F', 'R']; },
      ctrl: function () {
        return ['不带', '一控一', '一控二', '一控三', '一控一带变压器', '一控一直流直入', '一控二带变压器', '一控二直流直入'];
      }
    };
    Object.keys(L35_DEF).forEach(function (k) {
      var opts = L35_OPT[k]();
      if (!opts.length) return;
      /*
*/
      if (opts.indexOf(String(inp['lam2_' + k])) < 0) {
        inp['lam2_' + k] = (opts.indexOf(L35_DEF[k]) >= 0) ? L35_DEF[k] : opts[0];
      }
    });
    /**/
    var UOK = (d.unit_counts || []).map(function (o) { return String(o.v); });
    if (fam === 'LAM') inp.units = '1';
    else if (UOK.indexOf(String(inp.units)) < 0) inp.units = '1';
    if (String(inp.units) === '2') {
      var LOK = (d.rod_layouts || []).map(function (o) { return o.v; });
      if (LOK.indexOf(String(inp.layout)) < 0) inp.layout = LOK[0] || '电机内侧';
      /*


*/
      /*

*/
      inp.sync = (String(inp.sync || '').indexOf('电气') >= 0) ? '电气' : '机械';
      /*

*/
      if (inp.sync === '电气' && inp.install !== 'P3') inp.install = 'P3';
      /*


*/
      if (inp.sync === '电气' && String(inp.drive || '').indexOf('servo') !== 0) inp.drive = 'servo380';
    } else {
      inp.layout = '';
      inp.sync = '机械';
    }
    /*

*/
    if (fam === 'LAM') {      if (inp.install) inp.install = 'P1';
    } else if ((d.installs || []).map(function (x) { return x.v; }).indexOf(inp.install) < 0) {
      inp.install = 'P3';
    }
    if ((d.input_dirs || []).map(function (x) { return x.v; }).indexOf(inp.input_dir) < 0) inp.input_dir = 'RH';
    /*

*/
    var accV = (d.accessories || []).filter(function (a) {
      return fam === 'LAM' ? !!a.lamOnly : !a.lamOnly;
    }).map(function (a) { return a.v; });
    if (fam === 'LAM' && (inp.lam_group === 'LAM3' || inp.lam_group === 'LAM6')) accV = [];
    if (Array.isArray(inp.accessories)) inp.accessories = inp.accessories.filter(function (v) { return accV.indexOf(v) >= 0; });
    else inp.accessories = [];
    /*
*/
    if (fam === 'LAM') {
      inp.limit_sw = 'STD';
    } else {
      if (['STD', 'FCM', 'FCP', 'FCE', 'NONE'].indexOf(String(inp.limit_sw)) < 0) inp.limit_sw = 'STD';
      if (inp.limit_sw === 'FCM' && hasAR(inp)) inp.limit_sw = 'FCP';
    }
    /**/
    var svOk = ['汇川', 'V90', 'S200', 'S120', '台达', '雷赛', '惠斯通'];
    if (inp.drive === 'servo220' || inp.drive === 'servo380') {
      inp.servo_brand = (Array.isArray(inp.servo_brand) ? inp.servo_brand : [])
        .filter(function (v) { return svOk.indexOf(v) >= 0; });
    } else {
      inp.servo_brand = [];
    }
    /**/
    if (fam === 'LAM' && String(inp.temp) === '80') inp.temp = '20';
    if (inp.special && !Array.isArray(inp.special)) inp.special = [];
  }

  /**/
  function afterRun(inp, out) {
    if (inp && inp.series === 'LAM') return false;
    var r = out && out.chosenResult;
    /*
*/
    var changed283 = false;
    if (inp && String(inp.units) === '2') {
      if (!inp.layout) { inp.layout = '电机内侧'; changed283 = true; }
      /*

*/
      if (inp.sync === '电气') {
        if (String(inp.drive || '').indexOf('servo') !== 0) { inp.drive = 'servo380'; changed283 = true; }
        if (inp.install !== 'P3') { inp.install = 'P3'; changed283 = true; }
      }
    } else if (inp && inp.layout) {
      inp.layout = '';
      changed283 = true;
    }
    if (!r) return changed283;
    /**/
    var changed = !!(out && out.ac1_fallback);
    /**/
    if (inp.limit_sw === 'FCM' && baseNo(r.sub) != null && baseNo(r.sub) >= 56) {
      inp.limit_sw = 'FCP';
      changed = true;
      r.warnings = r.warnings || [];
      r.warnings.push('56 以上基座号（' + r.sub + '）标配 FCP 接近限位开关、不能选 FCM，已自动改为 FCP');
    }
    /*

*/
    var acc = Array.isArray(inp.accessories) ? (inp.accessories = inp.accessories || []) : (inp.accessories = []);
    if (acc.indexOf('BRE') >= 0) {
      inp.accessories = acc.filter(function (x) { return x !== 'BRE'; });
      r.accessories = inp.accessories.slice();
      changed = true;
    }
    /*

*/
    return changed || changed283;
  }

  function toCalc(input) { return ENG().toCalc(input, D()); }
  /*
*/
  function autoSelect(inp, data) {
    var d = data || D(), out;
    if (inp && inp.drive === 'ac1') {
      var bkw = ac1BaseKw(inp);
      if (bkw != null && bkw > AC1_KW_MAX) {
        inp.drive = 'ac3';
        out = ENG().autoSelect(inp, d);
        if (out && out.chosenResult) {
          out.chosenResult.warnings = (out.chosenResult.warnings || []).slice();
          out.chosenResult.warnings.push('本档基型超单相上限 5.5kW，驱动已自动改为三相交流');
        }
        if (out) out.ac1_fallback = true;
        return out;
      }
    }
    return ENG().autoSelect(inp, d);
  }

  /**/
  function motorSeg(m) {
    if (!m) return '';
    if (m.kind === 'dc24') return 'DC24V（满载 ' + m.A + 'A）';
    return 'AC3 ' + m.kw + 'kW ' + m.rpm + 'rpm 380V 50Hz';
  }
  /*





*/
  function rodDcSeg233(res, cal) {
    var dc = res && res.dc_motor;
    var volt = dc ? String(dc.volts[0]) : ({ dc12: '12', dc24: '24', dc48: '48' }[(cal && cal.drive)] || '24');
    if (!dc) {
      var moD = (res && res.mdef && res.mdef.motor) || {};
      return '直流电机 ' + volt + 'VDC（功率/转速/扭矩按需求功率折算，待样本确认'
        + (moD.A != null ? '；满载 ' + fN(moD.A, 1) + ' A' : '') + '）';
    }
    return '直流电机 ' + volt + 'VDC：功率 ' + fN(dc.p_kw, 2) + ' kW、转速 ' + dc.rpm_main + ' rpm、扭矩 '
      + fN(dc.t_nm, 1) + ' N·m、电压 ' + volt + 'VDC';
  }

  /*





*/
  var AC1_LADDER = [0.09, 0.12, 0.18, 0.25, 0.37, 0.55, 0.75, 1.1, 1.5, 2.2, 3, 4, 5.5];
  var AC1_KW_MAX = 5.5;
  /*
*/
  var _ac1KwMemo = { k: null, v: null };
  function ac1BaseKw(inp) {
    if (!inp) return null;
    var k = [inp.series, inp.load, inp.load_pull, inp.load_unit, inp.stroke, inp.speed,
      inp.cycles_per_day, inp.temp, inp.lam_group].join('|');
    if (_ac1KwMemo.k === k) return _ac1KwMemo.v;
    var v = null;
    try {
      var probe = {}, kk;
      for (kk in inp) if (Object.prototype.hasOwnProperty.call(inp, kk)) probe[kk] = inp[kk];
      var o = ENG().autoSelect(probe, D());
      var m = (o && o.chosenResult && o.chosenResult.mdef && o.chosenResult.mdef.motor) || null;
      if (m && m.kind !== 'dc24' && Number(m.kw) > 0) v = Number(m.kw);
    } catch (e) { v = null; }
    _ac1KwMemo = { k: k, v: v };
    return v;
  }
  /**/
  function ac1Pick(kw) {
    var k = Number(kw);
    if (!(k > 0)) return null;
    if (k > AC1_KW_MAX) return { kw: k, capped: false, no: true };
    if (k >= AC1_KW_MAX) return { kw: AC1_KW_MAX, capped: true, no: false };
    for (var i = 0; i < AC1_LADDER.length; i++) {
      if (AC1_LADDER[i] > k + 1e-9) {
        return { kw: Math.min(AC1_LADDER[i], AC1_KW_MAX), capped: AC1_LADDER[i] > AC1_KW_MAX, no: false };
      }
    }
    return { kw: AC1_KW_MAX, capped: true, no: false };
  }
  function kwTxt(k) { return String(Math.round(Number(k) * 1000) / 1000); }
  /**/
  function motorSegFor(cal, m) {
    if (!m) return '';
    if (cal && cal.drive === 'ac1' && m.kind !== 'dc24') {
      var p = ac1Pick(m.kw);
      if (p && !p.no) return 'AC1 ' + kwTxt(p.kw) + 'kW ' + m.rpm + 'rpm 220V 50Hz';
    }
    return motorSeg(m);
  }
  /**/
  var AC1_OVER_WARN = '【单相上限 5.5kW，本档基型超出，单相不可做，建议改三相】';

  /*
*/
  function envDocSeg(res, cal) {
    var k = (res && res.env_coef) || 1;
    if (k === 1) return '';
    var t = (res && res.temp) != null ? res.temp : (cal && cal.temp);
    var hot = Number(t) >= 80;
    var seg = '；工作温度 ' + t + '℃ 非标工况：扭矩与所需功率已按 ×' + k + ' 计，'
      + (hot ? '配高温电机 + 高温润滑脂' : '配低温电机 + 低温润滑脂');
    if (res && res.env_ok === false) seg += '；样本标配电机容量不足，须上调基型或定制' + (hot ? '高温电机' : '低温电机');
    return seg;
  }

  /*


*/
  function isServoDrive(cal) {
    return !!(cal && (cal.drive === 'servo220' || cal.drive === 'servo380'));
  }
  /*
*/
  function servoCodeShort(code) {
    var c = String(code == null ? '' : code);
    var i = c.search(/[（(]/);
    if (i > 0) c = c.slice(0, i);
    c = c.trim();
    /**/
    var mm = /^([^-]+-[^-]+)-[^-]+$/.exec(c);
    return (mm ? mm[1] : c).trim();
  }
  /*
*/
  function servoBrandShort(brand) {
    var b = String(brand == null ? '' : brand).replace(/\s+/g, ' ').trim();
    var i = b.indexOf(' ');
    return i > 0 ? b.slice(0, i) : b;
  }
  function servoPickRow(cal, res) {
    var sc = res && res.servo_calc;
    if (!sc || !sc.recommend || !sc.recommend.length) return null;
    var b = rodServoBomOf(cal, res);
    return (b && b.m) ? b.m : sc.recommend[0];
  }
  function servoVolt(cal, m) {
    if (m && m.need220) return '220V';
    return (cal && cal.drive === 'servo220') ? '220V' : '380V';
  }
  /**/
  function servoCodeSeg(cal, res) {
    var m = servoPickRow(cal, res);
    if (!m) return ('SERVO ' + servoVolt(cal, null)).trim();
    return ('SERVO ' + servoBrandShort(m.brand) + ' ' + servoCodeShort(m.code)
      + ' ' + m.power_kW + 'kW ' + iN(m.rpm) + 'rpm ' + servoVolt(cal, m)).replace(/\s+/g, ' ').trim();
  }
  /*
*/
  function servoSpecSeg(cal, res, bare) {
    var m = servoPickRow(cal, res);
    var head = bare ? '' : '伺服电机 ';
    if (!m) return head + servoVolt(cal, null) + '（库内暂无匹配机型，按所选品牌配套选型）';
    return head + (m.brand || '') + ' ' + m.code
      + '（' + m.power_kW + 'kW / ' + (m.rpm != null ? iN(m.rpm) : '—') + 'rpm / '
      + (m.torque_Nm != null ? fN(m.torque_Nm, 2) + 'N·m' : '—') + '）'
      + (m.need220 ? '，需 220V 供电（另备单相控制电源）' : '')
      /**/
      + (m.tq_under != null ? '，额定扭矩低于计算需求 ' + fN(m.tq_under, 1) + '%（扭矩临界，须与厂家确认）' : '');
  }
  /**/
  function driveSegText(cal, res, mo) {
    /**/
    if (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') return rodDcSeg233(res, cal);
    return isServoDrive(cal) ? servoSpecSeg(cal, res, true) : motorSegFor(cal, mo);
  }
  /*




*/
  function mountSize(sub, stroke, lower, upper, signal, pushN) {
    var lc = D().lam_code || {};
    if (stroke == null || stroke === '') return null;
    var s = Number(stroke);
    var upKey = ['1', '2', '3'].indexOf(String(upper)) >= 0 ? 'up123' : 'up456';
    var loKey = ['1', '2', '6'].indexOf(String(lower)) >= 0 ? 'lo126' : 'lo345';
    var A = (lc.mountA || {})[upKey + '|' + loKey];
    if (A == null) return null;
    var rows = lc.mountB || [], B = null;
    for (var i = 0; i < rows.length; i++) { if (s <= rows[i][0]) { B = rows[i][1]; break; } }
    if (B == null) B = rows.length ? rows[rows.length - 1][1] : 0;
    var extra = (lc.mountB3500Extra || {})[sub] || 0;
    if (extra && Number(pushN) >= 3500) B += extra;
    var cMap = (lc.mountC || {})[sub] || (lc.mountC || {}).LAM32 || {};
    var C = cMap[String(signal)];
    if (C == null) C = 0;
    return s + A + B + C;
  }
  /**/
  function isSpecCodeSub(sub) { return ((D().lam_code || {}).subs || []).indexOf(sub) >= 0; }

  /*




*/
  var _specMemo = { k: null, on: false };
  function specCodeActive(inp) {
    if (!(inp && inp.series === 'LAM' && ['LAM3', 'LAM6'].indexOf(String(inp.lam_group)) >= 0)) return false;
    var k = [inp.load, inp.load_pull, inp.static_load, inp.load_unit, inp.stroke, inp.speed,
      inp.cycles_per_day, inp.drive, inp.temp].join('|');
    if (_specMemo.k === k) return _specMemo.on;
    var on = false;
    try {
      var out = autoSelect(inp, D());
      on = !!(out && out.chosen && isSpecCodeSub(out.chosen.sub));
    } catch (e) { on = false; }
    _specMemo.k = k; _specMemo.on = on;
    return on;
  }

  /*




*/
  var _limitMemo = { k: null, sub: null };
  function limitSub(inp) {
    if (!(inp && (inp.series === 'LAP' || inp.series === 'LBP'))) return null;
    var k = [inp.series, inp.load, inp.load_pull, inp.static_load, inp.load_unit, inp.stroke,
      inp.speed, inp.cycles_per_day, inp.drive, inp.temp, inp.install, inp.joint,
      inp.units, inp.layout].join('|');
    if (_limitMemo.k === k) return _limitMemo.sub;
    var sub = null;
    try {
      var out = autoSelect(inp, D());
      if (out && out.chosen) sub = out.chosen.sub;
    } catch (e) { sub = null; }
    _limitMemo.k = k; _limitMemo.sub = sub;
    return sub;
  }
  function baseNo(sub) {
    var m = /(\d+)/.exec(String(sub || ''));
    return m ? Number(m[1]) : null;
  }
  /**/
  function limitStd(sub) {
    var n = baseNo(sub);
    if (n == null) return null;
    return n <= 40 ? 'FCM' : 'FCP';
  }
  function hasAR(inp) { return !!(inp && Array.isArray(inp.accessories) && inp.accessories.indexOf('AR') >= 0); }
  /**/
  function limitAllowed(inp, sub) {
    var n = baseNo(sub);
    var ar = hasAR(inp);
    return (D().limits || []).filter(function (x) {
      if (n != null && n >= 56 && x.v === 'FCM') return false;
      if (ar && x.v === 'FCM') return false;
      return true;
    });
  }
  /*
*/
  function limitResolved(cal, sub) {
    var v = String((cal && cal.limit_sw) || 'STD');
    var std = limitStd(sub) || 'FCP';
    if (v === 'NONE') return null;
    if (!v || v === 'STD') return std;
    if (v === 'FCM' && ((baseNo(sub) != null && baseNo(sub) >= 56) || hasAR(cal))) return 'FCP';
    return v;
  }
  /**/
  function noLimit(cal) { return String((cal && cal.limit_sw) || 'STD') === 'NONE'; }
  var LIMIT_NAME = { FCM: 'FCM 磁感应限位开关', FCP: 'FCP 接近限位开关', FCE: 'FCE 机械限位开关' };
  /*
*/
  function rodIsExMotor(cal, res) {
    var rec = (res && res.servo_calc && res.servo_calc.recommend) || [];
    var b = rec.length ? (String(rec[0].brand || '') + ' ' + String(rec[0].code || '')) : '';
    if (b && (/惠斯通/.test(b) || /(^|[^A-Za-z])ST-EX/i.test(b) || /-[A-Z0-9]*EX([-(]|$)/i.test(b))) return true;
    var sb = (cal && cal.servo_brand) || [];
    return Array.isArray(sb) ? sb.indexOf('惠斯通') >= 0 : /惠斯通/.test(String(sb || ''));
  }
  function limitNameOf(lim, ex) {
    if (!lim) return '';
    return ex ? ('防爆限位开关 ' + lim) : (LIMIT_NAME[lim] || lim);
  }

  /*
*/
  function lamVolt(cal, sub) {
    if (sub === 'LAM3') {
      var byDrive = { dc12: '12', dc24: '24', dc48: '48' }[cal && cal.drive];
      return byDrive || String((cal && cal.lam2_volt) || '24');
    }
    return String((cal && cal.lam2_volt) || '24');
  }

  /*

*/
  function suggestCode(cal, res, opts) {
    opts = opts || {};
    var m = res.mdef || (res.model ? D().models[res.model] : null) || {};
    var sub = res.sub || m.sub;
    /*
*/
    if (isLam(res.fam) && isSpecCodeSub(sub)) {
      var lc = D().lam_code || {};
      var volt = String(cal.lam_volt || '2');
      var allow = (lc.voltBySub || {})[sub] || [];
      if (allow.length && allow.indexOf(volt) < 0) volt = '2';    //
      var st = (cal.stroke != null) ? Number(cal.stroke) : null;
      var mt = mountSize(sub, st, cal.lam_lower, cal.lam_upper, cal.lam_signal, m.push_N);
      var segs = [sub, volt, res.code || m.code, st != null ? iN(st) : '', mt != null ? iN(mt) : '',
        cal.lam_lower, cal.lam_upper, cal.lam_angle, cal.lam_limit,
        cal.lam_signal, cal.lam_plug, cal.lam_cable, cal.lam_ip];
      return segs.filter(function (x) { return x !== '' && x != null; }).join('-');
    }
    /*

*/
    if (isLam(res.fam) && (sub === 'LAM3' || String(sub).indexOf('LAM5') === 0)) {
      var volt2 = lamVolt(cal, sub);
      var is3 = (sub === 'LAM3');     //
      var segs2 = [sub, res.code || m.code];
      if (cal.stroke != null) segs2.push(iN(cal.stroke));
      if (cal.joint) segs2.push(jointCode(cal.joint, sub));
      segs2.push('DC' + volt2 + 'V');
      var bc = bracketCode(sub, cal.lam2_bracket);
      if (bc) segs2.push(bc);
      if (is3 && cal.lam2_fb && cal.lam2_fb !== '无') segs2.push(cal.lam2_fb);
      if (!is3) {                      /**/
        if (cal.lam2_shell === 'SUS316') segs2.push('SUS316');
        else if (cal.lam2_shell === 'ST45') segs2.push('45#钢喷塑');
      }
      if (cal.lam2_ip) segs2.push(cal.lam2_ip);
      if (is3 && cal.lam2_limit) segs2.push(cal.lam2_limit);
      /**/
      if (Array.isArray(cal.accessories) && cal.accessories.length) segs2.push(cal.accessories.join('/'));
      return segs2.filter(function (x) { return x !== '' && x != null; }).join('-');
    }
    /**/
    var subOut = (cal && cal.lam2_screw === 'LBM6' && sub === 'LAM6') ? 'LBM6' : sub;
    var parts = [subOut, res.code || m.code];
    if (cal && cal.stroke != null) parts.push(iN(cal.stroke));
    if (res.joint) parts.push(jointCode(res.joint, sub));
    if (cal && !isLam(res.fam)) {
      /*



*/
      var limMainOnly = String(cal.limit_sw || 'STD') === 'STD';
      var limCode = (opts.follower && limMainOnly) ? null : limitResolved(cal, sub);
      if (limCode) parts.push(limCode);
      if (opts.follower) parts.push('P2');
      else parts.push(res.install || 'P3', res.input_dir || 'RH');
    }
    if (isLam(res.fam) && m.volts && m.volts.length) parts.push((m.ac ? 'AC' : 'DC') + m.volts.join('/') + 'V');
    else if (m.motor && !opts.follower && !opts.noMotor) {
      /*





*/
      var isDcDrvCode = cal && (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48');
      var dcCode233 = (isDcDrvCode && res && res.dc_motor && res.dc_motor.src === 'ac') ? res.dc_motor : null;
      if (dcCode233) {
        parts.push('DC' + dcCode233.volts[0] + 'V ' + fN(dcCode233.p_kw, 2) + 'kW ' + dcCode233.rpm_main + 'rpm');
      } else {
        parts.push(isServoDrive(cal) ? servoCodeSeg(cal, res) : motorSegFor(cal, (res && res.motor) || m.motor));
      }
    }
    /*
*/
    if (isLam(res.fam) && cal && cal.lam2_limit && cal.lam2_limit !== '标配') parts.push(cal.lam2_limit);
    if (isLam(res.fam) && cal && cal.lam2_ip && (sub === 'LAM8' || sub === 'LBM9')) parts.push(cal.lam2_ip);
    /*

*/
    var accCode = (cal && Array.isArray(cal.accessories)) ? cal.accessories.filter(function (x) { return x !== 'BRE'; }) : [];
    if (accCode.length) parts.push(accCode.join('/'));
    return parts.filter(Boolean).join(' ');
  }

  /**/
  function seriesInfoHTML(input) {
    /**/
    var lg = (input && input.series === 'LAM' && input.lam_group)
      ? (D().lam_series || []).filter(function (x) { return x.v === input.lam_group; })[0]
      : null;
    var s = lg || seriesMeta(input && input.series);
    if (!s.v && !s.img) return '';
    var html = '<div class="imgbox side-img"><img class="limg" src="' + catSrc(s.img) + '" alt="">'
      + '<div class="imgcap">' + esc(s.t) + '</div></div>';
    /**/
    html += '<div class="side-specs' + (s.bullet ? ' marked' : '') + '">'
      + (s.lead ? '<div class="lead">' + esc(s.lead) + '</div>' : '')
      + (s.specs || []).map(function (x) { return '<div>' + esc(x) + '</div>'; }).join('') + '</div>';
    return html;
  }

  /**/
  function sidePanelHTML() {
    var samples = [
      { t: '力姆泰克螺旋升降机电动推杆综合样本2026', file: '力姆泰克螺旋升降机电动推杆综合样本2026.pdf' },
      { t: '力姆泰克LAM32电动推杆样本', file: '力姆泰克LAM32电动推杆.pdf' },
      { t: '力姆泰克LAM33电动推杆样本', file: '力姆泰克LAM33电动推杆.pdf' },
      { t: '力姆泰克LAM5电动推杆样本', file: '力姆泰克LAM5电动推杆.pdf' }
    ];
    var html = '<div class="side-quick"><h4>快捷通道 · 按型号直查</h4>'
      + '<input id="fld_quick_model" type="text" placeholder="输入详细型号，如 LAM32-C / LAM33 / LAP40 / LBP25">'
      + '<div class="qops">'
      + '<button type="button" class="btn ghost" id="btnQuick">详细参数</button>'
      + '<button type="button" class="btn ghost" id="btnCad">三维数模下载</button>'
      + '</div>'
      + '<div id="quickInfo" class="quick-done" style="display:none"></div>'
      + '<div class="hint" style="margin-top:8px">详细参数：列出该型号各档位技术参数（额定推拉力/自锁力/速度/电流/最大行程），'
      + '如 LAM32 列出 A-L 十档；三维数模：LAM 系列按行程下载（共享u盘 Mini linear actuator LAM-3D），'
      + 'LAP/LBP 系列经 cn.lim-tec.com/soft.html 或 limtec.partcommunity.com。</div>'
      + '<div class="side-samples"><h5>样本下载</h5>'
      + samples.map(function (sm) {
          /*

*/
          var href;
          if (g.SJ_CATALOG_BIN) {
            var cdn = (g.SJCatalog && g.SJCatalog.SAMPLES_CDN) || '';
            href = cdn ? cdn + encodeURIComponent(sm.file) + sVer()
              : ((g.SJCatalog && g.SJCatalog.SAMPLES_WEB) || 'https://cn.lim-tec.com/');
          } else {
            href = './assets/samples/' + encodeURIComponent(sm.file) + sVer();
          }
          var dl = g.SJ_CATALOG_BIN ? '' : ' download="' + esc(sm.file) + '"';
          return '<a class="dl" href="' + href + '"' + dl + ' target="_blank" rel="noopener">' + esc(sm.t) + '</a>';
        }).join('')
      + '</div></div>';
    return html;
  }

  /**/
  function heroSub(cal, res, cand) {
    var sub = [];
    sub.push(famName(res.fam) + ' · 档位 ' + res.code + (res.duty ? ' · 工作制 ' + res.duty : ''));
    if (!isLam(res.fam)) sub.push('输入形式 ' + (res.install || 'P3') + '（' + nameOf(D().installs, res.install) + '）· ' + (res.input_dir || 'RH'));
    return sub;
  }

  function modelDetailHTML(cand, res, data) {
    var m = res.mdef || {};
    var kv = [];
    /**/
    if (Number(res.units) === 2) {
      /**/
      /**/
      kv.push(['台数与布置', (res.sync === '电气')
        ? '2 台 · 电气同步（每台 1 台电机独立直驱）'
        : '2 台（' + (res.layout || '电机内侧') + '）· 电机侧 ' + (res.install || 'P4') + ' + 从动台 P2']);
      if (res.total_load_N) {
        kv.push(['总负载 / 单台负载', fN(res.total_load_N, 0) + ' N ÷ 2 = ' + fN(res.load_req_N, 0) + ' N（每台）']);
      }
    }
    if (isLam(res.fam)) {
      kv.push(['额定推拉力', fN(m.push_N, 0) + ' N（约 ' + fN(m.push_N / 9806.65, 2) + ' 吨）']);
      if (m.pull_N != null && m.pull_N !== m.push_N) kv.push(['额定拉力', fN(m.pull_N, 0) + ' N']);
      kv.push(['自锁力', m.lock_N ? fN(m.lock_N, 0) + ' N（自锁）' : '不自锁（滚珠丝杠）']);
      kv.push(['速度（空载-满载）', fN(m.v0, 1) + ' - ' + fN(m.v1, 1) + ' mm/s']);
      if (m.iA != null) kv.push(['满载电流（24V）', fN(m.iA, 1) + ' A']);
      if (m.volts) kv.push(['电压', (m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V']);
      if (m.rpm) kv.push(['马达转速', iN(m.rpm) + ' RPM']);
    } else {
      /*
*/
      kv.push(['动态载荷', fN(m.load_N, 0) + ' N（约 ' + fN(m.load_N / 9806.65, 2) + ' 吨）'
        + (res.load_under_pct != null
          ? '　＜ 需求 ' + fN(res.load_req_N, 0) + ' N（欠 ' + fN(res.load_under_pct, 1)
            + '%，≤' + (res.load_under_max || 10) + '% 按备选口径放行，须客户确认）'
          : '')]);
      /*

*/
      kv.push(['速度', fN(m.speed, 1) + ' mm/s'
        + (res.speed_under_pct != null
          ? '（要求 ' + fN(res.speed_req, 1) + '，欠 ' + fN(res.speed_under_pct, 1) + '%，≤'
            + (res.speed_under_max || 20) + '% 按接近口径放行）'
          : '')]);
      kv.push(['减速比', res.code]);
      kv.push(['自锁系数', m.lock != null
        ? String(m.lock) + (m.lock <= 0.25 ? '（自锁）' : '（不自锁，配制动器）')
        : '按样本（滚珠丝杠不自锁，配制动器）']);
      /**/
      var limKv = limitResolved((res && res.cal) || null, m.sub);
      if (limKv) kv.push(['限位开关', limitNameOf(limKv, rodIsExMotor((res && res.cal) || null, res))
        + (String(((res && res.cal) || {}).limit_sw || 'STD') === 'STD' ? '（标配，样本 p9）' : '（指定）')]);
      else if (noLimit((res && res.cal) || null)) kv.push(['限位开关', '无限位开关（不配行程限位）']);
      /*
*/
      if (m.motor) kv.push(['电机', isServoDrive(res.cal) ? servoSpecSeg(res.cal, res, true)
        : ((res.cal && (res.cal.drive === 'dc24' || res.cal.drive === 'dc12' || res.cal.drive === 'dc48'))
          ? rodDcSeg233(res, res.cal)
          : motorSegFor((res && res.cal) || null, m.motor))]);
      if (m.weight != null) kv.push(['重量', fN(m.weight, 1) + ' kg（每 100mm 行程 +' + fN(m.w100, 1) + ' kg）']);
    }
    /*
*/
    if (res.cal && res.cal.stroke != null) kv.push(['需求行程', iN(res.cal.stroke) + ' mm（型号串已含）']);
    kv.push(['该型号最大行程', m.stroke_max != null ? iN(m.stroke_max) + ' mm' : '待样本确认']);
    if (res.stability_Lk_mm != null) kv.push(['允许行程（稳定性）', fN(res.stability_Lk_mm, 0) + ' mm']);
    if (res.life_km != null) kv.push(['理论寿命 L10', fN(res.life_km, 0) + ' km' + (res.annual_km != null ? '（年用 ' + fN(res.annual_km, 0) + ' km' + (res.life && res.life.years != null ? '，约 ' + fN(res.life.years, 1) + ' 年' : '') + '）' : '')]);
    kv.push(['自锁', res.self_lock ? '自锁，电机可不加制动器' : '不自锁，电机配制动器']);
    /**/
    if (res.motor_torque_Nm != null) kv.push(['电机端需求扭矩', fN(res.motor_torque_Nm, 2) + ' Nm'
      + (res.servo_calc ? (res.screw_torque_Nm != null ? '（丝杠端 ' + fN(res.screw_torque_Nm, 2) + ' Nm 折算）' : '')
        /**/
        : (Number(res.units) === 2 ? '（= 9550×计算功率÷电机转速）' : (res.screw_torque_Nm != null ? '（丝杠端 ' + fN(res.screw_torque_Nm, 2) + ' Nm 折算）' : '')))]);
    if (res.motor_power_kW != null) kv.push(['所需功率', fN(res.motor_power_kW, 2) + ' kW @ ' + fN(res.motor_sync, 0) + ' rpm']);
    /**/
    if (res.static_N != null) kv.push(['额定静载', fN(res.static_N, 0) + ' N（= 型号最大推力 ×1.5，样本 p20-21 口径）']);
    if (res.env_coef && res.env_coef !== 1) {
      var _tEnv = String(res.temp != null ? res.temp : (res.cal && res.cal.temp));
      var _hotEnv = Number(_tEnv) >= 80;
      kv.push(['环境系数', _tEnv + '℃ 工况 ×' + res.env_coef
        + '（已计入电机端扭矩与所需功率）'
        + (res.env_ok === false
          ? (_hotEnv ? '；样本标配电机容量不足，需上调基型或定制高温电机'
            : '；样本标配电机容量不足，需上调基型或定制低温电机')
          : '')]);
    }
    if (res.gear_ratio != null && res.gear_ratio > 1) kv.push(['行星减速机', 'i=' + res.gear_ratio + ':1（效率 ' + res.gear_eta + '）']);
    if (m.note) kv.push(['备注', cleanNote(m.note)]);
    return kv.map(function (r) {
      return '<div class="kv"><b>' + esc(r[0]) + '</b><span>' + esc(r[1]) + '</span></div>';
    }).join('');
  }

  /*














*/
  var STAB_SHEETS = [
    { file: 'stab-lap-25-40.png', w: 682, h: 523, minBase: 0, maxBase: 40,
      xA: [[0, 116], [1100, 666]],                        /* 100 mm = 50 px */
      yA: [[0, 460], [16000, 60]],                        /* 2000 N = 50 px */
      yMax: 16000, xMax: 1100, yUnit: 'N', yDiv: 1,
      lbl: [
        { k: 'title', b: [79, 9, 114, 17], fs: 16.5, an: 'start' },
        { k: 'yaxis', b: [9, 49, 35, 19], fs: 12.5, an: 'middle' },
        { k: 'sf', b: [90, 497, 104, 17], fs: 16, an: 'start' },
        { k: 'xaxis', b: [575, 498, 98, 16], fs: 16, an: 'end' }
      ] },
    { file: 'stab-lap-56-300.png', w: 668, h: 537, minBase: 56, maxBase: 999,
      xA: [[500, 101], [1600, 475], [2000, 532], [2500, 590], [3000, 648]],
      yA: [[0, 472], [200000, 132], [300000, 64]],
      yMax: 300000, xMax: 3000, yUnit: 'kN', yDiv: 1000,
      lbl: [
        { k: 'title', b: [71, 9, 116, 17], fs: 16.5, an: 'start' },
        { k: 'yaxis', b: [9, 58, 34, 18], fs: 12.5, an: 'middle' },
        { k: 'sf', b: [71, 511, 105, 17], fs: 16, an: 'start' },
        { k: 'xaxis', b: [560, 511, 99, 17], fs: 16, an: 'end' }
      ] }
  ];

  /**/
  var STAB_TXT = {
    title: '稳定性曲线图',
    yaxis: '压力',
    sf: '安全系数：3',
    xaxis: '行程（mm）'
  };

  /**/
  function mapPx(tab, v) {
    var i, n = tab.length, s;
    if (!n) return 0;
    if (n === 1) return tab[0][1];
    if (v <= tab[0][0]) {
      s = (tab[1][1] - tab[0][1]) / (tab[1][0] - tab[0][0] || 1);
      return tab[0][1] + (v - tab[0][0]) * s;
    }
    if (v >= tab[n - 1][0]) {
      s = (tab[n - 1][1] - tab[n - 2][1]) / (tab[n - 1][0] - tab[n - 2][0] || 1);
      return tab[n - 1][1] + (v - tab[n - 1][0]) * s;
    }
    for (i = 0; i < n - 1; i++) {
      if (v >= tab[i][0] && v <= tab[i + 1][0]) {
        return tab[i][1] + (v - tab[i][0]) / (tab[i + 1][0] - tab[i][0]) * (tab[i + 1][1] - tab[i][1]);
      }
    }
    return tab[0][1];
  }

  function stabSheetOf(sub) {
    var n = parseInt(String(sub || '').replace(/[^0-9]/g, ''), 10);
    if (!n) return null;
    for (var i = 0; i < STAB_SHEETS.length; i++) {
      var s = STAB_SHEETS[i];
      if (n >= s.minBase && n <= s.maxBase) return s;
    }
    return null;
  }

  /*


*/
  function stabSVG(sheet, sub) {
    var alt = esc(sub) + ' 稳定性曲线（样本 p10）';
    var an = { start: 'start', middle: 'middle', end: 'end' };
    var s = '<svg viewBox="0 0 ' + sheet.w + ' ' + sheet.h + '" preserveAspectRatio="xMidYMid meet"'
      + ' role="img" aria-label="' + alt + '" style="display:block;width:100%;height:auto">'
      + '<title>' + alt + '</title>'
      + '<image href="' + catSrc(sheet.file) + '" x="0" y="0"'
      + ' width="' + sheet.w + '" height="' + sheet.h + '"></image>';
    (sheet.lbl || []).forEach(function (L) {
      var b = L.b, pad = 3;
      var tx = L.an === 'middle' ? (b[0] + b[2] / 2) : (L.an === 'end' ? b[0] + b[2] : b[0]);
      var ty = b[1] + b[3] / 2;
      s += '<rect x="' + (b[0] - pad) + '" y="' + (b[1] - pad) + '"'
        + ' width="' + (b[2] + pad * 2) + '" height="' + (b[3] + pad * 2) + '" fill="#fff"></rect>'
        + '<text x="' + tx + '" y="' + ty + '" dy="0.35em" font-size="' + L.fs + '"'
        + ' text-anchor="' + (an[L.an] || 'start') + '" fill="#3a3a3a"'
        + ' font-family="Microsoft YaHei,PingFang SC,Noto Sans SC,Arial,sans-serif">'
        + STAB_TXT[L.k] + '</text>';
    });
    return s + '</svg>';
  }

  function stabilityHTML(cal, res) {
    if (!cal || (cal.fam !== 'LAP' && cal.fam !== 'LBP')) return '';
    var sub = (res && res.sub) || '';
    if (!sub) return '';
    var pts = ((D().stability || {})[sub]) || null;
    var head = '<div class="card"><div class="label">稳定性曲线（样本 p10，安全系数 3）</div>';
    if (!pts || pts.length < 2) {
      return head + '<div class="hint">' + esc(sub) + ' 在样本 p10 未给稳定性曲线：'
        + (sub === 'LAP22'
          ? 'LAP22 参照 LAP25 曲线核对（行程 ≤300mm 常规工况不受限），行程 >300mm 请与力姆泰克工程师确认。'
          : '行程 >300mm 请与力姆泰克工程师确认稳定性。')
        + '</div></div>';
    }
    var sheet = stabSheetOf(sub);
    if (!sheet) return head + '<div class="hint">' + esc(sub) + ' 暂无对应曲线图，请与力姆泰克工程师确认。</div></div>';

    var loadReq = Number(cal.load_N || 0), strokeReq = Number(cal.stroke || 0);
    var lk = (res.stability_Lk_mm != null) ? res.stability_Lk_mm : null;
    var okPt = (lk == null) ? true : (strokeReq <= lk * 1.001);

    /**/
    var xIn = strokeReq <= sheet.xMax && strokeReq >= sheet.xA[0][0];
    var yIn = loadReq <= sheet.yMax;
    var sx = Math.min(Math.max(strokeReq, sheet.xA[0][0]), sheet.xMax);
    var sy = Math.min(Math.max(loadReq, 0), sheet.yMax);
    var pl = mapPx(sheet.xA, sx) / sheet.w * 100;
    var pt = mapPx(sheet.yA, sy) / sheet.h * 100;
    var right = pl > 60, below = pt < 22;

    var img = stabSVG(sheet, sub);
    var dot = '<span style="position:absolute;left:' + pl.toFixed(2) + '%;top:' + pt.toFixed(2) + '%;'
      + 'width:12px;height:12px;margin:-6px 0 0 -6px;border-radius:50%;background:#e01b24;'
      + 'border:2px solid #fff;box-shadow:0 0 0 1.5px #e01b24,0 1px 4px rgba(0,0,0,.35)"></span>';
    var loadTxt = sheet.yUnit === 'kN'
      ? fN(loadReq / 1000, loadReq / 1000 >= 100 ? 0 : 1) + ' kN'
      : fN(loadReq, 0) + ' N';
    var tag = '<span style="position:absolute;left:' + pl.toFixed(2) + '%;top:' + pt.toFixed(2) + '%;'
      + 'transform:translate(' + (right ? 'calc(-100% - 14px)' : '14px') + ',' + (below ? '4px' : 'calc(-100% - 4px)') + ');'
      + 'background:rgba(255,255,255,.94);border:1px solid #e01b24;color:#c81e2a;font-size:12px;'
      + 'line-height:1.7;padding:0 6px;border-radius:3px;white-space:nowrap">本方案 '
      + fN(strokeReq, 0) + ' mm / ' + loadTxt + '</span>';
    var wrap = '<div style="position:relative;display:block;width:100%;max-width:' + sheet.w + 'px">'
      + img + dot + tag + '</div>';

    var tail = '<div class="hint" style="margin-top:6px">红点为本方案工况点（行程 ' + fN(strokeReq, 0)
      + ' mm，载荷 ' + loadTxt + '）；该载荷下样本允许行程'
      + (lk != null ? ' ' + fN(lk, 0) + ' mm' : '待确认')
      + (okPt ? '，本方案在曲线允许范围内。' : '，<b>本方案已超出，稳定性校核不通过。</b>')
      + (xIn && yIn ? '' : '（工况点' + (xIn ? '' : '行程') + (xIn || yIn ? '' : '与') + (yIn ? '' : '载荷') + '超出本图坐标范围，红点已贴边显示）')
      + ' 曲线为样本 p10 原图（安全系数 3），精确读数以样本为准。</div>';
    return head + wrap + tail + '</div>';
  }

  function motorHTML(res, cal) {
    var m = res.mdef || {};
    var html = '<div class="card"><div class="label">电机配置建议</div>';
    if (isLam(res.fam)) {
      html += '<div class="kvlist">'
        + '<div class="kv"><b>驱动方式</b><span>' + esc(nameOf(D().drives, cal.drive) || '直流电机') + '</span></div>'
        + (m.volts ? '<div class="kv"><b>电压</b><span>' + esc((m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V') + '</span></div>' : '')
        + (m.iA != null ? '<div class="kv"><b>满载电流（24V）</b><span>' + esc(fN(m.iA, 1)) + ' A（12V 约为 2 倍、36V 约 2/3、48V 约 1/2）</span></div>' : '')
        + (res.dc_motor
          ? '<div class="kv"><b>功率</b><span>' + fN(res.dc_motor.p_kw, 2) + ' kW（按计算功率配置，向上取整到 0.1kW）</span></div>'
            + '<div class="kv"><b>转速</b><span>' + res.dc_motor.rpm_main + ' rpm（直流电机只有 1500 / 3000 rpm 两档）</span></div>'
            + '<div class="kv"><b>扭矩</b><span>' + fN(res.dc_motor.t_nm, 1) + ' N·m（9550 × 功率 ÷ 转速档）</span></div>'
            + '<div class="kv"><b>另一档</b><span>' + res.dc_motor.rpm_alt + ' rpm（功率加大一号 ' + fN(res.dc_motor.p_kw_alt, 2) + ' kW）</span></div>'
          : '')
        + '<div class="kv"><b>工作制</b><span>' + esc(res.duty || '按样本') + '</span></div>'
        + '</div>'
        + '<div class="hint" style="margin-top:6px">直流推杆由内置直流永磁电机驱动，控制器可选一控一 / 一控二 / 一控三（部分系列支持双霍尔、CAN）；电机不计价（整机价已含电机）。</div>';
    } else {
      var mo = m.motor || {};
      var isServo = cal.drive === 'servo220' || cal.drive === 'servo380';
      var isStep = cal.drive === 'stepping';
      var isDc = cal.drive === 'dc24';
      var seg;
      var sc = res.servo_calc || null;
      if (isServo || isStep) {
        /*


*/
        var hasCalc = !!(sc && sc.n_req_rpm != null);
        if (hasCalc) {
          var brandTxt = (cal.servo_brand && cal.servo_brand.length)
            ? cal.servo_brand.join(' / ')
            : '未指定（西门子 V90 → S200 → S120 优先，与电缸一致）';
          var pTxtCard = (sc.p_req_kw == null) ? '—'
            : (sc.p_req_kw < 0.001 ? '&lt; 0.001' : fN(sc.p_req_kw, sc.p_req_kw < 0.1 ? 3 : 2));
          html += '<div class="kv"><b>所需功率</b><span>' + pTxtCard + ' kW（所需功率 = 电机运行转速 '
            + fN(sc.n_motor_rpm, 0) + ' rpm × 电机端需求扭矩 ' + fN(sc.t_motor_nm, 2) + ' Nm ÷ 9550'
            + (sc.t_src === 'calc'
              ? '，已含整体效率 ' + Math.round(sc.eff * 100) + '% 与安全系数 ' + sc.safety
              : '，效率待样本确认')
            + '）</span></div>';
          html += '<div class="kv"><b>所需扭矩</b><span>' + fN(sc.t_motor_nm, 2) + ' Nm（电机端需求 = 丝杠端 '
            + fN(sc.t_screw_nm, 2) + ' Nm（F×导程÷2π）÷ 减速比 ' + (sc.i_total || sc.i)
            + (sc.t_src === 'calc' ? ' ÷ 效率 ' + sc.eff + ' × 安全系数 ' + sc.safety : '（效率待确认，临时折算）')
            + '，' + (sc.gear > 1
              ? '经行星减速机 i=' + sc.gear + ':1（效率 ' + sc.gear_eta + '）× 样本减速比 i=' + sc.i
              : '经样本减速比 i=' + sc.i) + '）</span></div>';
          html += '<div class="kv"><b>额定转速</b><span>' + fN(sc.n_motor_rpm, 0) + ' rpm（本工况所需电机运行转速，'
            + '<b>伺服额定转速须 ≥ ' + fN(sc.n_motor_rpm, 0) + ' rpm</b>'
            + (sc.gear > 1 ? '；经行星 i=' + sc.gear + ':1 × ' : '；经')
            + '样本减速比 i=' + sc.i + ' 输出 ' + fN(sc.n_screw_rpm, 0) + ' rpm）</span></div>';
    if (sc.gear > 1) {
      var gp = sc.gear_pick;
      html += '<div class="kv"><b>减速机</b><span>行星减速机 i=' + sc.gear + ':1'
        + (gp ? ('，选 ' + gp.model + '（额定输出 ' + fN(gp.C, 0) + ' Nm / 最大 ' + fN(gp.D, 0) + ' Nm，'
        + gp.level + (gp.shaftNote ? '；' + gp.shaftNote : '') + (gp.price != null ? '，牌价 ' + moneyTxt(gp.price) : '，待询价') + '）')
                : '，型号与价格待询（非 HV 标准速比档）')
              + '；减速机输出扭矩 = 电机端需求 ' + fN(sc.t_motor_nm, 2) + ' × ' + sc.gear + ' = '
              + fN((sc.t_motor_nm || 0) * sc.gear, 2) + ' Nm</span></div>';
          }
          /**/
          html += '<div class="kv"><b>伺服电机品牌</b><span>' + esc(brandTxt) + '</span></div>';
          html += '<div class="kv"><b>制动器</b><span>' + esc(res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）') + '</span></div>';
          /**/
          var rows = (sc.recommend || []);
          if (rows.length) {
            html += '<table style="margin-top:8px"><thead><tr><th>品牌</th><th>型号</th><th>功率</th>'
              + '<th>额定转速</th><th>额定扭矩</th><th>额定电流</th><th>机座号</th><th>报价</th><th>减速比</th></tr></thead><tbody>';
            rows.forEach(function (r) {
              var mp = rodServoPriceOf(r, cal);
              var gearCell = (sc.gear > 1)
                ? '<b>G' + (sc.gear < 10 ? '0' + sc.gear : sc.gear) + '</b>（输出 ' + fN(sc.n_screw_rpm, 0) + 'rpm）'
                : '—（直连，样本 i=' + sc.i + '）';
              html += '<tr><td>' + esc(r.brand) + '</td>'
                + '<td>' + esc(r.code)
                + (r.fit_low ? ' <span class="pill a">1.1× 凑功率</span>' : '')
                + (r.need220 ? ' <span class="pill a">需 220V 供电</span>' : '')
                + (r.tq_under != null ? ' <span class="pill a" title="额定扭矩低于计算需求，差值在 2% 以内；仅作备选，正式报价前须与厂家确认">扭矩临界（欠 ' + esc(fN(r.tq_under, 1)) + '%）</span>' : '') + '</td>'
                + '<td>' + esc(String(r.power_kW)) + ' kW</td>'
                + '<td>' + (r.rpm != null ? esc(iN(r.rpm)) : '—') + (r.nmax_rpm != null ? '（最高 ' + esc(iN(r.nmax_rpm)) + '）' : '') + ' rpm</td>'
                + '<td>' + (r.torque_Nm != null ? esc(fN(r.torque_Nm, 2)) + ' Nm' : '—') + '</td>'
                + '<td>' + (r.current_A != null ? esc(fN(r.current_A, 1)) + ' A' : '—') + '</td>'
                + '<td>' + esc(r.frame || '—') + '</td>'
                + '<td>' + (mp && mp.hasPrice
                  ? '<b>' + esc(moneyTxt(mp.unit)) + '</b>'
                    + (mp.driveOnly ? '<br><span class="hint">（仅驱动器，电机另询）</span>' : '')
                  : '<span class="hint">待询价</span>') + '</td>'
                + '<td>' + gearCell + '</td></tr>';
            });
            html += '</tbody></table>';
          }
          /*
*/
          var elecSafetyK = (Number(cal.units) > 1 && String(cal.sync) === '电气');
          html += '<div class="hint" style="margin-top:6px">计算方式同电缸：所需扭矩 = 丝杠端扭矩（F×导程÷2π）÷ 样本减速比 ÷ 整体效率'
            + (elecSafetyK
              ? '，电气同步安全系数 1.5（每台 1 台电机独立直驱、无机械均载，不取 1.1 凑功率档）；'
              : '，单台安全系数 1.2（为凑电机标准功率档可取 1.1，行上标注「1.1× 凑功率」须在方案中注明）；')
            + '所需功率 = 电机端需求扭矩 × 电机运行转速 ÷ 9550。推杆常规不加减速机，直连扭矩撑不住时才按 HV 标准速比配行星减速机。'
            + '上表为库内可配套机型（<b>额定转速 ≥ 所需运行转速 ' + fN(sc.n_motor_rpm, 0) + ' rpm</b>；'
            + '按功率档升序、<b>从满足扭矩的最小档起连续 3 档、每档 1 台</b>；'
            + '不按样本交流电机参数、不靠弱磁超速选），同档按「库内有采购价优先 → 同电压优先 → 品牌优先」取一台；'
            + '三相 380V 驱动时，若所选品牌在该功率档只有 220V 单相机型，允许补位并在型号后标注「需 220V 供电」'
            + '（现场须另备 220V 单相控制电源，驱动器按单相配置）；'
            + '额定扭矩略欠计算需求、差值 ≤2% 的机型标「扭矩临界」，列作备选并排在达标机型之后，须与厂家确认后再定；'
            + '报价为电机＋配套驱动器成套价，标「待询价」的行暂无报价记录'
            + '（西门子选型工具站同源，站上亦无记录），需单独询价；最终配置与力姆泰克确认。</div>';
        } else {
          seg = '该型号' + (isServo ? '伺服电机' : '步进电机') + '计算参数（减速比/导程/效率）待样本确认，'
            + '暂按额定转速与额定扭矩覆盖选配，不套样本交流电机参数，具体与厂家确认'
            + (sc && sc.warn ? '；' + sc.warn : '');
          html += '<div class="kvlist"><div class="kv"><b>电机</b><span>' + esc(seg) + '</span></div>'
            + '<div class="kv"><b>制动器</b><span>' + esc(res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）') + '</span></div>'
            + '</div>';
        }
      } else if (isDc) {
        /*


*/
        var dc233 = res.dc_motor || null;
        var volt233 = dc233 ? String(dc233.volts[0]) : ({ dc12: '12', dc24: '24', dc48: '48' }[cal.drive] || '24');
        if (dc233 && dc233.src === 'ac') {
          /**/
          html += '<div class="kvlist">'
            + '<div class="kv"><b>电机</b><span>直流电机 ' + volt233 + 'VDC（参数同交流电机，价格不计）</span></div>'
            + '<div class="kv"><b>功率</b><span>' + fN(dc233.p_kw, 2) + ' kW（'
              + (dc233.via === 'two' ? '按两台总功率 ×1.5 安全系数取标准档' : '同样本交流电机功率') + '）</span></div>'
            + '<div class="kv"><b>转速</b><span>' + dc233.rpm_main + ' rpm（同样本交流电机转速）</span></div>'
            + '<div class="kv"><b>扭矩</b><span>' + fN(dc233.t_nm, 1) + ' N·m（9550 × 功率 ÷ 转速）</span></div>'
            + '<div class="kv"><b>电压</b><span>' + volt233 + 'VDC</span></div>'
            + '</div>';
        } else {
          html += dc233
            ? '<div class="kvlist">'
              + '<div class="kv"><b>电机</b><span>直流电机 ' + volt233 + 'VDC（按计算功率配置，无型号等其他参数，价格不计）</span></div>'
              + '<div class="kv"><b>功率</b><span>' + fN(dc233.p_kw, 2) + ' kW（需求功率 = 推力 × 速度 ÷ 效率'
                + (dc233.eff_src === 'sample' ? '' : '（样本效率未印，按机械功率口径）') + '，向上取整到 0.1kW）</span></div>'
              + '<div class="kv"><b>转速</b><span>' + dc233.rpm_main + ' rpm（直流电机只有 1500 / 3000 rpm 两档：'
                + (dc233.rpm_main === 1500 ? '需求功率 ≤400W 取 1500rpm' : '需求功率 >400W 取 3000rpm') + '）</span></div>'
              + '<div class="kv"><b>扭矩</b><span>' + fN(dc233.t_nm, 1) + ' N·m（扭矩 = 9550 × 功率 ÷ 转速档）</span></div>'
              + '<div class="kv"><b>电压</b><span>' + volt233 + 'VDC</span></div>'
              + '<div class="kv"><b>另一档</b><span>' + dc233.rpm_alt + ' rpm（功率加大一号 ' + fN(dc233.p_kw_alt, 2) + ' kW、扭矩 '
                + fN(dc233.t_nm_alt, 1) + ' N·m）</span></div>'
              + '</div>'
            : '<div class="kvlist"><div class="kv"><b>电机</b><span>' + esc(rodDcSeg233(res, cal)) + '</span></div></div>';
        }
        html += '<div class="kv"><b>制动器</b><span>' + esc(res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）') + '</span></div>';
      } else if ((cal.drive === 'ac3' || cal.drive === 'ac1') && Number(cal.units) > 1
        && (res.fam === 'LAP' || res.fam === 'LBP')) {
        /*

*/
        var needKw287 = (res.motor_power_kW != null) ? res.motor_power_kW : res.total_power_kW;
        var needNm287 = res.motor_torque_Nm;
        /**/
        var actRpm287 = Number(res.n_input_rpm) || 1400;
        var synRpm287 = (actRpm287 >= 1300) ? 1500 : ((actRpm287 >= 850) ? 1000 : 750);
        var POLE287 = { 1500: '4 极', 1000: '6 极', 750: '8 极' };
        html += '<div class="kv"><b>所需功率</b><span>' + (needKw287 != null ? fN(needKw287, 2) : '—')
          + ' kW（所需功率 = 电机侧计算功率，已含台数放大系数，不再二次放大）</span></div>';
        html += '<div class="kv"><b>所需扭矩</b><span>' + (needNm287 != null ? fN(needNm287, 1) + ' Nm' : '—')
          + '（T = 9550 × 所需功率 ÷ 电机输入转速）</span></div>';
        html += '<div class="kv"><b>电机极数与转速（同步 / 实际）</b><span>'
          + POLE287[synRpm287] + '（同步 ' + synRpm287 + ' rpm / 实际 <b>' + Math.round(actRpm287) + '</b> rpm，'
          + '交流不可调速，按实际转速计算功率与速度）</span></div>';
        /**/
        /*

*/
        function brandClean289(b) { return String(b || '').replace(/德力\s*/g, ''); }
        var rows287 = [];
        var SJEng287 = g.SJScrewJack, SJD287 = g.SJ_DATA;
        if (SJEng287 && SJD287 && typeof SJEng287.motorLibData === 'function' && typeof SJEng287.recommendMotor === 'function') {
          rows287 = (SJEng287.recommendMotor(SJEng287.motorLibData(null, SJD287), needKw287, needNm287, synRpm287, 'ac') || [])
            .filter(function (r0) { return r0 && r0.kind === 'ac'; });
        }
        if (rows287.length) {
          html += '<table style="margin-top:8px"><thead><tr><th>品牌</th><th>型号</th><th>功率</th><th>实际转速</th>'
            + '<th>额定扭矩</th><th>额定电流</th><th>机座号</th><th>价格</th><th>减速机</th></tr></thead><tbody>';
          rows287.forEach(function (r0) {
            var ap0 = (g.SJScrewJackProduct && typeof g.SJScrewJackProduct.acMotorPriceOf === 'function')
              ? g.SJScrewJackProduct.acMotorPriceOf(r0, false) : null;
            html += '<tr><td>' + esc(brandClean289(r0.brand || '')) + '</td><td>' + esc(r0.code || '') + '</td><td>' + fN(r0.power_kW, 2) + ' kW</td><td>'
              + (r0.rpm != null ? iN(r0.rpm) : '—') + '</td><td>' + (r0.torque_Nm != null ? fN(r0.torque_Nm, 1) + ' Nm' : '—') + '</td><td>'
              + (r0.current_A != null ? fN(r0.current_A, 1) + ' A' : '—') + '</td><td>' + esc(r0.frame || '—') + '</td><td>'
              + (ap0 && ap0.hasPrice ? '<b>' + moneyTxt(ap0.unit) + '</b>' : '—') + '</td><td>—</td></tr>';
          });
          html += '</tbody></table>';
        } else {
          html += '<div class="hint" style="margin-top:6px">所需功率/扭矩超出交流电机库可选范围，请按计算功率/扭矩与厂家确认选配。</div>';
        }
        html += '<div class="kv"><b>制动器</b><span>' + esc(res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）') + '</span></div>';
        html += '<div class="hint" style="margin-top:6px">两台机械同步共用 1 台电机（平台总功率口径）；同系列可换装不同功率档电机，选型时以样本表格行为准。</div>';
      } else {
        if (cal.drive === 'ac1') {
          /**/
          var ap4 = (mo && mo.kind !== 'dc24' && mo.kw) ? ac1Pick(mo.kw) : null;
          seg = (ap4 && ap4.no)
            ? '单相交流电机 220V（' + AC1_OVER_WARN + '）'
            : '单相交流电机 220V（' + motorSegFor(cal, mo) + '，' + (ap4 && ap4.capped ? '单相已达上限' : '单相已放大一号') + '）';
        } else if (cal.drive === 'hand') {
          seg = '手摇（HW 手摇轮，基型 ' + motorSeg(mo) + '，取消电机改手摇输入）';
        } else {
          seg = motorSeg(mo) + '；同系列可换装不同功率档电机（如 1400rpm 低速档），选型时以样本表格行为准';
        }
        html += '<div class="kvlist"><div class="kv"><b>电机</b><span>' + esc(seg) + '</span></div>'
          + '<div class="kv"><b>制动器</b><span>' + esc(res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）') + '</span></div>'
          + '</div>';
        html += '<div class="hint" style="margin-top:6px">LAP/LBP 电机皆可配单相交流 / 直流 / 步进 / 伺服电机（参数有变化需咨询）。</div>';
      }
    }
    return html + '</div>';
  }

  /**/
  function rodServoPriceOf(r, cal) {
    if (!r || !g.SJScrewJackProduct || typeof g.SJScrewJackProduct.motorDrivePriceOf !== 'function') return null;
    var m0 = { kind: 'servo', code: r.code, brand: r.brand, power_kW: r.power_kW, rpm: r.rpm };
    return g.SJScrewJackProduct.motorDrivePriceOf(m0, cal);
  }
  /*
*/
  function rodServoBomOf(cal, res) {
    var sc = res && res.servo_calc;
    if (!sc || !sc.recommend || !sc.recommend.length) return null;
    var hit = null;
    sc.recommend.forEach(function (r) {
      if (hit) return;
      var p = rodServoPriceOf(r, cal);
      if (p && p.hasPrice) hit = { m: r, price: p };
    });
    return hit || { m: sc.recommend[0], price: rodServoPriceOf(sc.recommend[0], cal) };
  }

  function specNotes(cal) {
    var out = [];
    if (cal.stroke != null && cal.stroke > 800) out.push('行程 >800mm 时，伸缩管及护管尺寸增加 200mm（样本选型注意事项）；行程大于 1500mm 另请咨询。');
    if (cal.series === 'LAM' && cal.stroke != null && cal.stroke > 300) out.push('LAM 系列行程 >300mm：样本要求稳定性与力姆泰克工程师确认（本系列不自动校核稳定性）。');
    if (cal.temp === '-40' || cal.temp === '-30') out.push('低温工况：按低温电机与特种润滑脂定制（非标），交期与配置在合同确认时书面明确。');
    if (String(cal.temp) === '80') {
      out.push(cal.series === 'LAM'
        ? '高温工况：+80℃ 超出 LAM 标准范围（LAM5 系列 -20~60℃、LAM32 负载≥500N 时 -25~+65℃），须定制，与厂家确认。'
        : '高温工况：+80℃ 按高温定制（高温润滑脂、高温型电机），电机端扭矩与所需功率按 ×2 计，交期与配置在合同确认时书面明确。');
    }
    (cal.special || []).forEach(function (s) {
      var tx = (cal.special_texts || {})[s];
      if (s === '交流电机品牌要求') out.push('交流电机品牌' + (tx ? '：' + tx : '') + '，按品牌配套选型后落实。');
      if (s === '伺服电机品牌要求') out.push('伺服电机品牌' + (tx ? '：' + tx : '') + '，按品牌电机参数重新匹配减速比档位。');
      if (s === '丝杠材料要求') out.push('丝杠材料' + (tx ? '：' + tx : '') + '，与厂家确认可否定制。');
      if (s === '整体防腐要求') out.push('整体防腐' + (tx ? '：' + tx : '') + '：可升级不锈钢外壳（SS）/ 不锈钢丝杠（SA）与防腐涂层。');
      if (s === '防爆要求') out.push('防爆工况：电机/传感器按防爆等级选配' + (tx ? '（' + tx + '）' : '') + '，整杆防爆方案与厂家确认。');
      if (s === '丝杠导程要求') out.push('客户指定丝杠导程' + (tx ? '：' + tx : '') + '，如与所选减速比档位不一致请与厂家确认可否定制。');
    });
    return out;
  }

  /*








*/
  var ROD_PB = (typeof SJ_PRICE_BOOK_ROD !== 'undefined') ? SJ_PRICE_BOOK_ROD : null;

  function moneyTxt(n) {
    if (typeof window !== 'undefined' && window.LANG_I18N) return window.LANG_I18N.cur(n);   /**/
    var x = Math.round(Number(n) || 0);
    return '¥' + String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function numTxt(n) {
    var x = Math.round((Number(n) || 0) * 100) / 100;
    return String(x);
  }
  function accName(v) { return nameOf(D().accessories, v) || v; }
  /**/
  function rodSheetOf(sub) {
    if (!ROD_PB || !ROD_PB.lap) return null;
    var m = /^(LAP|LBP)\s*(\d+)$/i.exec(String(sub || ''));
    return m ? (ROD_PB.lap['LAP' + m[2]] || null) : null;
  }
  /*
*/
  function rodLamSelfKey(sub) {
    var k = String(sub || '');
    return /^LAM5\d$/.test(k) ? 'LAM5' : k;
  }
  function rodLamBlock(sub) {
    if (!(ROD_PB && ROD_PB.lam)) return null;
    return ROD_PB.lam[rodLamSelfKey(sub)] || null;
  }
  /*
*/
  function rodPriceOf(cal, res) {
    var out = { parts: [], pend: [], base: 0, factor: 1, net: 0, lead: '', sheet: '' };
    if (!ROD_PB || !cal || !res) return out;
    var stroke = Number(cal.stroke) || 0;
    var accs = Array.isArray(res.accessories) ? res.accessories.slice()
      : (Array.isArray(cal.accessories) ? cal.accessories.slice() : []);
    function push(label, amt) {
      if (amt == null || isNaN(Number(amt))) { out.pend.push(label); return; }
      out.parts.push({ label: label, amount: Number(amt) });
    }
    if (res.fam === 'LAM') {
      var blk = rodLamBlock(res.sub);
      if (!blk) { out.pend.push(res.sub + ' 整机价'); return out; }
      var lamK = rodLamSelfKey(res.sub);          /**/
      out.sheet = lamK;
      out.factor = Number(blk.factor) || 1;
      out.lead = blk.lead || '';
      var keys = Object.keys(blk.prices || {}).map(Number).sort(function (a, b) { return a - b; });
      var pick = null;
      for (var i = 0; i < keys.length; i++) { if (keys[i] >= stroke) { pick = keys[i]; break; } }
      if (pick == null) {
        /**/
        out.pend.push('行程 ' + stroke + 'mm 超出报价档（' + lamK + ' 报价单最大 '
          + (keys.length ? keys[keys.length - 1] : '—') + 'mm，需人工报价）');
      } else {
        push('整机 ' + res.sub + '-' + pick + '（' + pick + 'mm 档，行程 ' + stroke + 'mm）', blk.prices[pick]);
      }
      accs.forEach(function (a) {
        if (a === 'HALL') {
          if (blk.acc && blk.acc['霍尔开关'] != null) push('附件 霍尔开关', blk.acc['霍尔开关']);
          else out.pend.push('附件 ' + accName(a));
        } else if (a === 'LS') {
          /**/
          if (blk.incl_switch) return;
          if (blk.acc && blk.acc['限位开关（S1减速比）'] != null) push('附件 限位开关（S1减速比）', blk.acc['限位开关（S1减速比）']);
          else out.pend.push('附件 ' + accName(a));
        } else if (a === 'CP') {
          /**/
          if (blk.acc && blk.acc['电流保护CP'] != null) push('附件 电流保护 CP', blk.acc['电流保护CP']);
          else out.pend.push('附件 ' + accName(a));
        } else {
          out.pend.push('附件 ' + accName(a));
        }
      });
    } else {
      var sh = rodSheetOf(res.sub);
      if (!sh) { out.pend.push('基座 ' + res.sub + ' 报价页'); return out; }
      out.sheet = sh.sheet || res.sub;
      out.factor = Number(sh.factor) || 1;
      out.lead = sh.lead || '';
      var segN = stroke / 100;                     /**/
      var install = String(cal.install || 'P1');
      push('输入形式 ' + install + '（' + nameOf(D().installs, install) + '）', sh.input ? sh.input[install] : null);
      if (res.fam === 'LBP') {
        push('滚珠丝杠基数费用', sh.ball_base);
        push('滚珠丝杠 ' + stroke + 'mm（' + numTxt(segN) + '×100mm）',
          (sh.per100 && sh.per100.LBP != null) ? sh.per100.LBP * segN : null);
      } else {
        push('普通齿丝杠 ' + stroke + 'mm（' + numTxt(segN) + '×100mm）',
          (sh.per100 && sh.per100.LAP != null) ? sh.per100.LAP * segN : null);
      }
      var jc = String(res.joint || cal.joint || 'ROE');
      var jp = (sh.joint || {})[jc];
      if ((jp == null || jp === '') && jc === 'FO') jp = (sh.joint || {}).TS;   /**/
      push('接头 ' + jc, (jp == null || jp === '') ? 0 : jp);
      var lim = limitResolved(cal, res.sub);
      if (lim) {
        var limEx = rodIsExMotor(cal, res);
        var limPrice = (sh.acc || {})[lim];
        if (limEx && limPrice != null) limPrice += 1000;
        push(limEx ? limitNameOf(lim, true) : ('限位开关 ' + (LIMIT_NAME[lim] || lim)), limPrice);
      }
      accs.forEach(function (a) {
        if (a === 'ST' || a === 'B') {
          var up = (sh.per100 || {})[a];
          push('附件 ' + accName(a) + '（' + numTxt(segN) + '×100mm）', up != null ? up * segN : null);
          return;
        }
        var pv = (sh.acc || {})[a];
        if (pv != null) push('附件 ' + accName(a), pv);
        else out.pend.push('附件 ' + accName(a));
      });
    }
    var base = 0;
    out.parts.forEach(function (p) { base += Number(p.amount) || 0; });
    out.base = Math.round(base * 100) / 100;
    out.net = Math.round(out.base * out.factor);
    return out;
  }
  /*
*/
  function rodMotorPriceOf(cal, res) {
    if (!ROD_PB || !cal || !res || res.fam === 'LAM') return null;
    if (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') return null;
    var sh = rodSheetOf(res.sub);
    if (!sh || !sh.motor) return null;
    var d = String(cal.drive || 'ac3'), key = null;
    if (d === 'ac3') key = (sh.motor['380V-2'] != null) ? '380V-2' : '380V-4';
    else if (d === 'ac1') key = '220V';
    else if (d === 'dc24') key = '24/12V';
    if (!key || sh.motor[key] == null) return null;
    /*

*/
    var mult = 1;
    if (d === 'ac1') {
      var bm = (res.mdef && res.mdef.motor) || {};
      var ap = (bm.kind && bm.kind !== 'dc24' && bm.kw) ? ac1Pick(bm.kw) : null;
      if (ap && ap.no) return null;
      if (ap && ap.kw && bm.kw) mult = Number(ap.kw) / Number(bm.kw);
    }
    return { base: sh.motor[key], net: Math.round(sh.motor[key] * (Number(sh.factor) || 1) * mult) };
  }

  /*




*/
  function rodRsdFrames() {
    var sj = g.SJ_DATA || {};
    var t = (((sj.reverse_gearboxes || {}).rsd_table || {}).at_1450rpm_1to1) || {};
    return Object.keys(t).map(function (k) { return { frame: k, torque: Number(t[k] && t[k].torque_Nm) || 0 }; })
      .filter(function (x) { return x.torque > 0; })
      .sort(function (a, b) { return a.torque - b.torque; });
  }
  function rodRsdPriceOf(frame) {
    var pb = g.SJ_PRICE_BOOK_LIMTEC || {};
    var map = pb.rsd || {};
    var key = String(frame);
    if (map[key] == null) key = key.replace(/^([A-Z]+)0+/, '$1');       /* RSD065 → RSD65 */
    if (map[key] == null) key = 'RSD' + parseInt(String(frame).replace(/[^0-9]/g, ''), 10);
    var v = map[key];
    if (v == null) return null;
    return Math.round(Number(v) * (Number(pb.rsd_factor) || 1));
  }
  function rodHvPick(ratio, torqueNm) {
    var hv = (g.SJ_DATA || {}).planetary_hv || {};
    var frames = hv.frames || {};
    var keys = Object.keys(frames)
      .filter(function (k) { return frames[k] && frames[k].L1 && frames[k].L1[ratio]; })
      .sort(function (a, b) { return Number(a) - Number(b); });
    for (var i = 0; i < keys.length; i++) {
      var f = frames[keys[i]], st = f.L1[ratio];
      if ((Number(st.C) || 0) >= Number(torqueNm)) {
        return {
          model: 'HV' + keys[i] + '-L1-i' + ratio, C: st.C, D: st.D, level: 'L1 单级',
          shafts: (hv.shafts || {})[keys[i]] || [],
          price: (f.price && f.price.direct && f.price.direct.L1) || null
        };
      }
    }
    return null;
  }
  /*




*/
  function rodShaftDiaOf(res) {
    var t = (D() && D().input_shaft_dia) || {};
    var d = (res && t[res.sub] != null) ? Number(t[res.sub]) : null;
    return (d > 0) ? d : null;
  }
  function rodPickDia(dia, obj) {
    var keys = Object.keys(obj || {}).map(Number).sort(function (a, b) { return a - b; });
    for (var i = 0; i < keys.length; i++) if (keys[i] >= dia - 1e-9) return keys[i];
    return keys.length ? keys[keys.length - 1] : null;
  }
  function rodShaftNetOf(dia, lenMm) {
    var bk = (typeof g.SJ_PRICE_BOOK_LIMTEC !== 'undefined') ? g.SJ_PRICE_BOOK_LIMTEC : null;
    if (!bk || !bk.shaftPerM || !(dia > 0) || !(lenMm > 0)) return null;
    var pick = rodPickDia(Math.round(dia * 2), bk.shaftPerM);
    var perM = (pick != null) ? bk.shaftPerM[String(pick)] : null;
    if (perM == null) return null;
    return { unit: Math.round(perM * (bk.shaft_factor || 1.5) * (lenMm / 1000)), dia: pick, perM: perM };
  }
  function rodCouplingNetOf(dia) {
    var bk = (typeof g.SJ_PRICE_BOOK_LIMTEC !== 'undefined') ? g.SJ_PRICE_BOOK_LIMTEC : null;
    if (!bk || !bk.coupling || !(dia > 0)) return null;
    var pick = rodPickDia(dia, bk.coupling);
    var p = (pick != null) ? bk.coupling[String(pick)] : null;
    if (p == null) return null;
    return { unit: Math.round(p * (bk.coupling_factor || 1.5)), dia: pick };
  }

  function rodRevBoxOf(cal, res) {
    if (!cal || !res) return null;
    var fam = res.fam || (res.mdef && res.mdef.fam);
    if (!(fam === 'LAP' || fam === 'LBP')) return null;
    if ((Number(cal.units) || 1) <= 1) return null;
    if (String(cal.layout || '电机内侧') !== '电机内侧') return null;
    if (String(cal.sync || '机械') === '电气') return null;
    if (String(cal.drive || '') === 'hand') return null;
    var mo = (res.motor && Number(res.motor.kw) ? res.motor : ((res.mdef && res.mdef.motor) || {}));
    var kw = Number(mo.kw) || 0, rpmM = Number(mo.rpm) || 0;
    var motorT = (rpmM > 0 && kw > 0) ? 9550 * kw / rpmM : 0;
    /**/
    var scv = res.servo_calc;
    if (scv && Number(scv.t_motor_nm) > 0) {
      motorT = Number(scv.t_motor_nm);
      rpmM = Number(scv.n_motor_rpm) || rpmM;
    }
    var tAll = Number(res.motor_torque_Nm) || 0;          /**/
    if (!(tAll > 0) || !(motorT > 0)) return null;
    var nIn = Math.round(Number(res.n_input_rpm) || rpmM || 0);
    var iPl = 1;
    if (rpmM > 0 && nIn > 0 && rpmM / nIn >= 1.8) {
      var cand = [3, 4, 5, 7, 10].filter(function (r) { return r <= rpmM / nIn + 1e-9; });
      if (cand.length) iPl = cand[cand.length - 1];
    }
    var tBranch = tAll / 2;
    var tChk = Math.max(tBranch, motorT * iPl);
    var fr = rodRsdFrames(), frame = null;
    for (var i = 0; i < fr.length; i++) { if (fr[i].torque >= tChk - 1e-9) { frame = fr[i].frame; break; } }
    if (!frame && fr.length) frame = fr[fr.length - 1].frame;
    if (!frame) return null;
    var hv = (iPl > 1) ? rodHvPick(iPl, motorT * iPl) : null;
    var rsdPrice = rodRsdPriceOf(frame);
    var price = (rsdPrice == null) ? null : rsdPrice + ((hv && hv.price != null) ? Number(hv.price) : 0);
    return {
      frame: frame, planet: iPl, planetPick: hv,
      t_req: tBranch, t_chk: tChk, motor_t: motorT, n_in: nIn,
      price: price, price_pend: (rsdPrice == null || (hv && hv.price == null))
    };
  }
  function rodRevBoxDesc(rev) {
    return '与电机一体化换向器 ' + rev.frame + '/1（速比 1:1）'
      + (rev.planet > 1
        ? '（配行星减速机 i=' + rev.planet + ':1，行星减速机与伞齿轮换向器一体化）（一进两出）'
        : '（带电机法兰，一进两出）');
  }
  function rodRevBoxSpec(rev) {
    /*
*/
    var s = '1 台：承受扭矩约 ' + fN(rev.t_chk, 0) + 'Nm（按电机额定扭矩 ' + fN(rev.motor_t, 1)
      + 'Nm 校核，需求扭矩 ' + fN(rev.t_req, 1) + 'Nm/路）（输入转速 ' + fN(rev.n_in, 0)
      + 'rpm），许用扭矩见样本 p141；分两路后每路按一半校核；从动台 P2 双输入轴（样本标注 L2）';
    if (rev.planet > 1 && rev.planetPick) {
      s += '；行星减速机 i=' + rev.planet + ':1：输入 ' + fN(rev.n_in * rev.planet, 0) + 'rpm（电机侧）、输出 '
        + fN(rev.n_in, 0) + 'rpm、输出扭矩 ' + fN(rev.motor_t * rev.planet, 1) + ' N·m（电机额定 '
        + fN(rev.motor_t, 1) + ' × 减速比 ' + rev.planet + '），选 ' + rev.planetPick.model
        + '（额定输出 ' + fN(rev.planetPick.C, 0) + 'Nm/最大 ' + fN(rev.planetPick.D, 0) + 'Nm，'
        + rev.planetPick.level
        + (rev.planetPick.shafts.length ? '；适配电机轴径 ' + rev.planetPick.shafts.join('/') + 'mm' : '')
        + '）';
    }
    return s;
  }

  /**/
  function quoteTableHTML(cal, res, cand, data) {
    var fullCode = suggestCode(cal, res);
    var m = res.mdef || {};
    var rows = '', no = 1, totalN = 0;
    /*

*/
    var pr = rodPriceOf(cal, res), mpr = rodMotorPriceOf(cal, res), priceTotal = 0;
    var scq = res.servo_calc || null;
    var bomS = rodServoBomOf(cal, res);
    var servoM = bomS ? bomS.m : null;
    var servoPr = bomS ? bomS.price : null;
    var gearPick = (scq && scq.gear > 1) ? scq.gear_pick : null;
    var gearPrice = (gearPick && gearPick.price != null) ? Number(gearPick.price) : null;
    var prTip = pr.parts.length
      ? '基本价分项：' + pr.parts.map(function (x) { return x.label + ' ' + moneyTxt(x.amount); }).join('；')
        + '；合计 ' + moneyTxt(pr.net)
      : '报价单无该型号价格';
    /**/
    var pendMain = pr.pend.some(function (x) {
      return x.indexOf('整机') >= 0 || x.indexOf('行程') >= 0 || x.indexOf('报价页') >= 0;
    });
    /*
*/
    var unitsN = Number(cal.units) || 1;
    var elec = unitsN > 1 && (res.fam === 'LAP' || res.fam === 'LBP') && cal.sync === '电气';
    var twin = unitsN > 1 && (res.fam === 'LAP' || res.fam === 'LBP') && !elec;
    var qtyMult = elec ? unitsN : 1;   /**/
    if (pr.parts.length) priceTotal += pr.net;
    /**/
    var motorUnit = (servoPr && servoPr.hasPrice) ? servoPr.unit
      : ((scq && scq.recommend && scq.recommend.length) ? null : (mpr ? mpr.net : null));
    if (motorUnit != null) priceTotal += motorUnit * qtyMult;
    if (gearPrice != null) priceTotal += gearPrice * qtyMult;
    /*


*/
    /*


*/
    var prF = null, pendF = false;
    /*


*/
    var fcpMainOnly = String(cal.limit_sw || 'STD') === 'STD';
    if (twin) {
      prF = rodPriceOf(Object.assign({}, cal, { install: 'P2' }, fcpMainOnly ? { limit_sw: 'NONE' } : {}), res);
      pendF = prF.pend.some(function (x) {
        return x.indexOf('整机') >= 0 || x.indexOf('行程') >= 0 || x.indexOf('报价页') >= 0;
      });
      if (prF.parts.length) priceTotal += prF.net;
    }
    /**/
    var rowMotorLine = !isLam(res.fam) && (
      cal.drive === 'servo220' || cal.drive === 'servo380' || cal.drive === 'stepping'
      || cal.drive === 'dc24' || cal.drive === 'ac1' || cal.drive === 'hand');
    var mainNet = pr.net + ((!rowMotorLine && !twin && motorUnit != null) ? motorUnit : 0);
    if (!rowMotorLine && !twin && motorUnit != null) {
      prTip += '；含配套交流电机（' + (nameOf(D().drives, cal.drive) || 'AC3') + ' ' + moneyTxt(motorUnit) + '）';
    }
    var seg = [];
    if (isLam(res.fam)) {
      seg.push('额定推/拉力 ' + fN(m.push_N, 0) + ' N' + (m.pull_N != null && m.pull_N !== m.push_N ? '（拉力 ' + fN(m.pull_N, 0) + ' N）' : ''));
      seg.push('自锁力 ' + (m.lock_N ? fN(m.lock_N, 0) + ' N' : '无（滚珠丝杠）'));
      seg.push('速度 ' + fN(m.v0, 1) + '-' + fN(m.v1, 1) + ' mm/s');
      if (m.volts) seg.push((m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V' + (m.iA != null ? '，满载 ' + fN(m.iA, 1) + ' A（24V）' : ''));
      seg.push('行程 ' + iN(cal.stroke) + ' mm（最大 ' + iN(m.stroke_max) + '）' + (res.extra_stroke ? '，加长行程：护管及伸缩管 +200mm' : ''));
      seg.push('接头 ' + jointText(res.joint, m.sub));
      seg.push('工作制 ' + (res.duty || '按样本'));
      /**/
      if (isSpecCodeSub(m.sub)) {
        var mt = mountSize(m.sub, cal.stroke, cal.lam_lower, cal.lam_upper, cal.lam_signal, m.push_N);
        if (mt != null) seg.push('安装尺寸 ' + iN(mt) + ' mm（= 行程 ' + iN(cal.stroke) + ' + 结构量 ' + iN(mt - Number(cal.stroke)) + '）');
        seg.push('规格码 电压' + cal.lam_volt + '·下端' + cal.lam_lower + '·上端' + cal.lam_upper
          + '·角度' + cal.lam_angle + '·限位' + cal.lam_limit + '·信号' + cal.lam_signal
          + '·插头' + cal.lam_plug + '·线长' + cal.lam_cable + '·IP' + cal.lam_ip);
      }
      /**/
      if (m.sub === 'LAM3' || String(m.sub).indexOf('LAM5') === 0) {
        var q = [];
        var is3q = (m.sub === 'LAM3');
        q.push('DC' + lamVolt(cal, m.sub) + 'V');
        if (is3q) q.push('附件 ' + (cal.lam2_fb === '无' ? '无' : cal.lam2_fb));
        if (cal.lam2_bracket && cal.lam2_bracket !== '无') q.push('支架 ' + bracketCode(m.sub, cal.lam2_bracket));
        if (cal.lam2_ctrl && cal.lam2_ctrl !== '不带') q.push('控制器 ' + cal.lam2_ctrl);
        if (!is3q) {
          q.push('外壳 ' + (cal.lam2_shell === 'SUS316' ? '316 不锈钢'
            : (cal.lam2_shell === 'ST45' ? '45# 钢喷塑' : '铝合金')));
          if (Array.isArray(cal.accessories) && cal.accessories.length) q.push('附件 ' + cal.accessories.join('/'));
        }
        q.push(cal.lam2_ip);
        if (is3q && cal.lam2_limit) q.push('限位 ' + cal.lam2_limit);
        seg.push('订货要素 ' + q.join('·'));
      }
    } else {
      seg.push('动态载荷 ' + fN(m.load_N, 0) + ' N，速度 ' + fN(m.speed, 1) + ' mm/s'
        + (res.speed_under_pct != null
          ? '（要求 ' + fN(res.speed_req, 1) + '，欠 ' + fN(res.speed_under_pct, 1) + '%，≤'
            + (res.speed_under_max || 20) + '% 按接近口径放行）'
          : '')
        /**/
        + (res.load_under_pct != null
          ? '；额定推力 ＜ 需求 ' + fN(res.load_req_N, 0) + ' N（欠 ' + fN(res.load_under_pct, 1)
            + '%，≤' + (res.load_under_max || 10) + '% 按备选口径放行，须客户确认）'
          : '')
        + '，减速比 ' + res.code);
      seg.push('电机 ' + driveSegText(cal, res, (res && res.motor) || m.motor));   /**/
      seg.push('行程 ' + iN(cal.stroke) + ' mm（最大 ' + (m.stroke_max != null ? iN(m.stroke_max) : '待样本确认') + '）' + (res.extra_stroke ? '，加长行程：护管及伸缩管 +200mm' : ''));
      seg.push('安装 ' + nameOf(D().installs, res.install) + '，方向 ' + (res.input_dir || 'RH') + '，接头 ' + jointText(res.joint, m.sub));
      /**/
      seg.push('自锁系数 ' + (m.lock != null ? String(m.lock) + (m.lock <= 0.25 ? '（自锁）' : '（不自锁，配制动器）')
        : '按样本（滚珠丝杠不自锁，配制动器）'));
      /**/
    var limIt = limitResolved(cal, m.sub);
    if (limIt) seg.push((rodIsExMotor(cal, res) ? limitNameOf(limIt, true) : ('限位开关 ' + (LIMIT_NAME[limIt] || limIt))) + (String(cal.limit_sw || 'STD') === 'STD' ? '（标配）' : '（指定）'));
    else if (noLimit(cal)) seg.push('限位开关 无限位开关（不配行程限位，需外置限位或客户自控）');
      /**/
      if (isServoDrive(cal)) {
        var scI = res.servo_calc || null;
        if (scI && scI.recommend && scI.recommend.length) {
          seg.push('所需扭矩 ' + fN(scI.t_motor_nm, 2) + ' N·m（含安全系数 ' + scI.safety + '）、所需功率 '
            + fN(scI.p_req_kw, 2) + ' kW @ ' + fN(scI.n_motor_rpm, 0) + ' rpm'
            + (scI.gear > 1 ? '；配行星减速机 i=' + scI.gear + ':1' : ''));
        } else if ((cal.servo_brand || []).length) {
          seg.push('伺服电机品牌 ' + cal.servo_brand.join('/'));
        }
      }
    }
    /**/
    if (cal.temp && String(cal.temp) !== '20') seg.push('工作温度 ' + cal.temp + '℃');
    /**/
    var accSeg296 = (Array.isArray(res.accessories) ? res.accessories : []).filter(function (a) { return a !== 'BRE'; });
    if (accSeg296.length) seg.push('附件 ' + accSeg296.join('/'));
    /*



*/
    var segM = twin ? seg.filter(function (x) { return String(x).indexOf('电机 ') !== 0; }) : seg;
    /*
*/
    var segElec = elec ? seg.filter(function (x) { return String(x).indexOf('电机 ') !== 0; }) : seg;
    var segF = twin ? seg.filter(function (x) {
      var sx = String(x);
      if (sx.indexOf('电机 ') === 0) return false;
      if (fcpMainOnly && sx.indexOf('限位开关 ') === 0) return false;
      return true;
    })
      .map(function (x) {
        var sx = String(x);
        if (sx.indexOf('安装 ') !== 0) return x;
        return sx.replace(/^安装 [^，]+/, '安装 ' + nameOf(D().installs, 'P2'))
          .replace(/，方向 [^，]+/, '');
      }) : seg;
    if (twin) {
      rows += '<tr><td>' + (no++) + '</td><td><b>Lim-Tec 电动推杆</b><br><span class="hint" style="font-family:Consolas,monospace">' + esc(suggestCode(cal, res, { noMotor: true })) + '</span></td>'
        + '<td>' + segM.map(esc).join('；') + '</td><td>1 台</td><td>'
        + (pr.parts.length
          ? (pendMain ? '<span class="hint" title="' + esc(prTip) + '">待报价（附件小计 ' + moneyTxt(pr.net) + ' 已计）</span>'
            : '<b title="' + esc(prTip) + '">' + moneyTxt(mainNet) + '</b>')
          : '<span class="hint">暂无价格</span>')
        + '</td></tr>';
      rows += '<tr><td>' + (no++) + '</td><td><b>Lim-Tec 电动推杆</b><br><span class="hint" style="font-family:Consolas,monospace">' + esc(suggestCode(cal, res, { follower: true })) + '</span>'
        + '<br><span class="hint">（从动侧）L2 = P2 双输入轴（无电机段）</span></td>'
        + '<td>' + segF.map(esc).join('；') + '</td><td>1 台</td><td>'
        + (prF && prF.parts.length
          ? (pendF ? '<span class="hint">待报价（附件小计 ' + moneyTxt(prF.net) + ' 已计）</span>'
            : '<b>' + moneyTxt(prF.net) + '</b>')
          : '<span class="hint">暂无价格</span>')
        + '</td></tr>';
      /*



*/
      var platL = Number(cal.platform_L) || 0;
      var shaftDiaN = rodShaftDiaOf(res);
      var shaftPrN = (platL > 0) ? rodShaftNetOf(shaftDiaN, platL) : null;
      var coupPrN = rodCouplingNetOf(shaftDiaN);
      var coupNetN = (coupPrN != null) ? coupPrN.unit * 2 : null;
      rows += '<tr><td>' + (no++) + '</td><td><b>传动轴</b></td>'
        + '<td>1 根：' + (platL > 0 ? '长度 ' + iN(platL) + ' mm（按客户平台中心距 ' + iN(platL) + ' mm）' : '长度按客户平台实际中心距确定')
        + '（' + esc(cal.layout || '电机内侧') + '布置）</td><td>1 根</td><td>'
        + (shaftPrN != null
          ? '<b title="' + esc('Ø' + shaftPrN.dia + ' × ' + iN(platL) + ' mm · ' + moneyTxt(shaftPrN.perM) + '/m × 1.5') + '">' + moneyTxt(shaftPrN.unit) + '</b>'
          : '<span class="hint">待报价</span>')
        + '</td></tr>';
      rows += '<tr><td>' + (no++) + '</td><td><b>联轴器</b></td>'
        + '<td>每根传动轴 2 个，与推杆输入轴及传动轴配套（' + esc(cal.layout || '电机内侧') + '布置）</td><td>2 个</td><td>'
        + (coupNetN != null
          ? '<b title="' + esc('Ø' + coupPrN.dia + ' · ' + moneyTxt(coupPrN.unit) + '/pc × 2') + '">' + moneyTxt(coupNetN) + '</b>'
          : '<span class="hint">待报价</span>')
        + '</td></tr>';
      if (shaftPrN != null) priceTotal += shaftPrN.unit;
      if (coupNetN != null) priceTotal += coupNetN;
      /*
*/
      var revT = rodRevBoxOf(cal, res);
      if (revT) {
        rows += '<tr><td>' + (no++) + '</td><td><b>与电机一体化换向器</b><br><span class="hint" style="font-family:Consolas,monospace">'
          + esc(revT.frame + '/1' + (revT.planet > 1 ? ' + ' + (revT.planetPick ? revT.planetPick.model : 'i=' + revT.planet + ':1') : ''))
          + '</span><br><span class="hint">（一进两出，速比 1:1）</span></td><td>' + esc(rodRevBoxSpec(revT)) + '</td><td>1 台</td><td>'
          + (revT.price != null ? '<b>' + moneyTxt(revT.price) + '</b>'
            : '<span class="hint">待询价（换向器价目）</span>')
          + '</td></tr>';
        if (revT.price != null) priceTotal += Number(revT.price);
        totalN += 1;
      }
      /**/
      totalN += 5;
    } else if (elec) {
      /*

*/
      var fullCodeElec = suggestCode(cal, res, { noMotor: true });
      for (var ei = 0; ei < unitsN; ei++) {
        rows += '<tr><td>' + (no++) + '</td><td><b>Lim-Tec 电动推杆</b><br><span class="hint" style="font-family:Consolas,monospace">' + esc(fullCodeElec) + '</span></td>'
          + '<td>' + segElec.map(esc).join('；') + '</td><td>1 台</td><td>'
          + (pr.parts.length
            ? (pendMain ? '<span class="hint" title="' + esc(prTip) + '">待报价（附件小计 ' + moneyTxt(pr.net) + ' 已计）</span>'
              : '<b title="' + esc(prTip) + '">' + moneyTxt(mainNet) + '</b>')
            : '<span class="hint">暂无价格</span>')
          + '</td></tr>';
      }
      totalN += unitsN;
    } else {
      rows += '<tr><td>' + (no++) + '</td><td><b>Lim-Tec 电动推杆</b><br><span class="hint" style="font-family:Consolas,monospace">' + esc(fullCode) + '</span></td>'
        + '<td>' + seg.map(esc).join('；') + '</td><td>' + unitsN + ' 台</td><td>'
        + (pr.parts.length
          ? (pendMain ? '<span class="hint" title="' + esc(prTip) + '">待报价（附件小计 ' + moneyTxt(pr.net) + ' 已计）</span>'
            : '<b title="' + esc(prTip) + '">' + moneyTxt(mainNet) + '</b>')
          : '<span class="hint">暂无价格</span>')
        + '</td></tr>';
      totalN += unitsN;
    }
    /*
*/
    if (rowMotorLine) {
      /*
*/
      var mo = (res && res.motor) || m.motor || {};
      var mseg;
      if (servoM) {
        mseg = nameOf(D().drives, cal.drive) + '；' + servoM.brand + ' ' + servoM.code
          + '（' + servoM.power_kW + ' kW / ' + (servoM.rpm != null ? iN(servoM.rpm) : '—') + ' rpm / '
          + (servoM.torque_Nm != null ? fN(servoM.torque_Nm, 2) + ' N·m' : '—')
          + (servoM.current_A != null ? ' / ' + fN(servoM.current_A, 1) + ' A' : '')
          + '，机座 ' + (servoM.frame || '按样本') + '）'
          + (servoM.need220 ? '；需 220V 供电（另备单相控制电源）' : '')
          + (servoM.tq_under != null ? '；额定扭矩低于计算需求 ' + fN(servoM.tq_under, 1) + '%（扭矩临界，须与厂家确认）' : '')
          + '；所需功率 ' + fN(scq.p_req_kw, 2) + ' kW（电机端 ' + fN(scq.t_motor_nm, 2) + ' N·m 含安全系数 ' + scq.safety + '）'
          + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置');
      } else if (cal.drive === 'ac1') {
        /*
*/
        var ap1 = (mo && mo.kind !== 'dc24' && mo.kw) ? ac1Pick(mo.kw) : null;
        mseg = (ap1 && ap1.no)
          ? nameOf(D().drives, cal.drive) + '；' + AC1_OVER_WARN
          : nameOf(D().drives, cal.drive) + '；选型参数 ' + (motorSegFor(cal, mo) || '按样本')
            + '；' + (ap1 && ap1.capped ? '单相已达上限' : '单相已放大一号');
        mseg += '；制动器' + (res.self_lock ? '按需选配' : '随电机内置');
      } else if (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') {
        /**/
        mseg = rodDcSeg233(res, cal) + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置');
      } else {
        mseg = nameOf(D().drives, cal.drive) + '；基型参数 ' + (motorSeg(mo) || '按样本')
          + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置');
      }
      rows += '<tr><td>' + (no++) + '</td><td><b>驱动电机</b></td><td>' + esc(mseg) + '</td><td>' + (twin ? 1 : unitsN) + ' 台</td><td>'
        + ((cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48')
          ? '—'
          : (motorUnit != null ? '<b title="' + esc('电机＋配套驱动器成套价 ' + moneyTxt(motorUnit) + (elec ? ' × ' + unitsN + ' 台' : '')) + '">' + moneyTxt(motorUnit * qtyMult) + '</b>'
            : '<span class="hint">待询价（按品牌配套报价）</span>'))
        + '</td></tr>';
      totalN += (twin ? 1 : unitsN);
      /**/
      if (scq && scq.gear > 1) {
        var gseg = '行星减速机 i=' + scq.gear + ':1（效率 ' + scq.gear_eta + '）'
          + (gearPick ? '；' + gearPick.model + '，额定输出 ' + fN(gearPick.C, 0) + ' N·m / 最大 ' + fN(gearPick.D, 0) + ' N·m，' + gearPick.level : '；型号待询')
          + '；输入 ' + fN(scq.n_motor_rpm, 0) + ' rpm / 输出 ' + fN(scq.n_screw_rpm, 0) + ' rpm';
        rows += '<tr><td>' + (no++) + '</td><td><b>行星减速机</b></td><td>' + esc(gseg) + '</td><td>' + (twin ? 1 : unitsN) + ' 台</td><td>'
          + (gearPrice != null ? '<b>' + moneyTxt(gearPrice * qtyMult) + '</b>' : '<span class="hint">待询价</span>') + '</td></tr>';
        totalN += (twin ? 1 : unitsN);
      }
    }
    /**/
    if (twin && !rowMotorLine) {
      rows += '<tr><td>' + (no++) + '</td><td><b>交流电机</b></td><td>' + esc(driveSegText(cal, res, (res && res.motor) || m.motor))
        + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置') + '</td><td>1 台</td><td>'
        + (motorUnit != null ? '<b title="' + esc('电机＋配套驱动器成套价 ' + moneyTxt(motorUnit)) + '">' + moneyTxt(motorUnit) + '</b>'
          : '<span class="hint">待询价（按品牌配套报价）</span>')
        + '</td></tr>';
      totalN += 1;
    }
    return '<table><thead><tr><th style="width:36px">No.</th><th style="width:220px">产品描述</th><th>规格参数</th><th style="width:64px">数量</th><th style="width:110px">价格</th></tr></thead>'
      + '<tbody>' + rows + '</tbody>'
      + '<tfoot><tr><td colspan="3" style="text-align:right"><b>合计</b></td><td>' + totalN + (twin ? ' 台/件' : ' 台') + '</td><td>'
      + (pendMain
        ? '<span class="hint">待报价' + (priceTotal > 0 ? '（附件小计 ' + moneyTxt(priceTotal) + ' 已计）' : '') + '</span>'
        : (priceTotal > 0 ? '<b>' + moneyTxt(priceTotal) + '</b>' : '<span class="hint">暂无价格</span>'))
      + '</td></tr></tfoot></table>'
      + '<div class="hint" style="margin-top:4px">价格供参考，正式报价以商务报价单为准。</div>';
  }

  /**/
  /*

*/
  function isLam5Pick(cal, res) {
    var grp = (cal && cal.lam_group) ? String(cal.lam_group) : '';
    var sub = (res && (res.sub || (res.mdef && res.mdef.sub))) || (cal && cal.sub) || '';
    return grp === 'LAM5' || String(sub).indexOf('LAM5') === 0;
  }
  function layoutImageFor() { return ''; }
  function layoutPickFor(cal, res) {
    var fam = (res && res.fam) || (cal && (cal.fam || cal.series));
    /**/
    if (cal && Number(cal.units) === 2) {
      /**/
      if (cal.sync === '电气') {
        var sE287 = seriesMeta(fam);
        var bnE287 = baseNo((res && (res.sub || (res.mdef && res.mdef.sub))) || (cal && cal.sub));
        var imgE287 = ((fam === 'LAP' || fam === 'LBP') && bnE287 != null && bnE287 >= 56) ? 'rod-56up.jpg' : (sE287.img || 'rod-lap.jpg');
        return { img: imgE287, label: (sE287.t || '') + '（电气同步，每台独立电机直驱）' };
      }
      var lay = String(cal.layout || '电机内侧');
      var lo = (D().rod_layouts || []).filter(function (o) { return o.v === lay; })[0];
      return { img: (lo && lo.img) || 'rod-lay2-inner.jpg', label: '两台电动推杆（' + lay + '）' };
    }
    var s = seriesMeta(fam);
    if (fam === 'LAM' && isLam5Pick(cal, res)) {
      return { img: 'rod-lam5.jpg', label: '小型电动推杆 LAM5' };
    }
    /*

*/
    var bn = baseNo((res && (res.sub || (res.mdef && res.mdef.sub))) || (cal && cal.sub));
    if ((fam === 'LAP' || fam === 'LBP') && bn != null && bn >= 56) {
      return { img: 'rod-56up.jpg', label: s.t || '' };
    }
    return { img: s.img || 'rod-lap.jpg', label: s.t || '' };
  }

  /**/
  function aboutLines() {
    return [
      '力姆泰克（Lim-Tec）——国内最专业、最具规模、最权威的电动推杆 / 螺旋升降机 / 伺服电动缸专业制造厂家。2005 年合资引进欧洲直线传动技术与模块化组合设计理念；2015 年完成股改（注册资本三千万元），2016 年登陆新三板（股票代码 836388），成为国内螺旋升降机、电动缸第一股。',
      '廊坊大厂一期 8,000 m²（投资 5,000 万元、30 亩工业产权）、二期 28,000 m²（累计投资两亿元）生产基地，年产 5 万台；配备上百台数控加工设备，蜗杆、箱体、丝杠等关键零件全部自加工，不外协。',
      '质量与检测：100 吨加载测试中心可对大吨位产品满载荷跑合试验；进口三坐标测量仪、丝杠精度检测等手段覆盖来料、加工与出厂全流程；产品逐台空载 / 负载跑合检验合格后出厂，随箱提供合格证与检验报告。',
      '电动推杆产品线覆盖 LAM 小型（LAM1/3/8、LAM32/33、LAM5 家族、LBM9）、LAP 梯形丝杠（LAP22~300）、LBP 滚珠丝杠（LBP25~300）三大系列，推力 0.01~30 吨，配套 P1~P4 输入形式、FL/TS/ROE/FO/NF/BA 六种接头与全套附件，可为客户提供完整直线推拉方案。',
      '全国 10 个办事处构成销售与服务网络，就近提供选型支持、安装指导与售后响应；产品广泛应用于工程机械、医疗、能源、物流、开窗通风、舞台机械、光伏等行业。',
      '对特殊工况（高低温、防腐、防爆等）具备成熟的定制经验：低温润滑脂与低温型电机、不锈钢外壳 / 丝杠、达克罗喷塑防腐、防爆电机等配置均可按需提供，并有同类项目业绩支撑。'
    ];
  }
  function featLines() {
    /*

*/
    var raw = [
      /*
*/
      'LAP 梯形丝杠系列传动效率 25~33%（国产同类 14~19%，选国产需更高输入功率）；LBP 滚珠丝杠系列 50~70%',
      '交流电机配置 ABB / SEW / NORD / Siemens 制造，或力姆泰克国产 OEM 产品',
      '力姆泰克箱体使用卧式加工中心加工，保证垂直度、同轴度、中心距，并用进口三坐标检测，保证产品质量完全合格',
      '蜗轮材料（锡青铜 10-1）对产品耐磨性能非常重要，是电动推杆寿命的主要决定因素',
      '蜗杆精加工使用数控蜗杆磨，保证蜗杆齿型与蜗轮吻合，保证啮合精度与传动平稳',
      '产品零部件加工精度高于国内 2 级，保证高质量产品',
      '运行平稳、噪音低，达到进口产品标准',
      '电动推杆产品表面氧化处理，无须喷漆；其他产品为烤漆处理',
      '进口特制磁感应限位开关，保证灵敏度，可任意位置调节',
      '电动推杆内部设防撞装置，保证推杆在超过极限推力时不损坏'
    ];
    return raw.map(function (s, i) { return (i < 9 ? '0' : '') + (i + 1) + '　' + s; });
  }
  function commFields() {
    return {
      TERM_PRICE: '本方案书单价仅供选型参考；正式价格与折扣以商务报价单为准，报价有效期 30 天。',
      TERM_DELIVERY: '标准机型合同生效后 6–8 周交货；带特殊工况配置（低温/防腐/防爆）或非标接口时，交期在合同确认时书面明确。',
      TERM_PAYMENT: '预付 30% 合同生效，发货前付清余款；长期合作客户可按年度框架协议执行。',
      TERM_WARRANTY: '自发货之日起 12 个月质保，非人为损坏免费维修或更换；非正常操作损坏除外。'
    };
  }

  function composeSpec(res, cal, data, opt) {
    opt = opt || {};
    var units = Number(cal.units) || 1;
    var code = suggestCode(cal, res);
    var m = res.mdef || {};
    /*

*/
    var moR = (res.motor && res.motor.kw != null) ? res.motor : m.motor;
    var moSlotKw = (m.motor && m.motor.kw != null) ? Number(m.motor.kw) : null;
    var moReSel = (moR && moR.kw != null && moSlotKw != null && Math.abs(Number(moR.kw) - moSlotKw) > 1e-9);
    var sMeta = seriesMeta(res.fam);
    var items = [];
    var seg = [];
    if (isLam(res.fam)) {
      seg.push('额定推力 ' + fN(m.push_N, 0) + ' N' + (m.pull_N != null && m.pull_N !== m.push_N ? '（拉力 ' + fN(m.pull_N, 0) + ' N）' : ''));
      seg.push('自锁力 ' + (m.lock_N ? fN(m.lock_N, 0) + ' N（自锁）' : '不自锁（滚珠丝杠，配制动器）'));
      seg.push('速度（空载-满载）' + fN(m.v0, 1) + '-' + fN(m.v1, 1) + ' mm/s');
      seg.push('行程 ' + iN(cal.stroke) + ' mm（型号最大 ' + iN(m.stroke_max) + '）' + (res.extra_stroke ? '，加长行程：护管及伸缩管 +200mm' : ''));
      if (m.volts) seg.push((m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V' + (m.iA != null ? '，满载电流 ' + fN(m.iA, 1) + ' A（24V）' : ''));
      seg.push('接头 ' + jointText(res.joint, m.sub) + '，工作制 '
        + ((m.sub === 'LAM6' && cal.lam2_screw === 'LBM6') ? '25%（滚珠型）' : (res.duty || '按样本')));
      /**/
      if (isSpecCodeSub(m.sub)) {
        var mtS = mountSize(m.sub, cal.stroke, cal.lam_lower, cal.lam_upper, cal.lam_signal, m.push_N);
        if (mtS != null) seg.push('安装尺寸 ' + iN(mtS) + ' mm');
        seg.push('规格码（样本 p6/p8）电压 ' + nameOf(D().lam_code.volt, cal.lam_volt)
          + '；下端 ' + nameOf(D().lam_code.lower, cal.lam_lower)
          + '；上端 ' + nameOf(D().lam_code.upper, cal.lam_upper)
          + '；下端角度 ' + nameOf(D().lam_code.angle, cal.lam_angle)
          + '；极限开关 ' + nameOf(D().lam_code.limit, cal.lam_limit)
          + '；信号输出 ' + nameOf(D().lam_code.signal, cal.lam_signal)
          + '；插头 ' + nameOf(D().lam_code.plug, cal.lam_plug)
          + '；线长 ' + nameOf(D().lam_code.cable, cal.lam_cable)
          + '；IP ' + nameOf(D().lam_code.ip, cal.lam_ip));
      }
      /**/
      if (m.sub === 'LAM3' || String(m.sub).indexOf('LAM5') === 0) {
        var fx = (D().lam35_specs || {});
        var nm = function (k, v) {
          var list = ((fx[k] || {})[(m.sub === 'LAM3') ? 'LAM3' : 'LAM5'] || []);
          var hit = list.filter(function (o) { return String(o.v) === String(v); })[0];
          return hit ? hit.t : String(v || '');
        };
        var vv = lamVolt(cal, m.sub);
        var is3s = (m.sub === 'LAM3');
        seg.push('工作电压 DC' + vv + 'V'
          + ((m.sub === 'LAM55' && vv === '12') ? '（该电压下最大负载 5000N）' : ''));
        if (is3s) seg.push('反馈附件 ' + nm('fb', cal.lam2_fb));
        if (cal.lam2_bracket && cal.lam2_bracket !== '无') seg.push('安装支架 ' + bracketCode(m.sub, cal.lam2_bracket));
        if (cal.lam2_ctrl && cal.lam2_ctrl !== '不带') seg.push('适配控制器 ' + cal.lam2_ctrl);
        if (is3s) {
          seg.push('防护 ' + cal.lam2_ip + '，' + nm('limit', cal.lam2_limit));
        } else {
          /**/
          seg.push('外壳 ' + nm('shell', cal.lam2_shell) + '，防护 ' + cal.lam2_ip);
        }
      }
      /*

*/
      if (m.sub === 'LAM6' || m.sub === 'LAM8' || m.sub === 'LBM9') {
        var fx2 = (D().lam35_specs || {});
        var gk = (m.sub === 'LAM6') ? 'LAM6' : 'LAM89';
        var nm2 = function (k, v) {
          var list = ((fx2[k] || {})[gk] || []);
          var hit = list.filter(function (o) { return String(o.v) === String(v); })[0];
          return hit ? hit.t : String(v || '');
        };
        if (m.sub === 'LAM6' && cal.lam2_screw === 'LBM6') {
          seg.push('丝杠 滚珠丝杠 LBM6（工作制 25%，不自锁需配制动器；LBM6 独立档位表待样本确认，本方案推力沿用 LAM6 六档）');
        } else if (m.sub === 'LAM6') {
          seg.push('丝杠 梯形丝杠 LAM6（工作制 10%）');
        }
        if (cal.lam2_limit) seg.push('限位开关 ' + nm2('limit', cal.lam2_limit));
        if (m.sub === 'LAM6') seg.push('防护 IP66（动态，样本 p16）');
        else if (cal.lam2_ip) seg.push('防护 ' + cal.lam2_ip);
        if (cal.lam2_ctrl && cal.lam2_ctrl !== '不带') seg.push('适配控制器 ' + cal.lam2_ctrl);
        /**/
        if (m.sub === 'LAM6') seg.push('CAN 通讯 可选（样本 p16：驱动可配置 CAN 通讯，需订货注明）');
      }
    } else {
      seg.push('动态载荷 ' + fN(m.load_N, 0) + ' N，速度 ' + fN(m.speed, 1) + ' mm/s'
        + (res.speed_under_pct != null
          ? '（要求 ' + fN(res.speed_req, 1) + '，欠 ' + fN(res.speed_under_pct, 1) + '%，≤'
            + (res.speed_under_max || 20) + '% 按接近口径放行）'
          : '')
        /**/
        + (res.load_under_pct != null
          ? '；额定推力 ＜ 需求 ' + fN(res.load_req_N, 0) + ' N（欠 ' + fN(res.load_under_pct, 1)
            + '%，≤' + (res.load_under_max || 10) + '% 按备选口径放行，须客户确认）'
          : '')
        + '，减速比 ' + res.code);
      seg.push('电机 ' + driveSegText(cal, res, (res && res.motor) || m.motor));   /**/
      seg.push('行程 ' + iN(cal.stroke) + ' mm（最大 ' + (m.stroke_max != null ? iN(m.stroke_max) : '待样本确认') + '）' + (res.extra_stroke ? '，加长行程：护管及伸缩管 +200mm' : ''));
      seg.push('安装 ' + nameOf(D().installs, res.install) + '，方向 ' + (res.input_dir || 'RH') + '，接头 ' + jointText(res.joint, m.sub));
      /**/
      seg.push('自锁系数 ' + (m.lock != null ? String(m.lock) + (m.lock <= 0.25 ? '（自锁）' : '（不自锁，配制动器）')
        : '按样本（滚珠丝杠不自锁，配制动器）'));
      /**/
    var limIt = limitResolved(cal, m.sub);
    if (limIt) seg.push((rodIsExMotor(cal, res) ? limitNameOf(limIt, true) : ('限位开关 ' + (LIMIT_NAME[limIt] || limIt))) + (String(cal.limit_sw || 'STD') === 'STD' ? '（标配）' : '（指定）'));
    else if (noLimit(cal)) seg.push('限位开关 无限位开关（不配行程限位，需外置限位或客户自控）');
      /**/
      if (isServoDrive(cal)) {
        var scS = res.servo_calc || null;
        if (scS && scS.recommend && scS.recommend.length) {
          seg.push('所需扭矩 ' + fN(scS.t_motor_nm, 2) + ' N·m（含安全系数 ' + scS.safety + '）、所需功率 '
            + fN(scS.p_req_kw, 2) + ' kW @ ' + fN(scS.n_motor_rpm, 0) + ' rpm'
            + (scS.gear > 1 ? '；配行星减速机 i=' + scS.gear + ':1' : ''));
        } else if ((cal.servo_brand || []).length) {
          seg.push('伺服电机品牌 ' + cal.servo_brand.join('/'));
        }
      }
    }
    /**/
    if (cal.temp && String(cal.temp) !== '20') seg.push('工作温度 ' + cal.temp + '℃');
    /**/
    var accSegD = (Array.isArray(res.accessories) ? res.accessories : []).filter(function (a) { return a !== 'BRE'; });
    if (accSegD.length) seg.push('附件 ' + accSegD.join('/'));
    /*
*/
    var dpr = rodPriceOf(cal, res), dmpr = rodMotorPriceOf(cal, res);
    var dsc = res.servo_calc || null;
    var dBom = rodServoBomOf(cal, res);
    var dsvM = dBom ? dBom.m : null;
    var dsvP = dBom ? dBom.price : null;
    var dMotorUnit = (dsvP && dsvP.hasPrice) ? dsvP.unit
      : (dsvM ? null : (dmpr ? dmpr.net : null));
    var dPendMain = dpr.pend.some(function (x) {
      return x.indexOf('整机') >= 0 || x.indexOf('行程') >= 0 || x.indexOf('报价页') >= 0;
    });
    var dUnit = (dPendMain ? 0 : (dpr.parts.length ? dpr.net : 0)) + (dMotorUnit || 0);
    if (dPendMain) seg.push('报价：' + dpr.pend.join('、'));   /**/
    /*


*/
    /**/
    var elecD = units > 1 && (res.fam === 'LAP' || res.fam === 'LBP') && cal.sync === '电气';
    var twinD = units > 1 && (res.fam === 'LAP' || res.fam === 'LBP') && !elecD;
    var dprF = null, dPendF = false;
    /**/
    var fcpMainOnlyD = String(cal.limit_sw || 'STD') === 'STD';
    if (twinD) {
      dprF = rodPriceOf(Object.assign({}, cal, { install: 'P2' }, fcpMainOnlyD ? { limit_sw: 'NONE' } : {}), res);
      dPendF = dprF.pend.some(function (x) {
        return x.indexOf('整机') >= 0 || x.indexOf('行程') >= 0 || x.indexOf('报价页') >= 0;
      });
    }
    /*
*/
    if (units > 1) seg.push(elecD
      ? '2 台配置：电气同步，每台 1 台电机独立直驱（无传动轴/联轴器）'
      : '2 台配置：1 台 ' + (res.install || 'P4')
        + (((res.install || 'P4') === 'P4' ? '（电机侧，样本标注 L4）' : '（电机侧）'))
        + ' + 1 台 P2（从动台，样本标注 L2），'
        + (cal.layout || '电机内侧'));
    if (twinD) {
      /*

*/
      var segMD = seg.filter(function (x) { return String(x).indexOf('电机 ') !== 0; });
      var segFD = seg.filter(function (x) {
        var sx = String(x);
        if (sx.indexOf('电机 ') === 0) return false;
        if (fcpMainOnlyD && sx.indexOf('限位开关 ') === 0) return false;
        return true;
      })
        .map(function (x) {
          var sx = String(x);
          if (sx.indexOf('安装 ') !== 0) return x;
          return sx.replace(/^安装 [^，]+/, '安装 ' + nameOf(D().installs, 'P2'))
            .replace(/，方向 [^，]+/, '');
        });
      var dUnitMain = (dPendMain ? 0 : (dpr.parts.length ? dpr.net : 0));
      var dUnitF = (dPendF ? 0 : (dprF.parts.length ? dprF.net : 0));
      items.push({
        desc: 'Lim-Tec 电动推杆\n' + (suggestCode(cal, res, { noMotor: true }) || code || ''), spec: segMD.join('；'), qty: '1 台',
        unit_price: (dPendMain || dUnitMain <= 0) ? null : moneyTxt(dUnitMain),
        total_price: (dPendMain || dUnitMain <= 0) ? null : moneyTxt(dUnitMain)
      });
      items.push({
        desc: 'Lim-Tec 电动推杆\n' + suggestCode(cal, res, { follower: true }) + '（从动侧 P2）',
        spec: segFD.join('；'), qty: '1 台',
        unit_price: (dPendF || dUnitF <= 0) ? null : moneyTxt(dUnitF),
        total_price: (dPendF || dUnitF <= 0) ? null : moneyTxt(dUnitF)
      });
      var platLD = Number(cal.platform_L) || 0;   /**/
      /**/
      var shaftDiaD = rodShaftDiaOf(res);
      var shaftPrD = (platLD > 0) ? rodShaftNetOf(shaftDiaD, platLD) : null;
      var coupPrD = rodCouplingNetOf(shaftDiaD);
      var coupNetD = (coupPrD != null) ? coupPrD.unit * 2 : null;
      items.push({
        desc: '传动轴', spec: '1 根：' + (platLD > 0 ? '长度 ' + iN(platLD) + ' mm（按客户平台中心距 ' + iN(platLD) + ' mm）' : '长度按客户平台实际中心距确定')
          + '（' + (cal.layout || '电机内侧') + '布置）',
        qty: '1 根',
        unit_price: (shaftPrD != null) ? moneyTxt(shaftPrD.unit) : null,
        total_price: (shaftPrD != null) ? moneyTxt(shaftPrD.unit) : null
      });
      items.push({
        desc: '联轴器', spec: '每根传动轴 2 个，与推杆输入轴及传动轴配套（' + (cal.layout || '电机内侧') + '布置）',
        qty: '2 个',
        unit_price: (coupPrD != null) ? moneyTxt(coupPrD.unit) : null,
        total_price: (coupNetD != null) ? moneyTxt(coupNetD) : null
      });
      /**/
      var revD = rodRevBoxOf(cal, res);
      if (revD) {
        items.push({
          desc: rodRevBoxDesc(revD), spec: rodRevBoxSpec(revD), qty: '1 台',
          unit_price: (revD.price != null) ? moneyTxt(revD.price) : null,
          total_price: (revD.price != null) ? moneyTxt(revD.price) : null
        });
      }
      /*
*/
      if (cal.drive !== 'hand') {
        items.push({
          desc: (cal.drive === 'ac3') ? '交流电机' : '驱动电机',
          spec: driveSegText(cal, res, (res && res.motor) || m.motor) + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置'),
          qty: '1 台',
          unit_price: (dMotorUnit != null) ? moneyTxt(dMotorUnit) : null,
          total_price: (dMotorUnit != null) ? moneyTxt(dMotorUnit) : null
        });
      }
    } else if (elecD) {
      /*

*/
      var dUnitE = (dPendMain ? 0 : (dpr.parts.length ? dpr.net : 0));
      var segED = seg.filter(function (x) { return String(x).indexOf('电机 ') !== 0; });
      var codeED = suggestCode(cal, res, { noMotor: true }) || code || '';
      for (var eiD = 0; eiD < units; eiD++) {
        items.push({
          desc: 'Lim-Tec 电动推杆\n' + codeED, spec: segED.join('；'), qty: '1 台',
          unit_price: (dPendMain || dUnitE <= 0) ? null : moneyTxt(dUnitE),
          total_price: (dPendMain || dUnitE <= 0) ? null : moneyTxt(dUnitE)
        });
      }
      if (cal.drive !== 'hand') {
        items.push({
          desc: '驱动电机',
          spec: driveSegText(cal, res, m.motor) + '；制动器' + (res.self_lock ? '按需选配' : '随电机内置'),
          qty: units + ' 台',
          unit_price: (dMotorUnit != null) ? moneyTxt(dMotorUnit) : null,
          total_price: (dMotorUnit != null) ? moneyTxt(dMotorUnit * units) : null
        });
      }
    } else {
      items.push({
        desc: 'Lim-Tec 电动推杆\n' + (code || '') + (units > 1 ? '（2 台）' : ''), spec: seg.join('；'), qty: units + ' 台',
        unit_price: (dPendMain || dUnit <= 0) ? null : moneyTxt(dUnit),
        total_price: (dPendMain || dUnit <= 0) ? null : moneyTxt(dUnit * units)
      });
    }
    var dGearPick = (dsc && dsc.gear > 1) ? dsc.gear_pick : null;
    if (dsc && dsc.gear > 1) {
      items.push({
        desc: '行星减速机\n' + (dGearPick ? dGearPick.model : 'i=' + dsc.gear + ':1'),
        spec: '减速比 i=' + dsc.gear + ':1（效率 ' + dsc.gear_eta + '）；输入 ' + fN(dsc.n_motor_rpm, 0)
          + ' rpm / 输出 ' + fN(dsc.n_screw_rpm, 0) + ' rpm'
          + (dGearPick ? '；额定输出 ' + fN(dGearPick.C, 0) + ' N·m / 最大 ' + fN(dGearPick.D, 0) + ' N·m，' + dGearPick.level
            + (dGearPick.shaftNote ? '；' + dGearPick.shaftNote : '') : '；型号待询'),
        qty: (twinD ? 1 : units) + ' 台',
        unit_price: (dGearPick && dGearPick.price != null) ? moneyTxt(dGearPick.price) : null,
        total_price: (dGearPick && dGearPick.price != null) ? moneyTxt(dGearPick.price * (twinD ? 1 : units)) : null
      });
    }
    /*
*/
    var dAll = (twinD
        ? dUnitMain + dUnitF + (dMotorUnit || 0) + ((shaftPrD != null) ? Number(shaftPrD.unit) : 0)
          + ((coupNetD != null) ? Number(coupNetD) : 0)
        : (elecD ? (dUnitE + (dMotorUnit || 0)) * units : dUnit))
      + ((dGearPick && dGearPick.price != null) ? Number(dGearPick.price) * (twinD ? 1 : units) : 0)
      + ((revD && revD.price != null) ? Number(revD.price) : 0);
    var dPriceTotal = dAll > 0 ? moneyTxt(dAll) : '暂无价格';

    /**/
    /*
*/
    var rmTwin286 = {
      P1: '，电机侧 P1 + 从动台 P2，传动轴 1 根 + 联轴器 2 个）',
      P2: '，电机侧 P2 + 从动台 P2，传动轴 1 根 + 联轴器 2 个）',
      P3: '，电机侧 P3 + 从动台 P2，传动轴 1 根 + 联轴器 2 个）',
      P4: '，电机侧 P4 + 从动台 P2，传动轴 1 根 + 联轴器 2 个）'
    };
    var REQ_MOTION = famName(res.fam) + '，' + units + ' 台'
      + (elecD ? '（电气同步，每台 1 台电机独立直驱，无传动轴/联轴器）'
        : (units > 1 ? ('（' + (cal.layout || '电机内侧') + (rmTwin286[res.install] || rmTwin286.P4)) : ''))
      + '；驱动 ' + (nameOf(D().drives, cal.drive) || '按默认')
      + '；' + (isLam(res.fam) ? '接头 ' + jointText(res.joint, m.sub) : '输入形式 ' + (res.install || 'P3') + '（' + nameOf(D().installs, res.install) + '），方向 ' + (res.input_dir || 'RH'));
    /**/
    var REQ_LOAD = (cal.total_load_N || cal.load_N
      ? '总负载推力 ' + fN(cal.total_load_N || cal.load_N, 0) + ' N（约 '
        + fN((cal.total_load_N || cal.load_N) / 9806.65, 2) + ' 吨）' : '')
      + (cal.total_pull_N || cal.pull_N ? '，总负载拉力 ' + fN(cal.total_pull_N || cal.pull_N, 0) + ' N' : '')
      + (cal.total_static_N || cal.static_N ? '；静载 ' + fN(cal.total_static_N || cal.static_N, 0) + ' N' : '')
      + (units > 1 ? '；每台承担 ' + fN(cal.load_N, 0) + ' N' : '')
      + '；校核用额定 ' + fN(res.rated_N, 0) + ' N';
    var REQ_SPEED = '行程 ' + iN(cal.stroke) + ' mm，速度 ' + fN(cal.speed_req, 1) + ' mm/s'
      + (cal.cycles_per_day ? '；' + iN(cal.cycles_per_day) + ' 次/日 × ' + iN(cal.days_per_year) + ' 天/年' : '');
    var REQ_MOUNT = isLam(res.fam)
      ? ('接头 ' + jointText(res.joint, m.sub) + '；直流推杆内置限位开关')
      : ('安装方式 ' + nameOf(D().installs, res.install) + '，方向 ' + (res.input_dir || 'RH') + '，接头 ' + jointText(res.joint, m.sub));
    /**/
    var limitTxt;
    if (isLam(res.fam)) {
      var limMap = { L2: 'L2 内置开关', XL2: 'XL2 内置开关外出线', FCM: 'FCM 外置磁感应开关', '标配': '内置（标配）', '取消': '不配限位开关（非标）' };
      /**/
      if ((res.sub === 'LAM3' || res.sub === 'LAM6' || res.sub === 'LAM8' || res.sub === 'LBM9') && cal.lam2_limit) {
        limitTxt = limMap[cal.lam2_limit] || '内置限位开关';
      } else {
        /**/
        var accSet = (cal.accessories || []);
        var parts2 = [];
        if (accSet.indexOf('LS') >= 0) parts2.push('内置限位开关');
        if (accSet.indexOf('CP') >= 0) parts2.push('电流保护');
        if (accSet.indexOf('HALL') >= 0) parts2.push('霍尔开关');
        limitTxt = parts2.length ? parts2.join(' / ') : '按需求选配';
      }
    } else {
      /*
*/
      var lv = limitResolved(cal, res.sub || (res.mdef && res.mdef.sub));
      limitTxt = noLimit(cal)
        ? '无限位开关（不配行程限位，需外置限位或客户自控）'
        /**/
        : (rodIsExMotor(cal, res) ? (lv || '按需求选配') + '（防爆型）' : (LIMIT_NAME[lv] || lv || '按需求选配'))
          + (String(cal.limit_sw || 'STD') === 'STD' ? '（标配）' : '（指定）');
    }
    var REQ_ENV = (cal.temp && cal.temp !== '20' ? '工作温度 ' + cal.temp + '℃，' : '')
      + '限位开关 ' + limitTxt
      + ((cal.special && cal.special.length) ? '；特殊要求：' + cal.special.join('/') : '')
      + envDocSeg(res, cal);

    /**/
    var stabStep = (res.steps || []).filter(function (x) { return x[0] === '稳定性校核'; })[0];
    var dutyStep = (res.steps || []).filter(function (x) { return x[0] === '工作制校核'; })[0];
    var lockStep = (res.steps || []).filter(function (x) { return x[0] === '自锁校核'; })[0];
    var fields = {
      DOC_TITLE: opt.docTitle || (units > 1 ? units + ' 台电动推杆选型方案书' : '电动推杆选型方案书'),
      DOC_SUBTITLE_EN: 'ELECTRIC LINEAR ACTUATOR　SELECTION & QUOTATION',
      META_CUSTOMER: opt.faxTo || '—',
      META_CONTACT: opt.faxAttn || '—',
      META_PROJECT: (opt.planTitle || '').replace(/　+/g, ' ') || '—',
      DOC_NO: opt.docNo || '',
      DOC_DATE: opt.docDate || '',
      META_AUTHOR: opt.faxFrom || '力姆泰克销售部',
      META_SALES: opt.faxSales || '',
      META_EMAIL: opt.faxEmail || 'sales@lim-tec.com',
      REQ_MOTION: REQ_MOTION, REQ_LOAD: REQ_LOAD, REQ_SPEED: REQ_SPEED, REQ_MOUNT: REQ_MOUNT, REQ_ENV: REQ_ENV,
      /**/
      LAYOUT_CAPTION: '图：' + (layoutPickFor(cal, res).label || sMeta.t || '电动推杆') + '　外形尺寸与接口以确认图为准',
      LAYOUT_PICK: layoutPickFor(cal, res).img || '',
      SUM_MODEL: code,
      /**/
      SUM_LOAD: res.load_short
        ? ('额定 ' + fN(res.rated_N, 0) + ' N ＜ 要求 ' + fN(cal.load_N || 0, 0) + ' N（约 '
          + fN(res.rated_N / 9806.65, 2) + ' 吨；欠 ' + fN(res.load_under_pct, 1)
          + '%，≤' + (res.load_under_max || 10) + '% 仅作备选方案，须客户确认）')
        : ('额定 ' + fN(res.rated_N, 0) + ' N ≥ 要求 ' + fN(cal.load_N || 0, 0) + ' N（约 ' + fN(res.rated_N / 9806.65, 2) + ' 吨）'),
      SUM_STAB: stabStep ? stabStep[1] : '按样本口径校核',
      SUM_RATIO: isLam(res.fam)
        ? ('直流小型推杆（' + (res.duty || '按样本') + '）；内置丝杠结构，档位 ' + res.code)
        : ((res.fam === 'LBP' ? '滚珠丝杠（工作制 100%）' : '梯形丝杠（工作制 30%）')
          + '；减速比 ' + res.code + '；输入形式 ' + (res.install || 'P3') + '（' + nameOf(D().installs, res.install) + '）'),
      SUM_TORQUE: isLam(res.fam)
        ? ('直流永磁电机驱动，满载电流 ' + (m.iA != null ? fN(m.iA, 1) + ' A（24V）' : '按样本') + '；电压 ' + (m.volts ? (m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V' : '按样本')
          + (res.dc_motor ? '；功率 ' + fN(res.dc_motor.p_kw, 2) + ' kW、转速 ' + res.dc_motor.rpm_main + ' rpm、扭矩 ' + fN(res.dc_motor.t_nm, 1) + ' N·m（按计算功率配置）' : ''))
        : ('驱动电机 ' + (isServoDrive(cal) ? servoSpecSeg(cal, res, true)
            : (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') ? rodDcSeg233(res, cal) : motorSegFor(cal, moR))
          + '；驱动方式 ' + (nameOf(D().drives, cal.drive) || '三相交流')
          + envDocSeg(res, cal)),
      SUM_POWER_LINE: isLam(res.fam)
        ? ('内置直流电机一体结构；推力 ' + fN(cal.load_N || 0, 0) + ' N ≤ 额定 ' + fN(res.rated_N, 0) + ' N')
        : ((function () {
          /**/
          if (isServoDrive(cal)) {
            var smp = servoPickRow(cal, res);
            if (!smp) return '伺服功率按所选品牌配套选型；驱动方式 ' + (nameOf(D().drives, cal.drive) || '伺服');
            return 'P = ' + smp.power_kW + ' kW（伺服额定功率）'
              + '；驱动方式 ' + (nameOf(D().drives, cal.drive) || '伺服')
              + (dsc && dsc.p_req_kw != null ? '；所需功率 ' + fN(dsc.p_req_kw, 2) + ' kW @ ' + fN(dsc.n_motor_rpm, 0) + ' rpm' : '');
          }
          /*
*/
          if (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') {
            var dcP233 = res.dc_motor;
            return 'P = ' + (dcP233 ? fN(dcP233.p_kw, 2) + ' kW（'
              + (dcP233.via === 'two' ? '两台总功率 ×1.5 后取标准档'
                : (dcP233.src === 'ac' ? '同样本交流电机功率' : '按计算功率配置')) + '）' : '按计算功率配置')
              + '；驱动方式 ' + (nameOf(D().drives, cal.drive) || '直流电机');
          }
          return 'P = ' + (moR && moR.kw != null ? moR.kw : '—') + ' kW（'
            + (moReSel ? '两台联动按总功率另选，档位样本 ' + fN(moSlotKw, 2) + ' kW' : '样本配机档位') + '）'
            + '；驱动方式 ' + (nameOf(D().drives, cal.drive) || '三相交流');
        })()),
      SUM_SPEED: (isLam(res.fam)
        ? ('满载速度 ' + fN(m.v1, 1) + ' mm/s（空载 ' + fN(m.v0, 1) + '）')
        : ('样本速度 ' + fN(m.speed, 1) + ' mm/s'))
        + ' ≥ 要求 ' + fN(cal.speed_req, 1) + ' mm/s',
      SUM_DUTY_LINE: dutyStep ? dutyStep[1] : '工作制按样本',
      SUM_MOTOR_LINE: isLam(res.fam)
        ? ('内置直流永磁电机' + (m.volts ? '（' + (m.ac ? 'AC ' : 'DC ') + m.volts.join('/') + ' V）' : '') + '；工作制 ' + (res.duty || '按样本')
          + (res.dc_motor ? '；功率 ' + fN(res.dc_motor.p_kw, 2) + ' kW、转速 ' + res.dc_motor.rpm_main + ' rpm、扭矩 ' + fN(res.dc_motor.t_nm, 1) + ' N·m（按计算功率配置，电机不计价）' : ''))
        : ((function () {
          /**/
          var sm = (dsc && dsc.n_req_rpm != null) ? (rodServoBomOf(cal, res) || {}).m : null;
          if (sm) {
            return nameOf(D().drives, cal.drive) + '；' + sm.brand + ' ' + sm.code
              + '（' + sm.power_kW + ' kW / ' + (sm.rpm != null ? iN(sm.rpm) : '—') + ' rpm / '
              + (sm.torque_Nm != null ? fN(sm.torque_Nm, 2) + ' N·m' : '—') + '）'
              + (sm.need220 ? '，需 220V 供电（另备单相控制电源）' : '')
              + (sm.tq_under != null ? '，额定扭矩低于计算需求 ' + fN(sm.tq_under, 1) + '%（扭矩临界，须与厂家确认）' : '') + '；'
              + '所需电机运行转速 ' + fN(dsc.n_req_rpm, 0) + ' rpm，按伺服额定转速 ≥ ' + fN(dsc.n_req_rpm, 0) + ' rpm 选型';
          }
          if (cal.drive === 'dc24' || cal.drive === 'dc12' || cal.drive === 'dc48') {
            /**/
            return rodDcSeg233(res, cal) + '；' + (res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）');
          }
          return motorSegFor(cal, moR) + '；' + (res.self_lock ? '自锁，可不加制动器' : '不自锁，配制动器（电机内置）')
            + (moReSel ? '（两台联动按总功率另选，档位样本 ' + fN(moSlotKw, 2) + ' kW）' : '');
        })()),
      SUM_SPECIAL: (res.warnings && res.warnings.length) ? res.warnings.slice(0, 2).join('；') : '无（按常规工况）',
      SUM_EXTRA: (res.stability_Lk_mm != null ? '允许行程（稳定性）' + fN(res.stability_Lk_mm, 0) + ' mm；' : '')
        + (res.life_km != null ? '理论寿命 L10 ' + fN(res.life_km, 0) + ' km' : '梯形丝杠寿命无理论计算'),
      ITEMS: items,
      ITEM_PRICE_TOTAL: dPriceTotal,
      /*


*/
      QUOTE_NOTE: (function () {
        try {
          if (typeof window !== 'undefined' && window.LANG_I18N && typeof window.LANG_I18N.fxNote === 'function') {
            var n = window.LANG_I18N.fxNote();
            if (n) return String(n);
          }
        } catch (e) {}
        return '';
      })(),
      TERM_PRICE: commFields().TERM_PRICE, TERM_DELIVERY: commFields().TERM_DELIVERY,
      TERM_PAYMENT: commFields().TERM_PAYMENT, TERM_WARRANTY: commFields().TERM_WARRANTY,
      ABOUT: aboutLines().slice(0, 6),
      ABOUT_1: aboutLines()[0], ABOUT_2: aboutLines()[1], ABOUT_3: aboutLines()[2],
      ABOUT_4: aboutLines()[3], ABOUT_5: aboutLines()[4], ABOUT_6: aboutLines()[5],
      FEAT_1: featLines()[0], FEAT_2: featLines()[1], FEAT_3: featLines()[2], FEAT_4: featLines()[3], FEAT_5: featLines()[4],
      FEAT_6: featLines()[5], FEAT_7: featLines()[6], FEAT_8: featLines()[7], FEAT_9: featLines()[8], FEAT_10: featLines()[9],
      FEAT_KEEP: '5'
    };
    /**/
    (function p1AutoGap() {
      var toks = ['REQ_MOTION', 'REQ_LOAD', 'REQ_SPEED', 'REQ_MOUNT', 'REQ_ENV'];
      var lines = 0;
      toks.forEach(function (t) {
        var str = String(fields[t] || ''), w = 0;
        for (var i = 0; i < str.length; i++) w += (str.charCodeAt(i) > 255 ? 1 : 0.55);
        lines += Math.max(1, Math.ceil(w / 40));
      });
      var free = 3000 - (lines - 5) * 320;
      if (free < 0) free = 0;
      fields.GAP_TITLE_IMG = String(40 + Math.round(free * 0.10));
      fields.GAP_IMG_INFO = String(40 + Math.round(free * 0.15));
      fields.GAP_INFO_01 = String(130 + Math.round(free * 0.15));
      fields.P1_ROWH = String(230 + Math.floor(free * 0.60 / 5));
    })();

    return { template: 'CY', fields: fields, items: items, zipDate: opt.docDate };
  }

  /**/
  g.SJRodProduct = {
    id: 'rod',
    name: '电动推杆',
    desc: 'LAM 小型 · LAP 梯形丝杠 · LBP 滚珠丝杠',
    status: 'ready',
    dataKey: 'SJ_ROD_DATA',

    SCHEMA: SCHEMA,
    defaultInput: defaultInput,
    loadUnitOptions: loadUnitOptions,
    /**/
    defaultLoadUnit: function (inp) { return defLoadUnit(inp && inp.series); },
    /**/
    UNIT_F: { 't': 9806.65, 'kN': 1000, 'kgf': 9.80665, 'kg': 9.80665, 'N': 1 },
    toCalc: toCalc,
    autoSelect: autoSelect,
    sanitizeInput: sanitizeInput,
    afterRun: afterRun,
    suggestCode: suggestCode,
    mountSize: mountSize,
    isSpecCodeSub: isSpecCodeSub,
    seriesInfoHTML: seriesInfoHTML,
    sidePanelHTML: sidePanelHTML,
    heroSub: heroSub,
    modelDetailHTML: modelDetailHTML,
    motorHTML: motorHTML,
    stabilityHTML: stabilityHTML,
    quoteTableHTML: quoteTableHTML,
    rodPriceOf: rodPriceOf,
    rodMotorPriceOf: rodMotorPriceOf,
    specNotes: specNotes,
    layoutImageFor: layoutImageFor,
    layoutPickFor: layoutPickFor,
    composeSpec: composeSpec
  };
})(typeof window !== 'undefined' ? window : globalThis);
