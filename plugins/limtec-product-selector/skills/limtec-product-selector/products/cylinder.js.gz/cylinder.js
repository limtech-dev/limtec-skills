/*




*/
(function (g) {
  'use strict';

  var D = function () { return g.SJ_CYL_DATA || {}; };
  var ENG = function () { return g.SJ_CylEngine; };

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  /*


*/
  function fN(x, n) {
    var c = g.SJCore;
    if (c && typeof c.fN === 'function') return c.fN(x, n);
    return (x == null || isNaN(Number(x))) ? 'nan' : Number(x).toFixed(n || 0);
  }

  /*

*/
  function cylIsISMG2(code) { return String(code || '').indexOf('ISMG2') === 0; }
  /*


*/
  function cylOverPowerPw(m, res) {
    var models = (D().models || {});
    var maxPw = (models[(res && res.model) || ''] || {}).max_power_kw;
    return (maxPw > 0 && m && m.power_kW != null && Number(m.power_kW) > maxPw + 1e-9) ? maxPw : null;
  }
  function cylCodeShown(m) {
    var c = String((m && m.code) || '');
    return cylIsISMG2(c) ? c : c.replace('-A331FA', '-A334FA');
  }

  /*

*/
  var SCHEMA = [
    /**/
    { key: 'series', label: '型号系列', type: 'cards', def: 'DMB', group: '选择1 · 型号系列', required: true,
      optionsFn: function () {
        return (D().series || []).map(function (s) { return { v: s.v, t: s.t, img: s.img }; });
      },
      hint: '选择系列后，下方显示该系列图片与技术参数说明；右侧快捷通道可按型号直查参数与三维数模' },

    /*



*/
    { key: 'input_form', label: '输入形式', type: 'imgpick', def: 'P10/P20', group: '选择2 · 输入形式', required: true,
      showWhen: { seriesNot: 'GTR' },
      /*
*/
      optionsFn: function (inp) {
        var forms = (D().input_forms || [{ v: 'SC', t: 'SC 直线安装（电机直连，i=1）' }]).slice();
        if (inp && (inp.series === 'DMB' || inp.series === 'EMB')) {
          var dme = { 'SC': 'cyl-form-sc-dme.jpg', 'P10/P20': 'cyl-form-belt-dme.jpg' };
          forms = forms.map(function (f) { var g = {}; for (var k in f) g[k] = f[k]; if (dme[f.v]) g.img = dme[f.v]; return g; });
        }
        /**/
        if (inp && (inp.series === 'DMB' || inp.series === 'FMR')) {
          forms = forms.map(function (f) {
            if (f.v !== 'P10/P20') return f;
            var g = {}; for (var k in f) g[k] = f[k];
            g.t = 'P10/P15/P20 同步带平行安装（速比 i=1/1.5/2 引擎自动定）';
            return g;
          });
        }
        return forms;
      },
      hint: '默认同步带平行安装：同步带速比 i=1/2 由引擎按螺旋升降机规则自动定——与行星标准比合成总速比，只取输出转速落在「所需~所需×1.2」窗口内的组合、窗口内取最大速比（电机运行点最贴近额定），需要时自动配行星减速机（效率 3~10 档 0.90、≥15 档 0.80）并在方案中注明；DMB/FMR 同步带含 P15（i=1.5）档，速比候选为 1/1.5/2；SC 直线安装为备选' },

    /**/
    { key: 'units', label: '电气同步数量', type: 'select', def: '1', required: true, group: '选择3 · 基本参数',
      options: [{ v: '1', t: '单台' }, { v: '2', t: '两台' }, { v: '3', t: '三台' }, { v: '4', t: '四台' }] },
    { key: 'sync', label: '同步方式', type: 'select', def: '电气', group: '选择3 · 基本参数',
      showWhen: { unitsNot: '1' },
      options: [{ v: '电气', t: '电气同步（每缸一台电机，扭矩链 ×1.5）' }, { v: '机械', t: '机械同步（共轴/换向器，扭矩 ×台数）' }] },
    { key: 'load', label: '总负载推力', type: 'number', unit: '', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'load_unit',
      hint: '拉力工况可不填（按 0 计算）；总负载推力 / 总负载拉力至少填写一项' },
    { key: 'load_pull', label: '总负载拉力', type: 'number', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'load_pull_unit',
      unit: function (inp) { return unitSuffix((inp && inp.load_pull_unit) || 't'); },
      hint: '拉力工况不校核稳定性；单位独立可选（默认随界面语言：中文吨 / 外语 kN）' },
    { key: 'static_load', label: '静载', type: 'number', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'static_load_unit',
      unit: function (inp) { return unitSuffix((inp && inp.static_load_unit) || 't'); } },
    { key: 'speed_mm_s', label: '最高速度', type: 'number', unit: 'mm/s', step: 'any', def: null, required: true, group: '选择3 · 基本参数' },
    { key: 'stroke_mm', label: '行程', type: 'number', unit: 'mm', step: 'any', def: null, required: true, group: '选择3 · 基本参数' },
    { key: 'avg_load', label: '往返行程平均推拉力', type: 'number', step: 'any', def: null, group: '选择3 · 基本参数',
      withUnit: true, unitKey: 'avg_load_unit',
      unit: function (inp) { return unitSuffix((inp && inp.avg_load_unit) || 't'); },
      hint: '单缸载荷：寿命公式 (C/P)³ 的 P 值（加权平均推力）' },
    { key: 'guide', label: '是否有导向', type: 'radio', def: '无', group: '选择3 · 基本参数',
      options: [{ v: '有', t: '有（客户自备导轨/导向柱）' }, { v: '无', t: '无（受压工况必查稳定性）' }] },
    { key: 'precision_mm', label: '丝杠选择', type: 'select', def: '0.05', group: '选择3 · 基本参数',
      optionsFn: function (inp) {
        /*

*/
        if (inp && (inp.series === 'FMR' || inp.series === 'GTR')) return [{ v: '0.02', t: '0.02 mm（磨制行星丝杠）' }];
        if (inp && inp.series === 'EMB') return [{ v: '0.05', t: '轧制滚珠丝杠（重复精度 0.05mm）' }];
        return (D().precisions || [{ v: '0.05', t: '轧制滚珠丝杠（重复精度 0.05mm）' }]);
      },
      /*


*/ },
    { key: 'cycles_per_day', label: '每日工作次数', type: 'number', unit: '次/天', step: 1,
      /*
*/
      def: function (inp) { return (inp && String(inp.precision_mm) === '梯形') ? 50 : 48; },
      group: '选择3 · 基本参数'
      /*


*/ },
    { key: 'days_per_year', label: '每年工作天数', type: 'number', unit: '日', step: 1, def: 300, group: '选择3 · 基本参数' },
    { key: 'life_years', label: '寿命要求', type: 'number', unit: '年', step: 1, def: 5, group: '选择3 · 基本参数',
      hint: '理论寿命L10 = (C/P)³×导程' },
    { key: 'drive', label: '驱动选择', type: 'select', def: 'servo380', group: '选择3 · 基本参数',
      showWhen: { seriesNot: 'GTR' },
      /*
*/
      optionsFn: function (inp) {
        var elecCyl = !!(inp && inp.sync === '电气' && (Number(inp.units) || 1) > 1);
        return [{ v: 'servo380', t: '伺服电机 380VAC（默认）' }, { v: 'servo220', t: '伺服电机 220VAC' },
                { v: 'ac3', t: '三相交流电机 380VAC' }].map(function (o) {
          if (elecCyl && o.v === 'ac3') return { v: o.v, t: o.t, dis: true };
          return o;
        });
      } },
    /*
*/
    { key: 'gtr_drive', label: '驱动器选择', type: 'select', def: 'Siemens', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['GTR'] },
      optionsFn: function () { return GTR_DRIVES.slice(); },
      hint: '样本 P77：力姆泰克伺服缸可与任意品牌伺服驱动器匹配——订单一定要注明驱动器型号及相关参数，'
        + '力姆泰克按驱动器厂家提供相应的反馈方式与接口。默认西门子 S120，'
        + '反馈方式默认 SM2；选 Elmo（直流）后可再选 EL1／EL2／EL3' },
    { key: 'gtr_fb', label: '反馈方式（GGG）', type: 'select', def: 'SM2', group: '选择3 · 基本参数',
      showWhen: { seriesIn: ['GTR'] },
      optionsFn: function (inp) { return gtrFbOptions(inp && inp.gtr_drive); },
      hint: '样本 77 页 GGG 段：Elmo—EL1 标准旋转变压器／EL2 标准增量型编码器（2048 线脉冲通讯，5VDC）／'
        + 'EL3 EnDat Heidenhain EQN1125 多圈绝对值编码器；Kollmorgen KM4/5/6、LENZE LZ1/5/6、Siemens SM2/3/4、'
        + 'SEW SW1/2/3、ABB AB1/2/3（英威腾／Stober 样本未列专用编码，按下单驱动器型号确定）。选定值直接进型号标注 GGG 段' },
    { key: 'servo_brand', label: '伺服电机品牌（可多选）', type: 'checks', def: [], group: '选择3 · 基本参数',
      showWhen: { drive: ['servo220', 'servo380'], seriesNot: 'GTR' },
      optionsFn: function () {
        /*
*/
        var ready = [
          { v: '汇川', t: '汇川（SV630 / SV660 + MS1 系列，1500 / 3000rpm）' },
          { v: 'V90', t: '西门子 V90（1FL6）' },
          { v: 'S200', t: '西门子 S200（1FL2）' },
          { v: 'S120', t: '西门子 S120（1FK7 / 1FT7，大功率段）' },
          { v: '台达', t: '台达（ASDA-A3 + ECMA 系列，220V 为主）' },
          { v: '雷赛', t: '雷赛（L7 / ACM2 系列，380V 1500rpm 为主）' },
          { v: '惠斯通', t: '惠斯通防爆（ST-EX 系列，隔爆 Ex d IIB T4 Gb，3000rpm 为主 + 折算档）' }
        ];
        /**/
        return ready;
      },
      hint: '不勾选 = 已接入常规品牌全部参与（默认，推荐）；勾选后电机表只在该品牌内选型。默认按螺旋升降机规则出西门子 V90 + S200 各一款；'
        + '功率超过 V90/S200 系列覆盖时自动接棒西门子 S120（1FK7/1FT7）。惠斯通防爆为特殊工况电机，须显式勾选才进入选型（防爆工况才选）。' },
    /*
*/
    { key: 'encoder', label: '编码器选择', type: 'select', def: '增量型', group: '选择3 · 基本参数',
      showWhen: { seriesNot: 'GTR' },
      options: [{ v: '增量型', t: '增量型编码器（默认）' },
                { v: '多圈绝对', t: '多圈绝对编码器' }, { v: '旋变', t: '旋转变压器' }] },
    { key: 'ambient_temp', label: '工作温度要求', type: 'select', def: '20', group: '选择3 · 基本参数',
      optionsFn: function () { return (D().temps || [{ v: '20', t: '+20℃' }]); } },
    { key: 'ip', label: '防护等级', type: 'select', def: 'IP65', group: '选择3 · 基本参数',
      options: [{ v: 'IP55', t: 'IP55' }, { v: 'IP65', t: 'IP65' }] },
    { key: 'special', label: '特殊要求', type: 'checks', def: [], group: '选择3 · 基本参数', textable: true,
      options: [{ v: '防腐要求', t: '防腐要求', ph: '如 316 不锈钢、盐雾等级' }, { v: '防爆要求', t: '防爆要求', ph: '如 Ex d IIB T4' },
                { v: '真空要求', t: '真空要求', ph: '如 10^-5 Pa、真空润滑脂' }, { v: '丝杠导程要求', t: '丝杠导程要求', ph: '指定导程，如 20mm' },
                { v: '其他特殊要求', t: '其他特殊要求', ph: '具体描述' }] },

    /**/
    /*
*/
    { key: 'install', label: '安装方式', type: 'imgpick', def: 'FF', group: '型号与附件', required: true,
      optionsFn: function (inp) {
        if (inp && inp.series === 'GTR') return GTR_INSTALLS.slice();
        return (D().installs || [{ v: 'FF', t: '前段法兰 FF' }]);
      },
      hint: 'DMB/EMB/FMR：安装方式图待补充（当前文字卡）；前后铰接按稳定性曲线校核，其他安装方式请与力姆泰克工程师确认。'
        + 'GTR（样本 77 页 E=安装形式）：C 尾部铰接 / F 前端法兰 / R 尾部法兰 / D 双面螺纹孔 / T 侧面耳轴 / E 外伸出螺纹轴 / K 公制双侧面螺纹孔 / Q 公制侧面耳轴 / M 公制伸出螺纹轴 / G 公制尾部铰接' },
    { key: 'joint', label: '接头形式', type: 'imgpick', def: 'FM', group: '型号与附件',
      optionsFn: function () { return (D().joints || [{ v: 'FM', t: '外螺纹 FM' }]); } },
    { key: 'accessories', label: '附件选择', type: 'checks', def: ['AR'], group: '型号与附件',
      optionsFn: function (inp) { return accOptions(inp && inp.series, inp && inp.ambient_temp); }
      /*







*/ }
  ];

  /*
*/
  var GTR_INSTALLS = [
    { v: 'C', t: 'C 尾部铰接' },
    { v: 'F', t: 'F 前端法兰' },
    { v: 'R', t: 'R 尾部法兰' },
    { v: 'D', t: 'D 双面螺纹孔安装' },
    { v: 'T', t: 'T 侧面耳轴安装' },
    { v: 'E', t: 'E 外伸出螺纹轴安装' },
    { v: 'K', t: 'K 公制双侧面螺纹孔安装' },
    { v: 'Q', t: 'Q 公制侧面耳轴安装' },
    { v: 'M', t: 'M 公制伸出螺纹轴安装' },
    { v: 'G', t: 'G 公制尾部铰接' }
  ];

  /*







*/
  var GTR_DRIVES = [
    { v: 'Elmo', t: 'Elmo（直流）' },
    { v: 'Kollmorgen', t: 'Kollmorgen 科尔摩根' },
    { v: 'LENZE', t: 'LENZE 伦茨' },
    { v: 'Siemens', t: 'Siemens 西门子（S120，默认）' },
    { v: 'SEW-EURODRIVE', t: 'SEW-EURODRIVE' },
    { v: 'ABB', t: 'ABB' },
    { v: '英威腾', t: '英威腾 INVT' },
    { v: 'Stober', t: 'Stober Drives' }
  ];
  var GTR_FB = {
    'Elmo': [
      { v: 'EL1', t: 'EL1 标准旋转变压器（型号 15）' },
      { v: 'EL2', t: 'EL2 标准增量型编码器（2048 线脉冲通讯，5VDC）' },
      { v: 'EL3', t: 'EL3 EnDat Heidenhain EQN1125 多圈绝对值编码器' }
    ],
    'Kollmorgen': [
      { v: 'KM5', t: 'KM5 标准旋转变压器（AKM 电机，M23 欧标接头）' },
      { v: 'KM6', t: 'KM6 标准增量编码器（AKM 电机，M23 欧标接头）' },
      { v: 'KM4', t: 'KM4 EnDat Heidenhain EQN1125 多圈绝对值编码器（AKM 电机，M23）' }
    ],
    'LENZE': [
      { v: 'LZ5', t: 'LZ5 标准旋转变压器（MCS 电机，M23 欧标接头）' },
      { v: 'LZ6', t: 'LZ6 标准增量编码器（MCS 电机，M23 欧标接头）' },
      { v: 'LZ1', t: 'LZ1 Hiperface Stegmann SRM050 多圈绝对值编码器（MCS 电机，M23）' }
    ],
    'Siemens': [
      { v: 'SM2', t: 'SM2 标准旋转变压器（1FK7 电机，M23 欧标接头）' },
      { v: 'SM3', t: 'SM3 EnDat Heidenhain EQN1325 多圈绝对值编码器（1FK7，M23）' },
      { v: 'SM4', t: 'SM4 EnDat Heidenhain EQN1125 多圈绝对值编码器（1FK7，M23）' }
    ],
    'SEW-EURODRIVE': [
      { v: 'SW1', t: 'SW1 标准旋转变压器（CM 电机，M23 欧标接头）' },
      { v: 'SW2', t: 'SW2 标准增量编码器' },
      { v: 'SW3', t: 'SW3 Hiperface Stegmann SRM050 多圈绝对值编码器（CM 电机，M23）' }
    ],
    'ABB': [
      { v: 'AB1', t: 'AB1 旋转变压器' },
      { v: 'AB2', t: 'AB2 标准增量型编码器' },
      { v: 'AB3', t: 'AB3 多圈绝对值编码器' }
    ],
    '英威腾': [
      { v: '—', t: '按驱动器型号确定（样本未列专用编码，下单注明驱动器型号）' }
    ],
    'Stober': [
      { v: '—', t: '按驱动器型号确定（样本未列专用编码，下单注明驱动器型号）' }
    ]
  };

  function gtrFbOptions(drive) {
    return GTR_FB[drive] || GTR_FB['Elmo'];
  }
  function gtrFbLabel(cal) {
    if (!cal) return '';
    var opt = gtrFbOptions(cal.gtr_drive).filter(function (o) { return o.v === cal.gtr_fb; })[0];
    return opt ? opt.t : (cal.gtr_fb || '');
  }
  function gtrDriveLabel(cal) {
    var d = (cal && cal.gtr_drive) || 'Siemens';
    var o = GTR_DRIVES.filter(function (x) { return x.v === d; })[0];
    return o ? o.t : d;
  }
  /*
*/
  function accOptions(series, temp) {
    var s = series || 'DMB';
    var hot80 = isHot80(temp);
    return (D().accessories || [{ v: 'AR', t: '防转 AR' }]).filter(function (a) {
      if (hot80 && a.v === 'FCM') return false;
      return !a.series || a.series.indexOf(s) >= 0;
    }).map(function (a) { return { v: a.v, t: a.t }; });
  }
  function accAllowedSet(series, temp) {
    var set = {};
    accOptions(series, temp).forEach(function (o) { set[o.v] = 1; });
    return set;
  }
  /**/
  function isHot80(temp) {
    var t = Number(temp);
    return isFinite(t) && t >= 80;
  }

  /*


*/
  function limitStdNote(res) {
    if (!res || !res.std_limit || res.std_cancelled) return '';
    if (res.std_limit_hot_off) return '（标配，+80℃ 不适用）';
    var picked = (res.accessories || []).filter(function (a) { return a === 'FCP' || a === 'FCM'; })[0] || null;
    if (!picked) return '，限位开关 ' + res.std_limit + '（标配）';
    if (picked === res.std_limit) return '（标配）';
    if (res.std_limit_alt && picked === res.std_limit_alt) return '（标配）';
    return '（改选，样本标配 ' + res.std_limit + (res.std_limit_alt ? '/' + res.std_limit_alt : '') + '）';
  }

  /**/
  function accText(res) {
    var list = (res.accessories || []).slice();
    var note = limitStdNote(res);
    var picked = list.filter(function (a) { return a === 'FCP' || a === 'FCM'; })[0] || null;
    if (!picked && res.std_limit && !res.std_cancelled) list.push(res.std_limit + '（标配' + (res.std_limit_hot_off ? '，+80℃ 不适用' : '') + '）');
    else if (picked) list = list.map(function (a) { return a === picked ? a + note : a; });
    /*
*/
    if (isExMotor(res)) {
      list = list.map(function (t) {
        var mm = String(t).match(/^(FCM|FCP)(.*)$/);
        return mm ? ('防爆限位开关 ' + mm[1] + mm[2]) : t;
      });
    }
    return list.join(' / ');
  }

  /*
*/
  function isExMotor(res) {
    var m = (res && res.motor_recommend && res.motor_recommend[0]) || null;
    if (!m) return false;
    var s = String((m.brandFull || m.brand || '') + ' ' + (m.code || '') + ' ' + (m.model || ''));
    return /惠斯通/.test(s) || /(^|[^A-Za-z])ST-EX/i.test(s) || /-[A-Z0-9]*EX([-(]|$)/i.test(s);
  }

  /*
*/
  var limitAutoFilled = false;
  /*



*/
  var lastSeries = null;
  /**/
  var lastTrap = null;
  function sanitizeInput(inp) {
    if (!inp) return;
    /*
*/
    if (inp.sync === '电气' && (Number(inp.units) || 1) > 1 && inp.series !== 'GTR'
        && String(inp.drive || '').indexOf('servo') !== 0) {
      inp.drive = 'servo380';
    }
    if ((inp.series === 'FMR' || inp.series === 'GTR') && inp.precision_mm !== '0.02') inp.precision_mm = '0.02';
    if (inp.series === 'EMB' && inp.precision_mm !== '0.05') inp.precision_mm = '0.05';
    /**/
    if (inp.series === 'GTR') {
      var fbo = gtrFbOptions(inp.gtr_drive);
      var fbOk = fbo.some(function (o) { return o.v === inp.gtr_fb; });
      if (!fbOk) inp.gtr_fb = fbo[0].v;
    }
    var switching = (inp.series !== lastSeries);
    if (!Array.isArray(inp.accessories)) inp.accessories = [];
    /*
*/
    var allowed = accAllowedSet(inp.series, inp.ambient_temp);
    inp.accessories = inp.accessories.filter(function (a) { return allowed[a]; });
    /*

*/
    var gtrVs = GTR_INSTALLS.map(function (x) { return x.v; });
    if (inp.series === 'GTR' && gtrVs.indexOf(inp.install) < 0) inp.install = 'F';
    if (inp.series !== 'GTR' && gtrVs.indexOf(inp.install) >= 0) inp.install = 'FF';
    if (inp.series !== 'GTR' && !(D().installs || []).some(function (x) { return x.v === inp.install; })) inp.install = 'FF';
    /**/
    if (!(D().joints || []).some(function (x) { return x.v === inp.joint; })) inp.joint = 'FM';
    if (switching) {
      /**/
      if (inp.series !== 'GTR' && inp.accessories.indexOf('AR') < 0) inp.accessories.unshift('AR');
      if (inp.series === 'GTR') inp.accessories = inp.accessories.filter(function (a) { return a !== 'AR'; });
      lastSeries = inp.series;
    }
    /**/
    if (inp.series === 'GTR' && inp.accessories.indexOf('L2') >= 0 && inp.accessories.indexOf('AR') < 0) {
      inp.accessories.push('AR');
    }
    /*
*/
    var isTrap = (inp.series === 'DMB' && String(inp.precision_mm) === '梯形');
    if (isTrap !== lastTrap) {
      var cycNow = Number(inp.cycles_per_day);
      if (isTrap && (!cycNow || cycNow === 48)) inp.cycles_per_day = 50;
      else if (!isTrap && cycNow === 50) inp.cycles_per_day = 48;
      lastTrap = isTrap;
    }
  }

  function afterRun(inp, out) {
    var r = out && out.chosenResult;
    if (!r || !r.std_limit) return false;
    var acc = Array.isArray(inp.accessories) ? inp.accessories : (inp.accessories = []);
    /*
*/
    if (r.std_limit_hot_off) {
      var iHot = acc.indexOf('FCM');
      if (iHot >= 0) { acc.splice(iHot, 1); limitAutoFilled = false; return true; }
      return false;
    }
    var hasStd = acc.indexOf(r.std_limit) >= 0;
    var other = r.std_limit === 'FCP' ? 'FCM' : 'FCP';
    if (limitAutoFilled && !hasStd && !r.std_cancelled) {
      /**/
      r.std_cancelled = true;
      limitAutoFilled = false;
      return false;
    }
    if (hasStd) { limitAutoFilled = true; return false; }
    if (acc.indexOf(other) >= 0) return false;     //
    acc.push(r.std_limit);
    limitAutoFilled = true;
    return true;
  }

  /*
*/
  var TAU = { t: 9.81, kN: 1, kgf: 0.00981, N: 0.001 };   // → kN

  function loadUnitOptions() {
    return [{ v: 't', t: '吨（t）' }, { v: 'kN', t: '千牛（kN）' }, { v: 'kgf', t: '公斤力（kgf）' }, { v: 'N', t: '牛（N）' }];
  }

  function langIsZh() { try { var L = g.LANG_I18N && g.LANG_I18N.lang; return !L || L === 'zh'; } catch (e) { return true; } }
  function defLoadUnit() { return langIsZh() ? 't' : 'kN'; }
  function unitSuffix(u) { return u === 't' ? (langIsZh() ? 't' : 'tons') : (u || 't'); }

  function defaultInput() {
    var o = { load_unit: defLoadUnit(), load_pull_unit: defLoadUnit(), static_load_unit: defLoadUnit(), avg_load_unit: defLoadUnit() };
    /*
*/
    SCHEMA.forEach(function (f) {
      var dv = (typeof f.def === 'function') ? f.def(o) : f.def;
      o[f.key] = (dv === undefined || dv === null) ? null
        : (typeof dv === 'object' ? JSON.parse(JSON.stringify(dv)) : dv);
    });
    o.load_unit = defLoadUnit();
    return o;
  }

  function toCalc(input) { return ENG().toCalc(input, D()); }
  function autoSelect(inp, data) { return ENG().autoSelect(inp, data || D()); }
  /*

*/
  function pickMotorOption(cal, data, cand, opts) {
    if (!opts || !opts.rpm) return null;
    var cal2 = Object.assign({}, cal, {
      motor_rpm_forced: opts.rpm,
      motor_belt_forced: opts.belt || 0,
      motor_ip_forced: opts.ip || 0
    });
    var lib = (g.SJ_DATA && g.SJ_DATA.motor_library) || (data && data.motor_library) || [];
    var ev = ENG().evalCandidate(cand, cal2, lib);
    /**/
    if (ev && ev.result && opts.code) {
      var mr = ev.result.motor_recommend || [];
      for (var pi = 0; pi < mr.length; pi++) {
        if (mr[pi].code === opts.code && pi > 0) { mr.unshift(mr.splice(pi, 1)[0]); break; }
      }
    }
    return (ev && ev.result) ? ev : { fatal: (ev && ev.fatal) || '点选电机重算失败' };
  }

  /**/
  function jointLabel(v) {
    var j = (D().joints || []).filter(function (x) { return x.v === v; })[0];
    return j ? v : (v || '');
  }
  /*







*/

  /**/
  function planetSeg(ip) {
    if (!ip) return '';
    return ip < 10 ? 'G0' + ip : 'G' + ip;
  }

  /*


*/
  function beltFormOf(formV) { return /P10|P20|P15/.test(String(formV || '')); }
  function formSegOf(res) {
    var f = String((res && res.form_v) || 'SC');
    var gseg = (res && res.planetary) ? planetSeg(res.planetary.ratio) : '';
    if (beltFormOf(f)) return (Number(res.ratio) === 2 ? 'P20' : (Number(res.ratio) === 1.5 ? 'P15' : 'P10')) + (gseg ? '-' + gseg : '');
    return gseg || f || 'SC';
  }
  function formDetailOf(res) {
    var det = [];
    if (beltFormOf(res && res.form_v) && Number(res && res.ratio) === 2) det.push('同步带 i=2:1');
    if (beltFormOf(res && res.form_v) && Number(res && res.ratio) === 1.5) det.push('同步带 i=1.5:1');
    if (res && res.planetary) det.push('行星减速机 i=' + res.planetary.ratio + ':1（效率 ' + res.planetary.eta + '）');
    if (!det.length) det.push(Number(res && res.ratio) > 1 ? 'i=' + res.ratio : '直连');
    return det.join(' × ');
  }

  function suggestCode(cal, res) {
    if (!res) return '';
    var stroke = (cal && cal.stroke != null) ? Math.round(cal.stroke) : '';
    var accs = (res.accessories || []).slice();
    /**/
    if (res.screw_sel === '磨制' && accs.indexOf('GB') < 0) accs.push('GB');

    if (res.integrated || (cal && cal.series === 'GTR')) {
      /**/
      /**/
      var mm = /^GTR\s*(\d+)\s*-?\s*(\d{4})?/i.exec(String(res.model || ''));
      var base = mm ? mm[1] : String(res.model || '').replace(/^GTR/i, '');
      var bbcc = (mm && mm[2]) ? mm[2] : '';
      if (!bbcc) bbcc = String(res.variant || '').replace(/\D/g, '').slice(0, 4);
      var d = 'M';                                       //
      /*
*/
      var eMap = { FF: 'F', RF: 'R', RC: 'C', ST: 'T', SH: 'D', SF: 'K' };
      var e = eMap[res.install] || res.install || 'F';
      var jMap = { BA: 'BA', FM: 'FM', TS: 'TS', FO: 'FO', ROE: 'FO', FL: 'F', TC: 'TS' };
      var fr = jMap[res.joint] || 'FM';
      /*

*/
      var fb = (cal && cal.gtr_fb) || '—';
      /*

*/
      var stator = res.winding === 1 ? '158' : (res.winding === 3 ? '358' : '258');
      /*
*/
      var spd = gtrSpeedCode(res.model);
      /*
*/
      var xx = (res.accessories || []).map(function (a) {
        return ({ AR: 'AR', L2: 'L2', RB: 'RB', B: 'PB', PF: 'PF' })[a] || '';
      }).filter(function (x) { return !!x; }).join('');
      return ['GTR' + base, bbcc, d, e, fr, fb, stator, spd, xx].filter(function (x, i) { return x !== '' || i === 0; }).join('-');
    }

    /**/
    /*



*/
    var modelHead = res.model;
    if (res.screw_sel === '梯形' && /^DMB/i.test(String(res.model || ''))) {
      modelHead = String(res.model).replace(/^DMB/i, 'DMA');
    }
    var segs = [modelHead, res.lead_mm, stroke, res.install || 'FF', res.joint || 'FO',
      formSegOf(res)];
    if (accs.length) segs.push(accs.join('/'));
    var m0 = (res.motor_recommend || [])[0];
    if (m0) segs.push(m0.brandFull + ' ' + cylCodeShown(m0));   /**/
    else if (res.motor_sync) segs.push(res.motor_sync + 'rpm伺服电机');
    return segs.filter(function (x, i) { return x !== '' || i === 0; }).join('-');
  }

  /*
*/
  function gtrSpeedCode(modelOrRpm) {
    var n = Number(modelOrRpm);
    if (n > 0) {                                        //
      if (n <= 2500) return '24';
      if (n <= 3500) return '30';
      return '50';
    }
    var mm = /^GTR\s*(\d+)/i.exec(String(modelOrRpm || ''));
    var base = mm ? Number(mm[1]) : 0;
    if (base === 20) return '50';
    if (base === 50 || base === 60) return '24';
    return '30';                                        //
  }

  function seriesMeta(v) {
    return (D().series || []).filter(function (s) { return s.v === v; })[0] || {};
  }
  function installLabel(v) {
    /**/
    var gi = GTR_INSTALLS.filter(function (x) { return x.v === v; })[0];
    if (gi) return gi.t;
    var i = (D().installs || []).filter(function (x) { return x.v === v; })[0];
    return i ? i.t : (v || '');
  }

  /**/
  function seriesInfoHTML(input) {
    var s = seriesMeta(input && input.series);
    if (!s.v) return '';
    var html = '<div class="imgbox side-img"><img class="limg" src="' + catSrc(s.img) + '" alt="">'
      + '<div class="imgcap">' + esc(s.t) + '</div></div>';
    html += '<div class="side-specs">' + (s.specs || []).map(function (x) { return '<div>' + esc(x) + '</div>'; }).join('') + '</div>';
    return html;
  }

  function catSrc(file) {
    var bin = g.SJ_CATALOG_BIN;
    if (bin && bin[file]) {
      return 'data:image/' + (/\.jpe?g$/i.test(file) ? 'jpeg' : 'png') + ';base64,' + bin[file];
    }
    return './assets/catalog/' + encodeURIComponent(file);
  }

  /*

*/
  function sidePanelHTML() {
    var CT = g.SJCatalog || {};
    var fallbackSamples = [
      { t: '力姆泰克螺旋升降机电动推杆综合样本2026', file: '力姆泰克螺旋升降机电动推杆综合样本2026.pdf' },
      { t: '力姆泰克伺服电缸中文2026', file: '力姆泰克伺服电缸中文2026.pdf' }
    ];
    /**/
    var samples = CT.samplesFor ? CT.samplesFor((g.LANG_I18N && g.LANG_I18N.lang) || 'zh')
      : ((CT.SAMPLES && CT.SAMPLES.length) ? CT.SAMPLES : fallbackSamples);
    var html = '<div class="side-quick"><h4>快捷通道 · 按型号直查</h4>'
      + '<input id="fld_quick_model" type="text" placeholder="输入详细型号，如 DMB80 / FMR60 / DMB50-10">'
      + '<div class="qops">'
      + '<button type="button" class="btn ghost" id="btnQuick">详细参数</button>'
      + '<button type="button" class="btn ghost" id="btnCad">三维数模下载</button>'
      + '</div>'
      + '<div id="quickInfo" class="quick-done" style="display:none"></div>'
      + '<div class="hint" style="margin-top:8px">详细参数：列出该型号逐导程技术参数（额定推力/最大速度/动载/稳定性曲线），'
      + '完整型号串（如 DMB80-20-300-FF-TS-G16-FCP）会逐段解读；三维数模：DMB/EMB/GTR/FMR 全系列 STEP。</div>'
      + '<div class="side-samples"><h5>样本下载</h5>'
      + samples.map(function (sm) {
          /**/
          var href;
          if (g.SJ_CATALOG_BIN) {
            var cdn = (CT.SAMPLES_CDN || '');
            href = cdn ? cdn + encodeURIComponent(sm.file) : (CT.SAMPLES_WEB || 'https://cn.lim-tec.com/');
          } else {
            href = './assets/samples/' + encodeURIComponent(sm.file);
          }
          var dl = g.SJ_CATALOG_BIN ? '' : ' download="' + esc(sm.file) + '"';
          return '<a class="dl" href="' + href + '"' + dl + ' target="_blank" rel="noopener">' + esc(sm.t) + '</a>';
        }).join('')
      + '</div></div>';
    return html;
  }

  /**/
  function heroSub(cal, res, cand) {
    var sub = [];
    sub.push((res.variant || '') + ' · ' + (seriesMeta(res.family).t || res.family));
    if (res.integrated) {
      /**/
      sub.push('一体化行星丝杠（电机内置，无输入形式）'
        + (cal && cal.gtr_drive ? '，配 ' + gtrDriveLabel(cal) : '')
        + (cal && cal.gtr_fb ? '，反馈 ' + cal.gtr_fb : ''));
    } else {
      /**/
      sub.push('输入形式 ' + formSegOf(res) + '（' + formDetailOf(res) + '）');
    }
    return sub;
  }

  function modelDetailHTML(cand, res, data) {
    var def = (data && data.models && (data.models[res.model] || data.models[String(res.model).split('-')[0]])) || {};
    var kv = [];
    kv.push(['额定推力', res.rated_kN + ' kN（约 ' + (Math.round(res.rated_kN / 9.81 * 100) / 100) + ' 吨）']);
    kv.push(['导程', res.lead_mm + ' mm']);
    /*
*/
    /**/
    if (cand.integrated && cand.max_stroke_mm != null) kv.push(['行程', cand.max_stroke_mm + ' mm（样本行程）']);
    else kv.push(['丝杠', res.screw_sel === '梯形' ? '梯形丝杠（自锁）' : (def.screw_type || '') + '丝杠']);
    /*
*/
    kv.push(['最大速度', cand.integrated
      ? (cand.max_speed_mm_s != null ? cand.max_speed_mm_s + ' mm/s（样本最高速度）' : '—')
      : def.variants ? '按导程档（本档 ' + res.max_speed_of_variant + ' mm/s）' : (def.max_speed_mm_s ? def.max_speed_mm_s + ' mm/s' : '—')]);
    kv.push(['安装方式', installLabel(res.install)]);
    if (res.stability_Lk_mm != null) kv.push(['允许行程（稳定性）', res.stability_Lk_mm + ' mm']);
    if (res.life_km != null) kv.push(['理论寿命', res.life_km + ' km' + (res.annual_km != null ? '（年用 ' + res.annual_km + ' km）' : '')]);
    /**/
    else if (res.screw_sel === '梯形') {
      kv.push(['工作制', '每日 ' + ((res.trap_duty && res.trap_duty.cycles_per_day) || (cal && cal.cycles_per_day) || '—')
        + ' 次（梯形丝杠基准 50 次/日）'
        + (res.trap_duty && res.trap_duty.ok === false ? '，超负载率允许上限 ' + res.trap_duty.max_cyc + ' 次/日，建议改选滚珠丝杠' : '')]);
    }
    if (cand.static_sample_kN != null) kv.push(['最大静载', cand.static_sample_kN + ' kN']);
    if (cand.inertia_kgm2 != null) kv.push(['转动惯量', cand.inertia_kgm2 + ' kg·m²']);
    if (cand.current400_A != null) kv.push(['400V 电流', cand.current400_A + ' A（' + (cand.winding || 2) + ' 匝）']);
    if (cand.C_kN != null) kv.push(['额定动载', cand.C_kN + ' kN']);
    if (cand.weight_kg != null) kv.push(['重量', cand.weight_kg + ' kg']);
    if (res.T_final_Nm != null) kv.push(['电机端需求扭矩', res.T_final_Nm + ' Nm']);
    if (res.motor_power_kW != null) kv.push(['所需功率', res.motor_power_kW + ' kW @ ' + res.motor_sync + ' rpm']);
    /**/
    /**/
    if (cand.integrated) kv.push(['丝杠', res.screw_sel === '梯形' ? '梯形丝杠（自锁）' : (def.screw_type || '') + '丝杠']);
    var html = kv.map(function (r) {
      return '<div class="kv"><b>' + esc(r[0]) + '</b><span>' + esc(r[1]) + '</span></div>';
    }).join('');
    return html;
  }

  function motorHTML(res, cal) {
    var ms = res.motor_recommend || [];
    var html = '';
    if (res.integrated) {
      /**/
      var accA = (res.accessories || []);
      return '<div class="hint">GTR 一体化行星丝杠电缸：电机内置（行程/导程码订货），无需外配电机、减速机与输入形式；'
        + '推力按绕组匝数分档（1/2/3 匝，样本 2026 第 64 页全量）；一体化结构不校核稳定性。</div>'
        + '<div class="kv"><b>驱动器</b><span>' + esc(gtrDriveLabel(cal)) + '</span></div>'
        + '<div class="kv"><b>反馈方式（GGG）</b><span>' + esc(gtrFbLabel(cal) || (cal && cal.gtr_fb) || '—') + '</span></div>'
        + '<div class="kv"><b>连接接头（D）</b><span>M 控制器厂家接头（样本 77 页 D 段）</span></div>'
        + '<div class="kv"><b>电机定子（HHH）</b><span>' + (res.winding === 1 ? '158' : (res.winding === 3 ? '358' : '258'))
        + '（' + (res.winding || 2) + ' 匝 400V，与推力校核匝数一致；样本空缺匝数订货前与厂家确认）</span></div>'
        + '<div class="kv"><b>转速码（II）</b><span>' + gtrSpeedCode(res.model) + '（样本 77 页标准档）</span></div>'
        + (accA.indexOf('RB') >= 0 ? '<div class="kv"><b>制动器</b><span>RB 尾部电子制动（已选）</span></div>'
          : '<div class="kv"><b>制动器</b><span>未选（RB 尾部电子制动为选配）</span></div>')
        + '<div class="hint" style="margin-top:4px">样本 77 页：GTR 可与任意品牌伺服驱动器匹配，订单一定要注明驱动器型号及相关参数，'
        + '力姆泰克按驱动器厂家提供相应的反馈方式与接口。</div>';
    }
    /*



*/
    var need = res.motor_power_kW;
    var mo = res.motor_options || [];
    var pk = mo.filter(function (o) { return o.recommended; })[0] || mo[0] || null;
    var beltPk = pk ? pk.belt : (res.ratio || 1);
    var ipPk = pk ? pk.ip : (res.planetary ? res.planetary.ratio : 1);
    var etaPk = pk ? pk.etaP : (res.planetary ? res.planetary.eta : 1);
    var screwRpm = (res.speed_mm_s && res.lead_mm) ? Math.round(res.speed_mm_s * 60 / res.lead_mm) : null;
    /*
*/
    function pgCode(belt, ip) {
      var gseg = Number(ip) > 1 ? (ip < 10 ? 'G0' + ip : 'G' + ip) : '';
      if (beltFormOf(res.form_v)) return (Number(belt) === 2 ? 'P20' : (Number(belt) === 1.5 ? 'P15' : 'P10')) + (gseg ? '-' + gseg : '');
      return gseg;
    }
    function ratioLabel(belt, ip) {
      var code = pgCode(belt, ip);
      if (!code) return '';
      var det = [];
      if (beltFormOf(res.form_v) && Number(belt) === 2) det.push('同步带 i=2');
      if (beltFormOf(res.form_v) && Number(belt) === 1.5) det.push('同步带 i=1.5');
      if (Number(ip) > 1) det.push('行星减速机 i=' + ip + ':1');
      return det.length ? code + '（' + det.join(' × ') + '）' : code;
    }
    /**/
    function ratioLabelCell(belt, ip) {
      return pgCode(belt, ip);
    }
    html += '<div class="kv"><b>所需功率</b><span>' + (need != null ? need + ' kW（所需功率 = 额定档 ' + (res.motor_sync || '—')
      + 'rpm × 电机端需求扭矩 ' + (res.T_final_Nm != null ? res.T_final_Nm : '—') + 'Nm ÷ 9550'
      + (ipPk > 1 ? '，已含行星减速机效率 ' + etaPk + ' 与安全系数链' : '，已含安全系数链') + '）' : '—') + '</span></div>';
    html += '<div class="kv"><b>所需扭矩</b><span>' + (res.T_final_Nm != null ? res.T_final_Nm + ' Nm（电机端需求 = 丝杠端 '
      + (res.T_screw_Nm != null ? res.T_screw_Nm : '—') + ' Nm ÷ 减速比 ' + (beltPk * ipPk)
      + (beltPk > 1 && ipPk > 1 ? '（同步带 ' + beltPk + ' × 行星 ' + ipPk + '）' : '')
      + (ipPk > 1 ? ' ÷ 效率 ' + etaPk : '')
      + '，配' + (ratioLabel(beltPk, ipPk) || '直连') + '）' : '—') + '</span></div>';
    html += '<div class="kv"><b>额定转速</b><span>' + (res.motor_sync || '—') + ' rpm（伺服'
      + ((beltPk > 1 || ipPk > 1)
        ? '，经' + ratioLabel(beltPk, ipPk) + ' 输出 '
          + (res.motor_sync ? Math.round(res.motor_sync / (beltPk * ipPk)) : '—') + ' rpm'
        : (screwRpm != null ? '，调速运行，丝杠端 ' + screwRpm + ' rpm' : '，调速运行'))
      + '）</span></div>';
    /*



*/
    var pickedCode = res._picked_motor_code || null;
    /**/
    function dispRules(list) {
      var pCalc = (res.motor_power_kW != null) ? Number(res.motor_power_kW) : null;
      var out = list.filter(function (rw) {
        if (pCalc > 0 && Number(rw.m.power_kW) > pCalc * 3 + 1e-9
          && rw.m.code !== pickedCode && rw.origIdx !== 0) return false;
        return true;
      });
      out.sort(function (a, b) {
        return (Number(a.m.power_kW) - Number(b.m.power_kW)) || ((a.m.rpm || 0) - (b.m.rpm || 0));
      });
      /*


*/
      var pinK = -1;
      if (pickedCode != null) {
        out.forEach(function (rw, k) { if (pinK < 0 && rw.m.code === pickedCode) pinK = k; });
      }
      if (pinK < 0) {
        out.forEach(function (rw, k) { if (rw.origIdx === 0) pinK = k; });
      }
      if (pinK > 0) out.unshift(out.splice(pinK, 1)[0]);
      if (out.length > 5) {
        var ki = -1;
        out.forEach(function (rw, k) { if (rw.m.code === pickedCode || rw.origIdx === 0) ki = k; });
        if (ki >= 5) { var t = out[4]; out[4] = out[ki]; out[ki] = t; }
        out = out.slice(0, 5);
      }
      return out;
    }
    var rowsAll = dispRules((res.motor_recommend || []).map(function (m, mi0) {
      return { m: m, origIdx: mi0 };
    }).filter(function (rw) { return !rw.m.kind || rw.m.kind === 'servo'; }));
    if (rowsAll.length) {
      html += '<table style="margin-top:8px"><thead><tr><th>品牌</th><th>型号</th><th>功率</th><th>实际转速</th><th>额定扭矩</th><th>额定电流</th><th>机座号</th><th>报价</th><th>减速机</th></tr></thead><tbody>';
      rowsAll.forEach(function (rw) {
        var m = rw.m;
        var outRpm = (m.gearbox && m.gearbox.out_rpm != null) ? m.gearbox.out_rpm
          : (res.motor_sync ? Math.round(res.motor_sync / ((m.belt || 1) * (m.ip || 1))) : null);
        var isPicked = pickedCode != null && m.code === pickedCode;
        html += '<tr id="motorRow_' + rw.origIdx + '" style="cursor:pointer' + (isPicked ? ';background:rgba(46,125,80,.10)' : '') + '" title="点击选用该电机（整行任意位置可点）"><td>' + esc(m.brandFull) + '</td><td>' + esc(cylCodeShown(m))
          + (cylIsISMG2(m.code) ? ' <span class="pill a">不带制动</span>' : '')
          + (isPicked ? ' <span class="pill a">当前选用</span>' : '')
          + (cylOverPowerPw(m, res) != null ? ' <span class="pill a">超功率</span>' : '')
          + (m.s120_fallback ? ' <span class="pill a">S120 接棒</span>' : '')
          + (m.overspeed ? ' <span class="pill a">弱磁超速</span>' : '')
          + (m.fit === '1.1' ? ' <span class="pill a">1.1× 凑功率</span>' : '')
            + (m.fit === 's11' ? ' <span class="pill a">1.1× 凑档</span>' : '')
          + (m.fit === 'far' ? ' <span class="pill a">偏离较大</span>' : '')
          + (m.tq_under != null ? ' <span class="pill a" title="额定扭矩低于计算需求，差值在 2% 以内；仅作备选，正式报价前须与厂家确认">扭矩临界（欠 ' + esc(fN(m.tq_under * 100, 1)) + '%）</span>' : '') + '</td><td>'
          + m.power_kW + ' kW</td><td>' + m.rpm + (m.overspeed ? '（最高 3000）' : '') + '</td><td>' + m.torque_Nm + ' Nm' + (m.torque_at_speed != null ? '（超速可用 ' + m.torque_at_speed + ' Nm）' : '') + '</td><td>'
          + (m.current_A != null ? m.current_A + ' A' : '—') + '</td><td>' + esc(m.frame) + '</td><td>'
          /**/
          + (function () { var mp = cylMotorDrivePriceOf(m, cal, res); return (mp && mp.hasPrice) ? '<b>' + esc(moneyTxt(mp.unit)) + '</b>' + (mp.driveOnly ? '<br><span class="hint">（仅驱动器，电机另询）</span>' : '') : '<span class="hint">暂无价格</span>'; })() + '</td><td>'
          + (ratioLabelCell(m.belt, m.ip) ? '<b>' + ratioLabelCell(m.belt, m.ip) + '</b>' + (outRpm != null ? '（输出 ≤' + outRpm + 'rpm）' : '') : '—（直连）')
          + '</td></tr>';
      });
      html += '</tbody></table>';
      /*







*/
      if (rowsAll.some(function (rw) { return cylIsISMG2(rw.m.code); })) {
        html += '<div class="hint" style="margin-top:4px">汇川 <b>ISMG2</b>（266×266 法兰）系列<b>无带制动器选型，均为不带制动</b>；'
          + '电缸恒配制动器（滚珠/行星丝杠不自锁）——可带抱闸的 <b>ISMG1</b>（200×200 法兰，抱闸版本后缀 -A334FA）优先接棒；'
          + '需求超出 ISMG1 上限（31.4kW@2000rpm）时才保留 ISMG2，制动须与汇川确认或另行解决。</div>';
      }
      if (rowsAll.some(function (rw) { return rw.m.s120_fallback; })) {
        html += '<div class="hint" style="margin-top:4px">标「S120 接棒」：所需功率/扭矩超过西门子 V90（1FL6）/ S200（1FL2）系列覆盖上限（7kW / 33.4Nm），'
          + '功率超出 V90 / S200 覆盖时自动改配西门子 S120（1FK7 / 1FT7）。</div>';
      }
      if ((res.motor_recommend || []).some(function (m) { return m.fit === 's11'; })) {
        /**/
        html += '<div class="hint" style="margin-top:4px">标「1.1× 凑档」：该机型按标准安全系数 1.2 略不足，按 <b>1.1 安全系数</b>即可覆盖（为凑电机标准功率档可取 1.1，须在方案中注明）。</div>';
      }
      if (rowsAll.some(function (rw) { return rw.m.fit === '1.1'; })) {
        /**/
        html += '<div class="hint" style="margin-top:4px">标「1.1× 凑功率」：该档按安全系数 1.1 即可覆盖所需功率/扭矩（单台安全系数一般为 1.2，为凑电机标准功率档可取 1.1，须在方案中注明）。</div>';
      }
      if (rowsAll.some(function (rw) { return cylOverPowerPw(rw.m, res) != null; })) {
        /**/
        html += '<div class="hint" style="margin-top:4px">标「超功率」：该电机额定功率超过所选型号的最大功率上限（2026-11-09 机座号上限批复）——超功率电机不建议选用，请换更大型号电缸。</div>';
      }
      if ((res.motor_weak || []).length) {
        /*
*/
        html += '<div class="hint" style="margin-top:8px"><b>弱磁降速档（参考，不占上表 5 行名额）</b>：'
          + '窗口内最大总速比下扭矩不足的更小功率机型（如 3.5kW 2000rpm），按大一档标准比配减速机、'
          + '电机超额定转速弱磁运行达速（≤最高转速），可用扭矩按恒功率折算——<b>须与厂家确认</b>。</div>';
        html += '<table style="margin-top:2px"><thead><tr><th>品牌</th><th>型号</th><th>功率</th><th>额定转速</th><th>额定扭矩</th><th>额定电流</th><th>机座号</th><th>报价</th><th>减速机</th></tr></thead><tbody>';
        (res.motor_weak || []).forEach(function (m) {
          var outRpmW = (m.gearbox && m.gearbox.out_rpm != null) ? m.gearbox.out_rpm : null;
          var rpmReach = (m.weak_nreq != null && m.belt && m.ip) ? Math.round(m.weak_nreq / (m.belt * m.ip)) : null;
          html += '<tr><td>' + esc(m.brandFull) + '</td><td>' + esc(m.code)
            + ' <span class="pill a">弱磁降速档</span></td><td>' + m.power_kW + ' kW</td><td>' + m.rpm
            + '（弱磁跑 ' + (m.weak_nreq || '—') + '）</td><td>' + m.torque_Nm + ' Nm'
            + (m.torque_at_speed != null ? '（折算可用 ' + m.torque_at_speed + ' Nm）' : '') + '</td><td>'
            + (m.current_A != null ? m.current_A + ' A' : '—') + '</td><td>' + esc(m.frame) + '</td><td>'
            + (function () { var mp = cylMotorDrivePriceOf(m, cal, res); return (mp && mp.hasPrice) ? '<b>' + esc(moneyTxt(mp.unit)) + '</b>' + (mp.driveOnly ? '<br><span class="hint">（仅驱动器，电机另询）</span>' : '') : '<span class="hint">暂无价格</span>'; })() + '</td><td>'
            + (ratioLabelCell(m.belt, m.ip) ? '<b>' + ratioLabelCell(m.belt, m.ip) + '</b>'
              + (outRpmW != null ? '（输出 ≤' + outRpmW + 'rpm' + (rpmReach != null ? '，弱磁达速 ' + rpmReach + 'rpm 后满足速度要求' : '') + '）' : '') : '—')
            + '</td></tr>';
        });
        html += '</tbody></table>';
      }
    } else if ((res.motor_recommend || []).length) {
      /*
*/
      var pickedCode2 = res._picked_motor_code || null;
      var rowsOv = dispRules((res.motor_recommend || []).map(function (m, mi0) {
        return { m: m, origIdx: mi0 };
      }).filter(function (rw) { return !rw.m.kind || rw.m.kind === 'servo'; }));
      html += '<table style="margin-top:8px"><thead><tr><th>品牌</th><th>型号</th><th>功率</th><th>实际转速</th><th>额定扭矩</th><th>额定电流</th><th>机座号</th><th>报价</th><th>减速机</th></tr></thead><tbody>';
      rowsOv.forEach(function (rw) {
        var m = rw.m;
        var isPicked2 = pickedCode2 != null && m.code === pickedCode2;
        html += '<tr id="motorRow_' + rw.origIdx + '" style="cursor:pointer' + (isPicked2 ? ';background:rgba(46,125,80,.10)' : '') + '" title="点击选用该电机（整行任意位置可点）"><td>' + esc(m.brandFull) + '</td><td>' + esc(cylCodeShown(m))
          + (cylIsISMG2(m.code) ? ' <span class="pill a">不带制动</span>' : '')
          + (isPicked2 ? ' <span class="pill a">当前选用</span>' : '')
          + (cylOverPowerPw(m, res) != null ? ' <span class="pill a">超功率</span>' : '')
          + (m.s120_fallback ? ' <span class="pill a">S120 接棒</span>' : '')
          + (m.overspeed ? ' <span class="pill a">弱磁超速</span>' : '')
          + (m.fit === '1.1' ? ' <span class="pill a">1.1× 凑功率</span>' : '')
            + (m.fit === 's11' ? ' <span class="pill a">1.1× 凑档</span>' : '')
          + (m.fit === 'far' ? ' <span class="pill a">偏离较大</span>' : '')
          + (m.tq_under != null ? ' <span class="pill a" title="额定扭矩低于计算需求，差值在 2% 以内；仅作备选，正式报价前须与厂家确认">扭矩临界（欠 ' + esc(fN(m.tq_under * 100, 1)) + '%）</span>' : '') + '</td><td>'
          + m.power_kW + ' kW</td><td>' + m.rpm + (m.overspeed ? '（最高 3000）' : '') + '</td><td>' + m.torque_Nm + ' Nm' + (m.torque_at_speed != null ? '（超速可用 ' + m.torque_at_speed + ' Nm）' : '') + '</td><td>'
          + (m.current_A != null ? m.current_A + ' A' : '—') + '</td><td>' + esc(m.frame) + '</td><td>'
          /**/
          + (function () { var mp = cylMotorDrivePriceOf(m, cal, res); return (mp && mp.hasPrice) ? '<b>' + esc(moneyTxt(mp.unit)) + '</b>' + (mp.driveOnly ? '<br><span class="hint">（仅驱动器，电机另询）</span>' : '') : '<span class="hint">暂无价格</span>'; })() + '</td><td>'
          + (ratioLabelCell(beltPk, ipPk) ? '<b>' + ratioLabelCell(beltPk, ipPk) + '</b>' + (res.motor_sync ? '（输出 ≤' + Math.round(res.motor_sync / (beltPk * ipPk)) + 'rpm）' : '') : '—（直连）')
          + '</td></tr>';
      });
      html += '</tbody></table>';
      if (rowsOv.some(function (rw) { return cylIsISMG2(rw.m.code); })) {
        html += '<div class="hint" style="margin-top:4px">汇川 <b>ISMG2</b>（266×266 法兰）系列<b>无带制动器选型，均为不带制动</b>；'
          + '电缸恒配制动器——可带抱闸的 <b>ISMG1</b>（抱闸版本后缀 -A334FA）优先接棒；'
          + '需求超出 ISMG1 上限（31.4kW@2000rpm）时才保留 ISMG2，制动须与汇川确认或另行解决。</div>';
      }
      if ((res.motor_recommend || []).some(function (m) { return m.fit === 's11'; })) {
        html += '<div class="hint" style="margin-top:4px">标「1.1× 凑档」：该机型按标准安全系数 1.2 略不足，按 <b>1.1 安全系数</b>即可覆盖（为凑电机标准功率档可取 1.1，须在方案中注明）。</div>';
      }
      if ((res.motor_recommend || []).some(function (m) { return m.fit === '1.1'; })) {
        html += '<div class="hint" style="margin-top:4px">标「1.1× 凑功率」：该档按安全系数 1.1 即可覆盖所需功率/扭矩（单台安全系数一般为 1.2，为凑电机标准功率档可取 1.1，须在方案中注明）。</div>';
      }
      if ((res.motor_recommend || []).some(function (m) { return cylOverPowerPw(m, res) != null; })) {
        html += '<div class="hint" style="margin-top:4px">标「超功率」：该电机额定功率超过所选型号的最大功率上限（2026-11-09 机座号上限批复）——超功率电机不建议选用，请换更大型号电缸。</div>';
      }
    }
    if (res.motor_real_missing) {
      /**/
      html += '<div class="note">电机表<b>该品牌无覆盖</b>：' + esc(res.motor_real_note || '所选品牌在该转速档无覆盖真机型，请调整品牌勾选或输入形式后重算。') + '</div>';
    }
    /*



*/
    return html;
  }

  /**/
  /*

*/
  function moneyTxt(n) {
    if (typeof window !== 'undefined' && window.LANG_I18N) return window.LANG_I18N.cur(n);   /**/
    var x = Math.round(Number(n) || 0);
    return '¥' + String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function motorDrivePriceOf(m0, cal) {
    var sj = g.SJScrewJackProduct;
    return (sj && sj.motorDrivePriceOf) ? sj.motorDrivePriceOf(m0, cal) : null;
  }

  /*







*/
  function cylBook() {
    /**/
    return g.SJ_PRICE_BOOK_CYL || null;
  }
  function cylSheetOf(model) {
    var B = cylBook();
    if (!B) return null;
    var m = String(model || '');
    var mm = m.match(/^(DMB|EMB|FMR|GTR)(\d+)/);
    if (!mm) return null;
    var fam = mm[1], no = mm[2];
    if (fam === 'FMR') {
      /**/
      var hostNo = ({ '25': '20', '30': '30', '35': '35', '40': '40', '50': '50', '60': '60', '80': '80', '200': '200' })[no];
      var host = B.DMB['DMB' + hostNo];
      return (host && host.fmr) ? { host: host, fmr: host.fmr, factor: host.factor, isFMR: true } : null;
    }
    var grp = B[fam];
    var key = (fam !== 'GTR' && m.length === 5 && !grp[m]) ? (fam + '0' + no) : m;
    /**/
    var sh = grp ? (grp[key] || grp[m] || grp[fam + no]) : null;
    return sh ? { host: sh, factor: sh.factor, isFMR: false } : null;
  }
  function strokeBaseOf(sh, stroke) {
    var strokes = sh.strokes || {};
    var ks = Object.keys(strokes).map(Number).sort(function (a, b) { return a - b; });
    if (!ks.length) return null;
    for (var i = 0; i < ks.length; i++) {
      if (stroke <= ks[i] + 1e-9) return { base: strokes[String(ks[i])], hit: ks[i], over: 0 };
    }
    /**/
    var maxK = ks[ks.length - 1];
    var per100 = (sh.per100 != null) ? sh.per100 : null;
    if (per100 == null) {
      /*


*/
      if (ks.length >= 2) {
        var k1 = ks[ks.length - 2], k2 = maxK;
        var p1 = strokes[String(k1)], p2 = strokes[String(k2)];
        if (p1 != null && p2 != null && p2 > 0) {
          var slope = (p2 - p1) / (k2 - k1);
          return { base: p2, hit: k2, over: Math.round((stroke - k2) * slope),
                   linear: true, slope: Math.round(slope * 100) / 100, from: k1 };
        }
      }
      return null;
    }
    var overCells = Math.ceil((stroke - maxK) / 100 - 1e-9);
    return { base: strokes[String(maxK)], hit: maxK, over: overCells * per100 };
  }
  function cylNetPriceOf(res, cal, data) {
    var sh = cylSheetOf(res.model);
    if (!sh) return null;
    var host = sh.host, parts = [], sum = 0, missing = [];
    var stroke = (cal && cal.stroke != null) ? Number(cal.stroke) : null;
    var sb = stroke ? strokeBaseOf(host, stroke) : null;
    if (!sb || sb.base == null) { missing.push('本体（行程超标准档，特殊行程 XT 与厂家确认）'); }
    else {
      parts.push({ txt: '本体（' + res.model + '，行程 ' + Math.round(stroke) + 'mm 按 ' + sb.hit + 'mm 标准档'
        + (sb.linear ? '＋超档 ' + Math.round(stroke - sb.hit) + 'mm 按 ' + sb.from + '→' + sb.hit + 'mm 档差比例折算' : '')
        + (sb.over && !sb.linear ? '＋非标每100mm累计' : '') + '）', p: sb.base + sb.over });
      sum += sb.base + sb.over;
    }
    /*

*/
    if (sh.isFMR && host.fmr && host.fmr.strokes) {
      var fSb = stroke ? strokeBaseOf({ strokes: host.fmr.strokes, per100: null }, stroke) : null;
      if (fSb && fSb.base != null) {
        parts.push({ txt: '行星丝杠 ' + (host.fmr.code || '') + '（行程 ' + Math.round(stroke) + 'mm 按 ' + fSb.hit + 'mm 标准档'
          + (fSb.linear ? '＋超档 ' + Math.round(stroke - fSb.hit) + 'mm 按 ' + fSb.from + '→' + fSb.hit + 'mm 档差比例折算' : '') + '）',
          p: fSb.base + fSb.over });
        sum += fSb.base + fSb.over;
      } else missing.push('行星丝杠 ' + ((host.fmr && host.fmr.code) || '') + '（行程超档，与厂家确认）');
    }
    /*

*/
    var inst = host.install || {};
    var instKey = (cal && cal.install) ? cal.install : null;
    if (instKey && inst[instKey] == null) {
      instKey = ({ FF: 'F', RF: 'R', RC: 'C', ST: 'T', SH: 'L', SF: 'S' })[instKey] || instKey;
    }
    var iv = instKey ? inst[instKey] : null;
    if (iv != null) { if (iv > 0) { parts.push({ txt: '安装 ' + (cal && cal.install), p: iv }); sum += iv; } }
    else missing.push('安装 ' + (cal && cal.install));
    /**/
    if (cal && cal.guide === '有' && host.guide != null) { parts.push({ txt: '导向模块 GM', p: host.guide }); sum += host.guide; }
    /*

*/
    var jt = host.joint || {};
    var jtKey = (cal && cal.joint) ? cal.joint : null;
    if (jtKey && jt[jtKey] == null) {
      jtKey = ({ BA: 'B', FM: 'F', ROE: 'R', TS: 'T', FO: 'F', FL: 'L' })[jtKey] || jtKey;
    }
    var jv = jtKey ? (jt[jtKey] != null ? jt[jtKey] : jt.std) : null;
    if (jv == null && sh.isFMR) jv = jt.std;
    if (jv != null) { if (jv > 0) { parts.push({ txt: '接头 ' + (cal && cal.joint), p: jv }); sum += jv; } }
    else if (cal && cal.joint) missing.push('接头 ' + cal.joint);
    /*

*/
    var inp = host.input || {};
    if (!res.integrated) {
      var fKey = String((cal && cal.form && cal.form.v) || cal.input_form || '');
      var ivf = /P10|P20|P15/.test(fKey) ? (inp.P10 != null ? inp.P10 : inp.P20) : inp.ISC;
      if (ivf != null) { if (ivf > 0) { parts.push({ txt: '输入形式 ' + (/P10|P20|P15/.test(fKey) ? 'P10/P15/P20 同步带平行安装' : 'SC 直连（含孔联轴器）'), p: ivf }); sum += ivf; } }
      else missing.push('输入形式');
    }
    /*


*/
    var acc = host.acc || {};
    var accMap = { AR: 'AR', L2: 'L2', RB: 'RB', B: 'PB', PF: 'PF' };
    var limCode = ((res.accessories || []).indexOf('FCP') >= 0) ? 'FCP'
      : (((res.accessories || []).indexOf('FCM') >= 0) ? 'FCM' : null);
    if (limCode) {
      if (acc.L2 != null) {
        /**/
        var limEx = isExMotor(res);
        var limAmt = (acc.L2 > 0 ? acc.L2 : 0) + (limEx ? 1000 : 0);
        if (limAmt > 0) {
          parts.push({ txt: (limEx ? '防爆限位开关 ' : '限位开关 ') + limCode
            + '（L2 外置接近限位开关 2 个，常开 NO' + (limEx ? '，防爆型 +1000' : '') + '）', p: limAmt });
          sum += limAmt;
        }
      } else missing.push((isExMotor(res) ? '防爆限位开关 ' : '限位开关 ') + limCode + '（L2）');
    }
    (res.accessories || []).forEach(function (a) {
      var k = accMap[a];
      if (!k) return;
      var v = acc[k];
      if (v != null) { if (v > 0) { parts.push({ txt: '附件 ' + a, p: v }); sum += v; } }
      else missing.push('附件 ' + a);
    });
    /*




*/
    var fixed = 0;
    var accSel2 = res.accessories || [];
    var famN = parseInt(String(res.model || '').replace(/^(DMB|EMB|FMR)/i, ''), 10);
    if (accSel2.indexOf('PL') >= 0) {
      var famS = String(res.family || '');
      var plP = null;
      if (famS === 'DMB') plP = (isFinite(famN) && famN <= 40) ? 3200 : (isFinite(famN) && famN >= 50 && famN <= 200) ? 4500 : null;
      else if (famS === 'EMB') plP = 3200;
      else if (famS === 'FMR') plP = (isFinite(famN) && famN <= 35) ? 3200 : 4500;
      if (plP != null) { parts.push({ txt: '压力传感器 PL（一口价）', p: plP }); fixed += plP; }
      else missing.push('压力传感器 PL（该型号未定价，与厂家确认）');
    }
    if (accSel2.indexOf('OS') >= 0) {
      var osP = (stroke != null && stroke > 100 - 1e-9 && stroke <= 500 + 1e-9) ? 5500
        : (stroke != null && stroke > 500 + 1e-9 && stroke <= 1000 + 1e-9) ? 9500 : null;
      if (osP != null) { parts.push({ txt: 'GIVI 光栅尺 OS（行程 ' + Math.round(stroke) + 'mm，一口价）', p: osP }); fixed += osP; }
      else missing.push('GIVI 光栅尺 OS（行程 ' + (stroke != null ? Math.round(stroke) + 'mm 超出 100~1000mm 标价范围' : '未知') + '，与厂家确认）');
    }
    /*



*/
    if (/^GTR/.test(String(res.model))) {
      var plugM = (host.plug && host.plug.M != null) ? host.plug.M : 0;
      if (plugM > 0) { parts.push({ txt: '插头 M（驱动器厂家标准）', p: plugM }); sum += plugM; }
      var fbTxt = String(gtrFbLabel(cal) || (cal && cal.encoder) || '');
      if (host.encoder && host.encoder.abs != null && /多圈绝对|多圈|abs/i.test(fbTxt)) {
        parts.push({ txt: '绝对多圈编码器（' + (cal && cal.gtr_fb) + '）', p: host.encoder.abs }); sum += host.encoder.abs;
      }
    }
    var factor = sh.factor != null ? sh.factor : 1;
    /**/
    var unit = Math.round(sum * factor) + (fixed || 0);
    return { unit: unit, hasPrice: missing.indexOf('本体（行程超标准档，特殊行程 XT 与厂家确认）') < 0 && (sum > 0 || fixed > 0),
      parts: parts, missing: missing, factor: factor, fixed: fixed || 0 };
  }
  /*

*/
  function gtrS120DriveOf(res, cal) {
    var B = cylBook();
    if (!B || !B.S120) return null;
    var mm = String(res.model || '').match(/^GTR(\d+)/);
    if (!mm) return null;
    var fam = B.GTR['GTR' + mm[1]];
    if (!fam || !fam.driveA_400V) return null;
    /**/
    var aNeed = fam.driveA_400V[(res.winding || 2) - 1] != null ? fam.driveA_400V[(res.winding || 2) - 1] : fam.driveA_400V[1];
    var pe = (B.S120.pe || []).filter(function (x) { return x.aL >= aNeed - 1e-9; })
      .sort(function (a, b) { return a.p - b.p; })[0];
    var cost = 0, missing = [];
    [pe, B.S120.cu, B.S120.cf, B.S120.brake].forEach(function (e) {
      if (e && e.p) cost += e.p; else missing.push(e === pe ? '功率单元' : 'S120 组件');
    });
    var unit = Math.round(cost * (B.S120.quote_factor || 2));
    return { unit: unit, hasPrice: missing.length === 0 && cost > 0, aNeed: aNeed, pe: pe,
      cu: B.S120.cu, cf: B.S120.cf, brake: B.S120.brake, missing: missing };
  }
  /*

*/
  function cylMotorDrivePriceOf(m0, cal, res) {
    var sj = motorDrivePriceOf(m0, cal);
    if (sj) return sj;
    var B = cylBook();
    if (!B || !B.S120 || !m0) return null;
    if (String(m0.brandFull || '').indexOf('S120') < 0 && String(m0.brand || '').indexOf('S120') < 0) return null;
    var code = String(m0.code || '').toUpperCase();
    var mRec = null;
    Object.keys(B.S120.motors || {}).forEach(function (k) {
      if (code.indexOf(k) === 0 && !mRec) mRec = B.S120.motors[k];
    });
    var pw = Number(m0.power_kW) || 0;
    var pe = (B.S120.pe || []).filter(function (x) { return x.kw >= pw - 1e-9; })
      .sort(function (a, b) { return a.p - b.p; })[0];
    var cost = 0, missing = [];
    if (mRec && mRec.p) cost += mRec.p; else missing.push('电机');
    [pe, B.S120.cu, B.S120.cf, B.S120.brake].forEach(function (e) {
      if (e && e.p) cost += e.p; else missing.push(e === pe ? '功率单元' : 'S120 组件');
    });
    if (!cost) return null;
    var unit = Math.round(cost * (B.S120.quote_factor || 2));
    var peOrder = pe ? pe.order : '—';
    var kitTxt = '配套驱动器（SINAMICS S120，380V）：功率单元 ' + peOrder
      + '（' + pe.kw + 'kW/' + pe.aL + 'A，≥ 电机额定）＋ CU310-2PN（6SL3040-1LA01-0AA0）＋ CF 卡 ＋ 制动电阻'
      + (missing.length ? '；' + missing.join('、') + '暂无报价（与西门子确认后报价）' : '')
      + '；成套附件：动力/编码器电缆（长度按现场配置，价格另计）';
    return { base: code, unit: unit, hasPrice: true, motorP: mRec ? mRec.p : null,
      driveOrder: peOrder, driveTxt: 'SINAMICS S120（' + peOrder + '，380V）',
      missing: missing, kitTxt: kitTxt, src: 's120' };
  }
  function quoteTableHTML(cal, res, cand, data, items) {
    var def = (data && data.models && data.models[res.model]) || {};
    var fullCode = suggestCode(cal, res);
    function nameOf(list, v) { var h = (list || []).filter(function (x) { return x.v === v; })[0]; return h ? h.t : (v || ''); }
    var rows = '';
    var no = 1;
    var priceSum = 0, hasAnyPrice = false, totalN = 0;
    /*
*/
    var vHasSD = /行程/.test(res.variant || '');
    var seg = ['额定推力 ' + res.rated_kN + ' kN（' + res.variant + '）'];
    if (cal.stroke != null && !vHasSD) seg.push('行程 ' + Math.round(cal.stroke) + ' mm');
    /**/
    if (cal.stroke != null && vHasSD && res.integrated) seg.push('要求行程 ' + Math.round(cal.stroke) + ' mm');
    /**/
    if (!vHasSD) seg.push(res.screw_sel === '梯形'
      ? '梯形丝杠，导程 ' + res.lead_mm + ' mm（自锁）'
      : (def.screw_type || '') + '丝杠，导程 ' + res.lead_mm + ' mm');
    seg.push('安装 ' + installLabel(res.install) + '，接头 ' + nameOf(D().joints, res.joint));
    /**/
    if (res.integrated) seg.push('一体化行星丝杠（电机内置，无输入形式）');
    else seg.push('输入形式 ' + formSegOf(res) + '（' + formDetailOf(res) + '）');
    if (res.screw_sel) seg.push('丝杠 ' + ({ '轧制': '轧制滚珠丝杠（0.05mm）', '磨制': '磨制滚珠丝杠（0.02mm，GB）', '梯形': '梯形丝杠（0.1mm，自锁，整缸效率 30%）' }[res.screw_sel] || res.screw_sel));
    if (cal.speed_mm_s != null) seg.push('速度 ' + cal.speed_mm_s + ' mm/s');
    if (res.accessories && res.accessories.length) seg.push('附件 ' + accText(res));
    if (cal.ip) seg.push('防护 ' + cal.ip);
    if (cal.temp && cal.temp !== '20') seg.push('工作温度 ' + cal.temp + '℃');
    if (cal.precision && cal.precision !== '无') seg.push('重复精度 ' + (cal.precision === '梯形' ? '0.1 mm（梯形丝杠，自锁）' : cal.precision + ' mm'));
    /**/
    var npMain = cylNetPriceOf(res, cal, data);
    var mainQty = (cal.units || 1);
    var mainPriceHtml = (npMain && npMain.hasPrice)
      ? esc(moneyTxt(npMain.unit)) + '（单价）<br>' + esc(moneyTxt(npMain.unit * mainQty)) + '（总价）'
      : '暂无价格';
    if (npMain && npMain.hasPrice) { priceSum += npMain.unit * mainQty; hasAnyPrice = true; }
    rows += '<tr><td>' + (no++) + '</td><td><b>Lim-Tec 伺服电缸</b><br><span class="hint" style="font-family:Consolas,monospace">' + esc(fullCode) + '</span></td>'
      + '<td>' + seg.map(esc).join('；') + '</td><td>' + mainQty + ' 台</td><td>' + mainPriceHtml + '</td></tr>';
    totalN += (cal.units || 1);
    /*



*/
    if (res.planetary) {
      var pHv195 = res.planetary.hv || null;
      var plQty195 = (cal.sync === '电气' ? (cal.units || 1) : 1);
      var plSpec195 = '输入形式段 ' + planetSeg(res.planetary.ratio)
        + '，速比 i=' + res.planetary.ratio + ':1，效率 ' + res.planetary.eta
        + '，与伺服电机匹配（机座号按电机法兰）';
      var plPrice195 = '待询价';
      if (pHv195) {
        plSpec195 += '；选 ' + pHv195.model + '（额定输出扭矩 ' + Math.round(pHv195.C) + 'Nm/最大 '
          + Math.round(pHv195.D) + 'Nm，' + pHv195.level + '；适配电机轴径 ' + pHv195.shafts.join('/') + 'mm）';
        if (pHv195.price != null) {
          plPrice195 = esc(moneyTxt(pHv195.price)) + '（单价）<br>' + esc(moneyTxt(pHv195.price * plQty195)) + '（总价）';
          priceSum += pHv195.price * plQty195; hasAnyPrice = true;
        } else {
          plPrice195 = esc(pHv195.priceNote || '待询价');
        }
      } else {
        plSpec195 += '；i=' + res.planetary.ratio + ' 非 HV 标准速比档（标准比 3/4/5/7/10、12~28、60~175），型号与价格待询';
      }
      rows += '<tr><td>' + (no++) + '</td><td><b>行星减速机</b>（自动匹配）</td><td>' + plSpec195 + '</td>'
        + '<td>' + plQty195 + ' 台</td><td>' + plPrice195 + '</td></tr>';
      totalN += plQty195;
    }
    /**/
    if (res.integrated) {
      /**/
      var gDrv = gtrS120DriveOf(res, cal);
      var gSeg = ['SINAMICS S120（380V），暂配 S120（额定电流 ' + (gDrv ? gDrv.aNeed : '—') + 'A，' + (res.winding || 2) + ' 匝 RMS）'];
      if (gDrv) {
        gSeg.push('功率单元 ' + gDrv.pe.order + '（' + gDrv.pe.kw + 'kW/' + gDrv.pe.aL + 'A ≥ 额定）');
        gSeg.push('CU310-2PN（' + gDrv.cu.order + '）＋ CF 卡（' + gDrv.cf.order + '）＋ 制动电阻（' + gDrv.brake.order + '）');
      }
      gSeg.push('反馈方式 ' + esc(gtrFbLabel(cal) || '—'));
      gSeg.push('电机定子 ' + (res.winding === 1 ? '158' : (res.winding === 3 ? '358' : '258')) + '（' + (res.winding || 2) + ' 匝 400V，与推力校核匝数一致）；连接接头 M（控制器厂家接头）');
      gSeg.push('驱动器须随机采购，出厂前驱动器与电机调通并记录参数（报价单注明）');
      var gDrvQty = (cal.units || 1);
      var gDrvHtml = (gDrv && gDrv.hasPrice)
        ? esc(moneyTxt(gDrv.unit)) + '（单价）<br>' + esc(moneyTxt(gDrv.unit * gDrvQty)) + '（总价）'
        : '暂无价格';
      if (gDrv && gDrv.hasPrice) { priceSum += gDrv.unit * gDrvQty; hasAnyPrice = true; }
      rows += '<tr><td>' + (no++) + '</td><td><b>伺服驱动器</b>（西门子 S120）</td>'
        + '<td>' + gSeg.map(esc).join('；') + '</td>'
        + '<td>' + gDrvQty + ' 台</td><td>' + gDrvHtml + '</td></tr>';
      totalN += gDrvQty;
    } else {
      var m0 = (res.motor_recommend || [])[0];
      var motorQty = (cal.sync === '电气' ? (Number(cal.units) || 1) : 1);
      if (m0) {
        /*
*/
        var mdKit = cylMotorDrivePriceOf(m0, cal, res);
        var mseg = [m0.brandFull + ' ' + cylCodeShown(m0), '功率 ' + m0.power_kW + ' kW', '额定转速 ' + m0.rpm + ' rpm'];
        /**/
        if (cylOverPowerPw(m0, res) != null) mseg.push('超功率，不建议选用');
        if (m0.torque_Nm != null) mseg.push('额定扭矩 ' + m0.torque_Nm + ' N·m');
        if (m0.frame) mseg.push('机座 ' + m0.frame);
        if (cylIsISMG2(m0.code)) mseg.push('不带制动（该系列无抱闸选配）；制动须与汇川确认或另行解决');
        else mseg.push('配制动器（带制动，立式安装/断电保持必配——滚珠/行星丝杠不自锁）');
        mseg.push((mdKit && mdKit.kitTxt) ? mdKit.kitTxt
          : '配套驱动器（本方案必选）：驱动器按电机品牌配套选型（价格暂无）；成套附件：动力/编码器电缆（长度按现场配置，价格另计）');
        if (m0.within_10pct) mseg.push('（1.1 倍紧凑选型，标准档正好合适——安全系数按 1.1 凑标准功率档）');
        var motorUnit = (mdKit && mdKit.hasPrice) ? mdKit.unit : null;
        var motorPriceHtml = motorUnit
          ? esc(moneyTxt(motorUnit)) + '（单价）<br>' + esc(moneyTxt(motorUnit * motorQty)) + '（总价）'
          : '暂无价格';
        if (motorUnit) { priceSum += motorUnit * motorQty; hasAnyPrice = true; }
        rows += '<tr><td>' + (no++) + '</td><td><b>交流伺服电机驱动器</b></td>'
          + '<td>' + esc(mseg.join('；')) + '</td>'
          + '<td>' + motorQty + ' 台</td><td>' + motorPriceHtml + '</td></tr>';
        totalN += motorQty;
      } else {
        rows += '<tr><td>' + (no++) + '</td><td><b>交流伺服电机</b></td>'
          + '<td>按所需 ' + (res.motor_power_kW != null ? res.motor_power_kW + ' kW / ' + res.T_final_Nm + ' Nm' : '—') + ' / ' + res.motor_sync + ' rpm 选配（品牌与型号商务确认）</td>'
          + '<td>' + (cal.sync === '电气' ? (cal.units || 1) : 1) + ' 台</td><td>暂无价格</td></tr>';
      }
    }
    return '<table><thead><tr><th style="width:36px">No.</th><th style="width:220px">产品描述</th><th>规格参数</th><th style="width:64px">数量</th><th style="width:110px">价格</th></tr></thead>'
      + '<tbody>' + rows + '</tbody>'
      + '<tfoot><tr><td colspan="3" style="text-align:right"><b>合计</b></td><td>' + totalN + ' 台</td><td>'
      + (hasAnyPrice && priceSum > 0 ? '<b>' + esc(moneyTxt(priceSum)) + '</b>' : '暂无价格') + '</td></tr></tfoot></table>'
      + '<div class="hint" style="margin-top:4px">价格供参考，正式报价以商务报价单为准。</div>';
  }

  /**/
  function specNotes(cal) {
    var out = [];
    /**/
    if (cal && cal.series === 'GTR') {
      out.push('GTR 英制订货码（样本 77 页）：驱动器 ' + gtrDriveLabel(cal) + '，反馈方式 ' + gtrFbLabel(cal)
        + '；连接接头 M（控制器厂家接头）；电机定子 HHH 按所选型号实际校核匝数出码（1 匝=158 / 2 匝=258 / 3 匝=358，'
        + '与推力校核匝数一致，样本空缺匝数订货前与厂家确认）——下单前请按实际驱动器型号确认 GGG 段。');
      if ((cal.accessories || []).indexOf('L2') >= 0) {
        out.push('外置限位开关 L2：样本 77 页要求必须同时选配 AR（外置反转装置），本方案已自动带上 AR。');
      }
    }
    if (cal.low_temp) {
      var lowC = cal.low_coef || 2;   /**/
      out.push('低温（' + (lowC === 1.5 ? '-30℃ 档' : '-40℃ 级') + '）工况：选配低温润滑脂与低温型电机/编码器，扭矩链已按低温系数 ×' + lowC + '。');
    }
    (cal.special || []).forEach(function (s) {
      var tx = (cal.special_texts || {})[s];
      if (s === '防腐要求') out.push('防腐工况：接触件可升级 316 不锈钢与防腐涂层' + (tx ? '（' + tx + '）' : '') + '，具体配置与厂家确认。');
      if (s === '防爆要求') out.push('防爆工况：电机/传感器按防爆等级选配' + (tx ? '（' + tx + '）' : '') + '，整缸防爆方案与厂家确认。');
      if (s === '真空要求') out.push('真空工况：选配真空润滑脂与真空兼容材料' + (tx ? '（' + tx + '）' : '') + '，与厂家确认。');
      if (s === '丝杠导程要求') out.push('客户指定丝杠导程' + (tx ? '：' + tx : '') + '，如与所选变型不一致请与厂家确认可否定制。');
      if (s === '其他特殊要求' && tx) out.push('其他特殊要求：' + tx + '（与厂家技术确认后落实）。');
    });
    return out;
  }

  /**/
  function layoutImageFor() { return ''; }

  /*




*/
  function aboutLines() {
    return [
      '力姆泰克（Lim-Tec）——国内最专业、最具规模、最权威的电动推杆 / 螺旋升降机 / 伺服电动缸专业制造厂家。2005 年合资引进欧洲直线传动技术与模块化组合设计理念；2015 年完成股改（注册资本三千万元），2016 年登陆新三板（股票代码 836388），成为国内螺旋升降机、电动缸第一股。',
      '廊坊大厂一期 8,000 m²（投资 5,000 万元、30 亩工业产权）、二期 28,000 m²（累计投资两亿元）生产基地，年产 5 万台；配备上百台数控加工设备，蜗杆、箱体、丝杠等关键零件全部自加工，不外协。',
      '质量与检测：100 吨加载测试中心可对大吨位产品满载荷跑合试验；进口三坐标测量仪、丝杠精度检测等手段覆盖来料、加工与出厂全流程；电缸逐台空载 / 负载跑合检验合格后出厂，随箱提供合格证与检验报告。',
      '伺服电动缸产品线覆盖 DMB（滚珠丝杠重载）、EMB（经济型）、FMR（行星滚柱重型）、GTR（一体化行星滚柱）四大系列，配套 SC 直连 / P10·P20 同步带平行 / 行星减速机等输入形式与全套安装、接头、附件，可为客户提供完整直线传动方案。',
      '全国 10 个办事处构成销售与服务网络，就近提供选型支持、安装指导与售后响应；产品广泛应用于汽车装备、自动化装备、冶金、航天航空军工、港口机械等行业。',
      '对特殊工况（高低温、真空、防腐、防爆等）具备成熟的定制经验：低温润滑脂与低温型电机、真空润滑脂、不锈钢丝杠 / 外壳、达克罗喷塑防腐、防爆电机等配置均可按需提供，并有同类项目业绩支撑。'
    ];
  }

  function featLines() {
    var raw = [
      '四大系列齐全：DMB 重载滚珠丝杠 / EMB 经济型 / FMR 行星滚柱重型 / GTR 一体化行星滚柱',
      '推力覆盖 0.5~1000 kN，同规格缸体比通用型紧凑，推力密度高',
      '重复精度可选 0.05 mm（轧制滚珠丝杠）/ 0.02 mm（磨制 GB）/ 0.01 mm（闭环光栅尺）',
      'FMR / GTR 行星滚柱丝杠：同体积下推力与寿命显著优于滚珠丝杠，适合重载高频工况',
      '输入形式模块化：SC 直连 / P10·P20 同步带平行 / 行星减速机（G05、GX），按工况自动配比',
      '可与任意品牌伺服驱动器匹配，反馈方式（旋变 / 增量 / 多圈绝对）按驱动器选配',
      '安装方式 7 种、前端接头 7 种，备件通用，现场改造与增补方便',
      '限位开关按型号标配（DMB / EMB / FMR：FCM 磁感应、FCP 接近开关；GTR：外置 L1/L2/L3，须同时选配 AR），防转 AR 按系列选配（GTR 为选配）',
      '采用进口散件组装：台湾滚珠丝杠、日本 NSK 轴承、德国欧比特同步带、德国 SICK 限位开关、德式密封圈、美孚润滑脂等',
      '低温 / 真空 / 防腐 / 防爆等特殊工况可定制，丝杠、缸筒、密封件按工况选材'
    ];
    return raw.map(function (s, i) { return (i < 9 ? '0' : '') + (i + 1) + '　' + s; });
  }

  function commFields() {
    return {
      TERM_PRICE: '本方案书不列价格明细，正式价格以商务报价单为准；报价有效期 30 天。',
      TERM_DELIVERY: '标准机型合同生效后 6–8 周交货；带特殊工况配置（低温/真空/防腐/防爆）或非标接口时，交期在合同确认时书面明确。',
      TERM_PAYMENT: '预付 30% 合同生效，发货前付清余款；长期合作客户可按年度框架协议执行。',
      TERM_WARRANTY: '自发货之日起 12 个月质保，非人为损坏免费维修或更换；非正常操作损坏除外。'
    };
  }

  function composeSpec(res, cal, data, opt) {
    opt = opt || {};
    var units = Number(cal.units) || 1;
    var fDesign = res.effective_load_kN;                       //
    var ann = res.annual_km;
    var m0 = (res.motor_recommend || [])[0];
    var code = suggestCode(cal, res);
    var meta = seriesMeta(cal.series);
    var jt = nameOfJoint(res.joint);
    var screwTxt = ({ '轧制': '轧制滚珠丝杠（精度 0.05mm，速度 <100mm/s）',
      '磨制': '磨制滚珠丝杠（精度 0.02mm，型号加 GB）',
      '梯形': '梯形丝杠（重复精度 0.1mm，自锁，整缸效率 30%）' })[res.screw_sel] || '';
    /*
*/
    var inputTxt = res.integrated ? '一体化行星丝杠（电机内置，无输入形式）'
      : (formSegOf(res) + '（' + formDetailOf(res) + '）');
    var accTxt2 = (res.accessories && res.accessories.length) ? accText(res)
      : (res.integrated ? '未选附件（GTR：AR 防转为选配）' : '标配');
    /*
*/
    var defM = (data && data.models && data.models[res.model]) || {};
    var speedMax = (res.max_speed_mm_s != null) ? res.max_speed_mm_s
      : (res.max_speed_of_variant != null ? res.max_speed_of_variant
        : (defM.max_speed_mm_s != null ? defM.max_speed_mm_s : null));
    var tempTxt = (cal.temp && cal.temp !== '20') ? '工作温度 ' + cal.temp + '℃，' : '';

    /**/
    var REQ_MOTION = '伺服电动缸 ' + (meta.t || cal.series) + '，' + units + ' 台'
      + (units > 1 ? '，' + cal.sync + '同步' : '')
      + (res.integrated
        ? '；一体化结构（电机内置，无输入形式）；伺服驱动器 ' + gtrDriveLabel(cal)
          + '，反馈方式 ' + (gtrFbLabel(cal) || '按下单驱动器型号确认')
        : '；输入形式 ' + inputTxt + '；伺服电机驱动（' + ((cal.brands || []).join('/') || '品牌待定') + '）');
    var REQ_LOAD = (cal.load_kN ? '总负载推力 ' + (Math.round(cal.load_kN * 10) / 10) + ' kN' : '')
      + (cal.load_pull_kN ? '，总负载拉力 ' + (Math.round(cal.load_pull_kN * 10) / 10) + ' kN' : '')
      + '；单缸设计负载 ' + fDesign + ' kN；校核用额定推力 ' + res.rated_kN + ' kN';
    var REQ_SPEED = '行程 ' + Math.round(cal.stroke) + ' mm，速度 ' + cal.speed_req + ' mm/s'
      + (cal.cycles_per_day ? '；' + cal.cycles_per_day + ' 次/日 × ' + (cal.days_per_year || 300) + ' 天/年' : '');
    var REQ_MOUNT = '安装方式 ' + installLabel(res.install) + '，前端接头 ' + jt + '；导向 ' + (cal.guide || '无')
      + '；防护等级 ' + (cal.ip || 'IP65')
      + ((!res.integrated && cal.encoder) ? '，编码器 ' + cal.encoder : '');
    var precTxt = (!res.precision || res.precision === '无') ? '按常规（0.05 mm 级）'
      : (res.precision === '梯形' ? '0.1 mm（梯形丝杠，自锁）' : res.precision + ' mm');
    /**/
    var limitTxt = res.std_limit ? ('标配 ' + res.std_limit + (isExMotor(res) ? '（防爆型）' : '')
        + (res.std_limit_hot_off ? '（+80℃ 不适用，高温不配磁感应限位开关，需按 FCP/耐高温型确认）' : ''))
      : (res.integrated
        ? ((res.accessories || []).indexOf('L2') >= 0 ? '外置 L2（同时配 AR）' : '按需求选配（P77 外置 L1/L2/L3，须同时配 AR）')
        : '按需求选配');
    var REQ_ENV = tempTxt + '限位开关 ' + limitTxt
      + '；重复精度 ' + precTxt
      + ((cal.special && cal.special.length) ? '；特殊要求：' + cal.special.join('/') : '');

    /**/
    var SUM_MODEL = code;
    var SUM_LOAD = '额定推力 ' + res.rated_kN + ' kN ≥ 单缸设计负载 ' + fDesign + ' kN'
      + (res.static_kN ? '；最大静载 ' + res.static_kN + ' kN' : '');
    var stabStep = (res.steps || []).filter(function (x) { return x[0] === '稳定性校核'; })[0];
    var SUM_STAB = stabStep ? stabStep[1] : (res.integrated
      ? 'GTR 一体化行星滚柱结构，样本无稳定性曲线要求，不校核'
      : '稳定性已按 2026 样本曲线校核');
    var SUM_RATIO = (screwTxt ? screwTxt + '；'
        : (res.integrated ? '行星滚柱丝杠（磨制，重复精度 0.02mm）；' : ''))
      + '导程 ' + res.lead_mm + ' mm；'
      + (res.integrated ? '一体化结构（电机内置，无输入形式、无减速机）'
        : ('输入形式 ' + formSegOf(res)
          + '（' + formDetailOf(res) + '）'));
    /*

*/
    var tqSample = res.torque_sample_Nm;
    var tqCmp = (tqSample != null && res.T_safety_Nm != null)
      ? (res.T_safety_Nm <= tqSample * 1.005 ? ' ≤ ' : ' ＞ ')
      : null;
    /*

*/
    var SUM_TORQUE = (function () {
      var compact = res.integrated
        ? ('丝杠端所需 T = ' + res.T_base_Nm + ' Nm × 1.2 安全系数 = ' + (res.T_safety_Nm != null ? res.T_safety_Nm : '—') + ' Nm'
          + (tqSample != null && tqCmp
            ? tqCmp + '样本额定传递扭矩 ' + tqSample + ' Nm（2 匝）' + (tqCmp === ' ＞ ' ? '，需与厂家确认' : '')
            : (tqSample != null ? '（样本额定传递扭矩 ' + tqSample + ' Nm，2 匝）' : '（样本额定传递扭矩与厂家确认）')))
        : ('丝杠端 T = ' + res.T_base_Nm + ' Nm × 1.2 安全系数'
          + (cal.sync === '机械' && units > 1 ? ' × ' + units + ' 台共轴' : '')
          + (cal.low_temp ? ' × ' + (cal.low_coef || 2) + '（低温）' : '')
          + (cal.sync === '电气' ? ' × 1.5（电气偏载）' : '')
          + ' → 电机端需求 ' + res.T_final_Nm + ' Nm'
          + (m0 ? ' ≤ ' + m0.brandFull + ' ' + m0.code + ' 额定 ' + m0.torque_Nm + ' Nm' : ''));
      var lines = [];
      ['驱动扭矩', '机械同步', '低温系数', '电气同步（电气偏载系数）'].forEach(function (k) {
        var t = '';
        (res.steps || []).forEach(function (x) { if (!t && x[0] === k) t = x[1]; });
        if (t) lines.push(k + '：' + t);
      });
      lines.push(compact);
      return lines.length > 1 ? lines.join('\n') : compact;
    })();
    var SUM_POWER_LINE = res.integrated
      ? '一体化内置电机：功率按样本电机定子绕组（2匝）配置；'
        + '所需推力 ' + (Math.round((res.effective_load_kN || 0) * 1000)) + ' N ≤ 额定 ' + (res.rated_kN * 1000) + ' N'
      : ('P = ' + (res.motor_sync || '—') + ' rpm × ' + res.T_final_Nm + ' Nm / 9550 = '
        + (res.motor_power_kW || '—') + ' kW'
        + (units > 1 ? '（每缸一台，总计 ' + (res.total_power_kW || res.motor_power_kW) + ' kW）' : ''));
    /*
*/
    var SUM_SPEED = (function () {
      var compact = res.integrated
        ? ('样本最高速度 ' + (speedMax != null ? speedMax : '—') + ' mm/s '
          + ((speedMax != null && cal.speed_req > speedMax * 1.001) ? '＜' : '≥') + ' 客户要求 ' + cal.speed_req + ' mm/s'
          + '（一体化内置电机，速度按行程/导程码订货）')
        : ('所需转速 ' + (res.rpm_needed || '—') + ' rpm ≤ 电机额定 ' + (res.motor_sync || '—') + ' rpm；'
          + '要求 ' + cal.speed_req + ' mm/s' + (speedMax != null ? ' ≤ 型号最大 ' + speedMax + ' mm/s' : '（型号最大速度按样本变型表校核）'));
      if (res.integrated) return compact;
      var t = '';
      (res.steps || []).forEach(function (x) { if (!t && x[0] === '速度校核') t = x[1]; });
      return t ? (t + '\n' + compact) : compact;
    })();
    /*


*/
    var SUM_DUTY_LINE = (function () {
      var compact = (res.screw_sel === '梯形')
        ? ('梯形丝杠不做 L10 寿命校核；按每日 ' + (cal.cycles_per_day || '—') + ' 次工作制判定'
          + '（基准 50 次/日，超过 50 次按负载率插值：负载率 50%→50 次、20%→100 次）'
          + (res.trap_duty && res.trap_duty.ok === false ? '；当前次数超过负载率允许上限 ' + res.trap_duty.max_cyc + ' 次/日，建议改选滚珠丝杠' : ''))
        : ((res.life_km != null ? '额定寿命 ' + res.life_km + ' km' : '寿命按样本额定动载校核')
          + (ann != null ? '（约 ' + ann + ' 年，按 ' + cal.cycles_per_day + ' 次/日推算）' : ''));
      var want = (res.screw_sel === '梯形') ? '工作制校核' : '寿命校核';
      var t = '';
      (res.steps || []).forEach(function (x) { if (!t && x[0] === want) t = x[1]; });
      if (res.screw_sel === '梯形') {
        /*
*/
        return t ? ('梯形丝杠不做 L10 寿命校核；' + t.replace(/^梯形丝杠：/, '')) : compact;
      }
      return t || compact;
    })();
var SUM_MOTOR_LINE = res.integrated
? ('GTR 一体化内置电机（定子 ' + (res.winding === 1 ? '158' : (res.winding === 3 ? '358' : '258')) + ' = ' + (res.winding || 2) + ' 匝 400V）；驱动器 ' + gtrDriveLabel(cal)
+ '；反馈方式 ' + gtrFbLabel(cal))
      : (m0 ? m0.brandFull + ' ' + cylCodeShown(m0) + '（' + m0.power_kW + ' kW / ' + m0.rpm + ' rpm / ' + m0.torque_Nm + ' Nm），'
        + (m0.flange ? m0.flange + '，' : '') + (cal.encoder || '增量型编码器') + '，'
        + (cylIsISMG2(m0.code) ? '不带制动（该系列无抱闸选配），制动须与汇川确认或另行解决' : '配制动器（带制动）')
        : '按所需 ' + (res.motor_power_kW || '—') + ' kW / ' + res.T_final_Nm + ' Nm / ' + (res.motor_sync || '—') + ' rpm 商务确认');
    var specials = [];
    if (cal.sync === '电气' && units > 1) specials.push('电气同步 ' + units + ' 台，功率放大 ×1.5');
    if (cal.sync === '机械' && units > 1) specials.push('机械同步 ' + units + ' 台共轴，扭矩 ×' + units);
    if (cal.low_temp) specials.push('低温 ' + ((cal.low_coef || 2) === 1.5 ? '-30℃ 档' : '-40℃ 级') + '，扭矩 ×' + (cal.low_coef || 2));
    if (cal.guide === '有') specials.push('带导向');
    var SUM_SPECIAL = specials.length ? specials.join('；') : '无（按常规工况）';
    /*
*/
    var extras = [];
    if (res.integrated) {
      if (res.static_kN != null) extras.push('最大静载 ' + Math.round(res.static_kN * 1000) + ' N');
      if (res.inertia_kgm2 != null) extras.push('电机转子惯量 ' + res.inertia_kgm2 + ' kg·m²');
      if (res.life_C != null) extras.push('额定动载 ' + Math.round(res.life_C * 1000) + ' N');
      if (res.weight_kg != null) extras.push('重量 ' + res.weight_kg + ' kg');
      if (res.current400_A != null) extras.push('400V 满载电流 ' + res.current400_A + ' A（直流单算）');
    }
    var SUM_EXTRA = extras.length ? extras.join('；') : '—';

    /**/
    var qtyMain = units;
    var qtyMotor = (cal.sync === '电气' ? units : 1);
    var items = [];
    /**/
    var mainHasSD = /行程/.test(res.variant || '');
    var mainSpec = ['额定推力 ' + res.rated_kN + ' kN（' + res.variant + '）'];
    if (!mainHasSD) mainSpec.push('行程 ' + Math.round(cal.stroke) + ' mm', '导程 ' + res.lead_mm + ' mm');
    /**/
    else if (res.integrated && cal.stroke != null) mainSpec.push('要求行程 ' + Math.round(cal.stroke) + ' mm');
    mainSpec.push('安装 ' + installLabel(res.install), '接头 ' + jt);
    /**/
    if (res.integrated) mainSpec.push('一体化行星滚柱丝杠（电机内置，无输入形式）');
    else mainSpec.push('输入 ' + inputTxt);
    if (screwTxt) mainSpec.push(screwTxt);
    if (res.precision && res.precision !== '无') mainSpec.push('重复精度 ' + (res.precision === '梯形' ? '0.1 mm' : res.precision + ' mm'));
    mainSpec.push('速度 ' + cal.speed_req + ' mm/s');
    if (cal.ip) mainSpec.push('防护 ' + cal.ip);
    if (cal.temp && cal.temp !== '20') mainSpec.push('工作温度 ' + cal.temp + ' ℃');
    mainSpec.push('附件 ' + accTxt2);
    /*
*/
    var priceTotal = 0, hasAnyPrice2 = false;
    var npSpec = cylNetPriceOf(res, cal, data);
    var mainItem = { desc: 'Lim-Tec 伺服电缸\n' + (code || ''), spec: mainSpec.join('；'), qty: qtyMain + ' 台' };
    if (npSpec && npSpec.hasPrice) {
      mainItem.unit_price = moneyTxt(npSpec.unit);
      mainItem.total_price = moneyTxt(npSpec.unit * qtyMain);
      priceTotal += npSpec.unit * qtyMain; hasAnyPrice2 = true;
    }
    items.push(mainItem);
    if (res.planetary) {
      /*
*/
      var hv195b = res.planetary.hv || null;
      var plItem = { desc: '行星减速机（自动匹配）', qty: qtyMotor + ' 台',
        spec: '速比 i=' + res.planetary.ratio + ':1，效率 ' + res.planetary.eta
          + '（标准比 3~10 档 0.90 / ≥15 档 0.80），机座号按电机法兰' };
      if (hv195b) {
        plItem.spec += '；选 ' + hv195b.model;
        if (hv195b.price != null) {
          plItem.unit_price = moneyTxt(hv195b.price);
          plItem.total_price = moneyTxt(hv195b.price * qtyMotor);
          priceTotal += hv195b.price * qtyMotor; hasAnyPrice2 = true;
        }
      } else {
        plItem.spec += '；i=' + res.planetary.ratio + ' 非 HV 标准速比档（标准比 3/4/5/7/10、12~28、60~175），型号与价格待询';
      }
      items.push(plItem);
    }
    if (res.integrated) {
      /**/
      var gDrv2 = gtrS120DriveOf(res, cal);
      var gSeg2 = ['SINAMICS S120（380V），暂配 S120（额定电流 ' + (gDrv2 ? gDrv2.aNeed : '—') + 'A，' + (res.winding || 2) + ' 匝 RMS）'];
      if (gDrv2) {
        gSeg2.push('功率单元 ' + gDrv2.pe.order + '（' + gDrv2.pe.kw + 'kW/' + gDrv2.pe.aL + 'A ≥ 额定）');
        gSeg2.push('CU310-2PN（' + gDrv2.cu.order + '）＋ CF 卡 ＋ 制动电阻');
      }
      gSeg2.push('反馈方式 ' + (gtrFbLabel(cal) || '—'));
      gSeg2.push('电机定子 ' + (res.winding === 1 ? '158' : (res.winding === 3 ? '358' : '258')) + '（' + (res.winding || 2) + ' 匝 400V）；连接接头 M；驱动器随机采购并调通（报价单注明）');
      var gItem = { desc: '伺服驱动器（西门子 S120）', qty: units + ' 台', spec: gSeg2.join('；') };
      if (gDrv2 && gDrv2.hasPrice) {
        gItem.unit_price = moneyTxt(gDrv2.unit);
        gItem.total_price = moneyTxt(gDrv2.unit * units);
        priceTotal += gDrv2.unit * units; hasAnyPrice2 = true;
      }
      items.push(gItem);
    } else {
      /**/
      if (m0) {
        var mdKit2 = cylMotorDrivePriceOf(m0, cal, res);
        var mseg2 = [m0.brandFull + ' ' + cylCodeShown(m0), '功率 ' + m0.power_kW + ' kW', '额定转速 ' + m0.rpm + ' rpm'];
        /**/
        if (cylOverPowerPw(m0, res) != null) mseg2.push('超功率，不建议选用');
        if (m0.torque_Nm != null) mseg2.push('额定扭矩 ' + m0.torque_Nm + ' N·m');
        if (m0.frame) mseg2.push('机座 ' + m0.frame);
        if (cylIsISMG2(m0.code)) mseg2.push('不带制动（该系列无抱闸选配）；制动须与汇川确认或另行解决');
        else mseg2.push('配制动器（带制动，立式安装/断电保持必配——滚珠/行星丝杠不自锁）');
        mseg2.push((mdKit2 && mdKit2.kitTxt) ? mdKit2.kitTxt
          : '配套驱动器（本方案必选）：驱动器按电机品牌配套选型；成套附件：动力/编码器电缆（长度按现场配置，价格另计）');
        if (m0.within_10pct) mseg2.push('（1.1 倍紧凑选型，标准档正好合适——安全系数按 1.1 凑标准功率档）');
        var mItem2 = { desc: '交流伺服电机驱动器', qty: qtyMotor + ' 台', spec: mseg2.join('；') };
        if (mdKit2 && mdKit2.hasPrice) {
          mItem2.unit_price = moneyTxt(mdKit2.unit) + (mdKit2.driveOnly ? '（仅驱动器，电机另询）' : '');
          mItem2.total_price = moneyTxt(mdKit2.unit * qtyMotor);
          priceTotal += mdKit2.unit * qtyMotor; hasAnyPrice2 = true;
        }
        items.push(mItem2);
      } else {
        items.push({ desc: '交流伺服电机', qty: qtyMotor + ' 台',
          spec: '按所需 ' + (res.motor_power_kW || '—') + ' kW / ' + res.T_final_Nm + ' Nm / ' + (res.motor_sync || '—') + ' rpm 选配（品牌与型号商务确认）' });
      }
    }
    /**/

    var comm = commFields();
    var feats = featLines();
    var abouts = aboutLines();
    var fields = {
      /**/
      DOC_TITLE: opt.docTitle || (units > 1 ? units + ' 台伺服电动缸选型方案书' : '伺服电动缸选型方案书'),
      DOC_SUBTITLE_EN: 'SERVO ELECTRIC CYLINDER　SELECTION & QUOTATION',
      META_CUSTOMER: opt.faxTo || '—',
      META_CONTACT: opt.faxAttn || '—',
      META_PROJECT: (opt.planTitle || '').replace(/　+/g, ' ') || '—',
      DOC_NO: opt.docNo || '',
      DOC_DATE: opt.docDate || '',
      META_AUTHOR: opt.faxFrom || '力姆泰克销售部',
      META_SALES: opt.faxSales || '',
      META_EMAIL: opt.faxEmail || 'sales@lim-tec.com',
      /**/
      REQ_MOTION: REQ_MOTION, REQ_LOAD: REQ_LOAD, REQ_SPEED: REQ_SPEED, REQ_MOUNT: REQ_MOUNT, REQ_ENV: REQ_ENV,
      /*
*/
      LAYOUT_CAPTION: res.integrated
        ? ('图：' + (meta.t || 'GTR 一体化行星丝杠电缸')
          + '　一体化结构（电机内置，无输入形式）；外形尺寸与接口以确认图为准')
        : ('图：' + (res.form_v === 'SC' ? 'SC 直线安装（电机直连）' : 'P10/P20 同步带平行安装')
          + '　输入形式与界面所选一致；外形尺寸与接口以确认图为准'),
      LAYOUT_PICK: layoutPickFor(cal, res).img || '',
      /**/
      SUM_MODEL: SUM_MODEL, SUM_LOAD: SUM_LOAD, SUM_STAB: SUM_STAB, SUM_RATIO: SUM_RATIO,
      SUM_TORQUE: SUM_TORQUE, SUM_POWER_LINE: SUM_POWER_LINE, SUM_SPEED: SUM_SPEED,
      SUM_DUTY_LINE: SUM_DUTY_LINE, SUM_MOTOR_LINE: SUM_MOTOR_LINE, SUM_SPECIAL: SUM_SPECIAL,
      SUM_EXTRA: SUM_EXTRA,
      /**/
      ITEMS: items,
      ITEM_PRICE_TOTAL: (hasAnyPrice2 && priceTotal > 0) ? moneyTxt(priceTotal) : '暂无价格',
      /*

*/
      QUOTE_NOTE: (function () {
        try {
          if (typeof window !== 'undefined' && window.LANG_I18N && typeof window.LANG_I18N.fxNote === 'function') {
            var n = window.LANG_I18N.fxNote();
            if (n) return String(n);
          }
        } catch (e) {}
        return '';
      })(),
      /**/
      TERM_PRICE: comm.TERM_PRICE, TERM_DELIVERY: comm.TERM_DELIVERY,
      TERM_PAYMENT: comm.TERM_PAYMENT, TERM_WARRANTY: comm.TERM_WARRANTY,
      /*
*/
      ABOUT: abouts.slice(0, 6),
      ABOUT_1: abouts[0], ABOUT_2: abouts[1], ABOUT_3: abouts[2],
      ABOUT_4: abouts[3], ABOUT_5: abouts[4], ABOUT_6: abouts[5],
      FEAT_1: feats[0], FEAT_2: feats[1], FEAT_3: feats[2], FEAT_4: feats[3], FEAT_5: feats[4],
      FEAT_6: feats[5], FEAT_7: feats[6], FEAT_8: feats[7], FEAT_9: feats[8], FEAT_10: feats[9],
      FEAT_KEEP: '5'
    };

    /*
*/
    (function p1AutoGap() {
      var toks = ['REQ_MOTION', 'REQ_LOAD', 'REQ_SPEED', 'REQ_MOUNT', 'REQ_ENV'];
      var lines = 0;
      toks.forEach(function (t) {
        var str = String(fields[t] || ''), w = 0;
        for (var i = 0; i < str.length; i++) w += (str.charCodeAt(i) > 255 ? 1 : 0.55);
        lines += Math.max(1, Math.ceil(w / 40));
      });
      var free = 3000 - (lines - 5) * 320;
      if (free < 0) free = 0;
      fields.GAP_TITLE_IMG = String(40 + Math.round(free * 0.10));
      fields.GAP_IMG_INFO = String(40 + Math.round(free * 0.15));
      fields.GAP_INFO_01 = String(130 + Math.round(free * 0.15));
      fields.P1_ROWH = String(230 + Math.floor(free * 0.60 / 5));
    })();

    /*
*/
    return { template: 'CY', fields: fields, items: [], zipDate: opt.docDate };
  }

  /**/
  function layoutPickFor(cal, res) {
    var isGtr = (res && res.integrated) || (cal && cal.series === 'GTR');
    if (isGtr) {
      var s = seriesMeta('GTR');
      return { img: s.img || 'cyl-gtr.png', label: s.t || 'GTR 一体化行星丝杠电缸' };
    }
    /**/
    var dmeImgs = { 'SC': 'cyl-form-sc-dme.jpg', 'P10/P20': 'cyl-form-belt-dme.jpg' };
    /*

*/
    var fv = String((cal && cal.form && cal.form.v) || (cal && cal.input_form) || '');
    var f = (D().input_forms || []).filter(function (x) { return x.v === fv; })[0];
    if (!f && cal && cal.belt_auto) f = (D().input_forms || []).filter(function (x) { return x.belt_auto; })[0];
    var img = (f && f.img) || 'cyl-form-belt.jpg';
    if (cal && (cal.series === 'DMB' || cal.series === 'EMB') && f && dmeImgs[f.v]) img = dmeImgs[f.v];
    /*

*/
    if (cal && cal.series === 'DMB' && f && f.v === 'P10/P20' && res) {
      var mfDmb = String(res.model || '').match(/^DMB(\d+)/i);
      var frnDmb = mfDmb ? parseInt(mfDmb[1], 10) : NaN;
      if (frnDmb === frnDmb) img = (frnDmb <= 50) ? 'cyl-form-belt-dme-s.jpg' : 'cyl-form-belt-dme-l.jpg';
    }
    return { img: img, label: (f && f.t) || '' };
  }

  function nameOfJoint(v) {
    var j = (D().joints || []).filter(function (x) { return x.v === v; })[0];
    return j ? j.t : (v || '');
  }

  /*
*/
  g.SJCylinderProduct = {
    id: 'cylinder',
    name: '伺服电缸',
    short: '电缸',
    desc: 'DMB 滚珠丝杠 · EMB 经济型 · GTR 一体化 · FMR 行星重型',
    status: 'ready',
    dataKey: 'SJ_CYL_DATA',

    SCHEMA: SCHEMA,
    defaultInput: defaultInput,
    loadUnitOptions: loadUnitOptions,
    UNIT_F: TAU,
    toCalc: toCalc,
    autoSelect: autoSelect,
    pickMotorOption: pickMotorOption,
    suggestCode: suggestCode,
    seriesInfoHTML: seriesInfoHTML,
    sidePanelHTML: sidePanelHTML,
    heroSub: heroSub,
    modelDetailHTML: modelDetailHTML,
    motorHTML: motorHTML,
    quoteTableHTML: quoteTableHTML,
    specNotes: specNotes,
    layoutImageFor: layoutImageFor,
    layoutPickFor: layoutPickFor,
    composeSpec: composeSpec,
    sanitizeInput: sanitizeInput,
    afterRun: afterRun,
    cylNetPriceOf: cylNetPriceOf,   /**/
    gtrS120DriveOf: gtrS120DriveOf
  };
  g.SJActuatorProduct = g.SJCylinderProduct;
})(typeof window !== 'undefined' ? window : globalThis);
