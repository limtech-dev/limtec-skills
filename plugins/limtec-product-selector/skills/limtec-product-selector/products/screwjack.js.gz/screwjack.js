/*


*/
(function (g) {
  'use strict';
  var C = g.SJCore;

  /*



*/
  var FAMILIES = {
    SJA: { route: 'A', screw: '梯形丝杠', label: 'SJA 梯形丝杠螺旋升降机',
      order: ['SJA5', 'SJA10', 'SJA20', 'SJA50', 'SJA80', 'SJA100', 'SJA200', 'SJA300', 'SJA450', 'SJA700', 'SJA1000'] },
    SJB: { route: 'A', screw: '滚珠丝杠', label: 'SJB 滚珠丝杠螺旋升降机',
      order: ['SJB10', 'SJB20', 'SJB21', 'SJB22', 'SJB50', 'SJB51', 'SJB80', 'SJB81', 'SJB100', 'SJB101', 'SJB200', 'SJB201', 'SJB300', 'SJB450'] },
    KV: { route: 'A', screw: '滚珠丝杠', label: 'KV 不锈钢螺旋升降机', order: ['KV60', 'KV85', 'KV100', 'KV120'] },
    EHB: { route: 'C', screw: '伞齿轮', label: 'EHB 伞齿轮升降机',
      order: ['EHB065', 'EHB095', 'EHB140', 'EHB160', 'EHB210', 'EHB250', 'EHB300'] },
    /*


*/
    DHB: { route: 'C', screw: '伞齿轮', label: 'EHB 伞齿轮升降机', order: ['DHB140'] },
    EHA: { route: 'C', screw: '伞齿轮', label: 'EHA 伞齿轮升降机（梯形丝杠）',
      order: ['EHA065', 'EHA095', 'EHA140', 'EHA160', 'EHA210', 'EHA250', 'EHA300'] },
    SCA: { route: 'A', screw: '梯形丝杠', label: 'SCA 梯形丝杠升降机推杆', order: [] },
    /*
*/
    SCB: { route: 'A', screw: '滚珠丝杠', label: 'SCB 滚珠丝杠升降机推杆', order: [] }
  };
  /*
*/
  var DEFAULT_FAMILIES = ['SJA', 'SCA', 'SJB', 'SCB', 'EHB'];   //

  /*


*/
  var bevelFamRe203 = /^EH[AB]/;
  function twinLineOf(code) {
    return String(code).replace(/^EHB(?=\d)/, 'EIB').replace(/^EHA(?=\d)/, 'EIA');
  }
  function twinAngleOf(code) {
    return String(code).replace(/^EHB(?=\d)/, 'ELB').replace(/^EHA(?=\d)/, 'ELA');
  }
  /**/
  function twinLineTag(code) { return /^EHA/.test(String(code)) ? 'EIA' : 'EIB'; }
  function twinAngleTag(code) { return /^EHA/.test(String(code)) ? 'ELA' : 'ELB'; }

  /*
*/
  function productLabelOf(fam) {
    var def = FAMILIES[fam];
    if (def && def.label) return 'Lim-Tec ' + String(def.label).replace(/^[A-Z]+\s*/, '');
    return 'Lim-Tec 机械螺旋升降机';
  }
  function seriesOf(cal, res) {
    /**/
    if (cal && cal.cross_fam) return cal.cross_fam;
    if (cal && cal.series && cal.series !== 'auto') return cal.series;
    return String((res && res.model) || '').replace(/[0-9].*$/, '');
  }
  /*
*/
  function screwPickText(cal) {
    var p = (cal && cal.precision_mm !== undefined) ? cal.precision_mm : null;
    if (p === null || p === undefined) return '无要求';
    if (Number(p) === 0.02) return '磨制滚珠丝杠（重复精度 0.02mm，附件 GB）';
    if (Number(p) === 0.1) return '梯形丝杠（重复精度 0.1mm，自锁）';
    if (Number(p) === 0.05) return '轧制滚珠丝杠（重复精度 0.05mm）';
    return p + ' mm';
  }

  /*
*/
  var CAT = g.SJCatalog || { SERIES: [], UNITS: null, DRIVES: null, TEMPS: null, SPECIALS: [], SHAFT_DIRS: null, JOINTS: null, ACCESSORIES: [] };

  /*



*/
  var ACCESSORIES_NO_R = ['AR', 'FCP', 'FCG'];
  /*
*/
  function isMotionR(inp) {
    if (!inp) return false;
    var se = String(inp.series || '');
    if (se === 'SCA' || se === 'SCB') return false;
    return String(inp.motion) === 'R';
  }
  /*





*/
  function mountingOptions(inp) {
    var se = String((inp && inp.series) || '').toUpperCase();
    var mo = ((inp && inp.motion) === 'R') ? 'R' : 'S';
    if (se === 'SCA' || se === 'SCB') {
      return [
        { v: '地脚安装', t: '地脚安装（fk=0.7）' },
        { v: '耳轴安装', t: '耳轴（尾部铰接）安装（fk=1）' },
        { v: '导向杆安装', t: '导向杆安装（fk=1.25）' }
      ];
    }
    var fFoot = 1, fTrun = 2;
    if (se === 'EHB' || se === 'EHA') { fFoot = (mo === 'R') ? 2 : 1; }
    else if (se === 'KV' || se === 'SJA' || se === 'SJB') { fFoot = (mo === 'R') ? 2.5 : 1; fTrun = (mo === 'R') ? 2.5 : 2; }
    return [
      { v: '地脚安装', t: '地脚安装（fk=' + fFoot + '）' },
      { v: '耳轴安装', t: '耳轴安装（fk=' + fTrun + '）' },
      { v: '导向杆安装', t: '导向杆安装（fk=2.5）' }
    ];
  }
  /**/
  function accessoriesFor(inp) {
    var list = CAT.ACCESSORIES || [];
    if (!isMotionR(inp)) return list;
    return list.filter(function (a) { return !a.noR && ACCESSORIES_NO_R.indexOf(a.v) < 0; });
  }
  /**/
  function sanitizeAccessories(inp) {
    if (!isMotionR(inp)) return inp;
    if (Array.isArray(inp.accessories)) {
      var kept = inp.accessories.filter(function (v) { return ACCESSORIES_NO_R.indexOf(v) < 0; });
      if (kept.length !== inp.accessories.length) inp.accessories = kept;
    }
    if (inp.joint && inp.joint !== 'std') inp.joint = 'std';
    return inp;
  }

  var SCHEMA = [
    /**/
    { key: 'series', label: '型号系列', type: 'select', def: 'SJA', group: '选择1 · 型号系列', required: true,
      options: (CAT.SERIES.length ? CAT.SERIES.map(function (x) { return { v: x.v, t: x.name }; })
        : [{ v: 'SJA', t: '梯形丝杠螺旋升降机 SJA' }, { v: 'SJB', t: '滚珠丝杠螺旋升降机 SJB' },
           { v: 'EHB', t: '伞齿轮螺旋升降机 EHB' }, { v: 'KV', t: '不锈钢螺旋升降机 KV' },
           { v: 'SCA', t: '梯形丝杠升降机推杆 SCA' }, { v: 'SCB', t: '滚珠丝杠升降机推杆 SCB' }]),
      hint: '选择系列后，下方显示该系列图片与技术参数说明；右侧快捷通道可按型号直查参数' },
    /**/
    { key: 'motion', label: '运动方式', type: 'radio', wide: true, def: 'S', group: '选择2 · 运动方式',
      showWhen: { seriesIn: ['SJA', 'SJB', 'EHB', 'KV'] },
      options: [{ v: 'S', t: '丝杠运动螺旋升降机' }, { v: 'R', t: '螺母运动螺旋升降机' }] },
    { key: 'kv_mode', label: 'KV 安装形式', type: 'select', def: 'KVL', group: '选择2 · 运动方式',
      showWhen: { series: 'KV' }, options: [{ v: 'KVL', t: 'KVL 地脚安装' }, { v: 'KVK', t: 'KVK 耳轴安装' }] },
    /**/
    { key: 'units', label: '台数 / 布置', type: 'select', unit: '', def: '1', required: true, group: '选择3 · 台数与布置',
      options: (CAT.UNITS || [{ v: '1', t: '1' }]),
      /**/
      optionsFn: function (inp) {
        var arr = CAT.UNITS || [{ v: '1', t: '1' }];
        if (inp && inp.series === 'EHB') {
          arr = arr.filter(function (o) { return o.v !== '6'; });
        }
        return arr;
      },
      hint: '多台默认机械同步；选「非标布置」时请填写实际台数并上传布置图' },
    { key: 'custom_units', label: '非标布置 · 实际台数', type: 'number', unit: '台', step: 1, def: 2, group: '选择3 · 台数与布置',
      showWhen: { units: 'custom' }, required: true },
    { key: 'layout', label: '布置形式', type: 'imgpick', def: '', group: '选择3 · 台数与布置',
      showWhen: { unitsNot: 'custom' }, optionsFn: function (inp) { return layoutOptions(inp); } },
    /**/
    { key: 'load', label: '总负载推力', type: 'number', unit: '', step: 'any', def: null, group: '选择4 · 基本参数', withUnit: true, unitKey: 'load_unit',
      hint: '拉力工况可不填（按 0 计算）；总负载推力 / 总负载拉力至少填写一项' },
    { key: 'load_pull', label: '总负载拉力', type: 'number', step: 'any', def: null, group: '选择4 · 基本参数',
      withUnit: true, unitKey: 'load_pull_unit',
      unit: function (inp) { return unitSuffix((inp && inp.load_pull_unit) || 't'); },
      hint: '拉力工况不校核稳定性；单位独立可选（默认随界面语言：中文吨 / 外语 kN）' },
    { key: 'static_load', label: '静载', type: 'number', step: 'any', def: null, group: '选择4 · 基本参数',
      withUnit: true, unitKey: 'static_load_unit',
      unit: function (inp) { return unitSuffix((inp && inp.static_load_unit) || 't'); } },
    { key: 'speed_mm_s', label: '速度', type: 'number', unit: 'mm/s', step: 'any', def: null, required: true, group: '选择4 · 基本参数' },
    { key: 'stroke_mm', label: '行程', type: 'number', unit: 'mm', step: 'any', def: null, required: true, group: '选择4 · 基本参数' },
    { key: 'guide', label: '是否有导向', type: 'radio', def: '无', group: '选择4 · 基本参数', options: [{ v: '有', t: '有（客户自备导轨/导向杆）' }, { v: '无', t: '无' }] },
    { key: 'mounting', label: '安装方式（无导向时影响稳定性）', type: 'select', def: '地脚安装', group: '选择4 · 基本参数', showWhen: { guide: '无' },
      options: [{ v: '地脚安装', t: '地脚安装（fk=1）' }, { v: '耳轴安装', t: '耳轴安装（fk=2）' }, { v: '导向杆安装', t: '导向杆安装（fk=2.5）' }],
      /**/
      optionsFn: function (inp) { return mountingOptions(inp); } },
    { key: 'cycles_per_day', label: '每日工作次数', type: 'number', unit: '次/天', step: 1, def: 50, group: '选择4 · 基本参数' },
    { key: 'hours_per_day', label: '每日工作小时', type: 'number', unit: '小时', step: 1, def: 8, group: '选择4 · 基本参数' },
    { key: 'days_per_year', label: '每年工作天数', type: 'number', unit: '日', step: 1, def: 300, group: '选择4 · 基本参数' },
    { key: 'drive', label: '驱动选择', type: 'select', def: 'ac3', group: '选择4 · 基本参数',
      /*
*/
      optionsFn: function (inp) {
        var drvElec = !!(inp && inp.sync === '电气' && effUnits(inp) > 1);
        return (CAT.DRIVES || [{ v: 'ac3', t: '三相交流电机' }]).map(function (o) {
          if (drvElec && String(o.v).indexOf('servo') !== 0) return { v: o.v, t: o.t, dis: true };
          return o;
        });
      } },
    /*

*/
    { key: 'servo_brand', label: '伺服品牌（可多选）', type: 'checks', def: [], group: '选择4 · 基本参数',
      showWhen: { drive: ['servo220', 'servo380'] },
      options: [
        { v: '汇川', t: '汇川（SV630 / SV660 + MS1 系列，1500 / 3000rpm）' },
        { v: 'V90', t: '西门子 V90（1FL6）' },
        { v: 'S200', t: '西门子 S200（1FL2）' },
        { v: 'S120', t: '西门子 S120（1FK7）' },
        { v: '台达', t: '台达（ASDA-A3 + ECMA 系列，220V 为主）' },
        { v: '雷赛', t: '雷赛（L7 / ACM2 系列，380V 1500rpm 为主）' },
        { v: '惠斯通', t: '惠斯通防爆（ST-EX 系列，隔爆 Ex d IIB T4 Gb，3000rpm 为主 + 折算档）' }
      ],
      hint: '不勾选 = 已接入常规品牌全部参与（默认，推荐）；勾选后电机表只在该品牌内选型。西门子 S120 一般由「特殊要求 · 伺服电机品牌要求」指定，此处勾选等效。惠斯通防爆为特殊工况电机，须显式勾选才进入选型（防爆工况才选）。' },
    { key: 'life_years', label: '寿命要求', type: 'number', unit: '年', step: 1, def: 5, group: '选择4 · 基本参数',
      hint: '寿命校核目标年限，默认 5 年；按每日工作次数 × 年工作天数 × 行程折算理论寿命' },
    /*


*/
    { key: 'precision_mm', label: '重复精度要求',
      labelFn: function (inp) { return (inp && inp.series === 'EHB') ? '丝杠选择' : '重复精度要求'; },
      type: 'select', def: '无', group: '选择4 · 基本参数',
      options: [{ v: '无', t: '无要求' }, { v: '0.1', t: '0.1 mm' }, { v: '0.05', t: '0.05 mm（只有滚珠丝杠可以达到）' }],
      optionsFn: function (inp) {
        if (!inp || inp.series !== 'EHB') return this.options;
        var v = Number(inp.speed_mm_s) || 0;
        var trap = { v: '0.1', t: '梯形丝杠（重复精度 0.1mm，自锁，型号改为 EHA）' };
        if (v >= 100) return [{ v: '0.02', t: '磨制滚珠丝杠（重复精度 0.02mm，默认，附件加 GB）' }, trap];
        return [{ v: '0.05', t: '轧制滚珠丝杠（重复精度 0.05mm，默认）' }, trap];
      } },
    { key: 'ambient_temp', label: '工作温度要求', type: 'select', unit: '℃', def: '20', group: '选择4 · 基本参数',
      options: (CAT.TEMPS || [{ v: '20', t: '+20' }]) },
    { key: 'env', label: '使用环境', type: 'select', def: '室内', group: '选择4 · 基本参数', options: [{ v: '室内', t: '室内常温' }, { v: '室外', t: '室外' }, { v: '洁净间', t: '洁净间' }, { v: '腐蚀潮湿', t: '腐蚀 / 潮湿（建议 KV 不锈钢）' }] },
    /*

*/
    { key: 'selflock', label: '需要自锁', type: 'radio', def: '否', group: '选择4 · 基本参数', showWhen: { seriesNot: ['EHB', 'EHA'] }, options: [{ v: '否', t: '否' }, { v: '是', t: '是（梯形丝杠）' }] },
    { key: 'sync', label: '同步方式', type: 'select', def: '机械', group: '选择4 · 基本参数', showWhen: { unitsNot: ['1', 'custom'] }, options: [{ v: '机械', t: '机械同步（默认）' }, { v: '电气', t: '电气同步' }] },
    /*
*/
    /*



*/
    { key: 'platform_L', label: '平台长度', type: 'number', unit: 'mm', step: 'any', def: null, group: '选择4 · 基本参数',
      showWhen: { sync: '机械', unitsIn: ['2', '3', '4', '6', '8'] }, },
    { key: 'platform_W', label: '平台宽度', type: 'number', unit: 'mm', step: 'any', def: null, group: '选择4 · 基本参数',
      showWhen: { sync: '机械', unitsIn: ['3', '4', '6', '8'] }, },
    { key: 'special', label: '特殊要求', type: 'checks', def: [], group: '选择4 · 基本参数', textable: true,
      options: (CAT.SPECIALS || []) },
    /**/
    /*




*/
    { key: 'input_type', label: '安装方式', type: 'imgpick', def: 'P1', group: '型号与附件',
      options: [{ v: 'P1', t: 'P1（单输入轴）', img: 'mount-p1.png' },
                { v: 'P2', t: 'P2（双输入轴）', img: 'mount-p2.png' },
                { v: 'P3', t: 'P3（单电机法兰输入）', img: 'mount-p3.png' },
                { v: 'P4', t: 'P4（电机法兰+轴）', img: 'mount-p4.png' }],
      optionsFn: function (inp) {
        if (inp && inp.series === 'EHB') {
          /*
*/
          if (Number(inp.precision_mm) === 0.1) {
            return [{ v: 'EHA', t: 'EHA（单轴布置·1个换向器·电机法兰输入）', img: 'ehb-mount-ehb.png' },
                    { v: 'EIA', t: 'EIA（直线双轴·1个换向器·电机法兰输入）', img: 'ehb-mount-eib.png' },
                    { v: 'ELA', t: 'ELA（直角双轴·2个换向器·电机法兰输入）', img: 'ehb-mount-elb.png' },
                    { v: 'EUA', t: 'EUA（三轴布置·3个换向器·电机法兰输入）', img: 'ehb-mount-eub.png' },
                    { v: 'EQA', t: 'EQA（四轴布置·4个换向器·电机法兰输入）', img: 'ehb-mount-eqb.png' }];
          }
          return [{ v: 'EHB', t: 'EHB（单轴布置·1个换向器·电机法兰输入）', img: 'ehb-mount-ehb.png' },
                  { v: 'EIB', t: 'EIB（直线双轴·1个换向器·电机法兰输入）', img: 'ehb-mount-eib.png' },
                  { v: 'ELB', t: 'ELB（直角双轴·2个换向器·电机法兰输入）', img: 'ehb-mount-elb.png' },
                  { v: 'EUB', t: 'EUB（三轴布置·3个换向器·电机法兰输入）', img: 'ehb-mount-eub.png' },
                  { v: 'EQB', t: 'EQB（四轴布置·4个换向器·电机法兰输入）', img: 'ehb-mount-eqb.png' }];
        }
        return this.options;
      } },
    { key: 'shaft_dir', label: '轴和电机法兰方向', type: 'radio', wide: true, def: 'RH', group: '型号与附件',
      showWhen: { motionNot: 'R', input_typeNot: 'P2', seriesNot: 'EHB' },   /**/
      options: (CAT.SHAFT_DIRS || [{ v: 'RH', t: '右输入 RH（标配）' }, { v: 'LH', t: '左输入 LH' }]) },
    { key: 'joint', label: '接头形式', type: 'imgpick', def: 'std', group: '型号与附件',
      showWhen: { motionNot: 'R' },      /**/
      options: (CAT.JOINTS || [{ v: 'std', t: '法兰端 FL' }]) },
    { key: 'accessories', label: '附件选择', type: 'checks', def: ['AR'], group: '型号与附件',
      /**/
      optionsFn: function (inp) { return accessoriesFor(inp); },
      hint: function (inp) {
        return isMotionR(inp)
          ? '螺母运动 R：防转 AR、限位开关 FCP/FCG、各类接头（FL/TS/TF/FO/NF）均不适用，已自动取消，无需选配。'
          : '';
      },
      options: (CAT.ACCESSORIES || []) }
  ];

  /*
*/
  var LOAD_UNITS = { t: 9.81, kN: 1, kgf: 0.00981, N: 0.001 };   // → kN

  function loadUnitOptions() {
    return [{ v: 't', t: '吨（t）' }, { v: 'kN', t: '千牛（kN）' }, { v: 'kgf', t: '公斤力（kgf）' }, { v: 'N', t: '牛（N）' }];
  }

  /**/
  function langIsZh() { try { var L = g.LANG_I18N && g.LANG_I18N.lang; return !L || L === 'zh'; } catch (e) { return true; } }
  function defLoadUnit() { return langIsZh() ? 't' : 'kN'; }
  function unitSuffix(u) { return u === 't' ? (langIsZh() ? 't' : 'tons') : (u || 't'); }

  function defaultInput() {
    var o = { load_unit: defLoadUnit(), load_pull_unit: defLoadUnit(), static_load_unit: defLoadUnit() };
    SCHEMA.forEach(function (f) { o[f.key] = f.def; });
    return o;
  }

  /**/
  /**/
  function driveToMotor(drive) {
    return { hand: '手摇（手摇轮驱动）', none: '无电机（客户自配，按电机技术要求选配）',
      ac3: '380V/220V三相交流电机', ac1: '单相220V交流电机', dc24: '直流电机 24VDC',
      servo220: '交流伺服电机', servo380: '交流伺服电机', stepper: '步进电机' }[drive] || '380V/220V三相交流电机';
  }
  function driveLabel(drive) {
    var o = (g.SJCatalog ? g.SJCatalog.DRIVES : []).filter(function (x) { return x.v === drive; })[0];
    return o ? o.t : driveToMotor(drive);
  }
  /**/
  function effUnits(inp) {
    var u = String(inp.units);
    if (u === 'custom') return Math.max(1, Math.round(Number(inp.custom_units) || 1));
    return Math.max(1, Math.round(Number(u) || 1));
  }

  function toCalc(input) {
    var loadKN = (Number(input.load) || 0) * (LOAD_UNITS[input.load_unit] || 9.81);
    var prec = String(input.precision_mm == null ? '' : input.precision_mm).trim();
    /*

*/
    if (input.series === 'EHB') {
      var vS201 = Number(input.speed_mm_s) || 0;
      var okVals = (vS201 >= 100) ? ['0.02', '0.1'] : ['0.05', '0.1'];
      if (okVals.indexOf(prec) < 0) prec = okVals[0];
    }
    var precNum = (prec === '' || prec === '无') ? null : Number(prec);
    var mounting = (input.guide === '无') ? (input.mounting || '地脚安装') : '导向杆安装';
    /*
*/
    var pullT = (Number(input.load_pull) || 0)
      * ((LOAD_UNITS[input.load_pull_unit] || LOAD_UNITS.t) / 9.81);
    var units = effUnits(input);
    return {
      raw: input,
      units: units,
      isCustomLayout: String(input.units) === 'custom',
      loadKN: loadKN,
      load_pull_t: pullT,
      pullDominant: pullT > 0 && pullT * 9.81 > loadKN,   //
      static_load_t: (Number(input.static_load) || 0)
        * ((LOAD_UNITS[input.static_load_unit] || LOAD_UNITS.t) / 9.81),
      loadKN_eff: Math.max(loadKN, pullT * 9.81),          //
      stroke_mm: Number(input.stroke_mm) || 0,
      speed_mm_s: Number(input.speed_mm_s) || 0,
      cycles_per_day: (input.cycles_per_day === '' || input.cycles_per_day == null) ? null : Number(input.cycles_per_day),
      hours_per_day: (input.hours_per_day === '' || input.hours_per_day == null) ? 8 : Number(input.hours_per_day),
      days_per_year: (input.days_per_year === '' || input.days_per_year == null) ? 300 : Number(input.days_per_year),
      /**/
      life_years: (isFinite(Number(input.life_years)) && Number(input.life_years) > 0) ? Number(input.life_years) : 5,
      /*
*/
      motion: (input.series === 'SCA' || input.series === 'SCB') ? 'S' : (input.motion || 'S'),
      kv_mode: input.kv_mode || 'KVL',
      mounting: mounting,
      /*

*/
      guide: (input.guide === '无') ? '无' : '有',
      /**/
      layout: (input.drive === 'hand' && input.layout === '电机一体化') ? '无电机' : (input.layout || ''),
      env: input.env || '室内',
      ambient_temp: (input.ambient_temp === '' || input.ambient_temp == null) ? 20 : Number(input.ambient_temp),
      precision_mm: precNum,
      selflock: input.selflock === '是',
      sync: units > 1 ? (input.sync || '机械') : '单台',
      drive: input.drive || 'ac3',
      drive_label: driveLabel(input.drive),
      motor_type: driveToMotor(input.drive),
      /*


*/
      motor_rpm: (function () {
        var ac = (input.drive === 'ac3' || input.drive === 'ac1');
        var dc233 = input.drive === 'dc24';
        if (input.motor_rpm === 'auto' || input.motor_rpm === '' || input.motor_rpm == null) return (ac || dc233) ? null : 1500;
        var n = Number(input.motor_rpm);
        if (!isFinite(n)) return (ac || dc233) ? null : 1500;
        if (ac && n > 1800) return 1500;
        return n;
      })(),
      special: Array.isArray(input.special) ? input.special.slice() : [],
      /**/
      servo_brand: Array.isArray(input.servo_brand) ? input.servo_brand.slice() : [],
      /*
*/
      speed_allow_pct: (function () {
        var a = Number(input.speed_allow_pct);
        return (a > 0) ? Math.min(50, Math.max(20, a)) : 25;
      })(),
      /**/
      special_texts: (input.special_texts && typeof input.special_texts === 'object')
        ? (function (o) { var c = {}, k; for (k in o) c[k] = o[k]; return c; })(input.special_texts) : {},
      shaft_dir: input.shaft_dir || 'RH',
      /*





*/
      input_type: (function () {
        var u = units, syncM = u > 1 ? (input.sync || '机械') === '机械' : false;
        var isEHB = (input.series || '') === 'EHB';
        /**/
        var isEHA = isEHB && Number(input.precision_mm) === 0.1;
        if (!syncM) return isEHB ? (input.input_type || (isEHA ? 'EHA' : 'EHB')) : (input.input_type || 'P1');
        var L = input.layout;
        if (isEHB) {
          if (L === '电机单侧' || L === '直线布置-电机单侧' || L === '直线布置') return isEHA ? 'EIA' : 'EIB';
          return isEHA ? 'EHA' : 'EHB';
        }
        if (L === '电机单侧' || L === '直线布置-电机单侧') return 'P4';
        /**/
        if (L === '直线布置') return (u === 4 || u === 6 || u === 8) ? 'P2' : 'P4';
        if (L === '电机中间' || L === '垂直布置-电机中间') return 'P2';
        if (isRevLayout(String(L || ''))) return 'P2';   /**/
        return input.input_type || 'P1';
      })(),
      joint: input.joint || 'std',
      /**/
      accessories: (function () {
        var list = Array.isArray(input.accessories) ? input.accessories.slice() : ['AR'];
        return isMotionR(input) ? list.filter(function (v) { return ACCESSORIES_NO_R.indexOf(v) < 0; }) : list;
      })(),
      series: input.series || 'auto'
    };
  }

  /**/
  function pickFamilies(cal) {
    /*

*/
    if (cal.series === 'EHB' && cal.precision_mm === 0.1) return ['EHA'];
    if (cal.series && cal.series !== 'auto') return [cal.series];
    var wet = /腐蚀|潮湿/.test(cal.env);
    var highSpeed = cal.speed_mm_s >= 30;                 //
    var highFreq = (cal.cycles_per_day || 0) > 200;        //
    var hiPrec = (cal.precision_mm !== null && cal.precision_mm <= 0.05);  //
    var fams = [];
    if (cal.selflock) return ['SJA'];                      //
    if (wet) fams.push('KV');                              //
    if (hiPrec || highSpeed || highFreq) {
      fams = fams.concat(['SJB', 'SCB', 'EHB']);           //
    } else {
      fams = fams.concat(DEFAULT_FAMILIES);
    }
    var seen = {}, out = [];
    fams.forEach(function (f) { if (FAMILIES[f] && !seen[f]) { seen[f] = 1; out.push(f); } });
    return out;
  }

  /*


*/
  var SYNC2ACTUAL = { 3000: 2800, 1500: 1400, 1000: 900, 750: 700 };
  /**/
  var POLES = [[1500, 1400], [1000, 900], [750, 700]];
  function actualRpm(motorRpm) {
    var r = Number(motorRpm) || 1500;
    return SYNC2ACTUAL[r] || r;
  }
  function isAcDrive(cal) { return cal.drive === 'ac3' || cal.drive === 'ac1'; }
  /*


*/
  var DC_POLES_233 = [[1500, 1500], [3000, 3000]];
  function isFixDrive233(cal) { return isAcDrive(cal) || cal.drive === 'dc24'; }
  function isDcDrive233(cal) { return cal.drive === 'dc24'; }
  function polesDomain233(cal) { return isDcDrive233(cal) ? DC_POLES_233 : POLES; }
  function ratiosFor(m, cal) {
    var opt = m.ratio_options || {};
    var keys = Object.keys(opt);
    if (!keys.length) return [];
    var vReq = Number(cal.speed_mm_s) || 0;
    var syncs = (cal.motor_rpm == null && isFixDrive233(cal))
      ? polesDomain233(cal)
      : [[Number(cal.motor_rpm) || 1500, actualRpm(cal.motor_rpm)]];
    /*
*/
    var bestFast = null, bestSlow = null;
    keys.forEach(function (k) {
      var mm = Number(opt[k].mm_per_rev) || 0;
      if (mm <= 0) return;
      var fast = /V/i.test(k);
      syncs.forEach(function (ps) {
        var va = ps[1] / 60 * mm;
        var score = Math.abs(va - vReq) + (va >= vReq ? 0 : 1e-6) + ps[1] * 1e-12; /**/
        var slot = fast ? 'fast' : 'slow';
        var best = fast ? bestFast : bestSlow;
        if (!best || score < best.score - 1e-12) {
          var pick = { k: k, sync: ps[0], score: score };
          if (fast) bestFast = pick; else bestSlow = pick;
        }
      });
    });
    var out = [];
    /*
*/
    var hand = cal.drive === 'hand';
    if (hand && bestSlow) out.push({ ratio_key: bestSlow.k, sync: bestSlow.sync });
    if (bestFast && (!bestSlow || bestSlow.k !== bestFast.k)) out.push({ ratio_key: bestFast.k, sync: bestFast.sync });
    if (!hand && bestSlow && (!bestFast || bestSlow.k !== bestFast.k)) out.push({ ratio_key: bestSlow.k, sync: bestSlow.sync });
    return out;
  }

  /*





*/
  var SERVO_RATED_C = [3000, 2000];
  /*


*/
  function servoRatedPriority(estKw, brand) {
    var p = (estKw == null || !isFinite(Number(estKw))) ? null : Number(estKw);
    /*



*/
    if (p !== null && p < 0.75 - 1e-9) return [3000];
    return servoIsSiemensBrand(brand) ? [2000, 3000] : [1500, 2000, 2500, 3000];
  }
  /**/
  function servoIsSiemensBrand(brand) {
    var arr = Array.isArray(brand) ? brand.filter(function (b) { return String(b || '').trim(); }) : (brand ? [brand] : []);
    if (!arr.length) return true;
    return arr.every(function (b) { return /西门子|V90|S200|S120/i.test(String(b || '')); });
  }
  /*
*/
  /*
*/
  var REV_RATIOS = [1, 2, 3, 5, 6, 8, 10, 15, 20, 25, 30, 40, 50];
  /*
*/
  var AC_REV_RATIOS = [2, 3, 5, 6, 8, 10, 15, 20, 25, 30, 40, 50];
  /*





*/
  var SJ_EHB_DUAL = false;
  /*


*/
  /*
*/
  /*
*/
  var PLANET_RATIOS = [3, 4, 5, 7, 10, 12, 15, 16, 20, 25, 28, 30, 40, 50, 60, 64, 70, 75, 80, 100, 125, 140, 160, 175];
  function gearOf(m) {
    var s = String(gv2(m, 'gear_ratio', '')), p = s.split(':');
    var g = p.length > 1 ? Number(p[1]) / Number(p[0]) : Number(s);
    return (isFinite(g) && g > 0) ? g : 2;
  }
  function gv2(o, k, d) { return (o && o[k] != null) ? o[k] : d; }
  /*



*/
  function pickServoRatedRev(needJackRpm, vReq, estKw, forcedSync, revList, preferMaxRev, brand) {
    if (!(vReq > 0) || !(needJackRpm > 0)) return { sync: 3000, rev: 1 };
    var best = null, fallback = null;
    var REVLIST = (Array.isArray(revList) && revList.length) ? revList : REV_RATIOS;
    /**/
    var prioList = forcedSync ? [forcedSync] : servoRatedPriority(estKw, brand);
    prioList.forEach(function (rated) {
      var iTotal = rated / needJackRpm;          /* vAct/vReq = iTotal/rev */
      var rev = null;
      if (preferMaxRev) {
        /*

*/
        if (best) return;
        for (var iM = 0; iM < REVLIST.length; iM++) {
          if (REVLIST[iM] <= iTotal + 1e-9 && rated / REVLIST[iM] <= 1500 + 1e-9) rev = REVLIST[iM];
        }
        if (rev === null) {
          /**/
          rev = 1;
          var ovF0 = (iTotal / rev - 1) * 100;
          if (!fallback || Math.abs(ovF0) < Math.abs(fallback.over) - 1e-9) {
            fallback = { sync: rated, rev: rev, over: ovF0, neg: true };
          }
          return;
        }
        var overM = (iTotal / rev - 1) * 100;
        best = { sync: rated, rev: rev, over: overM, neg: overM < -1e-9 };
        return;
      }
      for (var i = 0; i < REVLIST.length; i++) {
        if (REVLIST[i] <= iTotal + 1e-9) rev = REVLIST[i];   /**/
      }
      if (rev === null) rev = 1;                 /**/
      var over = (iTotal / rev - 1) * 100;
      var cand = { sync: rated, rev: rev, over: over, neg: over < -1e-9 };
      if (preferMaxRev) {
        /**/
      } else {
        /*




*/
        var prioP = forcedSync ? [forcedSync] : servoRatedPriority(estKw, brand);
        if (!forcedSync && !servoIsSiemensBrand(brand)) prioP = prioP.concat([1500]);
        prioP.forEach(function (rt) {
          var iT = rt / needJackRpm;
          REVLIST.forEach(function (rv) {
            var ov = (iT / rv - 1) * 100;
            if (ov > 20 + 1e-9 || ov < -20 - 1e-9) return;    /**/
            if (rt / rv > 1500 + 1e-9) return;                 /**/
            var cd = { sync: rt, rev: rv, over: ov, neg: ov < -1e-9 };
            /*




*/
            var g97 = cd.neg ? 1 : 0, gB97 = best ? (best.neg ? 1 : 0) : 9;
            if (!best || g97 < gB97
              || (g97 === gB97 && Math.abs(ov) < Math.abs(best.over) * (1 - 1e-6) - 1e-9)) best = cd;
            else if (g97 === gB97 && Math.abs(ov) <= Math.abs(best.over) * (1 + 1e-6) + 1e-9 && rt < best.sync) best = cd;
          });
        });
        /**/
        if (!fallback || Math.abs(over) < Math.abs(fallback.over) - 1e-9) fallback = cand;
      }
    });
    var pick = best || fallback || { sync: 3000, rev: 1 };
    /*
*/
    if (pick.sync / pick.rev > 1500 + 1e-9) {
      var rvC = null;
      for (var iC = 0; iC < REV_RATIOS.length; iC++) {
        if (pick.sync / REV_RATIOS[iC] <= 1500 + 1e-9) { rvC = REV_RATIOS[iC]; break; }
      }
      if (rvC !== null) pick = { sync: pick.sync, rev: rvC, over: pick.over };
    }
    return pick;
  }
  /*






*/
  function pickServoPlanetary(needJackRpm, vReq, estKw, forcedSync, brand) {
    if (!(vReq > 0) || !(needJackRpm > 0)) return { sync: 3000, planet: 1 };
    var best = null, fallback = null;
    (forcedSync ? [forcedSync] : servoRatedPriority(estKw, brand)).forEach(function (rated) {
      var iTotal = rated / needJackRpm;
      var planet = 1;
      /*

*/
      var iTol = iTotal * 1.005 + 1e-9;
      for (var i = 0; i < PLANET_RATIOS.length; i++) {
        if (PLANET_RATIOS[i] <= iTol) planet = PLANET_RATIOS[i];
      }
      var over = (iTotal / planet - 1) * 100;
      var cand = { sync: rated, planet: planet, over: over };
      /*
*/
      if (over >= -1e-9 && over <= 20 + 1e-9) { if (!best) best = cand; }
      else if (!fallback || Math.abs(over) < Math.abs(fallback.over) - 1e-9) fallback = cand;
    });
    var pick = best || fallback || { sync: 3000, planet: 1, over: 0 };
    /*
*/
    if (pick.sync / pick.planet > 1500 + 1e-9) {
      var plC = null;
      for (var iP = 0; iP < PLANET_RATIOS.length; iP++) {
        if (pick.sync / PLANET_RATIOS[iP] <= 1500 + 1e-9) { plC = PLANET_RATIOS[iP]; break; }
      }
      if (plC !== null) pick = { sync: pick.sync, planet: plC, over: pick.over };
    }
    return { sync: pick.sync, planet: pick.planet };
  }
  /*


*/
  function pickAcRevLayout(needJackRpm, allowDual, directOnly, domain) {
    /**/
    /*



*/
    var okDual = (allowDual !== false);
    var domP233 = domain || POLES;
    if (!(needJackRpm > 0)) return okDual
      ? { sync: domP233[0][0], rev: 1, plan: 'dual' }
      : { sync: domP233[0][0], rev: 2, plan: 'int' };
    var best1 = null, best2 = null;
    domP233.forEach(function (ps) {
      var iTotal = ps[1] / needJackRpm;
      [1, 2].forEach(function (rv) {
        if (directOnly && rv > 1) return;
        {
          var over = (iTotal / rv - 1) * 100;
          /*

*/
          if (over <= 20 + 1e-9 && over >= -20 - 1e-9) {
            var sc = Math.abs(over);
            var better = !best1 || sc < best1.score - 1e-9
              || (Math.abs(sc - best1.score) < 1e-9
                && ((over >= 0) !== (best1.over >= 0) ? over >= 0
                  : (rv < best1.rev || (rv === best1.rev && ps[1] < best1.sp))));
            if (better) best1 = { score: sc, over: over, rev: rv, sp: ps[1], sync: ps[0] };
          }
        }
      });
      var rv2 = 1, over2 = 0, score2 = 1000;
      if (okDual) {
        /**/
        rv2 = null;
        AC_REV_RATIOS.forEach(function (rv) { if (rv <= iTotal + 1e-9) rv2 = rv; });
        if (rv2 === null) rv2 = 1;
        over2 = (iTotal / rv2 - 1) * 100;
        score2 = (over2 <= 20 + 1e-9 && over2 >= -20 - 1e-9) ? Math.abs(over2) : 1000 + Math.abs(over2);
      } else {
        /*


*/
        var best2d2 = null;
        [2, 3, 4, 5, 8, 10].forEach(function (rv) {
          var o2v = (iTotal / rv - 1) * 100;
          var inWin2 = (o2v <= 20 + 1e-9 && o2v >= -20 - 1e-9);
          var sc2 = inWin2 ? Math.abs(o2v) : 1000 + Math.abs(o2v);
          var bet2 = !best2d2 || sc2 < best2d2.score - 1e-9
            || (Math.abs(sc2 - best2d2.score) < 1e-9
              && ((o2v >= 0) !== (best2d2.over >= 0) ? o2v >= 0 : rv < best2d2.rev));
          if (bet2) best2d2 = { score: sc2, over: o2v, rev: rv };
        });
        score2 = best2d2 ? best2d2.score : 1000;
        over2 = best2d2 ? best2d2.over : 0;
        rv2 = best2d2 ? best2d2.rev : 1;
      }
      var better2 = !best2 || score2 < best2.score - 1e-9
        || (Math.abs(score2 - best2.score) < 1e-9
          && ((over2 >= 0) !== (best2.over >= 0) ? over2 >= 0 : ps[1] < best2.sp));
      if (better2) best2 = { score: score2, over: over2, rev: rv2, sync: ps[0], sp: ps[1] };
    });
    if (best1 && okDual) return { sync: best1.sync, rev: best1.rev, plan: 'dual' };
    return { sync: best2 ? best2.sync : 1500, rev: best2 ? best2.rev : 1, plan: 'int' };
  }
  /*




*/
  function pickAcSpeed(needJackRpm, list, kind, domain) {
    var planet = (kind === 'planet');
    var domP233 = domain || POLES;   /**/
    if (!(needJackRpm > 0) || !list || !list.length) {
      return planet ? { sync: domP233[0][0], planet: 1 } : { sync: domP233[0][0], rev: 1 };
    }
    var best = null, fallback = null;
    domP233.forEach(function (ps) {
      list.forEach(function (g) {
        if (ps[1] / g > 1500 + 1e-9) return;                 /**/
        var over = (ps[1] / g / needJackRpm - 1) * 100;
        var cd = { sync: ps[0], g: g, over: over };
        if (over <= 20 + 1e-9 && over >= -20 - 1e-9) {
          if (!best) { best = cd; return; }
          var d = Math.abs(over) - Math.abs(best.over);
          if (d < -1e-9
            || (Math.abs(d) <= 1e-9
              && ((over >= 0) !== (best.over >= 0) ? over >= 0 : g < best.g))) best = cd;
        } else if (!fallback || Math.abs(over) < Math.abs(fallback.over) - 1e-9) {
          fallback = cd;
        }
      });
    });
    var pick = best || fallback || { sync: domP233[0][0], g: 1, over: 0 };
    return planet
      ? { sync: pick.sync, planet: pick.g, over: pick.over }
      : { sync: pick.sync, rev: pick.g, over: pick.over };
  }
  function variantSpeedChoices(m, cal, mid) {
    var gear = gearOf(m);
    var vReq = Number(cal.speed_mm_s) || 0;
    var ac = isFixDrive233(cal);   /**/
    var isDc233 = isDcDrive233(cal);
    var domAc233 = polesDomain233(cal);
    var units = Number(cal.units) || 1;
    /*
*/
    var estKw = ((cal.loadKN_eff != null ? cal.loadKN_eff : cal.loadKN) || 0) / units * vReq / 150;
    /*
*/
    var motFilter = (cal.motion === 'R' || cal.motion === 'S') ? cal.motion : null;
    var list = m.variants
      ? Object.keys(m.variants).map(function (k) { return { k: k, lead: Number(m.variants[k].lead_mm) || 0 }; })
      : [{ k: null, lead: Number(m.lead_mm) || 0 }];
    if (motFilter && m.variants) {
      var motMatched = list.filter(function (x) { return x.k && x.k.charAt(0) === motFilter; });
      if (motMatched.length) list = motMatched;
    }
    /*
*/
    var leadReqV = C.leadReqOf(cal.special_texts, cal.special);
    if (leadReqV > 0) {
      var leadMatched = list.filter(function (x) { return !(x.lead > 0) || Math.abs(x.lead - leadReqV) < 1e-9; });
      list = leadMatched;
    }
    var outV = [];
    list.sort(function (a, b) { return a.lead - b.lead; }).forEach(function (x) {
      var xAc1400 = null;   /**/
      var mmPerRev = x.lead / gear;              /**/
      var sync = null, rev = 1, planet = null, plan = null;
      if (cal.drive === 'hand' || cal.drive === 'none') {
        /*
*/
        sync = null; rev = 1; planet = null;
      } else if (units > 1 && cal.sync === '电气') {
        /*

*/
        var needJackE = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
        if (ac) {
          var bestE = null;
          domAc233.forEach(function (ps) {
            var vaE = ps[1] / 60 * mmPerRev;
            var scE = Math.abs(vaE - vReq) + (vaE >= vReq ? 0 : 1e-6);
            if (!bestE || scE < bestE.score) bestE = { sync: ps[0], score: scE };
          });
          sync = bestE ? bestE.sync : 1500; rev = 1; planet = null;
        } else {
          var pickE = pickServoPlanetary(needJackE, vReq, estKw, null, cal.servo_brand);
          sync = pickE.sync; planet = pickE.planet; rev = 1;
        }
      } else if (ac && units > 1 && (isRevLayout(String(cal.layout || ''))
        || isCenterLineCal(cal, mid))) {
        /*



*/
        var needJackA = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
        var famBevelHU = /伞齿轮/.test(String(m.family || ''));
        var pickA = pickAcRevLayout(needJackA, !(famBevelHU && SJ_EHB_DUAL === false),
          isCenterLineCal(cal, mid), domAc233);
        sync = pickA.sync; rev = pickA.rev; plan = pickA.plan;
      } else if (ac) {
        var best = null;
        if (units >= 3) {
          /*


*/
          var needJackAm = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
          var famBevelA = /伞齿轮/.test(String(m.family || ''));
          var pickAm = pickAcSpeed(needJackAm, famBevelA ? REV_RATIOS : [1, 2, 3, 5, 6, 8, 10], 'rev', domAc233);
          sync = pickAm.sync; rev = pickAm.rev;
          best = { sync: pickAm.sync };
        } else {
          domAc233.forEach(function (ps) {
            var va = ps[1] / 60 * mmPerRev;
            var score = Math.abs(va - vReq) + (va >= vReq ? 0 : 1e-6);
            if (!best || score < best.score) best = { sync: ps[0], score: score };
          });
          sync = best ? best.sync : domAc233[0][0];
        }
        /*




*/
        if (best && best.sync !== 1500 && !isDc233 && /伞齿轮/.test(String(m.family || '')) && mmPerRev > 0 && vReq > 0) {
          var needJack4 = vReq / mmPerRev * 60;
          var devD4 = (1400 / 60 * mmPerRev - vReq) / vReq * 100;
          var pAc = null, eAc = 1;
          if (Math.abs(devD4) <= 20 + 1e-9) { pAc = 1; }
          else {
            var bi4 = null, bd4 = 0;
            PLANET_RATIOS.forEach(function (i4) {
              var o4 = 1400 / i4;
              if (o4 < needJack4 * 0.8 - 1e-9 || o4 > needJack4 * 1.2 + 1e-9) return;
              var dv4 = Math.abs(o4 - needJack4);
              if (bi4 === null || dv4 < bd4 - 1e-9 || (Math.abs(dv4 - bd4) <= 1e-9 && i4 > bi4)) { bi4 = i4; bd4 = dv4; }
            });
            if (bi4 !== null) { pAc = bi4; eAc = bi4 >= 12 ? 0.80 : 0.90; }   /**/
          }
          if (pAc !== null) {
            xAc1400 = { k: x.k, lead: x.lead, sync: 1400, rev: 1, planet: pAc, plan: null,
              planetEff: pAc > 1 ? eAc : null };
          }
        }
      } else if (units <= 1) {
        /**/
        var needJack1 = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
        var pickP = pickServoPlanetary(needJack1, vReq, estKw, null, cal.servo_brand);
        sync = pickP.sync; planet = pickP.planet;
      } else {
        /*


*/
        var needJack = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
        /*


*/
        if (isInlineLayout(String(cal.layout || '')) && !isMidMotorLayout(String(cal.layout || ''))
          && String(m.family || '') !== '伞齿轮升降机'
          && !isCenterLineCal(cal, mid)) {
          if (ac) {
            /**/
            var pickAcP = pickAcSpeed(needJack, [1].concat(PLANET_RATIOS), 'planet', domAc233);
            sync = pickAcP.sync; planet = pickAcP.planet; rev = 1;
          } else {
            var pickPl = pickServoPlanetary(needJack, vReq, estKw, null, cal.servo_brand);
            sync = pickPl.sync; planet = pickPl.planet; rev = 1;
          }
        } else {
          /*


*/
          var isHuMultiC = [3, 4, 6, 8].indexOf(Number(cal.units) || 0) >= 0
            && (/^(H型|U2型|U型)/.test(String(cal.layout || ''))   /**/
              || isCenterLineCal(cal, mid));   /**/
          var famBevelC = /伞齿轮/.test(String(m.family || ''));
          var revDomC = famBevelC ? REV_RATIOS : [1, 2, 3, 5, 6, 8, 10];
          var pick;
          if (ac) {
            /**/
            pick = pickAcSpeed(needJack, revDomC, 'rev', domAc233);
          } else {
            pick = isHuMultiC
              ? pickServoRatedRev(needJack, vReq, estKw, null, revDomC, true, cal.servo_brand)
              : pickServoRatedRev(needJack, vReq, estKw, null, null, false, cal.servo_brand);
          }
          sync = pick.sync; rev = pick.rev;
        }
      }
      var baseV = { k: x.k, lead: x.lead, sync: sync, rev: rev, planet: planet, plan: plan || null };
      outV.push(baseV);
      if (xAc1400) outV.push(xAc1400);
    });
    return outV;
  }

  /**/
  /**/
  function ratedCapacity(m, route) {
    if (route === 'A') {
      var r = Number(m.rated_load_kN);
      return (isFinite(r) && r > 0) ? r : null;
    }
    var vmax = 0, vs = m.variants || {};
    Object.keys(vs).forEach(function (k) { vmax = Math.max(vmax, Number(vs[k].rated_thrust_kN) || 0); });
    if (!vmax) { var r2 = Number(m.rated_load_kN); vmax = (isFinite(r2) && r2 > 0) ? r2 : 0; }
    return vmax || null;
  }

  /**/
  var MODEL_ALIAS = { SCA: 'SJA', SCB: 'SJB' };

  /*



*/
  function docDispOf(cal, txt) {
    var dispFam = (cal && cal.series && MODEL_ALIAS[cal.series]) ? cal.series
      : (cal && cal.forced_prefix && MODEL_ALIAS[cal.forced_prefix]) ? cal.forced_prefix : null;
    if (!dispFam) return String(txt == null ? '' : txt);
    return String(txt).replace(new RegExp('\\b' + MODEL_ALIAS[dispFam] + '(?=\\d)', 'g'), dispFam);
  }

  /*


*/
  var SC_MIN_BASE_KN = 20;
  var SJB_BASE_LIST = [10, 20, 50, 80, 100, 200, 300, 450];
  function baseKnOf(mid, prefix) {
    var suf = String(mid || '').slice(String(prefix || '').length);
    if (!/^[0-9]+$/.test(suf)) return null;
    var n = Number(suf);
    if (prefix === 'SJB') {
      var best = null;
      for (var i = 0; i < SJB_BASE_LIST.length; i++) {
        if (SJB_BASE_LIST[i] <= n) best = SJB_BASE_LIST[i];
      }
      return best;
    }
    return n;
  }

  function buildCandidates(cal, data, famsOverride) {
    var fams = famsOverride || pickFamilies(cal);
    var seq = [], skipped = [];
    /**/
    var perUnit = (cal.loadKN_eff != null ? cal.loadKN_eff : cal.loadKN) / cal.units;
    fams.forEach(function (fam) {
      var def = FAMILIES[fam];
      if (!def) { skipped.push(fam + '（未知系列）'); return; }
      /*
*/
      var prefix = MODEL_ALIAS[fam] || fam;
      var order = def.order.length ? def.order
        : Object.keys(data.models).filter(function (k) { return k.indexOf(prefix) === 0; })
          .sort(function (a, b) { return (ratedCapacity(data.models[a], def.route) || 0) - (ratedCapacity(data.models[b], def.route) || 0); });
      /*
*/
      if (fam === 'SCA' || fam === 'SCB') {
        order = order.filter(function (mid) {
          var bk = baseKnOf(mid, prefix);
          return bk === null || bk >= SC_MIN_BASE_KN;
        });
      }
      if (!order.length) { skipped.push(fam + ' 系列（参数库暂未收录型号）'); return; }
      order.forEach(function (mid) {
        var m = data.models[mid];
        if (!m) { skipped.push(mid + '（参数库未收录）'); return; }
        var cap = ratedCapacity(m, def.route);
        if (cap !== null && perUnit > cap * 1.0001) { skipped.push(mid + '（单台 ' + C.fN(perUnit, 1) + 'kN 超额定 ' + cap + 'kN）'); return; }
        /*
*/
        var leadReqB = C.leadReqOf(cal.special_texts, cal.special);
        if (leadReqB > 0) {
          var lv = (m.variants
            ? Object.keys(m.variants).map(function (k2) { return Number(m.variants[k2].lead_mm) || 0; })
            : [Number(m.lead_mm) || 0]).filter(function (x2) { return x2 > 0; })
            .filter(function (x2, i2, a2) { return a2.indexOf(x2) === i2; })
            .sort(function (a2, b2) { return a2 - b2; });
          if (lv.length && !lv.some(function (x2) { return Math.abs(x2 - leadReqB) < 1e-9; })) {
            skipped.push(mid + '（无导程 ' + leadReqB + 'mm 档，现有 ' + lv.join('/') + 'mm）');
            return;
          }
        }
        if (def.route === 'A') {
          var ks = ratiosFor(m, cal);
          if (!ks.length) { skipped.push(mid + '（无满足速度的速比档）'); return; }
          ks.forEach(function (cb) { seq.push({ family: fam, route: 'A', model: mid, ratio_key: cb.ratio_key, motor_sync: cb.sync }); });
        } else {
          variantSpeedChoices(m, cal, mid).forEach(function (vr) {
            seq.push({ family: fam, route: 'C', model: mid, variant: vr.k,
              motor_sync: vr.sync, rev_ratio: vr.rev || 1,
              h_plan: vr.plan || null,
              planetary_ratio: (vr.planet && vr.planet > 1) ? vr.planet : null,
              planetary_eff: (vr.planet && vr.planet > 1) ? (vr.planetEff || null) : null });
          });
        }
      });
    });
    return { sequence: seq, skipped: skipped, families: fams };
  }

  function candLabel(c) {
    return c.model + (c.ratio_key ? (' / ' + c.ratio_key) : '') + (c.variant ? (' / ' + c.variant) : '')
      + (c.planetary_ratio ? (' / 行星' + c.planetary_ratio + ':1') : '')
      + (c.h_plan === 'dual' ? ' / 双出轴' : (c.h_plan === 'int' ? ' / 电机端换向器一体化' : ''));
  }

  /**/
  function buildCase(c, cal) {
    /**/
    var syncRpm = c.motor_sync || cal.motor_rpm || 1500;
    if (isAcDrive(cal) && syncRpm > 1800) syncRpm = 1500;
    return {
      route: c.route, model: c.model,
      ratio_key: c.ratio_key || undefined,
      variant: c.variant || undefined,
      units: cal.units,
      /*
*/
      total_load_kN: c.route === 'A' ? cal.loadKN_eff : undefined,
      load_kN: c.route === 'C' ? (cal.loadKN_eff / cal.units) : undefined,
      load_push_kN: cal.loadKN,
      load_pull_t: cal.load_pull_t || 0,
      static_load_t: cal.static_load_t || 0,
      speed_mm_s: cal.speed_mm_s,
      stroke_mm: cal.stroke_mm,
      sync: cal.sync,
      layout: cal.layout,
      motion: cal.motion,
      mounting: cal.mounting,
      ambient_temp: cal.ambient_temp,
      /*
*/
      drive: cal.drive,
      special: Array.isArray(cal.special) ? cal.special.slice() : [],
      /**/
      special_texts: (cal.special_texts && typeof cal.special_texts === 'object')
        ? (function (o) { var c = {}, k; for (k in o) c[k] = o[k]; return c; })(cal.special_texts) : {},
      /**/
      servo_brand: Array.isArray(cal.servo_brand) ? cal.servo_brand.slice() : [],
      cycles_per_day: cal.cycles_per_day === null ? undefined : cal.cycles_per_day,
      days_per_year: cal.days_per_year,
      life_years: cal.life_years,
      motor_rpm: syncRpm,
      /*
*/
      servo_rated: (c.servo_rated > 0) ? c.servo_rated : undefined,
      rev_ratio: c.rev_ratio || 1,       /**/
      /*

*/
      /*

*/
      dual_shaft: (c.h_plan === 'dual'
        || (c.h_plan !== 'int' && c.route === 'A' && isAcDrive(cal) && cal.sync === '机械'
          && (isRevLayout(String(cal.layout || '')) || isCenterLineCal(cal, c.model))
          && (Number(cal.units) || 1) > 1)) ? true : undefined,
      /*
*/
      ehb_dual: SJ_EHB_DUAL,
      /**/
      hu_plan: c.hu_plan,
      /*
*/
      overrides: (c.route === 'C' && c.planetary_ratio)
        ? { planetary_ratio: c.planetary_ratio, planetary_eff: c.planetary_eff || undefined }
        : undefined,
      series: c.family
    };
  }

  function failReason(res) {
    var c = res.checks || {};
    if (c['最大输入功率'] === false) return '功率';
    if (c['稳定性'] === false) return '稳定性';
    if (c['寿命'] === false) return '寿命';
    if (c['速度'] === false) return '速度';
    return '未知';
  }

  function evalOne(c, cal, data) {
    var res;
    try { res = g.SJScrewJack.runCase(buildCase(c, cal), data); }
    catch (e) { return { fatal: true, reason: '计算异常：' + e.message, label: candLabel(c) }; }
    if (res.error) return { fatal: true, reason: res.error, result: res, label: candLabel(c), warnings: res.warnings || [] };
    if (res.ratio_key) c.ratio_key = res.ratio_key;   //
    /*
*/
    if (res.motor_sync != null) c.motor_sync = res.motor_sync;
    else if (c.motor_sync) res.motor_sync = c.motor_sync;   //
    var stabMissing = res.checks && res.checks['稳定性'] === null;
    //
    if (res.all_pass && stabMissing && cal.stroke_mm > 300) {
      return {
        result: res, checks: res.checks, allPass: false, reason: '稳定性',
        note: '该型号无稳定性曲线数据（行程 ' + cal.stroke_mm + 'mm 须校核）',
        warnings: res.warnings || [], label: candLabel(c), fatal: false
      };
    }
    return {
      result: res, checks: res.checks, allPass: !!res.all_pass,
      reason: res.all_pass ? '' : failReason(res),
      warnings: res.warnings || [], label: candLabel(c), fatal: false
    };
  }

  /**/
  function advance(seq, i, rec) {
    var cur = seq[i], j = i + 1;
    if (rec.reason === '功率' || rec.reason === '稳定性' || rec.reason === '寿命') {
      while (j < seq.length && seq[j].model === cur.model) j++;
    }
    return j;
  }

  /**/
  /**/
  function largerModels(data, cal, route, curModel) {
    var prefix = String(curModel || '').replace(/[0-9].*$/, '') || 'SJA';
    if (cal && cal.series && MODEL_ALIAS[cal.series]) prefix = MODEL_ALIAS[cal.series];
    var cur = data.models[curModel];
    var cap0 = cur ? ratedCapacity(cur, route) : null;
    var out = [];
    Object.keys(data.models).forEach(function (k) {
      if (k.indexOf(prefix) !== 0) return;
      var cap = ratedCapacity(data.models[k], route);
      if (k !== curModel && cap0 !== null && cap !== null && cap < cap0 - 1e-9) return;
      out.push({ model: k, cap_kN: cap, current: k === curModel });
    });
    out.sort(function (a, b) { return (a.cap_kN || 0) - (b.cap_kN || 0); });
    return out;
  }

  /**/
  function recheckModel(cal, data, model, route) {
    if (!data || !data.models || !data.models[model]) {
      return { fatal: true, reason: '参数库无型号 ' + model, label: model };
    }
    var m = data.models[model];
    var c = { family: String(model).replace(/[0-9].*$/, ''), route: route, model: model };
    /*
*/
    var leadReqR = C.leadReqOf(cal.special_texts, cal.special);
    if (route === 'A' && leadReqR > 0 && Number(m.lead_mm) > 0
      && Math.abs(Number(m.lead_mm) - leadReqR) >= 1e-9) {
      return { fatal: true, label: model,
        reason: '该型号导程固定 ' + Number(m.lead_mm) + 'mm，非要求的 ' + leadReqR + 'mm' };
    }
    if (route === 'A') {
      var ks = ratiosFor(m, cal);
      if (ks.length) { c.ratio_key = ks[0].ratio_key; c.motor_sync = ks[0].sync; }
      else c.ratio_key = Object.keys(m.ratio_options || {})[0] || null;
    } else {
      var vs = variantSpeedChoices(m, cal);
      if (vs.length) {
        c.variant = vs[0].k; c.motor_sync = vs[0].sync; c.rev_ratio = vs[0].rev || 1;
        c.h_plan = vs[0].plan || null;
        c.planetary_ratio = (vs[0].planet && vs[0].planet > 1) ? vs[0].planet : null;
      }
      else return { fatal: true, reason: '型号 ' + model + ' 无可用导程档', label: model };
    }
    return evalOne(c, cal, data);
  }

  /*


*/
  function pickMotorOption(cal, data, cand, opt) {
    var rpm = Number(opt && opt.rpm) || 0;
    var m = data && data.models && data.models[cand && cand.model];
    if (!m) return { fatal: true, reason: '参数库无型号 ' + (cand && cand.model), label: candLabel(cand || {}) };
    if (!(rpm > 0)) return { fatal: true, reason: '电机额定转速无效', label: candLabel(cand) };
    var c2 = {};
    Object.keys(cand).forEach(function (k) { c2[k] = cand[k]; });
    c2.motor_sync = rpm;
    /*

*/
    var isAcPick = !!opt && opt.kind === 'ac';
    /**/
    var isDcPick233 = !!opt && opt.kind === 'dc';
    if (!isAcPick && !isDcPick233) c2.servo_rated = rpm;
    if (cand.route === 'C' && !isAcPick && !isDcPick233) {
      var gear = gearOf(m);
      var lead = (cand.variant && m.variants && m.variants[cand.variant])
        ? m.variants[cand.variant].lead_mm : m.lead_mm;
      var mmPerRev = lead / gear;
      var vReq = Number(cal.speed_mm_s) || 0;
      var needJack = mmPerRev > 0 ? (vReq / mmPerRev * 60) : 0;
      var estKw = ((cal.loadKN_eff != null ? cal.loadKN_eff : cal.loadKN) || 0)
        / (Number(cal.units) || 1) * vReq / 150;
      if (Number(cand.planetary_ratio) > 1) {
        /**/
        var p = pickServoPlanetary(needJack, vReq, estKw, rpm, cal.servo_brand);
        c2.planetary_ratio = (p.planet && p.planet > 1) ? p.planet : null;
        c2.rev_ratio = 1;
      } else if (cal.sync === '电气') {
        /*
*/
        var pE2 = pickServoPlanetary(needJack, vReq, estKw, rpm, cal.servo_brand);
        c2.planetary_ratio = (pE2.planet && pE2.planet > 1) ? pE2.planet : null;
        c2.rev_ratio = 1;
      } else {
        /*



*/
        var isHuMultiA = [3, 4, 6, 8].indexOf(Number(cal.units) || 0) >= 0
          && /^(H型|U2型|U型)/.test(String(cal.layout || ''))   /**/;
        var famBevelA = /^(EHB|DHB)/i.test(String(cand.model || ''));
        var rvListA = famBevelA ? REV_RATIOS : [1, 2, 3, 5, 6, 8, 10];
        var rowRev = Number(opt && opt.gearboxRatio);
        if (rowRev > 0) {
          c2.rev_ratio = rowRev;
        } else {
          var r2 = isHuMultiA
            ? pickServoRatedRev(needJack, vReq, estKw, rpm, rvListA, true, cal.servo_brand)
            : pickServoRatedRev(needJack, vReq, estKw, rpm, rvListA, false, cal.servo_brand);
          c2.rev_ratio = r2.rev || 1;
        }
        c2.planetary_ratio = null;
      }
    }
    var rec = evalOne(c2, cal, data);
    /*
*/
    if (!rec.fatal && rec.result && opt.code) {
      var mr = rec.result.motor_recommend || [];
      var pickIdx = -1;
      for (var i = 0; i < mr.length; i++) {
        if (mr[i].code === opt.code) { pickIdx = i; break; }
        if (pickIdx < 0 && Number(mr[i].rpm) === rpm) pickIdx = i;
      }
      if (pickIdx > 0) mr.unshift(mr.splice(pickIdx, 1)[0]);
    }
    return rec;
  }

  /*





*/
  var TIER_LABEL = {
    1: '优先1 · SJA-V1（电机额定转速实现，最小通过型号）',
    2: '优先2 · SJA-V1 放大一级（速度更贴近、裕量更大）',
    3: '优先3 · SJB-V1 滚珠丝杠（效率高，适合较高速度/频次）',
    4: '优先4 · SJB-L1 滚珠丝杠慢速档',
    5: '优先5 · EHB 伞齿轮（直角传动，伺服调速）'
  };
  /**/
  var HAND_TIER_LABEL = {
    1: '优先1 · 手摇自锁档 L1（最小通过型号，蜗轮副自锁）',
    2: '优先2 · 同型号 V1 备选（不自锁，须加制动器或其他安全措施）',
    3: '优先3 · 放大一级 L1 自锁档（裕量更大）',
    4: '优先4 · SJB 滚珠丝杠（效率高，适合较高频次）',
    5: '优先5 · EHB 伞齿轮（直角传动）'
  };
  function famClassOf(model) {
    /**/
    if (/^EHB|^EHA|^DHB/.test(model)) return 'bevel';
    if (/^SJB|^SCB/.test(model)) return 'ball';
    return 'trap';
  }
  function modelSize(model) { return parseInt(String(model).replace(/^[A-Z]+/, ''), 10) || 0; }
  function isFastRatio(cand) { return cand.route === 'C' || /V/i.test(cand.ratio_key || ''); }

  /*
*/
  function schemePools(history) {
    var pools = { trapFast: [], trapSlow: [], ballFast: [], ballSlow: [], bevel: [] };
    var seen = {};
    history.forEach(function (h) {
      if (h.fatal || !h.result || h.result.error) return;
      var c = h.cand;
      var k = c.model + '|' + (c.ratio_key || '') + '|' + (c.variant || '') + '|' + (c.motor_sync || '');
      if (seen[k]) return;
      seen[k] = 1;
      var fc = famClassOf(c.model), fast = isFastRatio(c);
      var key = fc === 'bevel' ? 'bevel'
        : fc === 'ball' ? (fast ? 'ballFast' : 'ballSlow')
        : (fast ? 'trapFast' : 'trapSlow');
      pools[key].push({ cand: c, rec: h, size: modelSize(c.model) });
    });
    Object.keys(pools).forEach(function (k) {
      pools[k].sort(function (a, b) { return a.size - b.size; });
    });
    return pools;
  }
  /*



*/
  function smallestPassing(pool, afterSize) {
    var i, min = null;
    var realPass = pool.some(function (p) { return p.rec.allPass && !p.rec.estStab; });
    for (i = 0; i < pool.length; i++) {
      var p = pool[i];
      if (!p.rec.allPass) continue;
      if (realPass && p.rec.estStab) continue;
      if (afterSize != null && p.size <= afterSize) continue;
      if (min === null || p.size < min) min = p.size;
    }
    if (min === null) return null;
    for (i = 0; i < pool.length; i++) {
      if (pool[i].rec.allPass && pool[i].size === min && !pool[i].rec.relaxed
        && !(realPass && pool[i].rec.estStab)) return pool[i];
    }
    for (i = 0; i < pool.length; i++) {
      if (pool[i].rec.allPass && pool[i].size === min && !(realPass && pool[i].rec.estStab)) return pool[i];
    }
    return null;
  }
  function firstPassing(pool) { return smallestPassing(pool, null); }
  function nextSizePassing(pool, afterSize) { return smallestPassing(pool, afterSize); }
  /**/

  /*

*/
  function speedDevOf(p, cal) {
    if (!cal || !cal.speed_mm_s || !p.rec || !p.rec.result || p.rec.result.speed_mm_s == null) return Infinity;
    /*


*/
    if (p.rec.result.sv_adj230) return 0;
    return Math.abs(Number(p.rec.result.speed_mm_s) - cal.speed_mm_s);
  }
  /*
*/
  function planetRatioOf(p) {
    var r = p && p.rec && p.rec.result && p.rec.result.planetary_ratio;
    if (!r && p && p.cand) r = p.cand.planetary_ratio;
    return r || 1;
  }
  function cmpBySizeDev(cal) {
    return function (a, b) {
      return (a.size - b.size) || (speedDevOf(a, cal) - speedDevOf(b, cal))
        || (planetRatioOf(a) - planetRatioOf(b))
        || ((a.relaxed ? 1 : 0) - (b.relaxed ? 1 : 0));
    };
  }

  /*

*/
  function ladderSameModelThenNext(pool, cal) {
    /*

*/
    function cmpLadder(a, b) {
      var da = speedDevOf(a, cal), db = speedDevOf(b, cal);
      var d = (da === db) ? 0 : (isFinite(da) && isFinite(db)
        ? (Math.abs(da - db) < 0.01 ? 0 : da - db)   /**/
        : (isFinite(da) ? -1 : (isFinite(db) ? 1 : 0)));
      return (a.size - b.size) || d
        || ((isFastRatio(a.cand) ? 1 : 0) - (isFastRatio(b.cand) ? 1 : 0))
        || (planetRatioOf(a) - planetRatioOf(b))
        || ((a.relaxed ? 1 : 0) - (b.relaxed ? 1 : 0));
    }
    var passed = pool.filter(function (p) { return p.rec.allPass; }).sort(cmpLadder);
    if (!passed.length) return [];
    /*
*/
    var p1 = passed.filter(function (p) { return !p.rec.estStab; })[0] || passed[0], out = [p1];
    function ck(p) {
      return (p.cand.ratio_key || '') + '|' + (p.cand.variant || '') + '|'
        + (p.cand.motor_sync || '') + '|' + (p.cand.planetary_ratio || '');
    }
    var p1Fast = isFastRatio(p1.cand);
    var sameOther = passed.filter(function (p) {
      return p.size === p1.size && ck(p) !== ck(p1);
    });
    var p2 = sameOther.filter(function (p) { return isFastRatio(p.cand) !== p1Fast; })[0] || sameOther[0];
    /*

*/
    var p3 = null;
    for (var i = 1; i < passed.length; i++) {
      if (passed[i].size > p1.size) { p3 = passed[i]; break; }
    }
    if (p2) out.push(p2);
    if (p3) out.push(p3);
    passed.forEach(function (p) {
      if (out.length >= 3) return;
      if (out.indexOf(p) >= 0) return;
      out.push(p);
    });
    return out;
  }

  function buildSchemes(history, cal, data, opt) {
    var pools = schemePools(history);
    var ladder = [];
    /*


*/
    var forcedMode = !!(opt && opt.forced);
    if (forcedMode) {
      var mergedF = [].concat(pools.trapFast || [], pools.trapSlow || [],
        pools.ballFast || [], pools.ballSlow || [], pools.bevel || []);
      ladderSameModelThenNext(mergedF, cal).slice(0, 3).forEach(function (p, i) {
        ladder.push({ tier: i + 1, tierLabel: '指定型号 · ' + p.cand.model, pick: p });
      });
    }
    /*

*/
    var explicit = (!forcedMode && cal && cal.series && cal.series !== 'auto') ? cal.series : null;
    /**/
    if (explicit === 'SCA' && cal && cal.cross_fam === 'SCB') explicit = 'SCB';
    if (forcedMode) {
      /**/
    } else if (explicit) {
      var fc = famClassOf(explicit === 'SCA' ? 'SJA' : explicit === 'SCB' ? 'SJB' : explicit);
      /**/
      var handSel = cal && cal.drive === 'hand';
      var poolKeys = fc === 'bevel' ? ['bevel']
        : fc === 'ball' ? (handSel ? ['ballSlow', 'ballFast'] : ['ballFast', 'ballSlow'])
        : (handSel ? ['trapSlow', 'trapFast'] : ['trapFast', 'trapSlow']);
      var famName = (FAMILIES[explicit] && FAMILIES[explicit].label) || explicit;
      var picked = [], seenCand = {};
      if (handSel && fc !== 'bevel') {
        /*
*/
        var slowPk = fc === 'ball' ? 'ballSlow' : 'trapSlow';
        var fastPk = fc === 'ball' ? 'ballFast' : 'trapFast';
        var bySize = {}, sizeSeq = [];
        [slowPk, fastPk].forEach(function (pk) {
          (pools[pk] || []).forEach(function (p) {
            if (!bySize[p.size]) { bySize[p.size] = {}; sizeSeq.push(p.size); }
            var rk = p.cand.ratio_key || (pk === slowPk ? 'L' : 'V');
            if (!bySize[p.size][rk]) bySize[p.size][rk] = p;
          });
        });
        sizeSeq.sort(function (a, b) { return a - b; });
        var ordered = [];
        sizeSeq.forEach(function (sz) {
          var m = bySize[sz];
          Object.keys(m).sort(function (a, b) {   //
            var la = /L/i.test(a), lb = /L/i.test(b);
            return la === lb ? (a < b ? -1 : 1) : (la ? -1 : 1);
          }).forEach(function (k) { ordered.push(m[k]); });
        });
        picked = ordered.filter(function (p) { return p.rec.allPass; }).slice(0, 3);
        /**/
      } else {
        var merged = poolKeys.reduce(function (acc, pk) { return acc.concat(pools[pk] || []); }, []);
        /*
*/
        var orderedEx = ladderSameModelThenNext(merged, cal);
        orderedEx.forEach(function (p) {
          if (picked.length >= 3) return;
          /*
*/
          var k2 = p.cand.model + '|' + (p.cand.ratio_key || '') + '|' + (p.cand.variant || '')
            + '|' + (p.cand.motor_sync || '') + '|' + (p.cand.planetary_ratio || '');
          if (seenCand[k2]) return;
          seenCand[k2] = 1;
          picked.push(p);
        });
        /**/
      }
      /*


*/
      if (!handSel && data && picked.length && picked[0].rec && picked[0].rec.allPass
        && huDualShaft(picked[0].rec.result, cal)) {
        var cInt = Object.assign({}, picked[0].cand, { h_plan: 'int', hu_plan: 'int' });
        var recInt = evalOne(cInt, cal, data);
        if (!recInt.fatal && recInt.result && recInt.allPass && !huDualShaft(recInt.result, cal)) {
          picked = [picked[0], { cand: cInt, rec: recInt, size: modelSize(cInt.model) }]
            .concat(picked.slice(1)).slice(0, 3);
        }
      }
      picked.forEach(function (p, i) {
        var lbl = '优先' + (i + 1) + ' · ' + famName
          + (p.cand && p.cand.hu_plan === 'int' ? '（非双出轴：电机端换向器一体化）' : '');
        ladder.push({ tier: i + 1, tierLabel: lbl, pick: p });
      });
    } else {
      /**/
      var handSel2 = cal && cal.drive === 'hand';
      var mainPool = handSel2 ? pools.trapSlow : pools.trapFast;
      var altPool = handSel2 ? pools.trapFast : pools.trapSlow;
      /**/
      var p1;
      if (!handSel2 && cal && cal.speed_mm_s) {
        var passingM = (pools.trapFast || []).concat(pools.trapSlow || [])
          .filter(function (p) { return p.rec.allPass; });
        /**/
        var orderedM = ladderSameModelThenNext(passingM, cal);
        orderedM.slice(0, 3).forEach(function (p, i) { ladder.push({ tier: i + 1, pick: p }); });
        p1 = orderedM[0] || null;
      } else {
        p1 = firstPassing(mainPool);
        if (p1) {
          ladder.push({ tier: 1, pick: p1 });
          if (handSel2) {
            /*
*/
            var vSame = null;
            (altPool || []).forEach(function (p) { if (!vSame && p.size === p1.size && p.rec.allPass) vSame = p; });
            /**/
            if (vSame) ladder.push({ tier: 2, pick: vSame });
            var pNext = nextSizePassing(mainPool, p1.size);
            if (pNext) ladder.push({ tier: 3, pick: pNext });
          } else {
            var p2 = nextSizePassing(mainPool, p1.size);
            if (p2) ladder.push({ tier: 2, pick: p2 });
          }
        }
      }
      if (!handSel2) ladder.push({ tier: 3, pool: altPool });
      ladder.push({ tier: 4, pool: pools.ballFast });
      ladder.push({ tier: 5, pool: pools.bevel });
    }
    var out = [];
    ladder.forEach(function (s) {
      if (out.length >= 3) return;
      /*

*/
      var pick = s.pick || firstPassing(s.pool);
      if (!pick) return;
      if (!pick.rec.allPass) return;   //
      for (var i = 0; i < out.length; i++) if (out[i].cand === pick.cand) return;
      out.push({ tier: s.tier, tierLabel: s.tierLabel
        || ((cal && cal.drive === 'hand') ? HAND_TIER_LABEL[s.tier] : TIER_LABEL[s.tier]),
        cand: pick.cand, rec: pick.rec });
    });
    return out;
  }

  function unmetList(checks) {
    var out = [];
    if (!checks) return out;
    Object.keys(checks).forEach(function (k) {
      if (checks[k] === false) out.push(k);
      else if (checks[k] === null) out.push(k + '（数据待补全）');
    });
    return out;
  }

  /**/
  /*









*/
  /**/
  var FAM_GROUP = { SJA: ['SJA', 'SCA'], SCA: ['SJA', 'SCA'],
    SJB: ['SJB', 'SCB'], SCB: ['SJB', 'SCB'],
    EHB: ['EHB', 'DHB', 'EHA'], DHB: ['EHB', 'DHB', 'EHA'], EHA: ['EHB', 'DHB', 'EHA'], KV: ['KV'] };
  function forcedModelsOf(cal, data) {
    var tx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
    var checked = Array.isArray(cal.special) ? cal.special : [];
    var joined = Object.keys(tx)
      .filter(function (k) { return checked.indexOf(k) >= 0; })
      .map(function (k) { return String(tx[k] || ''); }).join(' ');
    if (!joined) return { models: [], multi: false };
    var up = joined.toUpperCase();
    /**/
    var fmForeign = /(^|[^A-Za-z0-9])(DMB|EMB|FMR|GTR|LAM|LAP|LBP)(?![0-9]*[A-Za-z])/.exec(up);
    function scan(txt) {
      var h = [];
      Object.keys(data.models).forEach(function (mid) {
        if (new RegExp('(^|[^A-Za-z0-9])' + mid + '(?![0-9A-Za-z])').test(txt)) h.push(mid);
      });
      return h;
    }
    var hits = scan(up);
    var forcedPrefix = null;
    var multi = false;
    if (!hits.length) {
      var aliased = up.replace(/SCA/g, 'SJA').replace(/SCB/g, 'SJB');
      hits = scan(aliased);
      if (hits.length) forcedPrefix = (/SCA/.test(up) ? 'SCA' : 'SCB');
    }
    if (hits.length > 1) {
      multi = true;
      hits.sort(function (a, b) { return modelSize(b) - modelSize(a); });
      hits = [hits[0]];
    }
    /*

*/
    if (hits.length) {
      var hitFam0 = String(hits[0]).replace(/[0-9].*$/, '');
      var scFam = (forcedPrefix === 'SCA' || forcedPrefix === 'SCB') ? forcedPrefix
        : ((cal.series === 'SCA' || cal.series === 'SCB') && (hitFam0 === 'SJA' || hitFam0 === 'SJB') ? cal.series : null);
      if (scFam) {
        var bkF = baseKnOf(hits[0], MODEL_ALIAS[scFam]);
        if (bkF !== null && bkF < SC_MIN_BASE_KN) {
          return { models: [], multi: false, tooSmall: scFam + bkF, tooSmallFam: scFam };
        }
      }
    }
    /**/
    if (hits.length && cal.series && cal.series !== 'auto') {
      var famHit = String(hits[0]).replace(/[0-9].*$/, '');
      var grp = FAM_GROUP[famHit] || [famHit];
      var grpCur = FAM_GROUP[cal.series] || [cal.series];
      if (!grp.some(function (f) { return grpCur.indexOf(f) >= 0; })) {
        return { models: [], multi: false, outOfSeries: hits[0] };
      }
    }
    return { models: hits, multi: multi, prefix: forcedPrefix, foreign: fmForeign ? fmForeign[2] : null };
  }

  function selectOnce(input, data) {
    if (!data || !data.models) {
      /**/
      return { chosen: null, history: [], warnings: [], skipped: [], cal: toCalc(input),
               error: '型号参数库未加载（data/data-screwjack.js）。请刷新页面重新打开；若仍出现请重新获取最新版工具文件。' };
    }
    var cal = toCalc(input);
    var bc = buildCandidates(cal, data);
    if (!bc.sequence.length) {
      return { chosen: null, history: [], warnings: [], skipped: bc.skipped, cal: cal,
               error: '没有可用候选型号：' + (bc.skipped.join('；') || '型号库为空') };
    }
    /**/
    var history = [], warnings = [], sawFatal = null;
    function evalPush(c, sink) {
      /*
*/
      var hT = (sink && sink.history) ? sink.history : history;
      var wT = (sink && sink.warnings) ? sink.warnings : warnings;
      var rec = evalOne(c, cal, data);
      (rec.warnings || []).forEach(function (w) { if (wT.indexOf(w) < 0) wT.push(w); });
      hT.push({ index: hT.length, cand: c, label: rec.label || '',
        result: rec.result || null, checks: rec.checks || null,
        allPass: !!rec.allPass, relaxed: !!(rec.result && rec.result.power_relaxed),
        estStab: !!(rec.result && rec.result.est_stab),
        reason: rec.reason || '', fatal: !!rec.fatal, note: rec.note || '' });
      if (rec.fatal && !sawFatal && !sink) sawFatal = rec.reason;
    }
    bc.sequence.forEach(evalPush);
    /*


*/
    var explicitSeries = cal.series && cal.series !== 'auto';
    var hasBall = history.some(function (h) { return h.cand && famClassOf(h.cand.model) === 'ball'; });
    if (!hasBall && !explicitSeries) {
      var bcB = buildCandidates(cal, data, ['SJB']);
      var seenC = {};
      history.forEach(function (h) { seenC[h.cand.model + '|' + (h.cand.ratio_key || '') + '|' + (h.cand.variant || '') + '|' + (h.cand.motor_sync || '')] = 1; });
      bcB.sequence.forEach(function (c) {
        var k = c.model + '|' + (c.ratio_key || '') + '|' + (c.variant || '') + '|' + (c.motor_sync || '');
        if (!seenC[k]) evalPush(c);
      });
    }
    /*

*/
    /*



*/
    if (explicitSeries && cal.series === 'SCA' && !history.some(function (h) { return h.allPass; })) {
      var bcS317 = buildCandidates(cal, data, ['SCB']);
      var sinkS317 = { history: [], warnings: [] };
      var seenS317 = {};
      history.forEach(function (h) {
        seenS317[h.cand.model + '|' + (h.cand.ratio_key || '') + '|' + (h.cand.variant || '') + '|' + (h.cand.motor_sync || '')] = 1;
      });
      bcS317.sequence.forEach(function (c) {
        var kS317 = c.model + '|' + (c.ratio_key || '') + '|' + (c.variant || '') + '|' + (c.motor_sync || '');
        if (!seenS317[kS317]) evalPush(c, sinkS317);
      });
      if (sinkS317.history.length && sinkS317.history.some(function (h) { return h.allPass; })) {
        cal.cross_fam = 'SCB';
        sinkS317.history.forEach(function (h) { h.index = history.length; history.push(h); });
        sinkS317.warnings.forEach(function (w) { if (warnings.indexOf(w) < 0) warnings.push(w); });
        warnings.push('【跨系列推荐】所选 SCA 系列没有通过全部校核的型号，已自动跳评 SCB 滚珠丝杠系列（滚珠丝杠效率高，功率与寿命裕量更大）；如须坚持 SCA 系列，请与厂家技术确认');
      }
    }
    var forcedInfo = forcedModelsOf(cal, data);
    var historyForSchemes = history;
    /**/
    if (forcedInfo.outOfSeries) {
      warnings.push('特殊要求指定型号 ' + forcedInfo.outOfSeries
        + ' 不属于当前所选系列（' + cal.series + '），无法执行——请切换系列或修改特殊要求');
      forcedInfo = { models: [], multi: false };
    }
    /**/
    if (forcedInfo.tooSmall) {
      warnings.push(forcedInfo.tooSmallFam
        + ' 推杆系列无 5、10 基座（最小 20kN），特殊要求中的 ' + forcedInfo.tooSmall
        + ' 无法执行，已改按通用规则选型');
      forcedInfo = { models: [], multi: false };
    }
    /**/
    if (forcedInfo.foreign) {
      warnings.push('特殊要求中的型号 ' + forcedInfo.foreign
        + ' 不属于升降机产品线，无法执行——请检查特殊要求');
    }
    if (forcedInfo.models.length) {
      if (forcedInfo.prefix) cal.forced_prefix = forcedInfo.prefix;
      if (forcedInfo.multi) {
        warnings.push('特殊要求中出现多个型号代号，按规格最大者执行：' + forcedInfo.models[0]);
      }
      var evaldModel = {};
      history.forEach(function (h) { evaldModel[h.cand.model] = 1; });
      forcedInfo.models.forEach(function (mid) {
        if (evaldModel[mid]) return;
        /*
*/
        var mF = data.models[mid];
        var famF = mid.replace(/[0-9].*$/, '');
        var routeF = (FAMILIES[famF] && FAMILIES[famF].route) || mF.route || 'A';
        var seqF = [];
        if (String(routeF) === 'C') {
          variantSpeedChoices(mF, cal, mid).forEach(function (vr) {
            seqF.push({ family: famF, route: 'C', model: mid, variant: vr.k, motor_sync: vr.sync,
              rev_ratio: vr.rev || 1, h_plan: vr.plan || null,
              planetary_ratio: (vr.planet && vr.planet > 1) ? vr.planet : null,
              planetary_eff: (vr.planet && vr.planet > 1) ? (vr.planetEff || null) : null });
          });
        } else {
          ratiosFor(mF, cal).forEach(function (cb) {
            seqF.push({ family: famF, route: 'A', model: mid, ratio_key: cb.ratio_key, motor_sync: cb.sync });
          });
        }
        if (!seqF.length) {
          var leadReqF = C.leadReqOf(cal.special_texts, cal.special);
          warnings.push('特殊要求指定型号 ' + mid + '：'
            + (leadReqF > 0 ? '无导程 ' + leadReqF + 'mm 档或没有满足速度要求的速比档' : '没有满足速度要求的速比档')
            + '，已按通用规则选型，请与厂家技术确认');
        }
        seqF.forEach(evalPush);
      });
      var forcedPass = history.filter(function (h) {
        return h.allPass && forcedInfo.models.indexOf(h.cand.model) >= 0;
      });
      if (forcedPass.length) {
        historyForSchemes = forcedPass;
        warnings.push('已按特殊要求指定型号选型：' + forcedInfo.models.join('、'));
      } else {
        var failWhy = '';
        history.forEach(function (h) {
          if (failWhy || forcedInfo.models.indexOf(h.cand.model) < 0) return;
          if (!h.allPass) failWhy = h.label + '：' + (unmetList(h.checks).join('、') || h.reason || '校核未通过');
        });
        warnings.push('特殊要求指定型号 ' + forcedInfo.models.join('、')
          + '：没有通过全部校核的档位' + (failWhy ? '（' + failWhy + '）' : '')
          + '，已按通用规则选型，请与厂家技术确认');
      }
    }
    var schemes = buildSchemes(historyForSchemes, cal, data,
      (historyForSchemes !== history) ? { forced: true } : null);
    /*
*/
    var recTop = schemes.length ? schemes[0].rec : null;
    /**/
    if (recTop && !recTop.allPass) {
      var upNote = upgradeNoteOf(history, recTop.cand.model);
      if (upNote) warnings.push(upNote);
    }
    if (recTop && recTop.result && recTop.result.speed_warn
      && warnings.indexOf(recTop.result.speed_warn) < 0) {
      warnings.push(recTop.result.speed_warn);
    }
    var out;
    if (schemes.length) {
      out = { chosen: schemes[0].cand, chosenResult: schemes[0].rec.result,
              history: history, warnings: warnings, exhausted: false, schemes: schemes };
    } else {
      var best = null, bestScore = -1e9;
      history.forEach(function (h) {
        if (h.fatal) return;
        var sc = scoreRec(h);
        if (sc > bestScore) { bestScore = sc; best = h; }
      });
      /*



*/
      var bestEfforts = [];
      if (best) {
        bestEfforts.push({ cand: best.cand, result: best.result, label: best.label,
          unmet: unmetList(best.checks), text: unmetTextOf(best, cal, data), score: scoreRec(best) });
        var bestRk = String((best.cand && best.cand.ratio_key) || '');
        var bestFast = /V/i.test(bestRk);
        var altPick = null, altScore = -1e9;
        history.forEach(function (h) {
          if (h.fatal || !h.cand || h === best) return;
          if (!best.cand || h.cand.model !== best.cand.model) return;
          var rk = String(h.cand.ratio_key || '');
          if (/V/i.test(rk) === bestFast) return;      /**/
          var sc = scoreRec(h);
          if (sc > altScore) { altScore = sc; altPick = h; }
        });
        if (altPick) {
          bestEfforts.push({ cand: altPick.cand, result: altPick.result, label: altPick.label,
            unmet: unmetList(altPick.checks), text: unmetTextOf(altPick, cal, data), score: altScore });
        }
      }
      out = { chosen: null, chosenResult: null, history: history, warnings: warnings,
              exhausted: true, bestEffort: best, bestEfforts: bestEfforts,
              unresolved: best ? unmetList(best.checks) : [] };
      /*

*/
      if (best) {
        var upNote = upgradeNoteOf(history, best.cand.model);
        if (upNote) warnings.push(upNote);
      }
      if (!best && sawFatal) out.error = sawFatal;
    }
    out.skipped = bc.skipped;
    out.families = bc.families;
    out.cal = cal;
    /*
*/
    (function () {
      var u = Number(cal.units) || 0;
      if (u !== 5 && u !== 7) return;
      if (cal.sync !== '机械') return;
      var ly = String(cal.layout || '');
      if (ly !== 'H型布置' && ly !== 'H型' && ly !== '电机中间') return;
      var md = String((out.chosenResult && out.chosenResult.model) || '');
      /**/
      if (!bevelFamRe203.test(md)) return;
      var txt = (/^EHA/.test(md) ? 'EHA' : 'EHB')
        + ' 机械同步奇数台（5/7 台）暂不拆 RX/LX 两组，建议按 6 台或 8 台偶数台布置（左右各半）';
      if (!out.warnings) out.warnings = [];
      if (out.warnings.indexOf(txt) < 0) out.warnings.push(txt);
    })();
    /*





*/
    var puHist = processUnmetOf(history, out.chosen && out.chosen.model, cal, data);
    var puSeen = {};
    out.processUnmet = puHist.filter(function (r) {
      if (!r.text) return false;
      if (puSeen[r.model]) return false;
      puSeen[r.model] = 1; return true;
    }).sort(function (a, b) { return modelSize(a.model) - modelSize(b.model); });
    /**/
    var pick = out.chosenResult || (out.bestEffort && out.bestEffort.result);
    if (pick && pick.motor_sync) cal.motor_rpm = pick.motor_sync;
    if (!out.chosen && out.exhausted) {
      out.error = out.bestEffort
        ? ('没有完全通过全部校核的型号；以下为「最接近」的候选，未满足：' + (out.unresolved || []).join('、'))
        : ('已试完 ' + out.history.length + ' 个候选仍无可用型号，建议加导向 / 缩小行程 / 放宽速度或频次，或与厂家技术确认');
    }
    /*




*/
    if (out.chosen && (cal.drive === 'servo220' || cal.drive === 'servo380')) {
      var alignTier = function (cand, res) {
        if (!res) return res;
        /*



*/
        if (res.hu_window) return res;
        var mrT = res.motor_recommend || [];
        var tierUsed = Number(res.motor_sync) || 0;
        if (tierUsed <= 0) return res;
        /*




*/
        var pTotT = Number(res.total_power_kW);
        if (pTotT > 0 && pTotT <= 0.75 + 1e-9 && tierUsed !== 3000 && !res.sv_direct) {
          var row3k = null;
          mrT.forEach(function (m) {
            if (!row3k && m.kind === 'servo' && Number(m.rpm) === 3000 && m.fit !== 'over') row3k = m;
          });
          if (row3k) {
            var rec3k = pickMotorOption(cal, data, cand, { rpm: 3000, code: row3k.code });
            if (rec3k && !rec3k.fatal && rec3k.result && rec3k.result.all_pass) {
              rec3k.result.aligned_from_rpm = tierUsed;
              rec3k.result.aligned_small3000 = true;
              return rec3k.result;
            }
          }
        }
        var hasReal = mrT.some(function (m) {
          return m.kind === 'servo' && Number(m.rpm) === tierUsed && m.fit !== 'over';
        });
        /**/
        if (hasReal || res.sv_direct) return res;
        var fitRows = [];
        mrT.forEach(function (m) {
          if (m.kind === 'servo' && m.fit !== 'over' && Number(m.rpm) > 0) fitRows.push(m);
        });
        if (!fitRows.length) return res;
        fitRows.sort(function (a, b) { return Number(a.rpm) - Number(b.rpm); });
        var recF = pickMotorOption(cal, data, cand, { rpm: Number(fitRows[0].rpm), code: fitRows[0].code });
        if (recF && !recF.fatal && recF.result) {
          res.aligned_from_rpm = tierUsed;
          return recF.result;
        }
        return res;
      };
      /*


*/
      var keptSchemes = [], alignedTopTxt = '';
      (out.schemes || []).forEach(function (p) {
        var res0 = (p.cand === out.chosen) ? out.chosenResult : p.rec.result;
        var r2 = alignTier(p.cand, res0);
        if (r2 !== res0) {
          if (!r2.all_pass) return;   /**/
          if (p.cand === out.chosen) alignedTopTxt = r2.aligned_small3000
            ? ('所需功率 ≤750W，改按 3000rpm 档（原 ' + (r2.aligned_from_rpm || '') + 'rpm 档）重配减速比整案计算')
            : ((r2.aligned_from_rpm || '') + 'rpm 档在所选品牌内无功率/扭矩适配机型，'
              + '已按 ' + r2.motor_sync + 'rpm 档重配减速比整案计算');
        }
        p.rec.result = r2;
        keptSchemes.push(p);
      });
      if (keptSchemes.length) {
        var topP = keptSchemes[0];
        if (topP.cand !== out.chosen) {
          warnings.push('转速档调整：原选定 ' + out.chosen.model + ' 所用转速档对齐降档后校核不过，'
            + '已改选 ' + topP.cand.model + '（下一可行方案）');
          out.chosen = topP.cand;
        }
        out.chosenResult = topP.rec.result;
        if (alignedTopTxt) warnings.push('转速档调整：' + alignedTopTxt);
        out.schemes = keptSchemes;
        if (out.chosenResult && out.chosenResult.motor_sync) cal.motor_rpm = out.chosenResult.motor_sync;
      }
    }
    return out;
  }

  /*



*/
  var SPEED_ALLOW_LADDER = [25, 30, 35, 40, 45, 50];
  function autoSelect(input, data) {
    var isSrv = String((input && input.drive) || '').indexOf('servo') === 0;
    if (!isSrv) {
      var outAc = selectOnce(input, data);
      outAc.speed_allow_pct = 20;
      return outAc;
    }
    var bestL = null;
    for (var li = 0; li < SPEED_ALLOW_LADDER.length; li++) {
      var Lv = SPEED_ALLOW_LADDER[li];
      var inpL = {};
      for (var kk in input) inpL[kk] = input[kk];
      inpL.speed_allow_pct = Lv;
      var outL = selectOnce(inpL, data);
      var nSch = (outL.schemes || []).length;
      if (!bestL || nSch > (bestL.out.schemes || []).length) bestL = { out: outL, L: Lv };
      if (nSch >= 3) { bestL = { out: outL, L: Lv }; break; }
    }
    var lastTry = SPEED_ALLOW_LADDER[SPEED_ALLOW_LADDER.length - 1];
    var nBest = (bestL.out.schemes || []).length;
    if (nBest === 0) bestL.L = lastTry;     /**/
    bestL.out.speed_allow_pct = bestL.L;
    if (bestL.L > 25) {
      bestL.out.warnings = (bestL.out.warnings || []).concat([
        nBest === 0
          ? ('速度上限放宽：已按 +25→…→+' + lastTry + '% 逐级放宽（50% 封顶），仍无全部校核通过的方案')
          : ('速度上限放宽：默认 25%（向下调速 20%）下不足 3 个方案，已按 +' + bestL.L
            + '% 放宽计算（50% 封顶，速度校核如实标注偏差）')]);
    }
    return bestL.out;
  }

  /*
*/
  function upgradeNoteOf(history, recModel) {
    if (!recModel) return '';
    var recSize = modelSize(recModel);
    var seen = {}, lines = [];
    history.forEach(function (h) {
      var m = h.cand && h.cand.model;
      if (!m || h.fatal || seen[m]) return;
      if (m === recModel || modelSize(m) <= recSize) return;
      seen[m] = 1;
      var unmet = unmetList(h.checks);
      if (!unmet.length) return;   /**/
      var lifeTxt = '';
      ((h.result && h.result.steps) || []).forEach(function (st) {
        var s = String(st[1] || '');
        if (st[0] === '寿命校核' && s.indexOf('寿命不足') >= 0) {
          var km = s.match(/=\s*([\d.]+)km/), yr = s.match(/寿命不足\s*([\d.]+)\s*年/);
          if (km) lifeTxt = '寿命 ' + km[1] + 'km，不足 ' + (yr ? yr[1] + ' 年' : '寿命要求');
        }
      });
      lines.push(m + '：' + (lifeTxt || unmet.join('、')));
    });
    return lines.length ? ('更大档位核验（为何未继续升档）：' + lines.join('；')) : '';
  }

  /*




*/
  /*

*/
  function capacityUnmetOf(skipped, recModel) {
    var capSize = modelSize(recModel);
    var rows = [], seen = {};
    (skipped || []).forEach(function (s) {
      var mm = /^([A-Z]+\d+)\s*（(.+)）\s*$/.exec(String(s || ''));
      if (!mm) return;
      var mid = mm[1], why = mm[2];
      if (why.indexOf('超额定') < 0) return;
      if (modelSize(mid) >= capSize) return;
      if (seen[mid]) return;
      seen[mid] = 1;
      rows.push({ model: mid, label: mid + ' / 额定能力不足', text: why + '，须放大一级' });
    });
    return rows;
  }

  /*




*/
  function speedFixHintOf(h, cal, data) {
    var c = (h && h.checks) || {};
    if (c['速度'] !== false) return '';
    if (!cal || String(cal.drive || '').indexOf('servo') !== 0) return '';
    var res = (h && h.result) || {};
    var vReq = Number(cal.speed_mm_s) || 0;
    var vAct = Number(res.speed_mm_s) || 0;
    if (!(vReq > 0) || !(vAct > 0) || vAct >= vReq - 1e-9) return '';
    var md = (data && data.models) ? data.models[h.cand && h.cand.model] : null;
    var mmPerRev = 0;
    if (res.route === 'C') {
      var gear = 2;
      var gm = String((md && md.gear_ratio) || '').match(/(\d+)\s*:\s*(\d+)/);
      if (gm && Number(gm[1]) > 0) gear = Number(gm[2]) / Number(gm[1]);
      mmPerRev = (Number(res.lead_mm) || 0) / gear;
    } else {
      mmPerRev = Number(res.mm_per_rev) || 0;
    }
    if (!(mmPerRev > 0)) return '';
    var needIn = vReq * 60 / mmPerRev;      /**/
    if (needIn <= 1500 + 1e-9) return '；该型号达速需 1500rpm 伺服直连（非西门子品牌，如汇川/台达/雷赛），或改用更大导程档';
    return '；该型号达速需更大导程档或更高额定转速电机，请与厂家技术确认';
  }

  /*
*/
  function unmetTextOf(h, cal, data) {
    var unmet = unmetList(h.checks || {});
    if (!unmet.length) return '';
    var fixHint = speedFixHintOf(h, cal, data);
    var steps = (h.result && h.result.steps) || [];
    var parts = unmet.map(function (k) {
        if (k === '电机真机型') {
          /**/
          return k + '：' + ((h.result && h.result.motor_real_note) || '所选品牌库内无适用真机型');
        }
        var wantTitle = (k === '推力') ? '推拉力校核' : (k + '校核');
        var txt = '';
        steps.forEach(function (st) {
          if (txt || st[0] !== wantTitle) return;
          txt = String(st[1] || '').replace(/，?校核(失败|通过)$/, '');
        });
        if (!txt) {
          /**/
          steps.forEach(function (st) {
            if (txt || String(st[0]).indexOf(k) < 0) return;
            txt = String(st[1] || '').replace(/，?校核(失败|通过)$/, '');
          });
        }
        return k + '：' + (txt || '未通过') + ((k === '速度' && fixHint) ? fixHint : '');
      });
    return parts.join('；');
  }

  function processUnmetOf(history, recModel, cal, data) {
    var capSize = recModel ? modelSize(recModel) : Infinity;
    var seen = {}, rows = [];
    (history || []).forEach(function (h) {
      var m = h.cand && h.cand.model;
      if (!m || h.fatal || seen[m]) return;
      if (modelSize(m) > capSize) return;
      /*


*/
      if (recModel && m === recModel) return;
      seen[m] = 1;
      /*


*/
      var alias = (h.cand.family && MODEL_ALIAS[h.cand.family]) || null;
      var disp = (alias && m.indexOf(alias) === 0) ? h.cand.family + m.slice(alias.length) : m;
      rows.push({ model: disp, label: h.label, text: unmetTextOf(h, cal, data) });
    });
    return rows;
  }

  /**/
  function scoreRec(h) {
    var c = h.checks || {}, s = 0;
    if (c['稳定性'] === true) s += 100;
    if (c['最大输入功率'] === true) s += 40;
    if (c['寿命'] === true) s += 20;
    if (c['速度'] === true) s += 10;
    if (c['工作制'] !== false) s += 5;
    if (h.relaxed) s -= 8;   /**/
    return s;
  }

  /*






*/
  function isInlineLayout(layout) {
    return layout === '电机单侧' || layout === '电机中间' || layout === '直线布置-电机单侧'
      || layout === '垂直布置-电机中间' || layout === '直线布置';
  }
  /*
*/
  function isRevLayout(layout) {
    /**/
    return layout === 'H型布置' || layout === 'U型布置' || layout === 'U2型布置'
      || layout === 'H型' || layout === 'U型' || layout === 'U2型';
  }
  /*



*/
  function isCenterLineCal(cal, model) {
    var u = Number(cal && cal.units) || 0;
    if (String((cal && cal.layout) || '') !== '直线布置') return false;
    if ([4, 6, 8].indexOf(u) < 0) return false;
    /**/
    return !/^(EHB|EHA|ELB|ELA)/.test(String(model || (cal && cal.series) || ''));
  }
  function isMidMotorLayout(layout) {
    return layout === '电机中间' || layout === '垂直布置-电机中间';
  }
  /*


*/
  function huDualShaft(res, cal) {
    if (!res || !cal || (Number(cal.units) || 1) <= 1) return false;
    if (cal.sync !== '机械' || !(isRevLayout(String(cal.layout || ''))
      || isCenterLineCal(cal, res.model))) return false;
    if (!isFixDrive233(cal)) return false;   /**/
    return res.dual_shaft === true;
  }
  /*
















*/
  function shaftLenPlanOf(cal) {
    var raw = cal.raw || {};
    var L = Math.round(Number(raw.platform_L) || 0);
    var W = Math.round(Number(raw.platform_W) || 0);
    var units = Number(cal.units) || 1;
    var layout = String(cal.layout || '');
    if (!(L > 0)) return null;
    var parts = null;
    if (units === 2) {
      /**/
      if (layout === '电机单侧') {
        parts = [{ dir: '长度方向', n: 1, len: L, src: '平台长 ' + L + 'mm' }];
      } else if (layout === '电机中间' || layout === '导向柱一体化') {
        parts = [{ dir: '长度方向', n: 2, len: L / 2, src: '平台长 ' + L + 'mm ÷ 2' }];
      }
    } else if (units === 3) {
      /**/
      if (/^直线布置/.test(layout)) {
        parts = [{ dir: '长度方向', n: 2, len: L / 2, src: '平台长 ' + L + 'mm ÷ 2' }];
      } else if (/^垂直布置/.test(layout) && W > 0) {
        parts = [
          { dir: '长度方向', n: 2, len: L / 2, src: '平台长 ' + L + 'mm ÷ 2' },
          { dir: '宽度方向', n: 2, len: W / 2, src: '平台宽 ' + W + 'mm ÷ 2' }
        ];
      }
    } else if (units === 4) {
      /*
*/
      if (/^直线布置/.test(layout)) {
        parts = [{ dir: '长度方向', n: 4, len: L / 4, src: '平台长 ' + L + 'mm ÷ 4' }];
      } else if (/^H/.test(layout) && W > 0) {
        parts = [
          { dir: '长度方向', n: 4, len: L / 2, src: '平台长 ' + L + 'mm ÷ 2' },
          { dir: '宽度方向', n: 2, len: W / 2, src: '平台宽 ' + W + 'mm ÷ 2' }
        ];
      } else if (/^U/.test(layout) && W > 0) {
        parts = [
          { dir: '长度方向', n: 2, len: L / 2, src: '平台长 ' + L + 'mm ÷ 2' },
          { dir: '宽度方向', n: 2, len: W / 2, src: '平台宽 ' + W + 'mm ÷ 2' }
        ];
      }
    } else if (units === 6) {
      /**/
      if (/^直线布置/.test(layout)) {
        parts = [{ dir: '长度方向', n: 6, len: L / 6, src: '平台长 ' + L + 'mm ÷ 6' }];
      } else if (/^H/.test(layout) && W > 0) {
        parts = [
          { dir: '长度方向', n: 6, len: L / 3, src: '平台长 ' + L + 'mm ÷ 3' },
          { dir: '宽度方向', n: 2, len: W / 2, src: '平台宽 ' + W + 'mm ÷ 2' }
        ];
      }
    } else if (units === 8) {
      /**/
      if (/^直线布置/.test(layout)) {
        parts = [{ dir: '长度方向', n: 8, len: L / 8, src: '平台长 ' + L + 'mm ÷ 8' }];
      } else if (/^H/.test(layout) && W > 0) {
        parts = [
          { dir: '长度方向', n: 8, len: L / 4, src: '平台长 ' + L + 'mm ÷ 4' },
          { dir: '宽度方向', n: 2, len: W / 2, src: '平台宽 ' + W + 'mm ÷ 2' }
        ];
      }
    }
    return parts ? { parts: parts } : null;
  }
  /*


*/
  function pushShaftRows(items, cal, totalShafts, centerShafts) {
    var plan = shaftLenPlanOf(cal);
    if (plan) {
      var bearing = 0, over3500 = false, total = 0;
      plan.parts.forEach(function (p) {
        if (p.len > 2500) bearing += p.n;
        if (p.len > 3500) over3500 = true;
        total += p.n;
        items.push({ desc: '传动轴（' + p.dir + '）' + p.n + ' 根：单根约 ' + Math.round(p.len)
          + 'mm（按' + p.src + '计算）', qty: String(p.n), over3500: p.len > 3500 });
      });
      if (centerShafts) {
        items.push({ desc: '传动轴（中央输入轴）' + centerShafts + ' 根：长度按电机位置确定', qty: String(centerShafts) });
        total += centerShafts;
      }
      if (bearing > 0) {
        items.push({ desc: '轴承座 ' + bearing
          + ' 个：传动轴单根超过 2500mm，每根增设 1 个支承轴承座', qty: String(bearing), red: true });
      }
      return total;
    }
    var desc = '传动轴 ' + totalShafts + ' 根：轴长按客户平台实际尺寸确定';
    items.push({ desc: desc, qty: String(totalShafts) });
    return totalShafts;
  }
  function buildAccessories(res, cal, data) {
    /*
*/
    if (cal.units <= 1) {
      var pl = Number(res.planetary_ratio) || 0;
      if (pl > 1) {
        var m0gb = (res.motor_recommend || [])[0];
        var rpmInGb = m0gb ? m0gb.rpm : (Number(cal.motor_rpm) || 3000);
        var rpmOutGb = (m0gb && m0gb.gearbox && m0gb.gearbox.out_rpm) ? m0gb.gearbox.out_rpm : null;
        /**/
        var tRatGb = (m0gb && m0gb.torque_Nm) ? Number(m0gb.torque_Nm) : 0;
        var tOutTxtGb = tRatGb > 0
          ? '输出扭矩 = 电机额定扭矩 ' + C.fN(tRatGb, 1) + 'Nm × 减速比 ' + C.fN(pl, 0) + ' = ' + C.fN(tRatGb * pl, 0) + 'Nm'
          : '输出端需求扭矩约 ' + C.fN(res.planetary_out_torque_Nm || 0, 0) + 'Nm';
        /**/
        if (res.sv_changer) {
          var sRpmGb = rpmOutGb || 0;
          var runGb = (m0gb && m0gb.motor_run_rpm) ? Number(m0gb.motor_run_rpm) : Math.round(sRpmGb * pl);
          var pickGb1 = pickRsdForMotor(data, tRatGb > 0 ? tRatGb * pl : (Number(res.planetary_out_torque_Nm) || 0), runGb, m0gb, pl);
          return [{
            desc: '电机端换向器 ' + pickGb1.frame + '/' + C.fN(pl, 0) + '（速比 1:' + C.fN(pl, 0) + '，带电机法兰）1 台：'
              + tOutTxtGb + '（选型：许用输出扭矩须大于电机扭矩×速比，样本 p141），输入转速 '
              + C.fN(runGb, 0) + ' rpm（伺服 30~3000rpm 调速运行，该速比额定输入 ' + C.fN(3000 / pl, 0) + 'rpm）'
              + (sRpmGb ? '、输出转速 ' + C.fN(sRpmGb, 1).replace(/\.0$/, '') + ' rpm' : '')
              + '，电机经换向器接升降机输入轴' + rsdFitNote(pickGb1),
            qty: '1'
          }];
        }
        /*
*/
        var plHv1 = (typeof g.SJScrewJack.planetPickOf === 'function')
          ? g.SJScrewJack.planetPickOf(data, pl, tRatGb, rpmInGb, g.SJScrewJack.motorShaftOf(m0gb)) : null;
        return [{
          desc: '行星减速机 i=' + C.fN(pl, pl % 1 ? 1 : 0) + '（减速比 ' + C.fN(pl, pl % 1 ? 1 : 0)
            + ':1）1 台：' + tOutTxtGb
            + (plHv1 ? '，选 ' + plHv1.model + '（额定输出扭矩 ' + C.fN(plHv1.C, 0) + 'Nm/最大 ' + C.fN(plHv1.D, 0)
              + 'Nm，' + plHv1.level + '；适配电机轴径 ' + plHv1.shafts.join('/') + 'mm'
              + (plHv1.shaftNote ? '；' + plHv1.shaftNote : '')
              + (plHv1.torqueNote ? '；' + plHv1.torqueNote : '') + '）' : '')
            + '（选型：额定输出扭矩须大于电机扭矩×减速比），输入转速 '
            + C.fN(rpmInGb, 0) + ' rpm'
            + (rpmOutGb ? '、输出转速 ' + rpmOutGb + ' rpm' : '')
            + '，电机经减速机接升降机输入轴',
          qty: '1',
          _planet: plHv1
        }];
      }
      return [];
    }
    /*




*/
    if (cal.sync === '电气') {
      var nE = Number(cal.units) || 1;
      var plE = Number(res.planetary_ratio) || 0;
      if (nE > 1 && plE > 1) {
        var m0E = (res.motor_recommend || [])[0];
        var rpmInE = m0E ? m0E.rpm : (Number(cal.motor_rpm) || 3000);
        var rpmOutE = (m0E && m0E.gearbox && m0E.gearbox.out_rpm) ? m0E.gearbox.out_rpm : null;
        var tRatE = (m0E && m0E.torque_Nm) ? Number(m0E.torque_Nm) : 0;
        var tOutTxtE = tRatE > 0
          ? '输出扭矩 = 电机额定扭矩 ' + C.fN(tRatE, 1) + 'Nm × 减速比 ' + C.fN(plE, 0) + ' = ' + C.fN(tRatE * plE, 0) + 'Nm'
          : '输出端需求扭矩约 ' + C.fN(res.planetary_out_torque_Nm || 0, 0) + 'Nm';
        var plHvE = (typeof g.SJScrewJack.planetPickOf === 'function')
          ? g.SJScrewJack.planetPickOf(data, plE, tRatE, rpmInE, g.SJScrewJack.motorShaftOf(m0E)) : null;
        return [{
          desc: '行星减速机 i=' + C.fN(plE, plE % 1 ? 1 : 0) + '（减速比 ' + C.fN(plE, plE % 1 ? 1 : 0)
            + ':1）' + nE + ' 台（每台升降机 1 台，随各自电机）：' + tOutTxtE
            + (plHvE ? '，选 ' + plHvE.model + '（额定输出扭矩 ' + C.fN(plHvE.C, 0) + 'Nm/最大 ' + C.fN(plHvE.D, 0)
              + 'Nm，' + plHvE.level + '；适配电机轴径 ' + plHvE.shafts.join('/') + 'mm'
              + (plHvE.shaftNote ? '；' + plHvE.shaftNote : '')
              + (plHvE.torqueNote ? '；' + plHvE.torqueNote : '') + '）' : '')
            + '（选型：额定输出扭矩须大于电机扭矩×减速比），单台输入转速 '
            + C.fN(rpmInE, 0) + ' rpm（电机侧）'
            + (rpmOutE ? '、输出转速 ' + rpmOutE + ' rpm' : '')
            + '；单价为每台价',
          qty: String(nE),
          _planet: plHvE
        }];
      }
      return [];
    }
    /*
*/
    if (cal.sync !== '机械') return [];
    var isC = res.route === 'C';
    var isHand = cal.drive === 'hand';
    var units = cal.units;
    var items = [];
    var rpm = cal.motor_rpm || 1500;
    /*
*/
    var mmPerRev;
    if (isC) {
      var mDefC = (g.SJ_DATA && g.SJ_DATA.models) ? g.SJ_DATA.models[res.model] : null;
      var gearC = 2;
      if (mDefC) {
        var gmC = String(mDefC.gear_ratio || '').match(/(\d+)\s*:\s*(\d+)/);
        if (gmC && Number(gmC[1]) > 0) gearC = Number(gmC[2]) / Number(gmC[1]);
      }
      mmPerRev = (Number(res.lead_mm) || 0) / gearC;
    } else {
      mmPerRev = Number(res.mm_per_rev) || 0;
    }
    //
    var vActual = Number(res.speed_mm_s) || 0;
    var nInput = mmPerRev ? (vActual * 60 / mmPerRev) : rpm;
    //
    //
    //
    var tMax = isHand ? (Number(res.hand_torque_Nm) || 0) : (isC
      ? (Number(res.torque_at_jack_Nm) || (nInput ? 9550 * (Number(res.motor_power_kW) || 0)
        * (res.rev_ratio || 1) / nInput : 0))
      : (nInput ? (9550 * (Number(res.total_power_kW) || 0) / nInput) : 0));
    /*
*/
    var revRatio = Number(res.rev_ratio) || 1;
    /*
*/
    var isCenterLineAcc = isCenterLineCal(cal, res.model);
    if (isInlineLayout(String(cal.layout || '')) && !isCenterLineAcc) {
      if (isMidMotorLayout(String(cal.layout || ''))) {
        /*







*/
        var mMid = (res.motor_recommend || [])[0];
        var plMid = (!isHand && !res.sv_changer) ? (Number(res.planetary_ratio) || 0) : 0;
        /*


*/
        var tMidChk = (!isHand && mMid && mMid.torque_Nm)
          ? Math.max(tMax, plMid > 1 ? Number(mMid.torque_Nm) * plMid * revRatio : Number(mMid.torque_Nm))
          : tMax;
        var pickMid = pickRsdForMotor(data, tMidChk, nInput * revRatio, isFixDrive233(cal) || isHand ? null : mMid, revRatio);
        var rsdM = pickMid.frame;
        /*
*/
        var rTxtM = C.fN(revRatio, 1).replace(/\.0$/, '');
        /**/
        var plHvMid = null, plTxtMid = '';
        if (plMid > 1) {
          var tRatMid = (mMid && mMid.torque_Nm) ? Number(mMid.torque_Nm) : 0;
          var rpmInMid = mMid ? mMid.rpm : (Number(cal.motor_rpm) || 3000);
          plHvMid = (typeof g.SJScrewJack.planetPickOf === 'function')
            ? g.SJScrewJack.planetPickOf(data, plMid, tRatMid, rpmInMid, g.SJScrewJack.motorShaftOf(mMid)) : null;
          plTxtMid = '；行星减速机 i=' + C.fN(plMid, plMid % 1 ? 1 : 0) + ':1：输入转速 ' + C.fN(rpmInMid, 0)
            + 'rpm（电机侧）、输出转速 ' + C.fN(rpmInMid / plMid, 0) + 'rpm、输出扭矩 '
            + C.fN(tRatMid * plMid, 1) + ' N·m（电机额定扭矩 ' + C.fN(tRatMid, 1) + ' × 减速比 ' + C.fN(plMid, 0) + '）'
            + (plHvMid ? '，选 ' + plHvMid.model + '（额定输出扭矩 ' + C.fN(plHvMid.C, 0) + 'Nm/最大 ' + C.fN(plHvMid.D, 0)
              + 'Nm，' + plHvMid.level + '；适配电机轴径 ' + plHvMid.shafts.join('/') + 'mm'
              + (plHvMid.shaftNote ? '；' + plHvMid.shaftNote : '') + '）' : '');
        }
        items.push({
          desc: (plMid > 1 ? '与电机一体化换向器 ' : '换向器 ') + rsdM + '/' + rTxtM
            + (revRatio > 1 ? '（速比 1:' + rTxtM
              + (revRatio === 1.5 || revRatio === 2 ? '，RS 标准' : '，可选（非 1:1/1:2 优先档）') + '）' : '（速比 1:1）')
            + (isHand ? '（手轮输入，一进两出）'
              : (plMid > 1
                ? '（配行星减速机 i=' + C.fN(plMid, plMid % 1 ? 1 : 0) + ':1，行星减速机与伞齿轮换向器一体化）（一进两出）'
                : '（带电机法兰，一进两出）'))
            + '1 台：承受扭矩约 ' + C.fN(tMidChk, 0)
            + (tMidChk > tMax + 1e-9 && mMid && mMid.torque_Nm
              ? 'Nm（' + (plMid > 1
                ? '按电机额定扭矩 ' + C.fN(mMid.torque_Nm, 1) + 'Nm × 行星减速机 ' + C.fN(plMid, 0)
                  + ' × 换向器速比 ' + rTxtM + ' 校核'
                : '按电机额定扭矩 ' + C.fN(mMid.torque_Nm, 1) + 'Nm 校核')
              + '，需求扭矩 ' + C.fN(tMax, 1) + 'Nm）' : 'Nm')
            + '（' + (isHand ? '手轮端' : '输入') + '转速 ' + C.fN(nInput * revRatio, 0)
            + 'rpm），许用扭矩见样本 p141；分两路后每路按一半校核'
            + plTxtMid + rsdFitNote(pickMid),
          qty: '1',
          _planet: plHvMid
        });
        var nShaftMid = pushShaftRows(items, cal, units, 0);
        items.push({ desc: '联轴器 ' + (nShaftMid * 2) + ' 个：每根传动轴配 2 个，与升降机蜗杆输入轴及传动轴配套', qty: String(nShaftMid * 2) });
        return items;
      }
      /*

*/
      var plMulti = Number(res.planetary_ratio) || 0;
      if (plMulti > 1) {
        var m0gbM = (res.motor_recommend || [])[0];
        var rpmInM = m0gbM ? m0gbM.rpm : (Number(cal.motor_rpm) || 3000);
        var rpmOutM = (m0gbM && m0gbM.gearbox && m0gbM.gearbox.out_rpm) ? m0gbM.gearbox.out_rpm : null;
        /**/
        var tRatM = (m0gbM && m0gbM.torque_Nm) ? Number(m0gbM.torque_Nm) : 0;
        var tOutTxtM = tRatM > 0
          ? '输出扭矩 = 电机额定扭矩 ' + C.fN(tRatM, 1) + 'Nm × 减速比 ' + C.fN(plMulti, 0) + ' = ' + C.fN(tRatM * plMulti, 0) + 'Nm'
          : '输出端需求扭矩约 ' + C.fN(res.planetary_out_torque_Nm || 0, 0) + 'Nm';
        /**/
        if (res.sv_changer) {
          var sRpmM = rpmOutM || 0;
          var runM = (m0gbM && m0gbM.motor_run_rpm) ? Number(m0gbM.motor_run_rpm) : Math.round(sRpmM * plMulti);
          var pickGbM = pickRsdForMotor(data, tRatM > 0 ? tRatM * plMulti : (Number(res.planetary_out_torque_Nm) || 0), runM, m0gbM, plMulti);
          items.push({
            desc: '电机端换向器 ' + pickGbM.frame + '/' + C.fN(plMulti, 0) + '（速比 1:' + C.fN(plMulti, 0) + '，带电机法兰）1 台：'
              + tOutTxtM + '（选型：许用输出扭矩须大于电机扭矩×速比，样本 p141），输入转速 '
              + C.fN(runM, 0) + ' rpm（伺服 30~3000rpm 调速运行，该速比额定输入 ' + C.fN(3000 / plMulti, 0) + 'rpm）'
              + (sRpmM ? '、输出转速 ' + C.fN(sRpmM, 1).replace(/\.0$/, '') + ' rpm' : '')
              + '，电机经换向器接首台升降机输入轴' + rsdFitNote(pickGbM),
            qty: '1'
          });
        } else {
        /*
*/
        var plHvM = (typeof g.SJScrewJack.planetPickOf === 'function')
          ? g.SJScrewJack.planetPickOf(data, plMulti, tRatM, rpmInM, g.SJScrewJack.motorShaftOf(m0gbM)) : null;
        items.push({
          desc: '行星减速机 i=' + C.fN(plMulti, plMulti % 1 ? 1 : 0) + '（减速比 ' + C.fN(plMulti, plMulti % 1 ? 1 : 0)
            + ':1）1 台：' + tOutTxtM
            + (plHvM ? '，选 ' + plHvM.model + '（额定输出扭矩 ' + C.fN(plHvM.C, 0) + 'Nm/最大 ' + C.fN(plHvM.D, 0)
              + 'Nm，' + plHvM.level + '；适配电机轴径 ' + plHvM.shafts.join('/') + 'mm'
              + (plHvM.shaftNote ? '；' + plHvM.shaftNote : '')
              + (plHvM.torqueNote ? '；' + plHvM.torqueNote : '') + '）' : '')
            + '（选型：额定输出扭矩须大于电机扭矩×减速比），输入转速 '
            + C.fN(rpmInM, 0) + ' rpm'
            + (rpmOutM ? '、输出转速 ' + rpmOutM + ' rpm' : '')
            + '，电机经减速机接首台升降机输入轴',
          qty: '1',
          _planet: plHvM
        });
        }
      }
      var shafts = units - 1;
      var nShaftEnd = pushShaftRows(items, cal, shafts, 0);
      items.push({ desc: '联轴器 ' + (nShaftEnd * 2) + ' 个：每根传动轴配 2 个，与升降机蜗杆输入轴及传动轴配套', qty: String(nShaftEnd * 2) });
      return items;
    }

    /*





*/
    var isU = /^U/.test(String(cal.layout || ''));
    var revPre = isU ? 'RSS' : 'RSD';   /**/
    /**/
    var isU2Lay = /^U2/.test(String(cal.layout || ''));
    var m0hu = (res.motor_recommend || [])[0];
    var tRated = (m0hu && m0hu.torque_Nm) ? Number(m0hu.torque_Nm) : 0;
    var dual = !isHand && tRated > 0 && isFixDrive233(cal) && res.dual_shaft === true;   /**/
    function revTxtHv(rv) {
      return rv > 1 ? '（速比 1:' + C.fN(rv, 1).replace(/\.0$/, '')
        + (rv === 1.5 || rv === 2 ? '，RS 标准' : '，可选（非 1:1/1:2 优先档）') + '）' : '（速比 1:1）';
    }
    function frameNameHv(tq, rpmIn) {
      /*
*/
      return revPre + String(pickRsd(data, tq, rpmIn)).replace(/^RS[SD]/, '');
    }
    /*





*/
    /**/
    var isBevelEhb = !isHand && tRated > 0 && /^(EHB|EHA|ELB|ELA)/.test(String(res.model || ''));
    if (isBevelEhb && isRevLayout(String(cal.layout || ''))) {
      var tEndEhb = tRated * revRatio;
      var rpmEhb = (m0hu && m0hu.rpm) ? m0hu.rpm : nInput * revRatio;   /**/
      var pickEhb = pickRsdForMotor(data, tEndEhb, rpmEhb, isFixDrive233(cal) || isHand ? null : m0hu, revRatio);
      var kEhb = pickEhb.frame;
      items.push({
        desc: '伞齿轮减速机 ' + 'RSD' + String(kEhb).replace(/^RSD/, '') + '/' + revRatio + revTxtHv(revRatio)
          + '1 台：减速比按速度要求匹配，与伺服电机一体化安装（按电机额定扭矩 '
          + C.fN(tRated, 1) + 'Nm' + (revRatio > 1 ? '×减速比 ' + C.fN(revRatio, 0) + '=' + C.fN(tEndEhb, 0) + 'Nm' : '')
          + '，输入转速 ' + C.fN(rpmEhb, 0) + 'rpm，不超过样本 p141 许用输出扭矩选机座号）' + rsdFitNote(pickEhb),
        qty: '1'
      });
      /*

*/
      if (isU) {
        if (isU2Lay) {
          var tEachU2 = tEndEhb / 2;
          var kEachU2 = pickRsd(data, tEachU2, nInput);
          items.push({
            desc: '换向器 RSS' + String(kEachU2).replace(/^RS[SD]/, '') + '/1（速比 1:1）2 台：U2 型布置在减速机输出两路各接 1 台，'
              + '每台按电机额定扭矩 ' + C.fN(tRated, 1) + 'Nm'
              + (revRatio > 1 ? '×减速比 ' + C.fN(revRatio, 0) + '=' + C.fN(tEndEhb, 0) + 'Nm' : '')
              + '、两台分摊÷2=' + C.fN(tEachU2, 0) + 'Nm 选机座号（输入转速 ' + C.fN(nInput, 0)
              + 'rpm，不超过样本 p141 许用输出扭矩）',
            qty: '2'
          });
        }
        var nShaftEU = pushShaftRows(items, cal, units, 0);
        var nCoupEU = nShaftEU * 2 + (isU2Lay ? 2 : 0);
        items.push({
          desc: '联轴器 ' + nCoupEU + ' 个：每根传动轴配 2 个（' + (nShaftEU * 2) + ' 个）'
            + (isU2Lay ? '，U2 型 2 台 RSS 换向器另配 2 个' : '')
            + '，与升降机输入轴及传动轴配套',
          qty: String(nCoupEU)
        });
      } else {
        var tEachEhb = tEndEhb / 2;
        var kEachEhb = pickRsd(data, tEachEhb, nInput);
        items.push({
          desc: '换向器 ' + 'RSD' + String(kEachEhb).replace(/^RSD/, '') + '/1（速比 1:1）2 台：伞齿轮减速机输出分两路各接 1 台，'
            + '每台按电机额定扭矩 ' + C.fN(tRated, 1) + 'Nm'
            + (revRatio > 1 ? '×减速比 ' + C.fN(revRatio, 0) + '=' + C.fN(tEndEhb, 0) + 'Nm' : '')
            + '、两台分摊÷2=' + C.fN(tEachEhb, 0) + 'Nm 选机座号（输入转速 ' + C.fN(nInput, 0)
            + 'rpm，不超过样本 p141 许用输出扭矩）',
          qty: '2'
        });
        var shaftsEhb = units + 2;
        /**/
        var nShaftEH = pushShaftRows(items, cal, shaftsEhb, 0);
        items.push({ desc: '联轴器 ' + (nShaftEH * 2) + ' 个：每根传动轴配 2 个，与升降机输入轴及传动轴配套', qty: String(nShaftEH * 2) });
      }
      return items;
    }
    if (dual) {
      /*



*/
      if (!isCenterLineAcc) {
        var tSumD = tRated * revRatio;
        var tEachD = tSumD / 2;
        var nmD = frameNameHv(tEachD, nInput * revRatio);
        var kD = pickRsd(data, tEachD, nInput * revRatio);
        items.push({
          desc: '换向器 ' + nmD + '/' + revRatio + revTxtHv(revRatio)
            + '2 台：交流电机双出轴两端各接 1 台（省去电机端换向器），每台按电机额定扭矩 '
            + C.fN(tRated, 1) + 'Nm'
            + (revRatio > 1 ? '×减速比 ' + C.fN(revRatio, 0) + '=' + C.fN(tSumD, 0) + 'Nm' : '')
            + '、两台分摊÷2=' + C.fN(tEachD, 0) + 'Nm 选机座号（不超过样本 p141 许用输出扭矩；'
            + '输入转速 ' + C.fN(nInput * revRatio, 0) + 'rpm'
            + (rsdAllowTxt(data, kD, nInput * revRatio) ? '，该转速下' + rsdAllowTxt(data, kD, nInput * revRatio).replace('（', '').replace('）', '') : '') + '）',
          qty: '2'
        });
      }
    } else {
      /*

*/
      var plServo = Number(res.planetary_ratio) || 1;
      var gbMultHv = revRatio * plServo;
      var tEndHv = (!isHand && tRated > 0) ? tRated * gbMultHv : tMax;
      var endWhy = (isHand || !(tRated > 0))
        ? '承受全平台扭矩约 '
        : (gbMultHv > 1
          ? '按电机额定扭矩 ' + C.fN(tRated, 1) + 'Nm×减速比 ' + C.fN(gbMultHv, gbMultHv % 1 ? 1 : 0) + '='
          : '按电机额定扭矩 ' + C.fN(tRated * gbMultHv, 1) + 'Nm=');
      /**/
      var pickEndHv = pickRsdForMotor(data, tEndHv, isHand ? 0 : nInput * revRatio,
        (isHand || isFixDrive233(cal)) ? null : m0hu, revRatio);
      var kEndHv = pickEndHv.frame;
      items.push({
        desc: (isHand ? '带手轮输入的换向器 RSD' : '与电机一体化换向器 RSD')
          + String(kEndHv).replace(/^RS[SD]/, '')
          + (plServo > 1 ? '（配行星减速机 i=' + C.fN(plServo, plServo % 1 ? 1 : 0) + ':1，行星减速机与伞齿轮换向器一体化）' : '')
          + '/' + revRatio + revTxtHv(revRatio)
          + '1 台：' + endWhy + C.fN(tEndHv, 0) + 'Nm'
          + '（' + (isHand ? '手轮端' : '输入') + '转速 ' + C.fN(nInput * revRatio, 0)
          + 'rpm），不超过样本 p141 许用输出扭矩选机座号' + rsdFitNote(pickEndHv),
        qty: '1'
      });
      /*





*/
      if (units - 2 >= 1 && !isCenterLineAcc) {
        var tHalfHv = tEndHv / 2;
        var kHalf = pickRsd(data, tHalfHv, isHand ? 0 : nInput);
        var nMidHv = (units >= 4 ? 2 : (units - 2)) + (isU2Lay ? 2 : 0);
        items.push({
          desc: '换向器 ' + revPre + String(kHalf).replace(/^RS[SD]/, '') + '/1（速比 1:1）' + nMidHv
            + ' 台：' + (isU2Lay ? 'U 型 ' + (units - 2) + ' 台中间换向器 + U2 型另配 2 台（减速机输出分两路各接 1 台）；' : '')
            + '按电机端换向器扭矩的一半约 ' + C.fN(tHalfHv, 0)
            + 'Nm 选机座号（不超过样本 p141 许用输出扭矩'
            + (isHand ? '' : '；输入转速 ' + C.fN(nInput, 0) + 'rpm'
              + (rsdAllowTxt(data, kHalf, nInput) ? '，' + rsdAllowTxt(data, kHalf, nInput).replace('（', '').replace('）', '') : ''))
            + '）',
          qty: String(nMidHv)
        });
      }
    }
    //
    var shaftCount = /^H/.test(String(cal.layout || '')) ? (units + 2) : units;
    var nShaftHu = pushShaftRows(items, cal, shaftCount, 0);
    //
    var nCoupHu = nShaftHu * 2 + (isU2Lay ? 2 : 0);
    items.push({
      desc: '联轴器 ' + nCoupHu + ' 个：每根传动轴配 2 个（' + (nShaftHu * 2) + ' 个）'
        + (isU2Lay ? '，U2 型 2 台 RSS 换向器另配 2 个' : '') + '，与升降机蜗杆输入轴及传动轴配套',
      qty: String(nCoupHu)
    });
    return items;
  }

  /*









*/
  var RSD_MOTOR_FIT = {
    RSD065: { pLow: [0.05, 0.1, 0.2, 0.4], pHigh: [0.05, 0.1, 0.2], flange: [40, 60], shaftMax: 14 },
    RSD090: { pLow: [0.6, 0.75, 0.85, 1, 1.3, 1.5], pHigh: [0.4, 0.6, 0.75], flange: [80, 100, 130], shaftMax: 24, shaftNote: '24 轴无法开键槽' },
    RSD120: { pLow: [1, 1.3, 1.5, 1.8, 2, 2.5], pHigh: [0.75, 1, 1.3, 1.5], flange: [80, 100, 130], shaftMax: 24 },
    RSD140: { pLow: [2, 2.5, 3, 4, 5.5], pHigh: [2, 2.5, 3], flange: [130, 150, 180], shaftMax: 35 },
    RSD160: { pLow: [3, 4, 5.5, 7.5], pHigh: [3, 4], flange: [130, 150, 180, 200], shaftMax: 42 },
    RSD200: { pLow: [7.5, 10, 11, 12, 14, 16], pHigh: [5.5, 7.5, 11, 12], flange: [180, 200, 220, 240], shaftMax: 55 },
    RSD250: { pLow: [18, 20, 22, 24, 26, 30], pHigh: [14, 16, 18, 20, 22], flange: [180, 200, 220, 240, 260, 280], shaftMax: 60 },
    RSD280: {}                                    /**/
  };
  var RSD_FRAME_ORDER = ['RSD065', 'RSD090', 'RSD120', 'RSD140', 'RSD160', 'RSD200', 'RSD250', 'RSD280'];
  var STD_FLANGE = [40, 60, 80, 100, 130, 150, 180, 200, 220, 240, 260, 280];
  /*

*/
  function nearestFlange(x) {
    if (typeof g.SJScrewJack !== 'undefined' && g.SJScrewJack.nearestFlange) return g.SJScrewJack.nearestFlange(x);
    var best = STD_FLANGE[0], d = 1e9;
    STD_FLANGE.forEach(function (f) { if (Math.abs(f - x) < d) { d = Math.abs(f - x); best = f; } });
    return best;
  }
  /*
*/
  function shaftOfFlange(flange, kw) {
    if (typeof g.SJScrewJack !== 'undefined' && g.SJScrewJack.shaftOfFlange) return g.SJScrewJack.shaftOfFlange(flange, kw);
    if (flange <= 40) return 8;
    if (flange <= 60) return kw <= 0.4 ? 11 : 14;
    if (flange <= 80) return kw <= 1.5 ? 19 : 22;
    if (flange <= 100) return 24;
    if (flange <= 130) return kw < 2 ? 24 : 28;
    if (flange <= 150) return 30;
    if (flange <= 180) return kw <= 5.5 ? 35 : 42;
    if (flange <= 200) return 42;
    if (flange <= 220) return 48;
    if (flange <= 240) return 55;
    if (flange <= 260) return 60;
    return 65;
  }
  /**/
  function motorMountOf(m) {
    if (typeof g.SJScrewJack !== 'undefined' && g.SJScrewJack.motorMountOf) return g.SJScrewJack.motorMountOf(m);
    if (!m) return null;
    var fr = String(m.frame || '');
    var kw = Number(m.power_kW) || 0;
    /*



*/
    var nums = [];
    fr.replace(/\d+(\.\d+)?/g, function (sTxt) { nums.push(Number(sTxt)); return sTxt; });
    var isCenterH = /轴高/.test(fr);
    var isFlange = /法兰/.test(fr);
    var flanges = [];
    nums.forEach(function (v) {
      var f = 0;
      if (isCenterH) f = nearestFlange(v * 2);            /**/
      else if (isFlange) f = nearestFlange(v);
      else if (v >= 40) f = nearestFlange(v);
      else if (v > 0) f = nearestFlange(v * 2);
      if (f && flanges.indexOf(f) < 0) flanges.push(f);
    });
    flanges.sort(function (a, b) { return a - b; });
    var flange = flanges.length ? flanges[0] : 0;
    return { power: kw, flange: flange, flanges: flanges, multi: flanges.length > 1,
      shaft: flange ? shaftOfFlange(flange, kw) : 0, frame: fr };
  }
  function rsdFitMotor(frameKey, motor, ratio) {
    var fit = RSD_MOTOR_FIT[frameKey];
    var mount = motorMountOf(motor);
    if (!fit || !mount || !mount.flange) return { ok: true, mount: mount };
    var key = (Number(ratio) || 1) > 10 ? 'pHigh' : 'pLow';
    var list = fit[key];
    /*
*/
    var pMax = (list && list.length) ? list[list.length - 1] : null;
    var okP = (pMax == null) || (mount.power <= pMax + 1e-6);
    if (!okP) return { ok: false, power: false, flange: true, shaft: true, mount: mount };
    /*
*/
    var cand = (mount.flanges || [mount.flange]).filter(function (f) {
      return !fit.flange || fit.flange.indexOf(f) >= 0;
    });
    if (!cand.length) return { ok: false, power: true, flange: false, shaft: true, mount: mount };
    for (var ci = 0; ci < cand.length; ci++) {
      var sh = shaftOfFlange(cand[ci], mount.power);
      if (fit.shaftMax == null || sh <= fit.shaftMax) {
        var used = { power: mount.power, flange: cand[ci], flanges: mount.flanges, multi: mount.multi,
          shaft: sh, frame: mount.frame };
        return { ok: true, power: true, flange: true, shaft: true, mount: used };
      }
    }
    return { ok: false, power: true, flange: true, shaft: false, mount: mount };
  }
  /**/
  function pickRsdForMotor(data, torqueNm, inputRpm, motor, ratio) {
    /*

*/
    var tqChk = Math.max(Number(torqueNm) || 0, (motor && motor.torque_Nm) ? Number(motor.torque_Nm) : 0);
    var base = pickRsd(data, tqChk, inputRpm);
    if (!motor) return { frame: base, baseFrame: base, mount: null, bumped: false, over: false };
    var idx = RSD_FRAME_ORDER.indexOf(base);
    if (idx < 0) return { frame: base, baseFrame: base, mount: motorMountOf(motor), bumped: false, over: false };
    for (var i = idx; i < RSD_FRAME_ORDER.length; i++) {
      var f = RSD_FRAME_ORDER[i];
      var fit = rsdFitMotor(f, motor, ratio);
      if (fit.ok) {
        return { frame: f, baseFrame: base, mount: fit.mount, bumped: i > idx, over: false };
      }
    }
    return { frame: RSD_FRAME_ORDER[RSD_FRAME_ORDER.length - 1], baseFrame: base,
      mount: motorMountOf(motor), bumped: true, over: true };
  }
  /**/
  function rsdFitNote(pick) {
    if (!pick || !pick.mount) return '';
    var mt = '电机 ' + C.fN(pick.mount.power, 2) + 'kW／法兰 ' + pick.mount.flange + '／轴径 ' + pick.mount.shaft + 'mm';
    /**/
    if (pick.mount.multi && pick.mount.flanges && pick.mount.flanges.length > 1) {
      mt += '（该型号可选法兰 ' + pick.mount.flanges.join('/') + '，此处按 ' + pick.mount.flange
        + ' 一体化，订货须与厂家确认供货法兰）';
    }
    if (pick.over) {
      return '；注意：' + mt + ' 超出样本最大机座号 ' + pick.frame + ' 的一体化匹配能力，须与厂家确认';
    }
    if (!pick.bumped) return '';
    return '；已按一体化匹配升档：' + mt + ' 超出 ' + pick.baseFrame + ' 的允许法兰/轴径/功率，升为 ' + pick.frame;
  }

  function pickRsd(data, torqueNm, inputRpm) {
    var rtd = (data.reverse_gearboxes || {}).rsd_table || {};
    var tbl = rtd.at_1450rpm_1to1 || {};
    var byRpm = rtd.torque_by_rpm || {};
    var keys = Object.keys(tbl);
    var n = Number(inputRpm) || 0;
    /*



*/
    function allow(k) {
      var pts = byRpm[k];
      if (n > 0 && pts && pts.length) {
        var sorted = pts.slice().sort(function (a, b) { return a.rpm - b.rpm; });
        if (n <= sorted[0].rpm) return Number(sorted[0].torque_Nm) || 0;
        for (var i = 0; i < sorted.length - 1; i++) {
          var a = sorted[i], b = sorted[i + 1];
          if (n >= a.rpm && n <= b.rpm) {
            return a.torque_Nm + (b.torque_Nm - a.torque_Nm) * (n - a.rpm) / (b.rpm - a.rpm);
          }
        }
        return Number(sorted[sorted.length - 1].torque_Nm) || 0;
      }
      return Number((tbl[k] || {}).torque_Nm) || 0;
    }
    var best = null;
    keys.forEach(function (k) {
      var t = allow(k);
      if (t >= torqueNm && (best === null || t < allow(best))) best = k;
    });
    return best || keys[keys.length - 1] || 'RSD280';
  }
  /**/
  function rsdAllowTxt(data, k, inputRpm) {
    var rtd = (data.reverse_gearboxes || {}).rsd_table || {};
    var pts = (rtd.torque_by_rpm || {})[k];
    var n = Number(inputRpm) || 0;
    if (!n || !pts || !pts.length) return '';
    var sorted = pts.slice().sort(function (a, b) { return a.rpm - b.rpm; });
    var t = null;
    if (n <= sorted[0].rpm) t = sorted[0].torque_Nm;
    else if (n >= sorted[sorted.length - 1].rpm) t = sorted[sorted.length - 1].torque_Nm;
    else {
      for (var i = 0; i < sorted.length - 1; i++) {
        var a = sorted[i], b = sorted[i + 1];
        if (n >= a.rpm && n <= b.rpm) {
          t = Math.round((a.torque_Nm + (b.torque_Nm - a.torque_Nm) * (n - a.rpm) / (b.rpm - a.rpm)) * 10) / 10;
          break;
        }
      }
    }
    return t != null ? '（' + Math.round(n) + 'rpm 下样本 p141 许用输出扭矩约 ' + t + 'Nm）' : '';
  }

  /*

*/
  var LAYOUT_IMAGES = {
    1: [{ v: '单台', imgs: null }],   /**/
    2: [
      { v: '电机中间', imgs: { S: '两台机械同步螺旋升降机中间输入.png', R: '两台机械同步螺母运动-电机中间.png' },
        bySeriesImgs: { EHB: { R: '两台EHB螺旋升降机螺母运动-电机中间.png' } } },
        /**/
      { v: '电机单侧', imgs: { S: '两台机械同步螺旋升降机单侧输入.png', R: '两台机械同步螺母运动-电机单侧.png' },
        bySeriesImgs: { EHB: { S: '两台EHB螺旋升降机单侧输入.png', R: '两台EHB螺旋升降机螺母运动-电机单侧.png' } } },
        /**/
      { v: '导向柱一体化', imgs: null }   /**/
    ],
    3: [
      { v: '直线布置-电机单侧', imgs: { S: '三台机械同步螺旋升降机一字型.png', R: '三台机械同步螺母运动-直线布置-电机单侧.png' } },
      { v: '垂直布置-电机中间', imgs: { S: '三台机械同步螺旋升降机垂直布置-电机中间.png', R: '三台机械同步螺母运动-垂直布置-电机中间.png' } }
      /**/
    ],
    4: [
      { v: 'H型布置', imgs: { S: '四台机械同步螺旋升降机H型布置.png', R: '四台机械同步螺旋升降机H型布置-螺母运动.png' },   /**/
        bySeriesImgs: { EHB: { R: '四台EHB螺旋升降机螺母运动-H型布置.png' } } },   /**/
      { v: 'U型布置', imgs: { S: '四台同步螺旋升降机U型布置-丝杠运动.png', R: '四台同步螺旋升降机U型布置-螺母运动.png' },
        bySeriesImgs: { EHB: { R: '四台EHB螺旋升降机螺母运动-U型布置.png' } } },
      /*

*/
        { v: 'U2型布置', imgs: { S: '四台EHB螺旋升降机丝杠运动-U2型布置.png', R: '四台EHB螺旋升降机螺母运动-U2型布置.png' },
          bySeriesImgs: { EHB: { S: '四台EHB螺旋升降机丝杠运动-U2型布置.png', R: '四台EHB螺旋升降机螺母运动-U2型布置.png' } } },
      /*
*/
      { v: '直线布置', imgs: { S: '四台机械同步螺旋升降机一字布置.png', R: '四台机械同步螺母运动-直线布置.png' },
        bySeriesImgs: { SCA: { S: '四台推杆直线布置.png', R: '四台推杆直线布置.png' },
                        SCB: { S: '四台推杆直线布置.png', R: '四台推杆直线布置.png' } } }
    ],
    /**/
    6: [
      { v: '直线布置', imgs: { S: '六台机械同步螺旋升降机一字布置.png', R: '六台机械同步螺母运动-直线布置.png' } },
      { v: 'H型布置', imgs: { S: '六台机械同步螺旋升降机H型布置.png', R: '六台机械同步螺旋升降机H型布置-螺母运动.png' } }
    ],
    8: [
      { v: '直线布置', imgs: { S: '八台机械同步螺旋升降机一字布置.png', R: '八台机械同步螺母运动-直线布置.png' } },
      { v: 'H型布置', imgs: { S: '八台机械同步螺旋升降机H型布置.png', R: '八台机械同步螺旋升降机H型布置-螺母运动.png' } }
      /**/
    ]
  };

  /*

*/
  function layoutOptions(inp) {
    if (String(inp && inp.units) === 'custom') return [{ v: '非标布置', t: '非标布置（客户上传布置图）' }];
    var n = effUnits(inp);
    /**/
    if (n === 1) {
      var s = inp && inp.series;
      var img1 = (s === 'EHB') ? '-ehb' : (s === 'SCA' || s === 'SCB') ? '-sca' : '';
      if (img1 || s === 'SJA' || s === 'SJB' || s === 'KV') {
        /*


*/
        var hand1 = !!(inp && inp.drive === 'hand');
        var isR = isMotionR(inp);   /**/
        var motorImg = (!img1 && !isR)
          ? 'lay1-motor-s.jpg'
          : (img1 === '-ehb' && isR)
            ? 'lay1-motor-ehb-r.jpg'   /**/
            : 'lay1-motor' + img1 + '.jpg';
        return [{ v: '无电机', t: '无电机', img: 'lay1-nomotor' + img1 + '.jpg' },
          { v: '电机一体化', t: '电机一体化', img: motorImg,
            dis: hand1, hint: hand1 ? '手摇驱动无电机，不可选' : '' }];
      }
      return [];
    }
    var arr = LAYOUT_IMAGES[n] || [];
    /**/
    var series = inp && inp.series;
    var guideOk = (series === 'SJA' || series === 'SJB' || series === 'KV' || series === 'EHB')
      && String(inp && inp.motion) !== 'R';
    /**/
    var u2Ok = series === 'EHB';
    /*
*/
    var line4Ok = (series === 'SJA' || series === 'SJB' || series === 'KV'
      || series === 'SCA' || series === 'SCB')
      || (isMotionR(inp) && series === 'DHB');
    var picks = (g.SJCatalog && g.SJCatalog.LAYOUT_PICKS && g.SJCatalog.LAYOUT_PICKS[n]) || [];
    var isHandPick = inp && inp.drive === 'hand';
    return arr.filter(function (o) {
      if (o.v === '导向柱一体化' && !guideOk) return false;
      if (o.v === 'U2型布置' && !u2Ok) return false;
      if (o.v === '直线布置' && n === 4 && !line4Ok) return false;
      return true;
    }).map(function (o) {
      var pick = null;
      for (var i = 0; i < picks.length; i++) { if (picks[i].v === o.v) { pick = picks[i]; break; } }
      var img = '';
      if (pick) {
        /*
*/
        var ssv = pick.bySeries && inp && inp.series && pick.bySeries[inp.series];
        if (ssv) {
          if (typeof ssv === 'string') img = ssv;
          else img = (ssv[inp.motion] !== undefined ? ssv[inp.motion] : ssv.S);
          if (img && typeof img === 'object') img = img.img;
        } else if (pick.byMotion && inp && inp.motion && pick.byMotion[inp.motion]) {
          var mvO = pick.byMotion[inp.motion];
          img = (typeof mvO === 'string') ? mvO : mvO.img;
        } else {
          img = pick.img || '';
        }
      }
      /*
*/
      var label = isHandPick
        ? o.v.replace(/电机中间/g, '手轮中间').replace(/电机单侧/g, '手轮单侧')
        : o.v;
      /*
*/
      var elecLay = !!(inp && inp.sync === '电气');
      return { v: o.v, t: label, img: img, dis: elecLay || undefined };
    });
  }

  /*





*/
  function syncDriveLayout(inp, changed) {
    if (!inp) return inp;
    var L = inp.layout;
    if (changed === 'sync') {
      /*
*/
      if (inp.sync === '电气' && effUnits(inp) > 1 && String(inp.drive || '').indexOf('servo') !== 0) {
        inp.drive = 'servo380';
      }
      return inp;
    }
    if (changed === 'motion') {
      /*
*/
      var optsM = layoutOptions(inp);
      if (optsM.length && !optsM.some(function (o) { return o.v === inp.layout; })) {
        inp.layout = optsM[0].v;
      }
      return inp;
    }
    if (changed === 'layout' && (L === '无电机' || L === '电机一体化')) {
      if (inp.drive === 'hand') {
        inp.layout = '无电机';
      } else if (L === '电机一体化' && inp.drive === 'none') {
        inp.drive = 'ac3';
      } else if (L === '无电机' && inp.drive !== 'hand') {
        inp.drive = 'none';
      }
      return inp;
    }
    if (changed === 'drive') {
      /*
*/
      var opts = layoutOptions(inp);
      var hasNo = opts.some(function (o) { return o.v === '无电机'; });
      if (hasNo && (inp.drive === 'hand' || inp.drive === 'none')) {
        inp.layout = '无电机';
      }
    }
    if (changed === 'input_type') {
      /*

*/
      if (/^P[34]$/.test(String(inp.input_type || '')) && inp.drive !== 'hand') {
        var optsIt = layoutOptions(inp);
        if (optsIt.some(function (o) { return o.v === '电机一体化'; })) {
          inp.layout = '电机一体化';
          if (inp.drive === 'none') inp.drive = 'ac3';
        }
      }
    }
    return inp;
  }

  /*
*/
  function layoutDisp(cal) {
    var t = String((cal && cal.layout) || '');
    if (!cal || cal.drive !== 'hand') return t;
    return t.replace(/电机中间/g, '手轮中间')
      .replace(/电机单侧/g, '手轮单侧')
      .replace(/电机端/g, '手轮端');
  }

  /**/
  function singleImage(cal) {
    if (cal.motion !== 'R') return '';                     //
    var mt = String(cal.motor_type || '');
    if (mt.indexOf('交流电机') >= 0) return '单台螺旋升降机螺母运动匹配交流电机.png';
    if (mt.indexOf('伺服') >= 0) return '单台螺旋升降机螺母运动匹配伺服电机.png';
    return '单台螺旋升降机螺母运动匹配交流电机.png';
  }

  /**/
  function layoutImageFor(cal) {
    if (cal.isCustomLayout) return '';                     //
    /*
*/
    if (cal.sync === '电气') return singleImage(cal);
    if (cal.units <= 1) return singleImage(cal);
    var arr = LAYOUT_IMAGES[cal.units] || [];
    var raw = cal.raw || cal;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].v !== cal.layout) continue;
      if (!arr[i].imgs) return '';
      /*
*/
      var bs = arr[i].bySeriesImgs && raw && raw.series && arr[i].bySeriesImgs[raw.series];
      if (bs && bs[cal.motion] !== undefined) return bs[cal.motion] || '';
      /**/
      var im = arr[i].imgs[cal.motion];
      if (im === undefined) im = arr[i].imgs.S;
      return im || '';
    }
    return '';
  }

  /*
*/
  function layoutPickFor(cal) {
    var raw = cal.raw || cal;
    var n = effUnits(raw);
    /*

*/
    if (cal.sync === '电气' && n > 1) {
      var p1 = (g.SJCatalog && g.SJCatalog.LAYOUT_PICKS[1]) || [];
      var se225 = String((raw && raw.series) || '');
      for (var i225 = 0; i225 < p1.length; i225++) {
        if (p1[i225].v !== '电机一体化') continue;
        var sv225 = p1[i225].bySeries && se225 ? p1[i225].bySeries[se225] : undefined;
        if (typeof sv225 === 'string') return { v: p1[i225].v, img: sv225, skill: p1[i225].skill };
        if (sv225 && typeof sv225 === 'object') {
          var s225 = (sv225[raw.motion] !== undefined) ? sv225[raw.motion] : sv225.S;
          if (typeof s225 === 'string') return { v: p1[i225].v, img: s225, skill: p1[i225].skill };
        }
        /**/
        if (p1[i225].byMotion && raw.motion && p1[i225].byMotion[raw.motion]) {
          var mv225 = p1[i225].byMotion[raw.motion];
          if (typeof mv225 === 'string') return { v: p1[i225].v, img: mv225, skill: p1[i225].skill };
          if (mv225 && mv225.img) return { v: p1[i225].v, img: mv225.img, skill: mv225.skill || p1[i225].skill };
        }
        return p1[i225];
      }
      return null;
    }
    var picks = (g.SJCatalog && g.SJCatalog.LAYOUT_PICKS[n]) || [];
    for (var i = 0; i < picks.length; i++) {
      if (picks[i].v !== cal.layout) continue;
      var p = picks[i];
      /*
*/
      if (p.bySeries && raw.series && p.bySeries[raw.series]) {
        var sv = p.bySeries[raw.series];
        if (typeof sv === 'string') return { v: p.v, img: sv, skill: p.skill };
        var smv = sv[raw.motion] !== undefined ? sv[raw.motion] : sv.S;
        if (typeof smv === 'string') return { v: p.v, img: smv, skill: p.skill };
        return { v: p.v, img: smv.img, skill: smv.skill || p.skill };
      }
      /*
*/
      if (p.byMotion && raw.motion && p.byMotion[raw.motion]) {
        var mv = p.byMotion[raw.motion];
        if (typeof mv === 'string') return { v: p.v, img: mv, skill: p.skill };
        return { v: p.v, img: mv.img, skill: mv.skill || p.skill };
      }
      return p;
    }
    return null;
  }

  /**/
  /*

*/
  var TAIL_BUDGET = 15100;                 //
  /*


*/
  var TAIL_SAFETY = 1400;
  function tailWidth(s) {
    s = String(s || '');
    var w = 0;
    for (var i = 0; i < s.length; i++) {
      var o = s.charCodeAt(i);
      if (o > 0x2E7F) w += 1;
      else if (s.charAt(i) === ' ') w += 0.28;
      else w += 0.52;
    }
    return w;
  }
  /**/
  function tailLines(s, widthTwips, szHalf) {
    var w = tailWidth(s) * (szHalf / 2) * 20;
    return Math.max(1, Math.ceil(w / Math.max(1, widthTwips)));
  }
  function tailBudget(aboutAll, featAll, items, p2Extras) {
    function h(aN, fR) {
      var H = 1900;   //
      (items || []).forEach(function (it) {
        var d = String(it && it.desc || ''), q = String(it && it.qty || '');
        if (!d.trim() && !q.trim()) return;
        H += 60 + 235 * Math.max(2, tailLines(d, 2400, 14), tailLines(it && it.spec, 4000, 14));
      });
      H += 430;       //
      for (var i = 0; i < aN; i++) H += 100 + 235 * tailLines(aboutAll[i], 9440, 14);
      H += 430;       //
      for (var r = 0; r < fR; r++) {
        H += 60 + 235 * Math.max(2, tailLines(featAll[r * 2], 4600, 14),
          tailLines(featAll[r * 2 + 1], 4600, 14));
      }
      return H;
    }
    /**/
    var budget = TAIL_BUDGET - TAIL_SAFETY - Math.max(0, p2Extras || 0);
    var aN = aboutAll.length, fR = Math.ceil(featAll.length / 2);
    var full = h(aN, fR), H = full;
    while (H > budget) {
      if (aN > 2) aN -= 1;
      else if (fR > 2) fR -= 1;
      else break;
      H = h(aN, fR);
    }
    return { est: full, kept: H, aboutKeep: aN, featKeep: fR, budget: budget };
  }

  function clientLines(cal, res) {
    var unitTxt = { t: '吨', kN: 'kN', kgf: 'kgf', N: 'N' };
    var lines = [];
    var code = suggestCode(cal, res);
    if (code) lines.push('推荐型号全代号：' + code + '（按样本型号标注写全：系列-运动-减速比-行程-接头-输入形式-轴方向-附件/电机，客户可改选更大型号）');
    lines.push('同步台数：' + cal.units + ' 台' + (cal.units > 1 ? '（' + (cal.sync === '电气' ? '电气' : '机械') + '同步）' : ''));
    lines.push('总负载：' + ((cal.raw.load === '' || cal.raw.load == null) ? 0 : cal.raw.load) + ' '
      + (unitTxt[cal.raw.load_unit] || 't') + '（' + C.fN(cal.loadKN, 2) + ' kN，单台 ' + C.fN(cal.loadKN / cal.units, 2) + ' kN）');
    lines.push('行程：' + cal.stroke_mm + ' mm');
    lines.push('速度：' + cal.speed_mm_s + ' mm/s');
    lines.push('运动方式：' + (cal.motion === 'R' ? '螺母运动（丝杠固定）' : '丝杠运动（螺母固定）'));
    lines.push('导向：' + (cal.guide === '有' ? '有（客户自备导向）' : '无'));
    lines.push('安装方式：' + cal.mounting);
    if (cal.layout) lines.push('布置形式：' + layoutDisp(cal));
    /**/
    lines.push((cal.series === 'EHB'
      ? ('丝杠选择：' + screwPickText(cal))
      : ('重复精度：' + (cal.precision_mm === null ? '无要求' : cal.precision_mm + ' mm'))));
    lines.push('环境：' + cal.env + '，' + cal.ambient_temp + '℃');
    if (cal.load_pull_t) lines.push('总负载拉力：' + cal.load_pull_t + ' t（拉力工况不校核稳定性）');
    if (cal.static_load_t) lines.push('静载：' + cal.static_load_t + ' t');
    lines.push('工作节拍：每日 ' + (cal.cycles_per_day === null ? '—' : cal.cycles_per_day) + ' 次 × '
      + (cal.hours_per_day || 8) + ' 小时，年运行 ' + cal.days_per_year + ' 天');
    lines.push('驱动选择：' + (cal.drive_label || cal.motor_type));
    /**/
    if (cal.drive === 'hand' && res && res.hand_torque_Nm != null) {
      lines.push('手摇扭矩：' + C.fN(res.hand_torque_Nm, 1) + ' N·m（按启动效率 '
        + (res.eta_start != null ? C.fN(res.eta_start, 2) : '—') + ' 计算，无电机相关计算）');
      /**/
      lines.push('手摇把：手摇力 ' + ((res.hand_force_use_kg != null) ? res.hand_force_use_kg : res.hand_force_kg)
        + ' kg（手摇把半径 ' + (res.hand_radius_mm || 200) + 'mm'
        + (res.hand_radius_mm === 400 ? '，200mm 时 ' + res.hand_force_kg + ' kg 超 10kg 限额' : '')
        + (res.hand_force_tolerance ? '，超出 ≤5% 可设定合格' : '') + '）');
    }
    if (cal.drive === 'none' && res) {
      lines.push('电机技术要求：所需功率 ' + C.fN((res.motor_power_kW != null ? res.motor_power_kW : res.total_power_kW), 2)
        + ' kW / 所需扭矩 ' + C.fN(res.motor_torque_Nm, 1) + ' N·m / 转速 '
        + (res.motor_sync || cal.motor_rpm || res.rpm_needed || '—') + ' rpm（不配电机，客户按此自配）');
    }
    /**/
    if (cal.series !== 'EHB') {
      lines.push('轴和电机法兰方向：' + (cal.motion === 'R'
        ? '无需选择（螺母运动 R 型号无轴方向段）'
        : (cal.input_type === 'P2' ? '无需选择（双输入轴 P2）' : (cal.shaft_dir === 'LH' ? '左输入 LH' : '右输入 RH（标配）'))));
    }
    lines.push('安装方式：' + (cal.input_type || 'P1') + '（' + ({
      P1: '单输入轴', P2: '双输入轴', P3: '单电机法兰输入', P4: '电机法兰+轴',
      EHB: '单轴布置，1 个换向器（带电机法兰，与电机连接）',
      EIB: '直线双轴布置，1 个换向器（带电机法兰，与电机连接），另一端为轴端',
      ELB: '直角双轴布置，2 个换向器（其一带电机法兰与电机连接，另一端为轴端）',
      EUB: '三轴布置，3 个换向器（其一带电机法兰与电机连接，其余为轴端）',
      EQB: '四轴布置，4 个换向器（其一带电机法兰与电机连接，其余为轴端）',
      /**/
      EHA: '单轴布置，1 个换向器（带电机法兰，与电机连接）',
      EIA: '直线双轴布置，1 个换向器（带电机法兰，与电机连接），另一端为轴端',
      ELA: '直角双轴布置，2 个换向器（其一带电机法兰与电机连接，另一端为轴端）',
      EUA: '三轴布置，3 个换向器（其一带电机法兰与电机连接，其余为轴端）',
      EQA: '四轴布置，4 个换向器（其一带电机法兰与电机连接，其余为轴端）'
    }[cal.input_type] || '单输入轴') + '）');
    if (cal.series === 'EHB' && /^E/.test(cal.input_type || '')) {
      lines.push('输入连接尺寸：RX/LX 按力姆泰克样本第 104 页对应形式核对');
    }
    var jt = (g.SJCatalog ? g.SJCatalog.JOINTS : []).filter(function (x) { return x.v === cal.joint; })[0];
    lines.push('接头形式：' + (cal.motion === 'R' ? '无需接头（螺母运动）' : (jt ? jt.t : cal.joint)));
    if (cal.accessories && cal.accessories.length) {
      /**/
      var exAcc = jackIsExMotor(res, cal);
      var accNames = cal.accessories.map(function (v) {
        var a = (g.SJCatalog ? g.SJCatalog.ACCESSORIES : []).filter(function (x) { return x.v === v; })[0];
        if (exAcc && (String(v) === 'FCP' || String(v) === 'FCG')) return '防爆限位开关';
        return a ? a.t.split('（')[0].split(' ')[0] : v;
      });
      var seenExAcc = false;
      accNames = accNames.filter(function (x) {
        if (x !== '防爆限位开关') return true;
        if (seenExAcc) return false;
        seenExAcc = true; return true;
      });
      /**/
      lines.push('附件选择：' + accNames.join('、'));
    } else if (cal.motion === 'R') {
      lines.push('附件选择：无（螺母运动 R 不配防转、限位开关与接头）');
    }
    if (cal.special && cal.special.length) {
      var spTx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
      var spNames = cal.special.map(function (v) {
        var s = (g.SJCatalog ? g.SJCatalog.SPECIALS : []).filter(function (x) { return x.v === v; })[0];
        var t = s ? s.t : v;
        return spTx[v] ? (t + '（' + spTx[v] + '）') : t;
      });
      lines.push('特殊要求：' + spNames.join('、'));
    }
    lines.push('电机类型：' + cal.motor_type);
    return lines;
  }

  /*




*/
  function suggestCode(cal, res) {
    if (!res || !res.model || res.error) return '';
    var model = res.model;
    /*
*/
    /**/
    var dispFam = (cal.cross_fam && MODEL_ALIAS[cal.cross_fam] ? cal.cross_fam : null)
      || (MODEL_ALIAS[cal.series] ? cal.series : null)
      || (cal.forced_prefix && MODEL_ALIAS[cal.forced_prefix] ? cal.forced_prefix : null);
    if (dispFam) model = model.replace(/^[A-Z]+/, dispFam);
    if (cal.series === 'KV') model = model.replace(/^KV/, cal.kv_mode || 'KVL');   // KVL60/KVK60
    /*
*/
    var isPushRod = cal.series === 'SCA' || cal.series === 'SCB'
      || cal.forced_prefix === 'SCA' || cal.forced_prefix === 'SCB';
    var parts = [model];
    if (!isPushRod) parts.push((cal.motion === 'R') ? 'R' : 'S');
    if (res.route === 'A') {
      parts.push(res.ratio_key || res.ratio || '');
    } else {
      /*
*/
      var mDef = (g.SJ_DATA && g.SJ_DATA.models) ? g.SJ_DATA.models[res.model] : null;
      var vDef = (mDef && mDef.variants && res.variant) ? mDef.variants[res.variant] : null;
      var segs = String((vDef && vDef.model_code) || '').split('-');
      var screwSeg = '', gearSeg = '';
      segs.forEach(function (sg) {
        if (!screwSeg && /^\d{1,3}[xX×]\d{1,3}$/.test(sg)) screwSeg = sg.toLowerCase().replace('×', 'x');
        if (!gearSeg && /^\d+:\d+$/.test(sg)) gearSeg = sg;
      });
      if (!screwSeg) {
        screwSeg = String((vDef && vDef.screw) || (mDef && mDef.screw) || '').toLowerCase();
      }
      if (!gearSeg) {
        var gm = String((mDef && mDef.gear_ratio) || '').match(/(\d+)\s*:\s*(\d+)/);
        gearSeg = gm ? (gm[1] + ':' + gm[2]) : '1:2';
      }
      parts.push(screwSeg, gearSeg);
    }
    var st = Math.round(Number(cal.stroke_mm) || 0);
    if (st > 0) parts.push(String(st));
    if (cal.motion !== 'R') parts.push(cal.joint === 'std' ? 'FL' : (cal.joint || 'FL'));   //
    if (res.route === 'A') {
      parts.push(cal.input_type || 'P1');   //
      if (cal.motion !== 'R' && cal.input_type !== 'P2') parts.push(cal.shaft_dir === 'LH' ? 'LH' : 'RH');
    } else {
      parts.push('RX');   //
    }
    var tail = (cal.accessories || []).slice();
    /*

*/
    if (revSplitHost(cal, res) && tail.indexOf('FCP') < 0) tail.push('FCP');
    /*
*/
    if (cal.series === 'EHB' && cal.precision_mm === 0.02 && tail.indexOf('GB') < 0) tail.push('GB');
    /*

*/
    var spTxCode = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
    if ((cal.special || []).indexOf('screw_material') >= 0
      && String(spTxCode.screw_material || '').indexOf('不锈钢') >= 0 && tail.indexOf('SA') < 0) tail.push('SA');
    if ((cal.special || []).indexOf('anti_corrosion') >= 0
      && String(spTxCode.anti_corrosion || '').indexOf('不锈钢') >= 0 && tail.indexOf('SS') < 0) tail.push('SS');
    /*

*/
    if (cal.drive !== 'hand' && cal.drive !== 'none' && cal.units <= 1 && (cal.input_type === 'P3' || cal.input_type === 'P4')) {
      /*
*/
      var ms0 = res.motor_recommend || [];
      var m0 = ms0.length ? ms0[0] : null;
      if (m0) {
        var moRpm = m0.gearbox ? m0.gearbox.out_rpm : m0.rpm;
        tail.push('MO:' + C.fN(m0.power_kW, 2) + 'KW ' + Math.round(moRpm) + 'RPM');
      } else {
        var kw = (res.motor_power_kW != null) ? res.motor_power_kW : res.total_power_kW;
        if (kw != null) tail.push('MO:' + C.fN(kw, 2) + 'KW ' + Math.round(actualRpm(res.motor_sync || cal.motor_rpm)) + 'RPM');
      }
    }
    if (tail.length) parts.push(tail.join('/'));
    return parts.join('-');
  }

  function stepLines(res, cal) {
    var out = [];
    (res.steps || []).forEach(function (s, i) {
      out.push((i + 1) + '，' + s[0] + '：' + s[1]);
    });
    return out;
  }

  /*
*/
  /*

*/
  function brandClean(b) { return String(b || '').replace(/德力\s*/g, ''); }

  function brakeRequired(res) {
    return !!(res && res.warnings || []).some(function (w) {
      var s = String(w);
      return s.indexOf('制动器建议') >= 0 && s.indexOf('可不加') < 0 && s.indexOf('增加制动器') >= 0;
    });
  }

  /*

*/
  function ebhBrakeNote(res, cal) {
    if (cal && cal.drive === 'hand') return false;
    return /^(EHB|DHB)/i.test(String(res && res.model || ''));
  }

  /*

*/
  function isISMG2Code(code) { return String(code || '').indexOf('ISMG2') === 0; }
  function servoCodeShown(code, needBrake) {
    var c = String(code || '');
    return (needBrake && c.indexOf('ISMG1') === 0) ? c.replace('-A331FA', '-A334FA') : c;
  }
  function brakeSegOf(needBrake, code, sep, bevelBrake) {
    var sp = (sep === undefined) ? ' / ' : sep;
    if (!needBrake) return '';
    if (isISMG2Code(code)) return sp + '需配制动器——ISMG2 系列无抱闸选配，制动须与汇川确认或另行解决';
    /**/
    if (bevelBrake) return sp + '配内置抱闸（24V DC，订货选带抱闸版本）';
    return sp + '配制动器（本方案必选）';
  }

  function motorLines(res, cal) {
    var out = [];
    var ms = res.motor_recommend || [];
    if (!ms.length) { out.push('电机：按计算功率/扭矩配置，具体型号与厂家确认'); return out; }
    /*
*/
    var multi = cal ? ((Number(cal.units) || 1) > 1) : false;
    /*
*/
    var bevelBk = ebhBrakeNote(res, cal);
    var needBrake = brakeRequired(res) || bevelBk;
    var m0 = ms[0];
    var baseKw = (res.motor_demand_kW != null) ? res.motor_demand_kW
      : ((res.motor_power_kW != null) ? res.motor_power_kW : res.total_power_kW);
    out.push('推荐电机 ' + C.fN(m0.power_kW, 2) + ' kW / '
      + (m0.overspeed ? '3000 rpm（电机额定 2000rpm、最高 3000rpm，按最高转速运行）' : m0.rpm + ' rpm')
      + (needBrake ? (isISMG2Code(m0.code)
        ? '，需配制动器——ISMG2 系列无抱闸选配，制动须与汇川确认或另行解决'
        : '，配制动器（本方案必选）') : '')
      + (huDualShaft(res, cal) ? '（双出轴：两端输出轴各接 1 台换向器，省去电机端换向器）' : '')
      + (baseKw != null ? '（计算需求 ' + C.fN(baseKw, 2) + ' kW' + (multi ? '' : '，已按安全裕量选档') + '）' : ''));
    ms.forEach(function (m) {
      /**/
      var mNote = (m.kind === 'ac' && m.note)
        ? String(m.note).replace(/德力\s*/g, '') : m.note;
      /**/
      if (g.cleanNote) mNote = g.cleanNote(mNote);
      out.push((m.kind === 'ac' ? '' : (m.brand ? m.brand + ' ' : '')) + servoCodeShown(m.code, needBrake) + '：' + C.fN(m.power_kW, 2) + 'kW / ' + m.rpm + 'rpm'
        + (m.overspeed ? '（最高转速 3000rpm，本方案按 3000rpm 运行）' : '') + ' / ' + C.fN(m.torque_Nm, 2) + 'Nm'
        + (m.overspeed && m.torque_at_speed != null ? '（3000rpm 时可用 ' + C.fN(m.torque_at_speed, 2) + 'Nm，恒功率折算，大于所需扭矩×1.1）' : '')
        + (m.current_A != null ? ' / 额定电流 ' + m.current_A + 'A' : '')
        + (m.frame ? ' / 机座号 ' + m.frame : '')
        + (huDualShaft(res, cal) ? ' / 安装方式 地脚安装 B3（双出轴）' : (m.flange ? ' / 电机法兰 ' + String(m.flange).split('（')[0] : ''))
        + (String(m.code || '').indexOf('ISMG2') === 0 ? ' / 不带制动（该系列无抱闸选配）' : '')
        + brakeSegOf(needBrake, m.code, undefined, bevelBk && m.kind !== 'ac')
        + (m.within_10pct ? '（1.1 倍紧凑选型，标准档正好合适）' : '')
        + (m.tq_under != null ? '（额定扭矩低于计算需求 ' + (Math.round(m.tq_under * 1000) / 10) + '%，扭矩临界，须与厂家确认）' : '')
        + (mNote ? '　' + mNote : ''));
    });
    var ac0 = ms.filter(function (m) { return m.kind === 'ac'; })[0];
    if (ac0) {
      out.push('交流电机' + (huDualShaft(res, cal) ? '（双出轴）' : '') + '配置（样本 P142）：电压 ' + (ac0.voltage || '380/220VAC 50Hz')
        + '；防护等级 ' + (ac0.ip || 'IP54（标准）') + '；绝缘等级 ' + (ac0.insulation || 'F级（标准）')
        + '；' + (bevelBk
          ? '配制动器（本方案必选：伞齿轮不自锁，断电须抱闸防逆转）——YE3EJ 电磁制动系列，价含基座制动器'
          : needBrake ? '配制动器（本方案必选：蜗轮副/丝杠不自锁，断电须抱闸防逆转）' : (ac0.brake || '可选配制动器'))
        + '；' + (huDualShaft(res, cal)
          ? '双出轴电机采用地脚安装 B3（两端出轴，不用法兰安装）'
          : '电机法兰 B14/B5 两种可选配，按机座号匹配（≤100 默认 B14，≥112 默认 B5）'));
    }
    return out;
  }
  function cal0(res) { return res.rpm_needed || ''; }

  /*

*/
  function specNotes(cal) {
    var out = [];
    if (!cal) return out;
    var t = Number(cal.ambient_temp);
    if (isFinite(t) && cal.ambient_temp !== '' && cal.ambient_temp !== null) {
      if (t <= -30) {
        out.push('低温工况 ' + cal.ambient_temp + '℃：采用低温密封圈、低温润滑脂、低温电机'
          + (t <= -40 ? '（-40℃ 级）' : '（-30℃ 级）'));
      } else if (t >= 80) {
        out.push('高温工况 +' + t + '℃：采用高温密封圈、高温润滑脂、高温电机');
      }
    }
    if ((cal.special || []).indexOf('vacuum_grease') >= 0) {
      out.push('真空润滑脂：真空环境专用润滑脂，价格单独计费');
    }
    if (cal.drive === 'stepper') {
      out.push('步进电机：额定 300rpm、最大 1000rpm，不能过载，功率与扭矩按 2 倍裕量选型');
    } else if (cal.drive === 'ac1') {
      out.push('单相交流电机：不能过载，功率与扭矩按 1.5 倍裕量选型');
    }
    return out;
  }

  /*


*/
  function inlineSplitHost(cal) {
    if (!(cal.units >= 2 && cal.sync === '机械')) return false;
    if (cal.layout !== '电机单侧' && cal.layout !== '直线布置-电机单侧' && cal.layout !== '直线布置') return false;
    return cal.input_type === 'P4' || cal.series === 'EHB';
  }
  /*
*/
  function revSplitHost(cal, res) {
    if (isMotionR(cal)) return false;
    if (!(cal.units >= 2 && cal.sync === '机械')) return false;
    if (isRevLayout(String(cal.layout || ''))) return true;
    /*

*/
    return isCenterLineCal(cal, (res && res.model) || cal.series);
  }
  /*

*/
  function ehbRev4Split(cal, res) {
    if (!isMotionR(cal)) return false;
    if (Number(cal.units) !== 4 || cal.sync !== '机械') return false;
    if (!isRevLayout(String(cal.layout || ''))) return false;
    return bevelFamRe203.test(String((res && res.model) || cal.series || ''));   /**/
  }
  /*

*/
  function ehbHalfSplitEhb(cal, res) {
    if (cal.sync !== '机械') return false;
    var u = Number(cal.units) || 0;
    if (u !== 6 && u !== 8) return false;
    var ly = String(cal.layout || '');
    /*
*/
    if (ly !== 'H型布置' && ly !== 'H型' && ly !== '电机中间') return false;
    return bevelFamRe203.test(String((res && res.model) || cal.series || ''));   /**/
  }
  /*

*/
  function ehbLineSplitEhb(cal, res) {
    if (cal.sync !== '机械') return false;
    var u = Number(cal.units) || 0;
    if (u !== 6 && u !== 8) return false;
    if (String(cal.layout || '') !== '直线布置') return false;
    return bevelFamRe203.test(String((res && res.model) || cal.series || ''));   /**/
  }
  function followerCode(code) {
    var s = String(code)
      .replace(/\/MO:[^-]*(-[^-]*)?$/, '');
    if (/-(?:P1|P2|P4)-/.test(s)) {
      return s.replace(/-P4-(?:RH|LH)-/, '-P2-')
        .replace(/-P4-/, '-P2-');
    }
    /**/
    return s.replace(/-RX-/, '-LX-');
  }
  /**/
  function motorSideCode(code) {
    return twinLineOf(code);
  }

  /**/
  function calcLines(res) {
    var WANT = ['单台负载', '输出功率', '输入功率', '最大输入功率校核', '平台总功率',
      '放大系数', '电机扭矩', '速度校核', '稳定性校核', '工作制校核'];
    var out = [];
    (res.steps || []).forEach(function (s) {
      if (out.length >= 8) return;
      if (WANT.indexOf(s[0]) < 0) return;
      out.push((out.length + 1) + '. ' + s[0] + '：' + s[1]);
    });
    return out;
  }

  /**/
  function assumeLines(cal) {
    return [
      '载荷沿丝杠轴线方向、均布且无冲击；侧向力与偏载由客户导向机构承担，不作用在升降机上。',
      '客户自备机械限位与安全防护装置；如需本司配套限位开关、编码器或控制系统，请在订单中注明。',
      '电源 ' + ((cal.env === '室外') ? '按现场确认' : '380/220VAC 50Hz')
        + '；环境温度超出标准范围（−10 ~ +40 ℃）按特殊工况重新确认配置。',
      '安装接口尺寸以双方确认的接口图为准；多台同步要求各升降机行程、载荷与导程一致，异行程或异载需另行评估。'
    ];
  }

  /**/
  function stepText(res, label) {
    var hit = '';
    (res.steps || []).forEach(function (s) { if (!hit && s[0] === label) hit = s[1]; });
    return hit;
  }
  function stepJoin(res, labels) {
    var out = [];
    labels.forEach(function (l) { var t = stepText(res, l); if (t) out.push(t); });
    return out.join('；');
  }

  /**/
  function hostSpecText(res, cal, data) {
    var def = (data && data.models && data.models[res.model]) || {};
    var seg = [];
    if (res.route === 'A') {
      var opt = ((def.ratio_options || {})[res.ratio_key]) || {};
      if (def.rated_load_kN != null) seg.push('额定推拉力 ' + def.rated_load_kN + ' kN');
      if (def.rated_dynamic_kN != null) seg.push('额定动载荷 ' + def.rated_dynamic_kN + ' kN');
      if (def.screw_type) seg.push('丝杠类型：' + def.screw_type);
      var s1 = [];
      if (opt.ratio) s1.push('速比 ' + opt.ratio);
      if (opt.mm_per_rev != null) s1.push('每转行程 ' + opt.mm_per_rev + ' mm');
      /*
*/
      var screwA224 = opt.screw || def.screw;
      if (screwA224) s1.push('丝杠 Tr' + screwA224);
      if (opt.max_input_power_kW != null) s1.push('最大输入功率 ' + opt.max_input_power_kW + ' kW');
      if (s1.length) seg.push((res.ratio_key || '') + ' 档：' + s1.join('，'));
      var s2 = [];
      if (opt.eff_startup != null) s2.push('启动 η=' + opt.eff_startup);
      if (opt.eff_running_1500rpm != null) s2.push('运转 η=' + opt.eff_running_1500rpm);
      else if (opt.eff_running_100rpm != null) s2.push('运转 η=' + opt.eff_running_100rpm + '（按 100rpm 计）');
      if (s2.length) seg.push('传动效率 ' + s2.join('，'));
    } else {
      var v = ((def.variants || {})[res.variant]) || {};
      if (def.gear_ratio) seg.push('伞齿轮减速比 ' + def.gear_ratio);
      if (def.max_input_power_kW != null) seg.push('最大输入功率 ' + def.max_input_power_kW + ' kW'
        + (def.max_input_torque_Nm != null ? '（最大输入扭矩 ' + def.max_input_torque_Nm + ' Nm）' : ''));
      var s3 = [];
      if (v.rated_thrust_kN != null) s3.push('额定推力 ' + v.rated_thrust_kN + ' kN');
      if (v.screw) s3.push('丝杠 ' + v.screw);
      if (v.lead_mm != null) s3.push('导程 ' + v.lead_mm + ' mm');
      if (s3.length) seg.push((res.variant || '') + ' 档：' + s3.join('，'));
      var s4 = [];
      if (v.ball_C_kN != null) s4.push('滚珠动载荷 C ' + v.ball_C_kN + ' kN');
      if (v.rated_static_kN != null) s4.push('额定静载荷 ' + v.rated_static_kN + ' kN');
      if (v.efficiency_ref != null) s4.push('传动效率 η=' + v.efficiency_ref);
      if (s4.length) seg.push('丝杠参数：' + s4.join('，'));
    }
    var jt = (g.SJCatalog ? g.SJCatalog.JOINTS : []).filter(function (x) { return x.v === cal.joint; })[0];
    seg.push(cal.motion === 'R' ? '螺母运动，无需接头' : '接头：' + (jt ? jt.t.split('（')[0] : (cal.joint || '标配')));
    /**/
    var exSpec = jackIsExMotor(res, cal);
    var acc = (cal.accessories || []).map(function (v2) {
      if (exSpec && (String(v2) === 'FCP' || String(v2) === 'FCG')) return '防爆限位开关';
      var a = (g.SJCatalog ? g.SJCatalog.ACCESSORIES : []).filter(function (x) { return x.v === v2; })[0];
      return a ? a.t.split('（')[0].split(' ')[0] : v2;
    }).filter(Boolean);
    var seenExSpec = false;
    acc = acc.filter(function (x) {
      if (x !== '防爆限位开关') return true;
      if (seenExSpec) return false;
      seenExSpec = true; return true;
    });
    if (acc.length) seg.push('附件：' + acc.join('、'));
    /*
*/
    var spn = hostSpecSpecialNotes(cal);
    if (spn.length) seg.push('特殊要求：' + spn.join('，'));
    return seg.join('；');
  }

  /**/
  function hostSpecSpecialNotes(cal) {
    var sp = Array.isArray(cal.special) ? cal.special : [];
    if (!sp.length) return [];
    var spTx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
    var notes = [];
    if (sp.indexOf('screw_material') >= 0 && String(spTx.screw_material || '').trim()) {
      var sm = String(spTx.screw_material).trim();
      notes.push('丝杠材料：' + sm + (sm.indexOf('不锈钢') >= 0 ? '（附件代码 SA）' : '（特殊材质定制）'));
    }
    if (sp.indexOf('anti_corrosion') >= 0 && String(spTx.anti_corrosion || '').trim()) {
      var acn = String(spTx.anti_corrosion).trim();
      notes.push('防腐：' + acn + (acn.indexOf('不锈钢') >= 0 ? '（附件代码 SS）' : ''));
    }
    if (sp.indexOf('exproof') >= 0 && String(spTx.exproof || '').trim()) {
      notes.push('防爆：' + String(spTx.exproof).trim());
    }
    if (sp.indexOf('lead') >= 0 && String(spTx.lead || '').trim()) {
      notes.push('丝杠导程：' + String(spTx.lead).trim());
    }
    return notes;
  }

  /**/
  /*

*/
  function specialReqLines(cal) {
    var sp = Array.isArray(cal.special) ? cal.special : [];
    if (!sp.length) return [];
    var spTx = (cal.special_texts && typeof cal.special_texts === 'object') ? cal.special_texts : {};
    var lines = [];
    sp.forEach(function (v) {
      var txt = String(spTx[v] || '').trim();
      var def = (g.SJCatalog && g.SJCatalog.SPECIALS || []).filter(function (x) { return x.v === v; })[0];
      var label = def ? def.t : v;
      if (v === 'screw_material') {
        var s = '丝杠材料要求' + (txt ? '：' + txt : '');
        if (txt.indexOf('不锈钢') >= 0) s += '——丝杠按不锈钢材质供货（对应样本附件代码 SA，已标注在型号附件段），交期与价格需与厂家确认';
        else if (txt) s += '——丝杠按指定材质定制供货，需与厂家确认';
        lines.push(s);
      } else if (v === 'brand_servo') {
        lines.push('伺服电机品牌要求' + (txt ? '：' + txt : '') + '——电机系统按该品牌配套选型（电机推荐表已按此锁定），具体型号与厂家确认');
      } else if (v === 'brand_ac') {
        lines.push('交流电机品牌要求' + (txt ? '：' + txt : '') + '——电机按该品牌配套选型，具体型号与厂家确认');
      } else if (v === 'vacuum_grease') {
        return;   /**/
      } else if (txt) {
        lines.push(label + '：' + txt);
      } else {
        lines.push(label);
      }
    });
    return lines;
  }

  /*





*/
  var SJ_SIEMENS_PRICE_BOOK = {
    '1FK7103-2AC71': {"pn":5.2,"sys":"S120","m":{"p":31970,"date":"2025-07-03"},"d380":null,"d220":null},
    '1FK7103-3BC71': {"pn":null,"sys":null,"m":null,"d380":null,"d220":null},
    '1FK7103-5AF71': {"pn":null,"sys":null,"m":null,"d380":null,"d220":null},
    '1FL2102-2AF': {"pn":0.05,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-1AF0","pn":0.1}},
    '1FL2102-2AG': {"pn":0.05,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-1AF0","pn":0.1}},
    '1FL2102-4AF': {"pn":0.1,"sys":"S200","m":{"p":3042,"date":"2026-01-14"},"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-1AF0","pn":0.1}},
    '1FL2102-4AG': {"pn":0.1,"sys":"S200","m":{"p":3992,"date":"2026-09-23"},"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-1AF0","pn":0.1}},
    '1FL2103-2AF': {"pn":0.2,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-2AF0","pn":0.2,"p":3732,"date":"2026-04-01"}},
    '1FL2103-2AG': {"pn":0.2,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-2AF0","pn":0.2,"p":3732,"date":"2026-04-01"}},
    '1FL2103-4AF': {"pn":0.4,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-4AF0","pn":0.4,"p":3108,"date":"2026-06-08"},"d220":{"order":"6SL5510-1BB10-4AF0","pn":0.4,"p":2906,"date":"2025-09-26"}},
    '1FL2103-4AG': {"pn":0.4,"sys":"S200","m":{"p":4254,"date":"2026-06-08"},"d380":{"order":"6SL5510-1BE10-4AF0","pn":0.4,"p":3108,"date":"2026-06-08"},"d220":{"order":"6SL5510-1BB10-4AF0","pn":0.4,"p":2906,"date":"2025-09-26"}},
    '1FL2104-2AF': {"pn":0.75,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2104-2AG': {"pn":0.75,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2104-4AF': {"pn":1,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2104-4AG': {"pn":1,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2105-2AF': {"pn":1.45,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-5AF0","pn":1.75,"p":5004,"date":"2025-12-24"},"d220":null},
    '1FL2105-4AF': {"pn":2.1,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE12-5AF0","pn":2.5},"d220":null},
    '1FL2203-2AF': {"pn":0.2,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-2AF0","pn":0.2,"p":3732,"date":"2026-04-01"}},
    '1FL2203-2AG': {"pn":0.2,"sys":"S200","m":{"p":2872,"date":"2026-04-01"},"d380":{"order":"6SL5510-1BE10-2AF0","pn":0.2,"p":2586,"date":"2026-01-14"},"d220":{"order":"6SL5510-1BB10-2AF0","pn":0.2,"p":3732,"date":"2026-04-01"}},
    '1FL2203-4AF': {"pn":0.4,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-4AF0","pn":0.4,"p":3108,"date":"2026-06-08"},"d220":{"order":"6SL5510-1BB10-4AF0","pn":0.4,"p":2906,"date":"2025-09-26"}},
    '1FL2203-4AG': {"pn":0.4,"sys":"S200","m":{"p":3918,"date":"2025-09-26"},"d380":{"order":"6SL5510-1BE10-4AF0","pn":0.4,"p":3108,"date":"2026-06-08"},"d220":{"order":"6SL5510-1BB10-4AF0","pn":0.4,"p":2906,"date":"2025-09-26"}},
    '1FL2204-2AF': {"pn":0.75,"sys":"S200","m":{"p":5064,"date":"2025-11-04"},"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2204-2AG': {"pn":0.75,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2204-4AF': {"pn":1,"sys":"S200","m":{"p":6698,"date":"2025-11-13"},"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2204-4AG': {"pn":1,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2205-2AF': {"pn":0.94,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2205-4AF': {"pn":1.45,"sys":"S200","m":{"p":11576,"date":"2025-10-28"},"d380":{"order":"6SL5510-1BE11-5AF0","pn":1.75,"p":5004,"date":"2025-12-24"},"d220":null},
    '1FL2304-2AF': {"pn":0.4,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE10-4AF0","pn":0.4,"p":3108,"date":"2026-06-08"},"d220":{"order":"6SL5510-1BB10-4AF0","pn":0.4,"p":2906,"date":"2025-09-26"}},
    '1FL2304-4AF': {"pn":0.75,"sys":"S200","m":{"p":4948,"date":"2026-07-13"},"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2306-1AC': {"pn":0.75,"sys":"S200","m":{"p":6420,"date":"2025-09-01"},"d380":{"order":"6SL5510-1BE10-8AF0","pn":0.75,"p":3618,"date":"2026-07-13"},"d220":{"order":"6SL5510-1BB10-8AF0","pn":0.75}},
    '1FL2306-2AC': {"pn":1,"sys":"S200","m":{"p":6274,"date":"2026-03-04"},"d380":{"order":"6SL5510-1BE11-0AF0","pn":1,"p":3860,"date":"2026-03-04"},"d220":{"order":"6SL5510-1BB11-0AF0","pn":1}},
    '1FL2306-4AC': {"pn":1.5,"sys":"S200","m":null,"d380":{"order":"6SL5510-1BE11-5AF0","pn":1.75,"p":5004,"date":"2025-12-24"},"d220":null},
    '1FL2306-6AC': {"pn":1.76,"sys":"S200","m":{"p":6354,"date":"2025-12-24"},"d380":{"order":"6SL5510-1BE12-5AF0","pn":2.5},"d220":null},
    '1FL2306-7AC': {"pn":2.01,"sys":"S200","m":{"p":8016,"date":"2025-09-26"},"d380":{"order":"6SL5510-1BE12-5AF0","pn":2.5},"d220":null},
    '1FL2310-0AC': {"pn":2.5,"sys":"S200","m":{"p":21050,"date":"2026-09-29"},"d380":{"order":"6SL5510-1BE12-5AF0","pn":2.5},"d220":null},
    '1FL2310-2AC': {"pn":3.5,"sys":"S200","m":{"p":9264,"date":"2026-01-29"},"d380":{"order":"6SL5510-1BE13-5AF0","pn":3.5,"p":8038,"date":"2026-09-29"},"d220":null},
    '1FL2310-4AC': {"pn":5.01,"sys":"S200","m":{"p":12528,"date":"2026-08-10"},"d380":{"order":"6SL5510-1BE17-0AF0","pn":7,"p":13078,"date":"2026-09-29"},"d220":null},
    '1FL2310-6AC': {"pn":7,"sys":"S200","m":{"p":13108,"date":"2026-03-24"},"d380":{"order":"6SL5510-1BE17-0AF0","pn":7,"p":13078,"date":"2026-09-29"},"d220":null},
    '1FL6022-2AF21': {"pn":0.05,"sys":"V90","m":{"p":3818,"date":"2025-11-21"},"d380":{"order":"6SL3210-5FE10-4UF0","pn":0.4,"p":2686,"date":"2026-05-01"},"d220":{"order":"6SL3210-5FB10-1UF0","pn":0.1}},
    '1FL6024-2AF21': {"pn":0.1,"sys":"V90","m":{"p":3830,"date":"2026-09-29"},"d380":{"order":"6SL3210-5FE10-4UF0","pn":0.4,"p":2686,"date":"2026-05-01"},"d220":{"order":"6SL3210-5FB10-1UF0","pn":0.1}},
    '1FL6032-2AF21': {"pn":0.2,"sys":"V90","m":{"p":3900,"date":"2026-09-22"},"d380":{"order":"6SL3210-5FE10-4UF0","pn":0.4,"p":2686,"date":"2026-05-01"},"d220":{"order":"6SL3210-5FB10-2UF0","pn":0.2}},
    '1FL6034-2AF21': {"pn":0.4,"sys":"V90","m":{"p":3836,"date":"2026-08-10"},"d380":{"order":"6SL3210-5FE10-4UF0","pn":0.4,"p":2686,"date":"2026-05-01"},"d220":{"order":"6SL3210-5FB10-4UF1","pn":0.4,"p":2770,"date":"2026-08-10"}},
    '1FL6042-1AF61': {"pn":0.4,"sys":"V90","m":{"p":4074,"date":"2026-05-01"},"d380":{"order":"6SL3210-5FE10-4UF0","pn":0.4,"p":2686,"date":"2026-05-01"},"d220":{"order":"6SL3210-5FB10-4UF1","pn":0.4,"p":2770,"date":"2026-08-10"}},
    '1FL6042-2AF21': {"pn":0.75,"sys":"V90","m":{"p":4400,"date":"2026-08-04"},"d380":{"order":"6SL3210-5FE10-8UF0","pn":0.75,"p":3238,"date":"2026-05-13"},"d220":{"order":"6SL3210-5FB10-8UF0","pn":0.75,"p":3196,"date":"2026-08-04"}},
    '1FL6044-1AF61': {"pn":0.75,"sys":"V90","m":{"p":4460,"date":"2026-05-01"},"d380":{"order":"6SL3210-5FE10-8UF0","pn":0.75,"p":3238,"date":"2026-05-13"},"d220":{"order":"6SL3210-5FB10-8UF0","pn":0.75,"p":3196,"date":"2026-08-04"}},
    '1FL6044-2AF21': {"pn":1,"sys":"V90","m":{"p":5720,"date":"2026-06-24"},"d380":{"order":"6SL3210-5FE11-0UF0","pn":1,"p":3626,"date":"2026-09-11"},"d220":{"order":"6SL3210-5FB11-0UF1","pn":1,"p":3680,"date":"2026-01-01"}},
    '1FL6052-2AF21': {"pn":1.5,"sys":"V90","m":{"p":6888,"date":"2025-12-26"},"d380":{"order":"6SL3210-5FE11-5UF0","pn":1.5,"p":4160,"date":"2026-08-21"},"d220":{"order":"6SL3210-5FB11-5UF0","pn":1.5,"p":4134,"date":"2025-12-24"}},
    '1FL6054-2AF21': {"pn":2,"sys":"V90","m":{"p":7484,"date":"2025-09-26"},"d380":{"order":"6SL3210-5FE12-0UF0","pn":2,"p":5094,"date":"2026-09-10"},"d220":{"order":"6SL3210-5FB12-0UF0","pn":2,"p":4886,"date":"2026-09-08"}},
    '1FL6061-1AC61': {"pn":0.75,"sys":"V90","m":{"p":4300,"date":"2025-06-24"},"d380":{"order":"6SL3210-5FE10-8UF0","pn":0.75,"p":3238,"date":"2026-05-13"},"d220":{"order":"6SL3210-5FB10-8UF0","pn":0.75,"p":3196,"date":"2026-08-04"}},
    '1FL6062-1AC61': {"pn":1,"sys":"V90","m":{"p":5774,"date":"2026-09-18"},"d380":{"order":"6SL3210-5FE11-0UF0","pn":1,"p":3626,"date":"2026-09-11"},"d220":{"order":"6SL3210-5FB11-0UF1","pn":1,"p":3680,"date":"2026-01-01"}},
    '1FL6064-1AC61': {"pn":1.5,"sys":"V90","m":{"p":6522,"date":"2026-09-18"},"d380":{"order":"6SL3210-5FE11-5UF0","pn":1.5,"p":4160,"date":"2026-08-21"},"d220":{"order":"6SL3210-5FB11-5UF0","pn":1.5,"p":4134,"date":"2025-12-24"}},
    '1FL6066-1AC61': {"pn":1.75,"sys":"V90","m":{"p":8066,"date":"2026-01-30"},"d380":{"order":"6SL3210-5FE12-0UF0","pn":2,"p":5094,"date":"2026-09-10"},"d220":{"order":"6SL3210-5FB12-0UF0","pn":2,"p":4886,"date":"2026-09-08"}},
    '1FL6067-1AC61': {"pn":2,"sys":"V90","m":{"p":7280,"date":"2026-09-21"},"d380":{"order":"6SL3210-5FE12-0UF0","pn":2,"p":5094,"date":"2026-09-10"},"d220":{"order":"6SL3210-5FB12-0UF0","pn":2,"p":4886,"date":"2026-09-08"}},
    '1FL6090-1AC61': {"pn":2.5,"sys":"V90","m":{"p":9256,"date":"2026-08-31"},"d380":{"order":"6SL3210-5FE13-5UF0","pn":3.5,"p":6766,"date":"2026-09-29"},"d220":null},
    '1FL6092-1AC61': {"pn":3.5,"sys":"V90","m":{"p":10370,"date":"2026-08-21"},"d380":{"order":"6SL3210-5FE13-5UF0","pn":3.5,"p":6766,"date":"2026-09-29"},"d220":null},
    '1FL6094-1AC61': {"pn":5,"sys":"V90","m":{"p":10384,"date":"2026-04-15"},"d380":{"order":"6SL3210-5FE15-0UF0","pn":5,"p":8966,"date":"2026-09-29"},"d220":null},
    '1FL6096-1AC61': {"pn":7,"sys":"V90","m":{"p":12258,"date":"2026-03-24"},"d380":{"order":"6SL3210-5FE17-0UF0","pn":7,"p":11016,"date":"2026-09-29"},"d220":null},
    '1FT7105-5AF71': {"pn":8.8,"sys":"S120","m":{"p":60339,"date":""},"d380":null,"d220":null},
    /**/
    '1FT7108-1SF71': {"pn":18.8,"sys":"S120","m":{"p":81906,"date":"2026-04-24"},"d380":null,"d220":null},
    '1FT7108-5SC71': {"pn":15.3,"sys":"S120","m":{"p":81906,"date":"2026-04-24"},"d380":null,"d220":null},
    /**/
    '1FT7132-5AF71': {"pn":28.3,"sys":"S120","m":{"p":86930,"date":"2026-10-29"},"d380":null,"d220":null},
    '1FT7132-5SF71': {"pn":35.5,"sys":"S120","m":{"p":86930,"date":"2026-10-29"},"d380":null,"d220":null}

  ,
    '1FK7032-2AK71': {"pn":0.5,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7042-2AF71': {"pn":0.8,"sys":"S120","m":{"p":15996,"date":"2026-05-20"},"d380":null,"d220":null},
    '1FK7060-2AC71': {"pn":1.1,"sys":"S120","m":{"p":20390,"date":"2026-04-13"},"d380":null,"d220":null},
    '1FK7060-2AF71': {"pn":1.5,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7063-2AF71': {"pn":2.3,"sys":"S120","m":{"p":21986,"date":"2026-08-13"},"d380":null,"d220":null},
    '1FK7081-2AF71': {"pn":2.7,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7084-2AF71': {"pn":3.1,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7100-2AF71': {"pn":3.8,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7101-2AF71': {"pn":4.9,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FK7103-2AF71': {"pn":4.4,"sys":"S120","m":{"p":31970,"date":"2025-07-23"},"d380":null,"d220":null},
    '1FK7105-2AF71': {"pn":8.2,"sys":"S120","m":{"p":34946,"date":"2026-05-25"},"d380":null,"d220":null},
    '1FK7105-2AC71': {"pn":7.7,"sys":"S120","m":{"p":37522,"date":"2025-06-19"},"d380":null,"d220":null},
    '1FT7062-5AF71': {"pn":1.7,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7062-5AK71': {"pn":2.13,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7066-5AF71': {"pn":2.92,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7082-5AC71': {"pn":2.4,"sys":"S120","m":{"p":36428,"date":"2020-08-17"},"d380":null,"d220":null},
    '1FT7082-5AH71': {"pn":3.77,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7084-5AF71': {"pn":4.55,"sys":"S120","m":{"p":41256,"date":"2020-08-17"},"d380":null,"d220":null},
    '1FT7086-5AC71': {"pn":4.71,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7102-5AC71': {"pn":5.03,"sys":"S120","m":{"p":58852,"date":"2023-12-13"},"d380":null,"d220":null},
    '1FT7105-5AB71': {"pn":6.6,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7105-1AC74': {"pn":7.96,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7084-5SC71': {"pn":5,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7134-5SF71': {"pn":45.5,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7108-5AC71': {"pn":10.47,"sys":"S120","m":{"p":85570,"date":"2023-12-13"},"d380":null,"d220":null},
    '1FT7108-5AF71': {"pn":6.28,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7108-5SF71': {"pn":18.8,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7108-5WC70': {"pn":26.2,"sys":"S120","m":{"p":62166,"date":"2026-07-09"},"d380":null,"d220":null},
    '1FT7132-5AB71': {"pn":10.5,"sys":"S120","m":{"p":86930,"date":"2026-04-16"},"d380":null,"d220":null},
    '1FT7132-5SC71': {"pn":26.5,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7134-5AB71': {"pn":12.9,"sys":"S120","m":{"p":96046,"date":"2025-12-08"},"d380":null,"d220":null},
    '1FT7134-5AC71': {"pn":14,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7132-5AC71': {"pn":11.52,"sys":"S120","m":{"p":89686,"date":"2026-09-18"},"d380":null,"d220":null},
    '1FT7108-5AB71': {"pn":9.6,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7105-5AC71': {"pn":7.96,"sys":"S120","m":{"p":60339,"date":""},"d380":null,"d220":null},
    '1FT7084-5AC71': {"pn":3.54,"sys":"S120","m":null,"d380":null,"d220":null},
    '1FT7064-5AF71': {"pn":2.39,"sys":"S120","m":{"p":38499,"date":""},"d380":null,"d220":null},
    '1FK7062-2AC71': {"pn":1.5,"sys":"S120","m":{"p":18700,"date":"2025-12-11"},"d380":null,"d220":null},
    '1FK7083-2AC71': {"pn":2.6,"sys":"S120","m":{"p":24790,"date":"2026-04-08"},"d380":null,"d220":null},
    '1FK7084-2AC71': {"pn":3.1,"sys":"S120","m":{"p":26962,"date":"2025-05-27"},"d380":null,"d220":null},
    '1FK7100-2AC71': {"pn":3.04,"sys":"S120","m":{"p":26622,"date":"2025-03-05"},"d380":null,"d220":null},
    '1FK7101-2AC71': {"pn":4.29,"sys":"S120","m":{"p":27406,"date":"2025-06-19"},"d380":null,"d220":null},
    '1FT7042-2AK71': {"pn":0.94,"sys":"S120","m":{"p":18650,"date":"2025-05-12"},"d380":null,"d220":null},
    '1FT7042-5AF71': {"pn":0.85,"sys":"S120","m":{"p":30352,"date":"2020-08-17"},"d380":null,"d220":null},
    '1FT7044-5AF71': {"pn":1.35,"sys":"S120","m":{"p":35183,"date":""},"d380":null,"d220":null},
    '1FT7046-5AF71': {"pn":1.76,"sys":"S120","m":{"p":45194,"date":"2023-12-13"},"d380":null,"d220":null},
    '1FT7086-5AF71': {"pn":5.65,"sys":"S120","m":{"p":47502,"date":"2020-08-17"},"d380":null,"d220":null},
    '1FT7102-5AF71': {"pn":6.28,"sys":"S120","m":{"p":49792,"date":""},"d380":null,"d220":null},
    '1PH8133-3FG02': {"pn":20,"sys":"S120","m":{"p":76627,"date":"2025-01-05"},"d380":null,"d220":null},
    '1PH8137-3FG02': {"pn":28,"sys":"S120","m":{"p":79698,"date":"2025-06-19"},"d380":null,"d220":null},
    '1PH8165-3FF03': {"pn":37,"sys":"S120","m":{"p":108380,"date":"2025-01-05"},"d380":null,"d220":null},
    '1PH8165-4FF03': {"pn":69,"sys":"S120","m":{"p":159610,"date":"2025-06-19"},"d380":null,"d220":null},
    '1FK2103-2AH10': {"pn":0.28,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-4DF1","pn":0.4,"p":null,"date":null},"d220":null},
    '1FK2103-4AH10': {"pn":0.48,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2104-4AF10': {"pn":0.4,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-4DF1","pn":0.4,"p":null,"date":null},"d220":null},
    '1FK2104-4AK10': {"pn":0.6,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2104-5AF10': {"pn":0.75,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2104-5AK10': {"pn":1.07,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-5DF1","pn":1.5,"p":null,"date":null},"d220":null},
    '1FK2104-6AF10': {"pn":1,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-0DF1","pn":1,"p":null,"date":null},"d220":null},
    '1FK2105-4AF10': {"pn":1.45,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-5DF1","pn":1.5,"p":null,"date":null},"d220":null},
    '1FK2105-6AF10': {"pn":2.1,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2106-3AF10': {"pn":2.3,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2106-4AF10': {"pn":2.7,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2106-6AF10': {"pn":3.3,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2203-2AK10': {"pn":0.255,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-4DF1","pn":0.4,"p":null,"date":null},"d220":null},
    '1FK2203-4AK10': {"pn":0.43,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2204-5AF10': {"pn":0.75,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2204-5AK10': {"pn":0.57,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE10-8DF1","pn":0.75,"p":null,"date":null},"d220":null},
    '1FK2204-6AF10': {"pn":1,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-0DF1","pn":1,"p":null,"date":null},"d220":null},
    '1FK2205-2AF10': {"pn":0.94,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-0DF1","pn":1,"p":null,"date":null},"d220":null},
    '1FK2205-4AF10': {"pn":1.45,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE11-5DF1","pn":1.5,"p":null,"date":null},"d220":null},
    '1FK2206-2AF10': {"pn":1.71,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE12-0DF1","pn":2,"p":null,"date":null},"d220":null},
    '1FK2206-4AF10': {"pn":2.85,"sys":"S210","m":{"p":15996,"date":"2026-05-20"},"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2208-3AC10': {"pn":3.05,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE13-5DF1","pn":3.5,"p":3732,"date":"2026-04-01"},"d220":null},
    '1FK2208-4AC10': {"pn":3.55,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE15-0DF1","pn":5,"p":null,"date":null},"d220":null},
    '1FK2208-5AC10': {"pn":4,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE15-0DF1","pn":5,"p":null,"date":null},"d220":null},
    '1FK2210-3AB10': {"pn":4.5,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE15-0DF1","pn":5,"p":null,"date":null},"d220":null},
    '1FK2210-3AC10': {"pn":5.5,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE17-0DF1","pn":7,"p":null,"date":null},"d220":null},
    '1FK2210-4AB10': {"pn":5.4,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE17-0DF1","pn":7,"p":null,"date":null},"d220":null},
    '1FK2210-4AC10': {"pn":6.4,"sys":"S210","m":null,"d380":{"order":"6SL5310-1BE17-0DF1","pn":7,"p":null,"date":null},"d220":null}
  };


  function moneyTxt(n) {
    if (typeof window !== 'undefined' && window.LANG_I18N) return window.LANG_I18N.cur(n);   /**/
    var x = Math.round(Number(n) || 0);
    return '¥' + String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function siemensBaseOf(code) {
    /*
*/
    var m = String(code || '').match(/1F[A-Z0-9]{5}-[0-9A-Z]{3,5}/i);
    return m ? m[0].toUpperCase() : null;
  }
  /*



*/
  function domesticBook() {
    /**/
    return g.SJ_PRICE_BOOK_DOMESTIC || null;
  }
  function domesticBrandOf(m0) {
    var b = String((m0 && m0.brand) || '');
    if (b.indexOf('汇川') >= 0) return '汇川';
    if (b.indexOf('台达') >= 0) return '台达';
    if (b.indexOf('惠斯通') >= 0) return '惠斯通';
    if (b.indexOf('雷赛') >= 0) return '雷赛';
    if (b.indexOf('桢正') >= 0) return '桢正';
    return '';
  }
  function stripTrailLetters(t) {
    var m = String(t).match(/^(.*[0-9])([A-Z]+)$/);
    return m ? m[1] : t;
  }
  /**/
  function domesticKeysOf(m0) {
    var brand = domesticBrandOf(m0);
    if (!brand) return [];
    var code = String((m0 && m0.code) || '').toUpperCase();
    var keys = [];
    function push(k) { if (k && keys.indexOf(brand + '|' + k) < 0) keys.push(brand + '|' + k); }
    var mm;
    if (brand === '汇川') {
      mm = code.match(/MS1H[1-4]-[0-9]{2}[A-Z][0-9]{2}[A-Z]{2}/);
      if (mm) {
        push(mm[0]);
        var fam = mm[0].match(/^(MS1H[1-4]-[0-9]{2}[A-Z][0-9]{2})[A-Z]{2}$/);
        if (fam) push(fam[1]);
      }
      mm = code.match(/ISMG[12]-[0-9]{2}[A-Z][0-9]{2}[A-Z]{2}/);
      if (mm) push(mm[0]);
    } else if (brand === '惠斯通') {
      mm = code.match(/[0-9]{2,3}ST-\s?[A-Z][0-9A-Z]+/);
      if (mm) {
        var b2 = mm[0].replace(/\s+/g, '');
        push(b2 + (/-EX/.test(code) ? '-EX' : ''));
        push(b2);
      }
    } else if (brand === '台达') {
      mm = code.match(/ECM[A-Z]*-[A-Z0-9]+(?:-[A-Z0-9]+)*/);
      if (mm) push(stripTrailLetters(mm[0]));
    } else if (brand === '桢正') {
      mm = code.match(/ZLS[0-9]{3,5}[A-Z]?/);
      if (mm) push(mm[0]);
    } else if (brand === '雷赛') {
      mm = code.match(/57CM[0-9]{2}[A-Z]*|ACM2[A-Z]-[0-9A-Z]+|LVM[0-9A-Z]+|86CME[0-9]+/);
      if (mm) {
        push(mm[0]);
        /*
*/
        var acm2 = mm[0].match(/^ACM2[A-Z]-(.+)$/);
        if (acm2) push('ACM0H-' + acm2[1]);
      }
    }
    return keys;
  }
  function domesticDrivePriceOf(m0) {
    var book = domesticBook();
    var keys = domesticKeysOf(m0);
    for (var i = 0; i < keys.length; i++) {
      var e = book ? book[keys[i]] : null;
      if (e && e.unit > 0) {
        return {
          base: keys[i], unit: e.unit, hasPrice: true,
          motorP: e.motorP,
          driveOrder: e.drv || null,
          driveTxt: e.drv ? (e.drv + (e.volt ? '（' + e.volt + '）' : '')) : '',
          missing: e.drvP != null ? [] : ['驱动器'],
          date: e.date, src: 'domestic', cableTxt: e.cableTxt || '', volt: e.volt || ''
        };
      }
    }
    return null;
  }
  /**/
  function kitTxtOf(md) {
    if (!md) return '';
    var miss = md.missing && md.missing.length ? '（' + md.missing.join('、') + '暂无价格）' : '';
    var drivePart = md.driveTxt ? ('驱动器 ' + md.driveTxt + miss) : '驱动器按电机品牌配套选型（价格暂无）';
    var cablePart = (md.src === 'domestic' && md.cableTxt)
      ? '成套附件：含动力/编码器电缆（' + md.cableTxt + '，其他长度按实际结算）'
      : '成套附件：动力/编码器电缆（长度按现场配置，价格另计）';
    return drivePart + '；' + cablePart;
  }
  function motorDrivePriceOf(m0, cal) {
    if (!m0 || m0.kind !== 'servo') return null;
    var base = siemensBaseOf(m0.code);
    var e = base ? SJ_SIEMENS_PRICE_BOOK[base] : null;
    if (e) {
      var is220 = String(cal && cal.drive) === 'servo220';
      var d = is220 ? (e.d220 || null) : (e.d380 || null);
      var voltTxt = is220 ? '220V' : '380V';
      var unit = 0, missing = [];
      if (e.m && e.m.p) unit += e.m.p; else missing.push('电机');
      if (d && d.p) unit += d.p; else missing.push('驱动器');
      /*

*/
      var md = {
        base: base, unit: (missing.length === 0 ? unit : 0), hasPrice: unit > 0 && missing.length === 0,
        motorP: (e.m && e.m.p) || null,
        driveOrder: d ? d.order : null,
        /**/
        driveTxt: d ? ('SINAMICS ' + (e.sys || (String(d.order || '').indexOf('6SL5310') === 0 ? 'S210' : 'V90')) + ' ' + d.order + '（' + voltTxt + '）') : '',
        missing: missing,
        /**/
        driveOnly: missing.indexOf('电机') >= 0 && missing.indexOf('驱动器') < 0,
        date: e.m && e.m.date, src: 'siemens', cableTxt: '', volt: voltTxt
      };
      md.kitTxt = kitTxtOf(md);
      return md;
    }
    /**/
    var dd = domesticDrivePriceOf(m0);
    if (dd) { dd.kitTxt = kitTxtOf(dd); return dd; }
    return null;
  }
  /**/
  function servoKitSpecOf(m0, cal) {
    if (!m0 || m0.kind !== 'servo') return '';
    var md = motorDrivePriceOf(m0, cal);
    if (md && md.kitTxt) return '；' + md.kitTxt;
    return '；驱动器按电机品牌配套选型（价格暂无）；成套附件：动力/编码器电缆（长度按现场配置，价格另计）';
  }
  /*





*/
  /**/
  function frameNumOf(fr) {
    var m = String(fr || '').match(/^(\d+)/);
    return m ? m[1] : '';
  }
  function acMotorPriceOf(m0, dual) {
    if (!m0 || m0.kind !== 'ac') return null;
    var book = limtecBook();
    var list = (book && book.motor_ac) || [];
    if (!list.length) return null;
    var rpm = Number(m0.rpm) || 0, tier = null, byFrame = false;
    if (rpm >= 1300 - 1e-9 && rpm < 2500 - 1e-9) tier = 1400;
    else if (rpm >= 850 - 1e-9 && rpm < 1300 - 1e-9) tier = 900;
    var kw = Number(m0.power_kW) || 0, hit = null, byUpsize = null, scaledBase = null;
    if (tier !== null) {
      list.forEach(function (x) {
        if (Number(x.rpm) === tier && Math.abs(Number(x.kw) - kw) < 1e-6) hit = x;
      });
      if (!hit) {
        /*




*/
        var fn0 = frameNumOf(m0.frame);
        var same = list.filter(function (x) { return Number(x.rpm) === tier && frameNumOf(x.frame) === fn0; });
        var tierList = list.filter(function (x) { return Number(x.rpm) === tier; });
        var tierMaxKw = 0;
        tierList.forEach(function (x) { if (Number(x.kw) > tierMaxKw) tierMaxKw = Number(x.kw); });
        if (!same.length) return { hasPrice: false, reason: 'frame', tentative: true };
        var upSame = null, maxSame = null;
        same.forEach(function (x) {
          var k = Number(x.kw);
          if (k >= kw - 1e-9 && (!upSame || k < Number(upSame.kw))) upSame = x;
          if (!maxSame || k > Number(maxSame.kw)) maxSame = x;
        });
        if (upSame) { hit = upSame; byUpsize = 'same_frame'; }
        else if (Number(maxSame.kw) < tierMaxKw - 1e-9) {
          /**/
          scaledBase = Math.round((Number(maxSame.price) || 0) * 1.2);
          byUpsize = 'scale12';
        } else {
          return { hasPrice: false, reason: 'top', tentative: true };
        }
      }
    } else if (rpm > 0 && rpm < 850 - 1e-9) {
      /*


*/
      var fn = frameNumOf(m0.frame), cand = null;
      list.forEach(function (x) {
        if (Number(x.rpm) !== 900) return;
        if (frameNumOf(x.frame) !== fn) return;
        var d = Math.abs(Number(x.kw) - kw);
        if (!cand || d < cand.d - 1e-9 || (Math.abs(d - cand.d) < 1e-9 && Number(x.kw) > cand.kw))
          cand = { x: x, d: d, kw: Number(x.kw) };
      });
      if (!cand) return { hasPrice: false, reason: 'frame' };
      hit = cand.x; byFrame = true;
    } else {
      return { hasPrice: false, reason: 'tier' };   /**/
    }
    var base = (scaledBase !== null) ? scaledBase : (Number(hit.price) || 0), brakeAdd = 0;
    if (/电磁制动|YE3EJ/.test(String(m0.brand || '')) && book.brake_ac) {
      var fr = String(m0.frame || '').trim();
      var bk = book.brake_ac[fr];
      if (bk == null && fr === '160') bk = book.brake_ac['160M'];
      if (bk != null) brakeAdd = Number(bk) || 0;
    }
    var unit = base + brakeAdd, dualUp = false;
    if (dual) { unit = Math.round(unit * 1.15); dualUp = true; }
    return { hasPrice: true, unit: unit, base: base, brakeAdd: brakeAdd, dualUp: dualUp, tier: tier,
      byFrame: byFrame, byUpsize: byUpsize };
  }

  /*






*/
  function limtecBook() {
    return (typeof SJ_PRICE_BOOK_LIMTEC !== 'undefined') ? SJ_PRICE_BOOK_LIMTEC : null;
  }
  function wormDiaOf(res, data) {
    var md = (data && data.models && res && res.model) ? data.models[res.model] : null;
    return (md && md.input_shaft_dia_mm != null) ? Number(md.input_shaft_dia_mm) : null;
  }
  function limtecPickDia(dia, obj) {
    var keys = Object.keys(obj).map(Number).sort(function (a, b) { return a - b; });
    for (var i = 0; i < keys.length; i++) if (keys[i] >= dia - 1e-9) return keys[i];
    return keys.length ? keys[keys.length - 1] : null;
  }
  function jackSheetKeyOf(model, cal) {
    var book = limtecBook(); if (!book || !model) return null;
    var m = String(model).match(/^([A-Za-z]+)([0-9]+)$/);
    if (!m) return null;
    var fam = m[1], base = m[2];
    if (fam === 'KVL' || fam === 'KVK') fam = 'KV';
    /*
*/
    if (fam === 'EHA') fam = 'EHB';
    /*
*/
    var series = (cal && cal.series) ? String(cal.series) : '';
    if (series === 'SCA' || series === 'SCB') {
      /**/
      var b2 = base;
      if (/[12]$/.test(b2) && b2.length >= 2) b2 = b2.slice(0, -1) + '0';
      var sBase = b2.replace(/^0+/, '');
      /*


*/
      if (!book.jack['SC' + sBase] && book.jack['SCA' + sBase]) return 'SCA' + sBase;
      return 'SC' + sBase;
    }
    var mp = book.sheetOf[fam];
    return (mp && mp[base]) || null;
  }
  /*


*/
  /*
*/
  function jackIsExMotor(res, cal) {
    var m = (res && res.motor_recommend && res.motor_recommend[0]) || null;
    var s = m ? String((m.brandFull || m.brand || '') + ' ' + (m.code || '') + ' ' + (m.model || '')) : '';
    if (s && (/惠斯通/.test(s) || /(^|[^A-Za-z])ST-EX/i.test(s) || /-[A-Z0-9]*EX([-(]|$)/i.test(s))) return true;
    var sb = (cal && cal.servo_brand) || [];
    return Array.isArray(sb) ? sb.indexOf('惠斯通') >= 0 : /惠斯通/.test(String(sb || ''));
  }

  function jackNetPriceOf(res, cal, data, inputType) {
    var book = limtecBook(); if (!book || !res || !res.model) return null;
    var key = jackSheetKeyOf(res.model, cal);
    var sheet = key ? book.jack[key] : null;
    if (!sheet) return null;
    var segs = Math.ceil((Number(cal.stroke_mm) || 0) / 100) || 1;
    var parts = [], missing = [];
    var fam = String(res.model).replace(/[0-9]+$/, '');
    if (key === 'KV') {
      var kvModel = 'KV' + String(res.model).match(/([0-9]+)$/)[1];
      var kvit = sheet.items ? (sheet.items[kvModel] || sheet.items[res.model]) : null;
      if (!kvit) return null;
      var boxNet = Math.round(kvit.box * 1.2 * 100) / 100;
      parts.push({ txt: '箱体（网络报价＝箱体报价×1.2）', amt: boxNet });
      parts.push({ txt: '丝杠/尾罩/蜗杆 每100mm×' + segs, amt: (kvit.per100 || 0) * segs });
      return { unit: Math.round(boxNet + (kvit.per100 || 0) * segs), parts: parts, missing: missing, factor: 1 };
    }
    var motion = (cal.motion === 'R') ? 'R' : 'S';
    var input = (motion === 'R') ? sheet.inputR : sheet.inputS;
    var itSel = inputType || cal.input_type || 'P1';
    /*

*/
    var ehbItMap = { EHB: 'P2', EIB: 'P2', ELB: 'P4', EUB: 'P4', EQB: 'P4',
      /**/
      EHA: 'P2', EIA: 'P2', ELA: 'P4', EUA: 'P4', EQA: 'P4' };
    if (input && input[itSel] == null && ehbItMap[itSel]) itSel = ehbItMap[itSel];
    var it2 = input ? input[itSel] : null;
    if (it2 != null) parts.push({ txt: '输入形式 ' + itSel + '（' + (motion === 'R' ? '螺母运动' : '丝杠运动') + '）', amt: it2 });
    else missing.push('输入形式');
    var mDef = (data && data.models) ? data.models[res.model] : null;
    /*

*/
    if (!mDef && data && data.models) {
      var fAlias = (fam === 'SCA') ? 'SJA' : (fam === 'SCB') ? 'SJB' : null;
      var bNum2 = fAlias ? String(res.model).match(/([0-9]+)$/) : null;
      if (bNum2) mDef = data.models[fAlias + bNum2[1]] || null;
    }
    var lead = (mDef && mDef.lead_mm != null) ? Number(mDef.lead_mm) : null;
    if (fam === 'EHB' || fam === 'DHB' || fam === 'EHA') {
      var vDef = (mDef && mDef.variants && res.variant) ? mDef.variants[res.variant] : null;
      var sm = String((vDef && vDef.screw) || '').match(/[xX](\d+)/);
      if (sm) lead = Number(sm[1]);
    }
    /*





*/
    var mDefType = (mDef && mDef.screw_type) ? String(mDef.screw_type) : '';
    var isBall = (fam === 'SJB' || fam === 'SCB' || fam === 'EHB' || fam === 'DHB' || fam === 'EHA')
      || mDefType === '滚珠丝杠';
    var p100 = sheet.per100 || {};
    if (isBall) {
      var bb = sheet.ballBase || null;
      var bv = null, bvPick = null;
      if (bb) {
        if (bb[(lead || 10) + 'mm'] != null) { bv = bb[(lead || 10) + 'mm']; bvPick = lead || 10; }
        else if (bb['base'] != null) bv = bb['base'];
        else {
          /*

*/
          var bks = Object.keys(bb).filter(function (k) { return /^[0-9]+mm$/.test(k); })
            .map(function (k) { return parseInt(k, 10); }).sort(function (a, b) { return a - b; });
          if (bks.length) {
            var wantLead = Number(lead) || bks[0], pickGate = null;
            for (var bi = 0; bi < bks.length; bi++) { if (bks[bi] <= wantLead) pickGate = bks[bi]; }
            if (pickGate == null) pickGate = bks[0];
            bv = bb[pickGate + 'mm']; bvPick = pickGate;
          }
        }
      }
      if (bv != null) parts.push({ txt: '滚珠丝杠基数' + (lead ? '（导程 ' + lead + 'mm' + (bvPick && bvPick !== lead ? ' → 按 ' + bvPick + 'mm 档' : '') + '）' : ''), amt: bv });
      else missing.push('滚珠丝杠基数');
      if (p100.ball != null) parts.push({ txt: '滚珠丝杠 每100mm×' + segs, amt: p100.ball * segs });
      else missing.push('滚珠丝杠行程价');
    } else {
      if (p100.trap != null) parts.push({ txt: '梯形丝杠 每100mm×' + segs, amt: p100.trap * segs });
      else missing.push('梯形丝杠行程价');
    }
    var jc = sheet.joint || {};
    /**/
    var jmap = { std: 'FL', FL: 'FL', NF: 'std', TS: 'TS', FO: 'FO', TF: 'ROE', ROE: 'ROE', bare: 'bare' };
    var jKey = jmap[cal.joint] || (cal.joint === 'FQ' ? null : 'FL');
    var jv = jKey ? jc[jKey] : null;
    if (jv != null && motion !== 'R') parts.push({ txt: '前接头 ' + (String(cal.joint).toUpperCase()), amt: jv });
    else if (motion !== 'R' && cal.joint !== 'bare') missing.push('前接头 ' + cal.joint);
    var acc = sheet.acc || {};
    var accs = (cal.accessories || []).slice();
    /*
*/
    accs.forEach(function (a) {
      var v = acc[String(a)];
      /*
*/
      if ((String(a) === 'FCP' || String(a) === 'FCG') && jackIsExMotor(res, cal)) {
        if (v != null) { parts.push({ txt: '防爆限位开关 ' + a, amt: v + 1000 }); return; }
        missing.push('防爆限位开关 ' + a);
        return;
      }
      if (v != null) parts.push({ txt: '附件 ' + a, amt: v });
      else missing.push('附件 ' + a);
    });
    /*
*/
    if (acc.tail != null && (key.indexOf('SJ') === 0 || key.indexOf('DHB') === 0)) {
      var tSegs = Math.max(1, Math.ceil((Number(cal.stroke_mm) || 0) / 500));
      parts.push({ txt: '尾罩 每500mm×' + tSegs, amt: acc.tail * tSegs });
    }
    if (!parts.length) return null;
    var sum = 0;
    parts.forEach(function (p) { sum += p.amt; });
    var f = (sheet.factor != null) ? sheet.factor : 1.2;
    return { unit: Math.round(sum * f), parts: parts, missing: missing, factor: f };
  }
  function rsdNetPriceOf(desc) {
    var book = limtecBook(); if (!book) return null;
    var m = String(desc || '').match(/R(SD|SS|VD|VDF)(\d{2,3})/);
    if (!m) return null;
    /*
*/
    var base = 'R' + m[1] + m[2];
    var p = book.rsd[base];
    if (p == null) {
      var norm = 'R' + m[1] + parseInt(m[2], 10);
      p = book.rsd[norm];
      if (p != null) base = norm;
    }
    if (p == null) return null;
    return { unit: Math.round(p * (book.rsd_factor || 1.2)), base: base };
  }
  function shaftNetPriceOf(wormDia, lenMm) {
    var book = limtecBook();
    if (!book || wormDia == null || !(lenMm > 0)) return null;
    var pick = limtecPickDia(Math.round(wormDia * 2), book.shaftPerM);
    var perM = book.shaftPerM[String(pick)];
    if (perM == null) return null;
    var perMNet = Math.round(perM * (book.shaft_factor || 1.5));
    return { unit: Math.round(perMNet * (lenMm / 1000)), dia: pick, perMNet: perMNet };
  }
  function couplingNetPriceOf(wormDia) {
    var book = limtecBook(); if (!book || wormDia == null) return null;
    var pick = limtecPickDia(wormDia, book.coupling);
    var p = book.coupling[String(pick)];
    if (p == null) return null;
    return { unit: Math.round(p * (book.coupling_factor || 1.5)), dia: pick };
  }
  function stripSpan(s) { return String(s || '').replace(/<[^>]+>/g, ''); }
  /*

*/
  function applyLimtecPrices(items, res, cal, data) {
    var book = limtecBook();
    if (!book || !items || !items.length) return items;
    var jk = jackNetPriceOf(res, cal, data);
    var jkByType118 = {};
    var dia = wormDiaOf(res, data);
    var hostTxt = stripSpan(productLabelOf(seriesOf(cal, res)));
    items.forEach(function (it) {
      if (!it || it.unit_price != null || it._unit != null) return;   /**/
      var d = stripSpan(it.desc || '');
      var n = Math.max(Number(it.n) || Number(it.qty) || 0, 1);
      if (d.indexOf(hostTxt) === 0) {
        if (jk) {
          /*


*/
          var im118 = d.match(/-P([1-4])(?=[-\/]|$)/);
          var hasFcp118 = /FCP/.test(d);
          /*
*/
          var itSel118 = (im118 ? 'P' + im118[1] : (cal.input_type || 'P1')) + (hasFcp118 ? '+FCP' : '-FCP');
          var itBase118 = String(itSel118).split(/[+-]/)[0];
          if (!jkByType118[itSel118]) {
            var calRow118 = cal;
            var accFcp118 = (cal.accessories || []).indexOf('FCP') >= 0;
            if (hasFcp118 !== accFcp118) {
              calRow118 = Object.assign({}, cal, { accessories: hasFcp118
                ? (cal.accessories || []).concat(['FCP'])
                : (cal.accessories || []).filter(function (a) { return a !== 'FCP'; }) });
            }
            jkByType118[itSel118] = jackNetPriceOf(res, calRow118, data, itBase118);
          }
          var jr = jkByType118[itSel118] || jk;
          it._unit = jr.unit;
          it.unit_price = moneyTxt(jr.unit);
          it.total_price = moneyTxt(jr.unit * n);
          /*
*/
        }
        return;
      }
      /*
*/
      if (/^行星减速机/.test(d) && it._planet) {
        var pv195 = it._planet;
        if (pv195.price != null) {
          it._unit = pv195.price;
          it.unit_price = moneyTxt(pv195.price);
          it.total_price = moneyTxt(pv195.price * n);
        } else {
          it.spec = (it.spec || '') + '（' + pv195.priceNote + '）';
        }
        return;
      }
      if (/^(换向器|伞齿轮减速机|带手轮输入的换向器|与电机一体化换向器)\s*R(SD|SS|VD|VDF)\d/.test(d)) {
        var rp = rsdNetPriceOf(d);
        if (rp) {
          /*

*/
          var rpUnit146 = rp.unit, plPriceNote146 = '';
          if (it._planet) {
            if (it._planet.price != null) {
              rpUnit146 += it._planet.price;
              it.spec = (it.spec || '') + '（合价含换向器 ' + moneyTxt(rp.unit) + ' ＋ 行星减速机 '
                + moneyTxt(it._planet.price) + '）';
            } else {
              plPriceNote146 = '（' + it._planet.priceNote + '，未计入合价）';
            }
          }
          it._unit = rpUnit146;
          it.unit_price = moneyTxt(rpUnit146);
          it.total_price = moneyTxt(rpUnit146 * n);
          if (plPriceNote146) it.spec = (it.spec || '') + plPriceNote146;
        }
        return;
      }
      if (d.indexOf('传动轴') === 0 && d.indexOf('长度按电机位置确定') < 0) {
        /*
*/
        var lm = d.match(/单根约\s*([0-9.]+)\s*mm/) || String(it.spec || '').replace(/<[^>]+>/g, '').match(/单根约\s*([0-9.]+)\s*mm/);
        if (lm && dia != null) {
          var sp = shaftNetPriceOf(dia, Number(lm[1]));
          if (sp) {
            it._unit = sp.unit;
            it.unit_price = moneyTxt(sp.unit) + '（Φ' + sp.dia + '，' + moneyTxt(sp.perMNet) + '/m）';
            it.total_price = moneyTxt(sp.unit * n);
          }
        }
        return;
      }
      if (d.indexOf('联轴器') === 0 && dia != null) {
        var cp = couplingNetPriceOf(dia);
        if (cp) {
          it._unit = cp.unit;
          it.unit_price = moneyTxt(cp.unit) + '（Φ' + cp.dia + '）';
          it.total_price = moneyTxt(cp.unit * n);
        }
        return;
      }
    });
    return items;
  }

  function quoteItems(res, cal, data, accItems, fullCode) {
    var items = [];
    var units = Number(cal.units) || 1;
    var code = fullCode || res.model;
    var spec = hostSpecText(res, cal, data);
    var hostName = productLabelOf(seriesOf(cal, res));
    /**/
    var limNameQ = jackIsExMotor(res, cal) ? '防爆限位开关' : '接近限位开关';
    /*
*/
    function dirCode(src, dir) {
      var s0 = String(src);
      if (/-R[XL](-|$)/.test(s0)) return s0.replace(/-R[XL](-|$)/, '-' + dir + '$1');
      return s0 + '-' + dir;
    }
    /*
*/
    function stripFcp(src) { return String(src).replace(/[-\/]FCP/, ''); }
    function withFcp(src) { return stripFcp(src) + '/FCP'; }
    if (cal.series === 'EHB' && units === 2 && cal.sync === '机械') {
      /*


*/
      var fcp2 = isMotionR(cal) ? '' : '/FCP';
      var sideMotor2 = (cal.layout === '电机单侧' || cal.layout === '直线布置-电机单侧' || cal.layout === '直线布置');
      /**/
      var codeRx2 = isMotionR(cal) ? stripFcp(String(code)) : withFcp(String(code));
      var codeLx2 = stripFcp(String(code).replace(/-RX(-|$)/, '-LX$1'));
      /**/
      var famTag2 = /^EHA/.test(String(code)) ? 'EHA' : 'EHB';
      var twinTag2 = twinLineTag(code);
      var noteRx2 = (sideMotor2 ? '电机侧 ' + twinTag2 + '：直线双轴 + 电机输入法兰，右旋丝杠 RX' : '输入轴方向 RX')
        + (fcp2 ? '；带' + limNameQ + ' FCP，整组行程控制' : '');
      items.push({
        desc: hostName + '　' + (sideMotor2 ? motorSideCode(codeRx2) : codeRx2)
          + '（' + noteRx2 + '）', spec: spec, qty: '1 台', n: 1
      });
      items.push({
        desc: hostName + '　' + codeLx2 + (sideMotor2 ? '（从动侧 ' + famTag2 + '：左旋丝杠 LX，标准）' : '（从动侧：输入轴方向 LX，标准）'),
        spec: spec, qty: '1 台', n: 1
      });
    } else if (ehbHalfSplitEhb(cal, res)) {
      /*



*/
      var uHalf = Number(cal.units) || 0;
      var stdHalf = stripFcp(code);
      /**/
      var ibHalf = function (dir) { return dirCode(twinLineOf(stdHalf), dir); };
      var lineTagHalf = twinLineTag(stdHalf);
      var rowHalf = function (desc, qty, n) { items.push({ desc: hostName + '　' + desc, spec: spec, qty: qty, n: n }); };
      if (isMotionR(cal)) {
        rowHalf(dirCode(stdHalf, 'RX') + '（输入轴方向 RX，标准）', '2 台', 2);
      } else {
        /**/
        rowHalf(withFcp(dirCode(stdHalf, 'RX')) + '（输入轴方向 RX；带' + limNameQ + ' FCP，整组行程控制）', '1 台', 1);
        rowHalf(dirCode(stdHalf, 'RX') + '（输入轴方向 RX，标准）', '1 台', 1);
      }
      rowHalf(ibHalf('RX') + '（' + lineTagHalf + ' 直线双轴型，贯通传动轴，输入轴方向 RX，标准）', '2 台', 2);
      if (uHalf === 8) rowHalf(ibHalf('LX') + '（' + lineTagHalf + ' 直线双轴型，贯通传动轴，输入轴方向 LX，标准）', '2 台', 2);
      rowHalf(dirCode(stdHalf, 'LX') + '（输入轴方向 LX，标准）', '2 台', 2);
    } else if (ehbLineSplitEhb(cal, res)) {
      /*



*/
      var uLine = Number(cal.units) || 0;
      var stdLine = stripFcp(code);
      /**/
      var ibLine = function (dir) { return dirCode(twinLineOf(stdLine), dir); };
      var lineTagLine = twinLineTag(stdLine);
      var rowLine = function (desc, qty, n) { items.push({ desc: hostName + '　' + desc, spec: spec, qty: qty, n: n }); };
      var midLine = (uLine - 2) / 2;
      if (isMotionR(cal)) {
        rowLine(dirCode(stdLine, 'RX') + '（输入轴方向 RX，标准）', '1 台', 1);
      } else {
        /**/
        rowLine(withFcp(dirCode(stdLine, 'RX')) + '（输入轴方向 RX；带' + limNameQ + ' FCP，整组行程控制）', '1 台', 1);
      }
      rowLine(ibLine('RX') + '（' + lineTagLine + ' 直线双轴型，贯通传动轴，输入轴方向 RX，标准）', midLine + ' 台', midLine);
      rowLine(ibLine('LX') + '（' + lineTagLine + ' 直线双轴型，贯通传动轴，输入轴方向 LX，标准）', midLine + ' 台', midLine);
      rowLine(dirCode(stdLine, 'LX') + '（输入轴方向 LX，标准）', '1 台', 1);
    } else if (revSplitHost(cal, res) || ehbRev4Split(cal, res)) {
      if (units === 4 && bevelFamRe203.test(String(res.model || ''))) {
        /*



*/
        var codeEhb = String(code);
        var codeEhbStd = stripFcp(codeEhb);
        var isEha4 = /^EHA/.test(codeEhbStd);
        var twinTag4 = twinLineTag(codeEhbStd);
        var angTag4 = twinAngleTag(codeEhbStd);
        var fcp4 = isMotionR(cal) ? '' : '；带' + limNameQ + ' FCP，整组行程控制';
        /*

*/
        var codeRx4 = function () { return isMotionR(cal) ? dirCode(codeEhb, 'RX') : withFcp(dirCode(codeEhb, 'RX')); };
        if (/^U2/.test(String(cal.layout || ''))) {
          /**/
          items.push({ desc: hostName + '　' + codeRx4() + '（输入轴方向 RX' + fcp4 + '）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(codeEhbStd, 'LX') + '（输入轴方向 LX，标准）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(twinLineOf(codeEhbStd), 'LX') + '（' + twinTag4 + ' 直线双轴型，输入轴方向 LX）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(twinLineOf(codeEhbStd), 'RX') + '（' + twinTag4 + ' 直线双轴型，输入轴方向 RX）', spec: spec, qty: '1 台', n: 1 });
        } else if (/^U/.test(String(cal.layout || ''))) {
          items.push({ desc: hostName + '　' + codeRx4() + '（输入轴方向 RX' + fcp4 + '）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(codeEhbStd, 'LX') + '（输入轴方向 LX，标准）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(twinAngleOf(codeEhbStd), 'RX') + '（' + angTag4 + ' 直角型，输入轴方向 RX）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(twinAngleOf(codeEhbStd), 'LX') + '（' + angTag4 + ' 直角型，输入轴方向 LX）', spec: spec, qty: '1 台', n: 1 });
        } else {
          items.push({ desc: hostName + '　' + codeRx4() + '（输入轴方向 RX' + fcp4 + '）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(codeEhbStd, 'RX') + '（输入轴方向 RX，标准）', spec: spec, qty: '1 台', n: 1 });
          items.push({ desc: hostName + '　' + dirCode(codeEhbStd, 'LX') + '（输入轴方向 LX，标准）', spec: spec, qty: '2 台', n: 2 });
        }
      } else {
      /*
*/
      items.push({ desc: hostName + '　' + code + '（带' + limNameQ + ' FCP，整组行程控制）', spec: spec, qty: '1 台', n: 1 });
      items.push({ desc: hostName + '　' + stripFcp(code) + '（标准 P2 双输入轴）', spec: spec, qty: (units - 1) + ' 台', n: units - 1 });
      }
    } else if (inlineSplitHost(cal)) {
      /**/
      var sideTxt = (cal.drive === 'hand') ? '手轮侧' : '电机侧';
      if (cal.series === 'EHB') {
        /*

*/
        var famTagIn = /^EHA/.test(String(code)) ? 'EHA' : 'EHB';
        items.push({
          desc: hostName + '　' + motorSideCode(code) + '（' + sideTxt + ' ' + twinLineTag(code) + '：直线双轴 + 电机输入法兰，右旋丝杠 RX）',
          spec: spec, qty: '1 台', n: 1
        });
        items.push({
          desc: hostName + '　' + followerCode(code) + '（从动侧 ' + famTagIn + '：左旋丝杠 LX）',
          spec: spec, qty: (units - 1) + ' 台', n: units - 1
        });
      } else {
        items.push({ desc: hostName + '　' + code + '（' + sideTxt + ' P4）', spec: spec, qty: '1 台', n: 1 });
        items.push({
          desc: hostName + '　' + followerCode(code) + '（从动侧 P2）',
          spec: spec, qty: (units - 1) + ' 台', n: units - 1
        });
      }
    } else {
      items.push({ desc: hostName + '　' + code, spec: spec, qty: units + ' 台', n: units });
    }
    (accItems || []).forEach(function (it) {
      var d = String(it.desc || '');
      var i = d.indexOf('：');
      var head = i > 0 ? d.slice(0, i) : d;
      var mu = /(\d+)\s*(台|根|个|套)/.exec(head);
      items.push({
        desc: head.replace(/\s*\d+\s*(台|根|个|套)\s*$/, ''),
        spec: i > 0 ? d.slice(i + 1) : '',
        qty: String(it.qty) + (mu ? ' ' + mu[2] : ' 件'),
        n: Number(it.qty) || 0,
        /**/
        red: !!it.red, over3500: !!it.over3500,
        /*
*/
        _planet: it._planet
      });
    });
    var m0 = (res.motor_recommend || [])[0];
    /*
*/
    var bevelBkList = ebhBrakeNote(res, cal);
    var nbList = brakeRequired(res) || bevelBkList;
    if (cal.drive !== 'hand' && m0) {
      /**/
      var mseg = [(m0.kind === 'ac' ? (m0.code || '') : (m0.brand || '') + ' ' + servoCodeShown(m0.code, nbList)), '功率 ' + C.fN(m0.power_kW, 2) + ' kW'];
      /**/
      if (m0.ac_over_cap != null) mseg.push('超功率（额定超该档最大输入功率 ' + C.fN(m0.ac_over_cap, 2) + ' kW）');
      /*


*/
      var hasGbRow2 = items.some(function (it) { return /行星减速机/.test(String(it.desc || '')); });
      var gbIsPlanetRow2 = /行星减速机/.test(String((m0.gearbox && m0.gearbox.type) || '行星减速机'));
      if (m0.gearbox && gbIsPlanetRow2 && !hasGbRow2) mseg.push('i=' + m0.gearbox.ratio + ' ' + m0.gearbox.type + '（输出 ' + m0.gearbox.out_rpm + ' rpm）');
      else mseg.push('额定转速 ' + m0.rpm + ' rpm');
      if (m0.torque_Nm != null) mseg.push('额定扭矩 ' + C.fN(m0.torque_Nm, 1) + ' N·m');
      if (m0.frame) mseg.push('机座 ' + m0.frame);
      if (m0.voltage && m0.kind !== 'dc') mseg.push(m0.voltage);   /**/
      if (isISMG2Code(m0.code)) mseg.push('不带制动（该系列无抱闸选配）');
      /**/
      if (nbList && !bevelBkList) mseg.push(isISMG2Code(m0.code)
        ? '需配制动器——ISMG2 系列无抱闸选配，制动须与汇川确认或另行解决'
        : '配制动器（本方案必选）');
      /*

*/
      if (bevelBkList) mseg.push('所有电机（含伺服）配制动器（必选）——'
        + (m0.kind === 'ac'
          ? 'YE3EJ 电磁制动系列，价含基座制动器'
          : (m0.kind === 'dc'
            ? '直流电机须选带制动器版本（24VDC）'
            : '配内置抱闸（24V DC），订货选带抱闸版本，抱闸加价按订货确认')));
      var sn = specNotes(cal);
      if (sn.length) mseg.push(sn.join('；'));
      var mqty = (cal.sync === '电气') ? units : 1;
      /*
*/
      /*


*/
      var mdKit = (m0.kind === 'servo') ? motorDrivePriceOf(m0, cal)
        : (m0.kind === 'ac' ? acMotorPriceOf(m0, huDualShaft(res, cal)) : null);
      var kitSpec2 = servoKitSpecOf(m0, cal);
      /**/
      var noPriceTxt2 = (m0.kind === 'servo' && /^1FL2|^1FT7/.test(String(m0.code || '')))
        ? 'S200/1FT7 系列价格待补'
        : (m0.kind === 'ac' && mdKit && mdKit.tentative) ? '暂定价格' : '暂无价格';
      /**/
      var driveOnly2 = !!(mdKit && mdKit.hasPrice && mdKit.driveOnly);
      /**/
      var dcNoPrice233 = (m0.kind === 'dc');
      var up2 = dcNoPrice233 ? '—' : ((mdKit && mdKit.hasPrice) ? (moneyTxt(mdKit.unit) + (driveOnly2 ? '（仅驱动器，电机另询）' : '')) : noPriceTxt2);
      var tp2 = dcNoPrice233 ? '—' : ((mdKit && mdKit.hasPrice) ? (moneyTxt(mdKit.unit * mqty) + (driveOnly2 ? '（不含电机）' : '')) : noPriceTxt2);
      items.push({
        desc: (m0.kind === 'ac'
          ? (huDualShaft(res, cal) ? '交流电机（双出轴）' : '交流电机')
          : (m0.kind === 'dc'
            ? '直流电机'
            : '交流伺服电机驱动器')) + '　' + C.fN(m0.power_kW, 2) + ' kW',
        spec: mseg.join('；') + kitSpec2, qty: mqty + ' 台', n: mqty,
        unit_price: up2, total_price: tp2, _unit: (!dcNoPrice233 && mdKit && mdKit.hasPrice) ? mdKit.unit : null
      });
    } else if (cal.drive === 'none') {
      /*
*/
      var nrQty = (cal.sync === '电气') ? units : 1;
      var nrSpec = ['所需功率 ' + C.fN((res.motor_power_kW != null ? res.motor_power_kW : res.total_power_kW), 2) + ' kW',
        '所需扭矩 ' + C.fN(res.motor_torque_Nm, 1) + ' N·m',
        '转速 ' + (res.motor_sync || cal.motor_rpm || res.rpm_needed || '—') + ' rpm'];
      if (res.rev_ratio && res.rev_ratio > 1) nrSpec.push('换向器减速比 1:' + res.rev_ratio);
      if (res.planetary_ratio) nrSpec.push('行星减速机 ' + res.planetary_ratio + ':1');
      if (brakeRequired(res)) nrSpec.push('需配制动器');
      /*
*/
      else if (ebhBrakeNote(res, cal)) nrSpec.push('伞齿轮系列不自锁，所有电机（含伺服）配制动器（必选）');
      nrSpec.push('电机由客户自配，接口尺寸/法兰按样本或与厂家确认');
      items.push({ desc: '电机技术要求（客户自配）', spec: nrSpec.join('；'), qty: nrQty + ' 台', n: nrQty });
    } else if (cal.drive !== 'hand') {
      /**/
      var fbQty = (cal.sync === '电气') ? units : 1;
      items.push({
        desc: '驱动电机（按计算功率配置）',
        spec: '计算需求 ' + C.fN(res.total_power_kW, 2) + ' kW / ' + (res.rpm_needed || '—') + ' rpm'
          + '；具体型号与厂家确认' + (brakeRequired(res) ? '，需配制动器' : ''),
        qty: fbQty + ' 台', n: fbQty
      });
    }
    /*
*/
    var spLines = specialReqLines(cal);
    if (spLines.length) {
      items.push({ desc: '特殊要求', spec: spLines.join('；'), qty: '—', n: 0 });
    }
    /**/
    return applyLimtecPrices(items, res, cal, data);
  }

  function aboutLines() {
    return [
      '力姆泰克（Lim-Tec）——国内最专业、最具规模、最权威的电动推杆 / 螺旋升降机 / 伺服电动缸专业制造厂家。2005 年合资引进欧洲直线传动技术与模块化组合设计理念；2015 年完成股改（注册资本三千万元），2016 年登陆新三板（股票代码 836388），成为国内螺旋升降机、电动缸第一股。',
      '廊坊大厂一期 8,000 m²（投资 5,000 万元、30 亩工业产权）、二期 28,000 m²（累计投资两亿元）生产基地，年产 5 万台；配备上百台数控加工设备，蜗杆、箱体、丝杠等关键零件全部自加工，不外协。',
      '质量与检测：100 吨加载测试中心可对大吨位产品满载荷跑合试验；进口三坐标测量仪、蜗杆磨精度检测等手段覆盖来料、加工与出厂全流程；产品逐台空载 / 负载跑合检验合格后出厂，随箱提供合格证与检验报告。',
      '产品线覆盖机械螺旋升降机（SJA/SJB/KV）、伞齿轮螺旋升降机（EHB）、电动推杆（SCA/SCB）、伺服电动缸及换向器、传动轴、联轴器、减速电机等成套传动附件，可为客户提供完整平台方案而非单件产品。',
      '全国 10 个办事处构成销售与服务网络，就近提供选型支持、安装指导与售后响应；截至 2020 年底近 16 万台产品成功应用于汽车装备、自动化装备、冶金、航天航空军工、港口机械等行业。',
      '对特殊工况（高低温、真空、防腐、防爆等）具备成熟的定制经验：低温密封圈与低温润滑脂、真空润滑脂（单独计费）、不锈钢丝杠 / 外壳、达克罗喷塑防腐、ExdIIBT4 防爆等配置均可按需提供，并有同类项目业绩支撑。'
    ];
  }

  function featLines() {
    var raw = [
      '传动效率 25%–33%，显著高于国产同类（14%–19%）',
      '规格实标：20 吨级箱体 75kg、丝杠 Ø80mm，型号比国产大一号',
      '球墨铸铁箱体（国产为灰铸铁），卧式加工中心 + 进口三坐标检测',
      '优质蜗轮材料，耐磨性能与使用寿命更优',
      '数控蜗杆磨精加工，啮合精度高、传动平稳',
      '零部件加工精度高于国内 2 级',
      '尾罩防转专利设计，保证丝杠不自转',
      '箱体凹槽散热设计，提升产品工作制',
      '欧洲标准模块化设计，附件齐全（限位开关、安全螺母、编码器等）',
      '提供成套平台方案与附件（传动轴、联轴器、换向器、减速电机），含现场调试支持'
    ];
    return raw.map(function (s, i) { return (i < 9 ? '0' : '') + (i + 1) + '　' + s; });
  }

  function commFields() {
    return {
      TERM_PRICE: '本方案书不列价格明细，正式价格以商务报价单为准；报价有效期 30 天。',
      TERM_DELIVERY: '标准机型合同生效后 6–8 周交货；带特殊工况配置（低温/高温/真空脂）或非标接口时，交期在合同确认时书面明确。',
      TERM_PAYMENT: '预付 30% 合同生效，发货前付清余款；长期合作客户可按年度框架协议执行。',
      TERM_WARRANTY: '自发货之日起 12 个月质保，非人为损坏免费维修或更换；非正常操作损坏除外。'
    };
  }

  function v2Fields(res, cal, data, opt, items, fullCode) {
    var units = Number(cal.units) || 1;
    var totalN = 0;
    (items || []).forEach(function (it) { totalN += (Number(it.n) || 0); });
    var def = (data && data.models && data.models[res.model]) || {};
    var m0 = (res.motor_recommend || [])[0];
    var brake = brakeRequired(res);
    /**/
    var bevelBkSum = ebhBrakeNote(res, cal);
    var layoutTxt = cal.layout ? layoutDisp(cal) : '';
    var syncTxt = (units > 1) ? ((cal.sync === '电气' ? '电气' : '机械') + '同步') : '单台';

    /**/
    var motorTxt = '按计算功率配置，具体型号与厂家确认';
    if (cal.drive === 'hand' && res.hand_torque_Nm != null) {
      motorTxt = '手摇轮驱动：手轮扭矩 ' + C.fN(res.hand_torque_Nm, 1) + ' N·m（按启动效率 '
        + (res.eta_start != null ? C.fN(res.eta_start, 2) : '—') + ' 计算）；手摇驱动无电机功率/转速计算';
    } else if (cal.drive === 'none') {
      motorTxt = '无电机（客户自配）：所需功率 ' + C.fN((res.motor_power_kW != null ? res.motor_power_kW : res.total_power_kW), 2)
        + ' kW / 所需扭矩 ' + C.fN(res.motor_torque_Nm, 1) + ' N·m / 转速 '
        + (res.motor_sync || cal.motor_rpm || res.rpm_needed || '—') + ' rpm，按电机技术要求选配';
    } else if (m0) {
      motorTxt = brandClean(m0.brand) + ' ' + servoCodeShown(m0.code, brake || bevelBkSum) + (huDualShaft(res, cal) ? '（双出轴）' : '') + '：'
        + C.fN(m0.power_kW, 2) + ' kW / '
        + m0.rpm + ' rpm'
        + (m0.ac_over_cap != null ? '（超功率：额定超该档最大输入功率 ' + C.fN(m0.ac_over_cap, 2) + ' kW）' : '')
        + (m0.torque_Nm != null ? '，额定扭矩 ' + C.fN(m0.torque_Nm, 1) + ' N·m' : '')
        + (isISMG2Code(m0.code) ? '，不带制动（该系列无抱闸选配）' : '')
        + (brake ? (isISMG2Code(m0.code)
          ? '，需配制动器——ISMG2 系列无抱闸选配，制动须与汇川确认或另行解决'
          : '，带制动器（本方案必选）')
          : (bevelBkSum
            ? (m0.kind === 'ac'
              ? '，带制动器（伞齿轮不自锁，YE3EJ 电磁制动系列，价含基座制动器）'
              : '，带制动器（伞齿轮不自锁，内置抱闸 24V DC，订货选带抱闸版本，加价按订货确认）')
            : ''))
        + '；' + ((cal.sync === '电气' && units > 1) ? units + ' 台（每台 1 台电机）' : (units > 1 ? '整线 1 台（机械同步共用）' : '1 台'));
    }

    /**/
    var rated = (res.route === 'A') ? def.rated_load_kN
      : (((def.variants || {})[res.variant] || {}).rated_thrust_kN);
    var eff = Number(res.effective_load_kN) || 0;
    var floor = (typeof rated === 'number') ? 0.2 * rated : null;
    var modelMargin = (typeof rated === 'number' && eff > 0)
      ? '（裕量 ' + C.fN((rated - eff) / rated * 100, 0) + '%）' : '';
    /**/
    var thrustPass = (typeof rated === 'number' && eff > 0) ? (rated >= eff - 1e-9) : null;
    /*

*/
    var codeDocTxt = docDispOf(cal, (function (code) {
      if (!m0 || m0.rpm == null) return code || res.model;
      return String(code || res.model).replace(/(MO:[0-9.]+KW\s+)([0-9.]+)(RPM)/i,
        function (s0, p1, p2, p3) { return p1 + Math.round(Number(m0.rpm)) + p3; });
    })(fullCode));
    /**/
    var modelTxt = '选型 ' + docDispOf(cal, res.model) + (res.ratio_key ? ' ' + res.ratio_key : '')
      + (typeof rated === 'number'
        ? '：额定推拉力 ' + rated + ' kN ' + (thrustPass === false ? '<' : '≥') + ' 单台需求 ' + C.fN(eff, 1) + ' kN'
          + modelMargin + '，' + (thrustPass === false ? '推力不足，需选更大型号；' : '选型通过；')
          + '完整型号 ' + codeDocTxt
        : '：额定推力数据待补全，需与厂家确认');
    var loadTxt = '单台 ' + C.fN(eff, 1) + ' kN（总 ' + C.fN(eff * units, 1) + ' kN ÷ ' + units + ' 台）'
      + (floor ? '；20% 下限 ' + C.fN(floor, 1) + ' kN'
        + ((Number(res.per_unit_load_kN) || 0) < floor * 1.001 ? '，按该下限取值' : '，按实际载荷计算') : '');

    /**/
    var sn = specNotes(cal);
    var mip = (res.route === 'A')
      ? (((def.ratio_options || {})[res.ratio_key] || {}).max_input_power_kW) : def.max_input_power_kW;
    var pDiffTxt = '';
    if (res.power_relaxed) pDiffTxt = '，审核通过（每日工作次数不超过 20 次，最大输入功率允许放大 1.5 倍采用）';
    var etaM = /η\(([0-9.]+)\)/.exec(stepText(res, '输入功率') || '');
    var outTxt = 'P出 = F × v = ' + C.fN(eff, 1) + ' kN × ' + C.fN(res.speed_mm_s, 2) + ' mm/s = '
      + C.fN(res.p_out_W, 1) + ' W（单台）';
    var powerTxt = 'P出 ' + C.fN(res.p_out_W, 1) + ' W ÷ η' + (etaM ? '(' + etaM[1] + ')' : '')
      + ' = P入 ' + C.fN(res.p_in_calc_kW, 2) + ' kW'
      + (sn.length ? '（已含特殊工况系数' + (units > 1 ? '，单台计算' : '与单台安全裕量') + '）'
        : (units > 1 ? '（单台）' : '（已含单台安全裕量）'));
    var checkTxt = 'P入 ' + C.fN(res.p_in_calc_kW, 2) + ' kW'
      + (mip != null ? ' ≤ 最大输入功率 ' + C.fN(mip, 2) + ' kW，' : '，')
      + (res.checks && res.checks['最大输入功率'] === false ? '校核未通过' : '校核通过') + pDiffTxt;
    /**/
    var demandKwS = (res.motor_demand_kW != null) ? Number(res.motor_demand_kW) : Number(res.total_power_kW);
    var ampCS = (res.motor_amp_coef != null && units <= 1) ? Number(res.motor_amp_coef) : null;
    var ampSegS = (ampCS != null)
      ? '（计算功率 ' + C.fN(res.total_power_kW, 2) + ' kW × ' + ampCS.toFixed(1) + (ampCS < 1.2 ? '，小于 1.2 凑标准档' : ' 放大') + '）' : '';
    /*



*/
    function briefStep(t) {
      return String(t || '')
        .replace(/（速度[\s\S]*?）$/, '')
        .replace(/（η 取[\s\S]*?）$/, '')
        .replace(/（多台功率已含台数放大系数）/g, '')
        .replace(/校核通过（裕量足）/g, '校核通过')
        .replace(/（组合系数按样本[\s\S]*）$/, '')
        /*
*/
        .replace(/；每级换向器\/减速机[\s\S]*$/, '');
    }
    function speedBrief(t) {
      var s = String(t || '')
        .replace(/^伺服换向器类布置（[^）]*）：/, '')
        .replace(/电机由驱动器调速运行至[^；:：]*[；:：]/g, '')
        .replace(/（第\d+轮[^）]*）/g, '')
        .replace(/（要求[\s\S]*?）/g, '')
        .replace(/，配换向器速比[\s\S]*满足使用要求/, '')
        .replace(/，按最接近速度档使用，满足使用要求/, '')
        .replace(/，满足使用要求$/, '')
        .replace(/^取 /, '');   /**/
      var i = s.indexOf('v = ');
      if (i > 0) s = s.slice(0, i).replace(/[：；]$/, '，') + '\n' + s.slice(i);
      return s;
    }
    var powerLineTxt = (function () {
      var compact = 'P出 ' + C.fN(res.p_out_W, 0) + ' W；P入 ' + C.fN(res.p_in_calc_kW, 2) + ' kW'
        + (mip != null ? ' ≤ 最大输入 ' + C.fN(mip, 2) + ' kW，' : '，')
        + (res.checks && res.checks['最大输入功率'] === false ? '未通过' : '通过')
        + (units > 1 ? '；P平 ' + C.fN(res.total_power_kW, 2) + ' kW'
          : '；需求功率 ' + C.fN(demandKwS, 2) + ' kW' + ampSegS)
        + (res.power_relaxed ? '（每日≤20 次，允许放大 1.5 倍）' : '');
      var lines = [];
      ['输出功率', '输入功率', '最大输入功率校核'].forEach(function (k) {
        var t = stepText(res, k);
        if (t) lines.push(k + '：' + briefStep(t));
      });
      if (units > 1) {
        if (cal.sync === '电气') {
          /*
*/
          lines.push('电机功率 = 总负载 ÷ ' + units + ' 台 × 放大系数 1.5 = '
            + C.fN(res.total_power_kW, 2) + ' kW');
        } else {
          var tP = briefStep(stepText(res, '平台总功率'));
          lines.push('平台总功率：' + (tP || ('P平 = P入 × ' + units + ' 台（含组合系数与换向器级损）= '
            + C.fN(res.total_power_kW, 2) + ' kW')));
        }
        var tA = stepText(res, '放大系数');
        var mA = String(tA || '').match(/^总功率 = ([0-9.]+)kW × ([0-9.]+) = /);
        if (mA) {
          lines.push('放大系数：总功率 = ' + mA[1] + 'kW × ' + mA[2] + ' = ' + C.fN(Number(mA[1]) * Number(mA[2]), 2) + 'kW');
        } else if (tA) {
          lines.push('放大系数：' + tA);
        }
      } else {
        lines.push('需求功率 ' + C.fN(demandKwS, 2) + ' kW' + ampSegS);
      }
      /**/
      return lines.length > 1 ? lines.join('\n') : compact;
    })();
    var totalTxt = (units > 1
      ? 'P平 ' + C.fN(res.total_power_kW, 2) + ' kW（单台 ' + C.fN(res.p_in_calc_kW, 2) + ' kW × ' + units + ' 台，含组合与放大系数）'
      : '需求功率 ' + C.fN(demandKwS, 2) + ' kW' + ampSegS);
    var speedReq = Number(cal.speed_mm_s) || 0;
    /*
*/
    var speedTxt = speedBrief(stepText(res, '速度校核')) || (C.fN(res.speed_mm_s, 2) + ' mm/s（要求 ' + C.fN(speedReq, 2)
      + (speedReq ? '，偏差 ' + (res.speed_mm_s >= speedReq ? '+' : '') + C.fN((res.speed_mm_s - speedReq) / speedReq * 100, 1) + '%' : '')
      + '），按最接近速度档');
    var rpmTxt = m0 ? (m0.gearbox ? m0.gearbox.out_rpm : m0.rpm)
      : (res.motor_sync || res.motor_rpm || cal.motor_rpm || res.rpm_needed || 0);
    /*




*/
    var motorRpmTxt = m0 ? (Number(m0.rpm) || m0.rpm)
      : (res.motor_sync || res.motor_rpm || cal.motor_rpm || res.rpm_needed || 0);
    /*
*/
    var handRadius = res.hand_radius_mm || 200;
    var handUseF = (res.hand_force_use_kg != null) ? res.hand_force_use_kg : res.hand_force_kg;
    /*




*/
    var gbRatioT = 1, gbEffT = 1;
    if (m0 && m0.gearbox) {
      var gbNumT = parseFloat(String(m0.gearbox.ratio));
      if (isFinite(gbNumT) && gbNumT > 1) gbRatioT = gbNumT;
      var gbEffNum = Number(m0.gearbox.eff);
      if (isFinite(gbEffNum) && gbEffNum > 0) gbEffT = gbEffNum;
    }
    /*


*/
    var isRouteCT = String(res.route) === 'C';
    var tqPowV = isRouteCT ? Number(res.motor_power_kW)
      : ((gbRatioT > 1) ? (demandKwS / gbEffT) : demandKwS);
    var tqRpmV = isRouteCT ? Number(res.motor_run_rpm || 0)
      : ((gbRatioT > 1) ? motorRpmTxt : rpmTxt);
    var tqNmV = (!isRouteCT && gbRatioT > 1 && Number(tqRpmV) > 0)
      ? (9550 * tqPowV / Number(tqRpmV))
      : res.motor_torque_Nm;
    /**/
    var ampSegT = (gbRatioT > 1) ? '' : ampSegS;
    var torqueTxt = (cal.drive === 'hand' && res.hand_torque_Nm != null)
      ? '手摇扭矩 ' + C.fN(res.hand_torque_Nm, 1) + ' N·m ≤ 最大输入扭矩 '
        + (res.max_input_torque_Nm != null
          ? C.fN(res.max_input_torque_Nm, 1) + ' N·m（= 满载启动扭矩 '
            + C.fN(res.startup_torque_Nm, 1) + ' N·m × 2，样本 p' + (res.startup_torque_page || 63) + '）'
          : '（= 满载启动扭矩 × 2，样本 p' + (res.startup_torque_page || 63) + '；数据待补全，需与厂家确认）')
        + '，' + (res.checks && res.checks['扭矩'] === false ? '未通过' : '校核通过')
        + '；手摇力 ' + (handUseF != null ? C.fN(handUseF, 1) + 'kg' : '—')
          + '（手摇把半径 ' + handRadius + 'mm，限 10kg'
          + (res.hand_force_tolerance ? '，超出 ≤5% 可设定合格' : '') + '）'
      : 'T = 9550 × ' + C.fN(tqPowV, 2) + ' kW' + (ampSegT ? ' ' + ampSegT : '')
        + ' ÷ ' + C.fN(tqRpmV, 0) + ' rpm = ' + C.fN(tqNmV, 1) + ' N·m'
        + (gbRatioT > 1 && gbEffT < 0.999 ? '（电机端，已经行星减速机折算）' : '');
    var dutyTxt = stepText(res, '工作制校核') || '按样本选择原则校核';
    var lifeTxt = res.life
      ? '理论寿命 ' + C.fN(res.life.life_km, 0) + ' km ≈ ' + res.life.years + ' 年'
        + (res.life.pass ? '，满足 ' + res.life.req_years + ' 年要求' : '，不足 ' + res.life.req_years + ' 年，需调整选型')
      : '';
    /**/
    var handV = (cal.drive === 'hand') && (res.ratio_key && /V/i.test(res.ratio_key));
    var brakeTxt = cal.drive === 'hand'
      ? (handV ? 'V1 蜗轮蜗杆不自锁，须加装制动器或其他安全措施防逆转，注意安全'
               : '蜗轮副自锁（L1 大减速比），防逆转满足要求')
      : (brake
        ? '蜗轮副/丝杠不自锁，所有电机配制动器（本方案必选）'
        /*
*/
        : (ebhBrakeNote(res, cal)
          ? '伞齿轮系列不自锁，所有电机（含伺服）配制动器（必选）：交流配 YE3EJ 电磁制动系列（价含基座制动器），伺服配内置抱闸（24V DC，加价按订货确认）'
          : (cal.selflock === '是' ? '要求自锁，选用自锁机构满足' : '机构自锁满足要求，电机可不配制动器')));
    var ratioTxt = (res.route === 'A')
      ? '速比 ' + (res.ratio || '—') + '，每转 ' + C.fN(res.mm_per_rev, 2) + ' mm'
        + '；丝杠 ' + (res.mm_per_rev ? C.fN(res.speed_mm_s * 60 / res.mm_per_rev, 0) : '—') + ' rpm'
        + '（电机端 ' + C.fN(motorRpmTxt, 0) + ' rpm）'
      : '导程 ' + (((def.variants || {})[res.variant] || {}).lead_mm != null
        ? ((def.variants || {})[res.variant]).lead_mm + ' mm' : '—')
        + '；丝杠转速 ' + C.fN(res.speed_mm_s * 60 / (((def.variants || {})[res.variant] || {}).lead_mm || 1), 0) + ' rpm';
    var reqEnv = cal.env + '，' + cal.ambient_temp + ' ℃'
      + (cal.series === 'EHB'
        ? '；丝杠选择 ' + screwPickText(cal)
        : (cal.precision_mm !== null && cal.precision_mm !== undefined && cal.precision_mm !== '无'
          ? '；重复精度 ' + cal.precision_mm + ' mm' : ''))
      + (sn.length ? '；' + sn.join('；') : '；无特殊工况配置');

    var dateTxt = opt.docDate || '';

    /*




*/
    var aboutAll = aboutLines(), featAll = featLines();
    /**/
    var motorLineTxt = (function () {
      if (cal.drive === 'hand' && res.hand_torque_Nm != null) {
        return '手摇轮驱动：手轮扭矩 ' + C.fN(res.hand_torque_Nm, 1) + ' N·m，手摇把半径 '
          + (res.hand_radius_mm || 200) + 'mm，手摇驱动力 '
          + (handUseF != null ? C.fN(handUseF, 1) + 'kg' : '—')
          + (res.hand_force_tolerance ? '（超出 10kg 限额 ≤5%，可设定合格）' : '')
          + '；' + (handV ? '不自锁，注意安全' : '蜗轮副自锁');
      }
      if (cal.drive === 'none') {
        return '无电机（客户自配）：所需功率 ' + C.fN((res.motor_power_kW != null ? res.motor_power_kW : res.total_power_kW), 2)
          + 'kW / ' + C.fN(res.motor_torque_Nm, 1) + 'N·m / '
          + (res.motor_sync || cal.motor_rpm || res.rpm_needed || '—') + 'rpm；' + brakeTxt;
      }
      return ((m0
        ? brandClean(m0.brand) + ' ' + (m0.code || '') + ' ' + C.fN(m0.power_kW, 2) + 'kW/'
        + motorRpmTxt + 'rpm'
          + (m0.torque_Nm != null ? '，' + C.fN(m0.torque_Nm, 0) + 'N·m' : '')
          + (m0.ac_over_cap != null ? '（超功率：额定超该档最大输入功率 ' + C.fN(m0.ac_over_cap, 2) + ' kW）' : '')
        : '按计算功率配置')
        + (units > 1 ? '，整线 1 台' : '，1 台') + '；' + brakeTxt);
    })();
    var layoutCaptionTxt = (function () {
      var pick0 = layoutPickFor(cal);
      if (!layoutImageFor(cal) && !(pick0 && pick0.img)) {
        return '本工况暂无标准布置示意，最终布置以双方确认的接口图为准。';
      }
      /**/
      if (units <= 1) {
        var lay1 = (pick0 && pick0.v) || cal.layout || '';
        return '图：单台螺旋升降机' + (lay1 ? '（' + lay1 + '）' : '')
          + (cal.drive === 'hand' ? '，手轮驱动' : '，电机 + 联轴器直连')
          + '；最终布置以双方确认的接口图为准。';
      }
      /**/
      if (cal.sync === '电气') {
        return '图：单台电机一体化（每台 1 台伺服电机直驱）× ' + units + ' 台；最终布置以双方确认的接口图为准。';
      }
      var accTxt = (items || []).filter(function (it) {
        return it.n && /传动轴|联轴器|换向器/.test(it.desc);
      }).map(function (it) { return it.desc + ' ' + it.qty; });
      /*
*/
      var hostPre = '';
      if (revSplitHost(cal) || ehbRev4Split(cal, res)) {
        /*

*/
        if (units === 4 && bevelFamRe203.test(String(res.model || ''))) {
          var isEhaCap = /^EHA/.test(String(res.model || ''));
          var fT = isEhaCap ? 'EHA' : 'EHB', twT = isEhaCap ? 'EIA' : 'EIB', agT = isEhaCap ? 'ELA' : 'ELB';
          var fcpCap = isMotionR(cal) ? '' : '（其中 1 台带 FCP）';
          hostPre = /^U2/.test(String(cal.layout || ''))
            ? fT + '-RX / ' + fT + '-LX / ' + twT + '-LX / ' + twT + '-RX 各 1 台 + '
            : /^U/.test(String(cal.layout || ''))
              ? fT + '-RX / ' + fT + '-LX / ' + agT + '-RX / ' + agT + '-LX 各 1 台 + '
              : fT + '-RX 2 台' + fcpCap + ' + ' + fT + '-LX 2 台 + ';
        } else hostPre = (units - 1) + ' 台标准 P2 + 1 台带 FCP + ';
      }
      else if (inlineSplitHost(cal)) hostPre = '1 台 P4 + ' + (units - 1) + ' 台 P2 + ';
      return '图：' + units + ' 台' + (layoutTxt || '') + '，' + syncTxt
        + '（' + hostPre + accTxt.join(' + ') + ' + ' + ((cal.drive === 'hand') ? '手动' : '1 台电机') + '）';
    })();
    var p2Extras = (function () {
      function extraLines(s) { return Math.max(0, tailLines(String(s || ''), 8500, 14) - 1); }
      var e = extraLines(motorLineTxt)
        + extraLines(dutyTxt + (lifeTxt ? '；' + lifeTxt : ''))
        + extraLines(sn.length ? sn.join('；') : '')
        + extraLines(layoutCaptionTxt);
      return e * 235;
    })();
    var tb = tailBudget(aboutAll, featAll, items, p2Extras);
    var aboutKeep = tb.aboutKeep, featKeep = tb.featKeep;
    /*

*/
    var famDoc = String(res.model || '').replace(/[0-9]+$/, '');
    /**/
    if (famDoc === 'EHB' || famDoc === 'DHB' || famDoc === 'EHA') featKeep = 0;

    var out = {
      DOC_TITLE: opt.docTitle || '螺旋升降机选型方案书',
      DOC_SUBTITLE_EN: (res.route === 'A' ? 'Screw Jack Solution Proposal & Quotation'
        : 'Bevel-Gear Screw Jack Solution Proposal') + '　|　' + docDispOf(cal, res.model)
        + (res.route === 'A' ? (res.ratio_key ? ' ' + res.ratio_key : '') : (res.variant ? ' ' + res.variant : '')),
      DOC_NO: 'LMT-TP-' + dateTxt.replace(/-/g, '') + '-' + docDispOf(cal, res.model || 'SJ').replace(/[^A-Z0-9]/gi, ''),
      DOC_REV: 'V3.1',
      DOC_DATE: dateTxt,
      DOC_STATUS: res.all_pass ? 'Final　最终版' : 'For Review　待确认',
      DOC_VALID: '30 天',
      META_CUSTOMER: opt.faxTo || '—',
      META_CONTACT: [opt.faxAttn, opt.faxTel].filter(Boolean).join('　') || '—',
      META_PROJECT: opt.docTitle || '—',
      META_AUTHOR: opt.faxFrom || '力姆泰克销售部',
      META_SALES: opt.faxSales || [opt.faxName, opt.faxMobile].filter(Boolean).join('　')
        || opt.faxFrom || '销售部',
      META_EMAIL: opt.faxEmail || 'sales@lim-tec.com',

      /**/
      REQ_MOTION: (cal.motion === 'R' ? '螺母运动（丝杠固定）' : '丝杠运动（螺母固定）')
        + '；' + units + ' 台' + (units > 1 ? '，' + syncTxt : '')
        /**/
        + (layoutTxt && cal.sync !== '电气' ? '，' + layoutTxt + '布置' : '')
        + '；' + (cal.drive_label || cal.motor_type)
        + (units > 1 && cal.sync !== '电气' ? '（整线共用 1 台）' : ''),
      REQ_LOAD: '总负载 ' + ((cal.raw.load === '' || cal.raw.load == null) ? 0 : cal.raw.load) + ' '
        + ({ t: '吨', kN: 'kN', kgf: 'kgf', N: 'N' }[cal.raw.load_unit] || 't')
        + '（' + C.fN(eff * units, 1) + ' kN），单台 ' + C.fN(eff, 1) + ' kN'
        + (cal.load_pull_t ? '；拉力工况 ' + cal.load_pull_t + ' t' : '')
        + (cal.static_load_t ? '；静载 ' + cal.static_load_t + ' t' : ''),
      /*
*/
      REQ_SPEED: (cal.drive === 'hand')
        ? '行程 ' + cal.stroke_mm + ' mm；手摇驱动，输出速度由人工控制'
          + '；每日 ' + (cal.cycles_per_day === null ? '—' : cal.cycles_per_day) + ' 次 × '
          + (cal.hours_per_day || 8) + ' 小时，年运行 ' + cal.days_per_year + ' 天'
        : '行程 ' + cal.stroke_mm + ' mm；速度 ' + cal.speed_mm_s + ' mm/s'
        + (res.speed_mm_s && Math.abs(res.speed_mm_s - cal.speed_mm_s) > 0.05
          ? '（实际输出 ' + C.fN(res.speed_mm_s, 2) + ' mm/s）' : '')
        + '；每日 ' + (cal.cycles_per_day === null ? '—' : cal.cycles_per_day) + ' 次 × '
        + (cal.hours_per_day || 8) + ' 小时，年运行 ' + cal.days_per_year + ' 天',
      /*


*/
      REQ_MOUNT: cal.mounting + (cal.guide === '有'
        ? '；客户自备导向，侧向力不作用于升降机'
        : '；无导向，侧向力不作用于升降机')
        + (cal.drive === 'hand'
          /**/
          ? '；手摇驱动（无电机）：' + (/V/i.test(String((res && res.ratio_key) || ''))
            ? 'V1 档蜗轮蜗杆不自锁，须加装制动器或其他安全措施'
            : 'L1 档蜗轮副自锁')
          : ('；' + (cal.selflock === '是' ? '要求自锁' : '不要求自锁')
            + (brake ? (isISMG2Code(m0 && m0.code)
              ? '，需配制动器——ISMG2 系列无抱闸选配，制动须与汇川确认或另行解决'
              : '，电机配制动器（必选）')
              /*
*/
              : (ebhBrakeNote(res, cal) ? '，伞齿轮不自锁，所有电机（含伺服）配制动器（必选）' : '，电机可不配制动器')))),
      REQ_ENV: reqEnv,

      SUM_LOAD: loadTxt,
      SUM_MODEL: modelTxt,
      /*


*/
      SUM_OUT: outTxt,
      SUM_POWER: powerTxt,
      SUM_CHECK: checkTxt,
      /**/
      SUM_TOTAL: totalTxt,
      /**/
      SUM_RATIO: (cal.drive === 'hand') ? '[[HIDE]]' : ratioTxt,
      SUM_POWER_LINE: (cal.drive === 'hand') ? '[[HIDE]]' : powerLineTxt,
      SUM_SPEED: (cal.drive === 'hand') ? '[[HIDE]]' : speedTxt,
      SUM_TORQUE: torqueTxt,
      SUM_STAB: (function () {
        /*

*/
        var t = stepText(res, '稳定性校核') || '按样本稳定性曲线校核';
        var c0 = res.checks ? res.checks['稳定性'] : undefined;
        var verdict = (c0 === false) ? '校核未通过' : (c0 === null ? '待厂家确认' : '校核通过');
        if (t.length <= 46) return t;
        var mLk = t.match(/Lk≈\s*([0-9.]+)\s*mm/);
        /**/
        if (mLk && t.indexOf(mLk[0]) + mLk[0].length > 34) return 'Lk≈' + mLk[1] + 'mm，' + verdict;
        return t.slice(0, 34).replace(/[，、；]$/, '') + '…，' + verdict;
      })(),
      SUM_DUTY: dutyTxt,
      SUM_LIFE: lifeTxt,
      SUM_DUTY_LINE: dutyTxt + (lifeTxt ? '；' + lifeTxt : ''),
      SUM_MOTOR: motorTxt,
      SUM_BRAKE: brakeTxt,
      SUM_MOTOR_LINE: motorLineTxt,
      SUM_SPECIAL: sn.length ? sn.join('；') : '标准工况，无特殊系数修正',

      LAYOUT_CAPTION: layoutCaptionTxt,
      CALC: calcLines(res),
      /**/
      ABOUT: aboutAll.slice(0, aboutKeep),
      /**/
      FEAT_KEEP: featKeep,
      ABOUT_1: aboutAll[0], ABOUT_2: aboutAll[1], ABOUT_3: aboutAll[2],
      ABOUT_4: aboutAll[3], ABOUT_5: aboutAll[4], ABOUT_6: aboutAll[5],
      FEAT_1: featAll[0], FEAT_2: featAll[1], FEAT_3: featAll[2], FEAT_4: featAll[3],
      FEAT_5: featAll[4], FEAT_6: featAll[5], FEAT_7: featAll[6], FEAT_8: featAll[7],
      FEAT_9: featAll[8], FEAT_10: featAll[9],
      /*




*/
      QUOTE_NOTE: (function () {
        try {
          if (typeof window !== 'undefined' && window.LANG_I18N && typeof window.LANG_I18N.fxNote === 'function') {
            var n = window.LANG_I18N.fxNote();
            if (n) return String(n);
          }
        } catch (e) {}
        return '';
      })(),
      ITEM_TOTAL: units + ' 台'
      /**/
    };
    /**/
    var cf = commFields();
    Object.keys(cf).forEach(function (k) { out[k] = cf[k]; });
    return out;
  }

  function composeSpec(res, cal, data, opt) {
    opt = opt || {};
    var route = res.route;
    /*
*/
    var accItems = buildAccessories(res, cal, data);
    var fullCode = suggestCode(cal, res);
    var qItems = quoteItems(res, cal, data, accItems, fullCode);

    var fields = {
      PLAIN: true,
      DOC_TITLE: opt.docTitle || ((cal.units > 1 ? cal.units + '台' : '') + '螺旋升降机选型方案书'),
      DOC_DATE: opt.docDate || '',
      COVER_HEADER: opt.coverHeader || '力 姆 泰 克 北京办事处',
      FAX_DATE: opt.faxDate || '',
      FAX_EMAIL: opt.faxEmail || 'sales@lim-tec.com',
      FAX_FROM: opt.faxFrom || '力姆泰克技术部',
      FAX_MOBILE: opt.faxMobile || '',
      FAX_TO: opt.faxTo || '',
      FAX_ATTN: opt.faxAttn || '',
      FAX_TEL: opt.faxTel || '',
      PLAN_TITLE: opt.planTitle || (docDispOf(cal, res.model) + ' 螺旋升降机选型方案'),
      PLAN_SUBTITLE: opt.planSubtitle || '',
      CLIENT: clientLines(cal, res),
      PARAM: clientLines(cal, res),
      STEP: stepLines(res, cal),
      MOTOR: motorLines(res, cal),
      ITEMS: qItems,
      /**/
      ITEM_PRICE_TOTAL: (function () {
        var t = 0, any = false;
        (qItems || []).forEach(function (it) {
          if (it && typeof it._unit === 'number' && it._unit > 0 && it.n > 0) { t += it._unit * it.n; any = true; }
        });
        return any ? moneyTxt(t) : '暂无价格';
      })(),
      LAYOUT_IMAGE: layoutImageFor(cal),
      /*

*/
      LAYOUT_PICK: (function () {
        var pk = layoutPickFor(cal);
        return (pk && pk.img) ? pk.img : '';
      })(),
      STABILITY_IMAGE: (route === 'A') ? '' : null
    };
    var v2 = v2Fields(res, cal, data, opt, qItems, fullCode);
    Object.keys(v2).forEach(function (k) { fields[k] = v2[k]; });

    /*


*/
    (function p1AutoGap() {
      var toks = ['REQ_MOTION', 'REQ_LOAD', 'REQ_SPEED', 'REQ_MOUNT', 'REQ_ENV'];
      var lines = 0;
      toks.forEach(function (t) {
        var s = String(fields[t] || ''), w = 0;
        for (var i = 0; i < s.length; i++) w += (s.charCodeAt(i) > 255 ? 1 : 0.55);
        lines += Math.max(1, Math.ceil(w / 40));   /**/
      });
      var free = 3000 - (lines - 5) * 320;         /**/
      if (free < 0) free = 0;
      fields.GAP_TITLE_IMG = String(40 + Math.round(free * 0.10));
      fields.GAP_IMG_INFO = String(40 + Math.round(free * 0.15));
      fields.GAP_INFO_01 = String(130 + Math.round(free * 0.15));
      fields.P1_ROWH = String(230 + Math.floor(free * 0.60 / 5));
    })();
    /*
*/
    return { template: (route === 'A') ? 'A' : 'C', fields: fields, items: qItems,
      layoutImage: fields.LAYOUT_IMAGE, zipDate: opt.docDate || '' };
  }

  /**/
  g.SJScrewJackProduct = {
    id: 'screwjack', name: '螺旋升降机', status: 'ready', dataKey: 'SJ_DATA',
    /**/
    desc: 'SJA 梯形丝杠 · SJB 滚珠丝杠 · KV 不锈钢 · SCA/SCB 升降机推杆',
    FAMILIES: FAMILIES, SCHEMA: SCHEMA, LOAD_UNITS: LOAD_UNITS, UNIT_F: LOAD_UNITS, loadUnitOptions: loadUnitOptions,
    /**/
    defaultLoadUnit: function () { return defLoadUnit(); },
    defaultInput: defaultInput, toCalc: toCalc,
    pickFamilies: pickFamilies, buildCandidates: buildCandidates,
    autoSelect: autoSelect, buildAccessories: buildAccessories, quoteItems: quoteItems,
    productLabelOf: productLabelOf, seriesOf: seriesOf,
    layoutOptions: layoutOptions, layoutDisp: layoutDisp, syncDriveLayout: syncDriveLayout, layoutImageFor: layoutImageFor, layoutPickFor: layoutPickFor,
    tailBudget: tailBudget,
    LAYOUT_IMAGES: LAYOUT_IMAGES, effUnits: effUnits, driveLabel: driveLabel, suggestCode: suggestCode,
    /**/
    pickRsd: pickRsd, pickRsdForMotor: pickRsdForMotor,
    actualRpm: actualRpm, inlineSplitHost: inlineSplitHost, followerCode: followerCode, motorSideCode: motorSideCode,
  revSplitHost: revSplitHost, ehbRev4Split: ehbRev4Split, isRevLayout: isRevLayout, huDualShaft: huDualShaft,
  ehbHalfSplitEhb: ehbHalfSplitEhb, ehbLineSplitEhb: ehbLineSplitEhb,
  /**/
  twinLineOf: twinLineOf, twinAngleOf: twinAngleOf, twinLineTag: twinLineTag, twinAngleTag: twinAngleTag,
  bevelFamRe203: bevelFamRe203,
    accessoriesFor: accessoriesFor, mountingOptions: mountingOptions, sanitizeAccessories: sanitizeAccessories, ACCESSORIES_NO_R: ACCESSORIES_NO_R,
    isInlineLayout: isInlineLayout, brakeRequired: brakeRequired, specNotes: specNotes,
    composeSpec: composeSpec, candLabel: candLabel, largerModels: largerModels, recheckModel: recheckModel,
  pickMotorOption: pickMotorOption, specialReqLines: specialReqLines, hostSpecSpecialNotes: hostSpecSpecialNotes,
  motorDrivePriceOf: motorDrivePriceOf, acMotorPriceOf: acMotorPriceOf, moneyTxt: moneyTxt,
  applyLimtecPrices: applyLimtecPrices, jackNetPriceOf: jackNetPriceOf, wormDiaOf: wormDiaOf,
  /**/
  isExMotor: jackIsExMotor,
  shaftNetPriceOf: shaftNetPriceOf, couplingNetPriceOf: couplingNetPriceOf, rsdNetPriceOf: rsdNetPriceOf,
    clientLines: clientLines
  };
})(typeof window !== 'undefined' ? window : globalThis);
